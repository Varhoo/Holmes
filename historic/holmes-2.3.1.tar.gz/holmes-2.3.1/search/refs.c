/*
 *	Sherlock Search Engine -- Processing of References
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#undef LOCAL_DEBUG
#undef DEBUG_DUMP_HEAP

#include "lib/lib.h"
#include "lib/pools.h"
#include "lib/unaligned.h"
#include "lib/heap.h"
#include "search/sherlockd.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* RHEAP is used for global searching for matching objects */

struct ref_heap_entry {
  oid_t oid;
  struct ref_chain *ref;
};

#define RHEAP_LESS(a,b) (a.oid < b.oid)
#define RHEAP_SWAP(heap,a,b,t) (t=heap[a], heap[a]=heap[b], heap[b]=t)

/* THEAP (aka results->result_heap) holds best matching documents */

#define THEAP_LESS(a,b) (a->q < b->q || a->q == b->q && a->sec_sort_key > b->sec_sort_key)
#define THEAP_SWAP(h,a,b,t) (t=h[a], h[a]=h[b], h[b]=t, h[a]->heap=a, h[b]->heap=b)

/*
 *  PHEAP is used for merging of reference chains during phrase searches.
 *  Its layout is somewhat tricky: it consists of 32-bit words, each describing
 *  a single reference chain; upper 12 bits tell the next position available
 *  in that chain, lower 20 bits index the phrase_status array containing
 *  all other information about the chain.
 */

#define PHEAP_LESS(a,b) (a < b)
#define PHEAP_SWAP(heap,a,b,t) (t=heap[a], heap[a]=heap[b], heap[b]=t)

struct phrase_status {
  u16 *refs;
  uns idx;			/* Position inside the phrase */
  uns type_mask;
};

static u32 *phrase_heap;
static struct phrase_status *phrase_status;

static void
map_refs(struct query *q)
{
  struct ref_chain *first = q->first_ref;
  uns i;
  uns n = q->last_ref - q->first_ref;
  struct mmap_request *mm = alloca(sizeof(struct mmap_request) * n);

  for (i=0; i<n; i++)
    {
      mm[i].u.req.fd = q->dbase->fd_refs;
      mm[i].u.req.start = first[i].u.file.start;
      mm[i].u.req.end = first[i].u.file.stop;
      mm[i].userdata = i;
    }
  if (mmap_regions(q, mm, n) < 0)
    {
      add_cerr("-117 Too many documents match");
      eval_err(317);
    }
  for (i=0; i<n; i++)
    {
      int j = mm[i].userdata;
      first[j].u.mem.pos = mm[i].u.map.start;
    }
}

static void
init_ref_heap(struct ref_heap_entry *rheap, struct ref_chain *chain, uns rcnt)
{
  uns i;

  for (i=0; i<rcnt; i++)
    {
      rheap[i+1].oid = GET_U32_BE16(chain[i].u.mem.pos);
      rheap[i+1].ref = &chain[i];
    }
  HEAP_INIT(struct ref_heap_entry, rheap, rcnt, RHEAP_LESS, RHEAP_SWAP);
}

static void
init_ref_words(struct query *q)
{
  uns i;

  /*
   *  Caveat: Even words not present in the boolean expression (i.e., those
   *  with ref_count==0) need to have their ref_chains initialized as near
   *  matching might access them.
   */
  for (i=0; i<q->nwords; i++)
    {
      struct word *w = &q->words[i];
      w->ref_chains = w->last_ref_chain = w->end_ref_chains = mp_alloc(q->pool, sizeof(addr_int_t) * w->ref_count);
      w->q = w->q2 = -1;
    }
}

static void
init_ref_phrases(struct query *q)
{
  uns i, j, l, max;

  max = 0;
  for (i=0; i<q->nphrases; i++)
    {
      struct phrase *p = &q->phrases[i];
      l = 0;
      for (j=0; j<p->length; j++)
	l += q->words[p->word[j]].ref_count;
      if (l > max)
	max = l;
    }
  if (!max)
    return;
  ASSERT(max <= 65536);
  DBG("Allocating phrase heap for %d entries", max);
  phrase_heap = ((u32*)mp_alloc(q->pool, max * sizeof(u32 *))) - 1;
  phrase_status = mp_alloc(q->pool, max * sizeof(struct phrase_status));
}

static inline void do_record_match(int wq, uns wpos, uns width, uns *matches)
{
  uns i, x, y, z;
  x = ~wpos & 0xfff;
  if (!x)
    return;
  x |= ((wq/2 + 32768) << 16) | (width << 12);
  for (i=0; i < HARD_MAX_NOTES; i++)
    {
      if (matches[i] < x)
	{
	  z = x;
	  while (i < HARD_MAX_NOTES)
	    {
	      y = matches[i];
	      matches[i++] = z;
	      if (!((y ^ x) & 0xffff))
		break;
	      z = y;
	    }
	  break;
	}
      else if (!((matches[i] ^ x) & 0xffff))
	break;
    }
}

static inline int
do_record_phrase_match(struct phrase *p, int q, uns start, uns end, uns *matches)
{
  uns width;

  q += p->weight;
  end += p->width[p->length-1];
  if (end >= 0xfff)
    return q/2;
  q = MIN(32767, q);
  q = MAX(-32767, q);
  width = MIN(15, end - start);
  DBG("\tBest: q=%d, start=%d, width=%d", q, start, width);
  do_record_match(q, start, width, matches);
  return q;
}

static int
do_phrase(struct query *q, struct phrase *p, uns *matches)
{
#define INFTY 1000000
  u32 *heap = phrase_heap;
  struct phrase_status *stat = phrase_status;
  uns hcnt = 0;
  int wpos[MAX_PHRASE_LEN], wwei[MAX_PHRASE_LEN];
  uns last_idx = p->length - 1;
  int bestq = prox_limit-1, bestq2 = bestq, qq, wei, wrel;
  int *weight_array = q->dbase->word_weights;
  uns beststart = ~0U, bestend = ~0U, beststart2 = ~0U, bestend2 = ~0U;
  uns pos, type, idx;

  for (idx=0; idx<p->length; idx++)
    {
      struct word *w = &q->words[p->word[idx]];
      addr_int_t *r;
      for (r=w->ref_chains; r<w->end_ref_chains; r++)
	{
	  u16 *refs = (u16 *)(*r & ~(addr_int_t)1);
	  if (*refs & 0xf000)
	  {
	    stat[hcnt].refs = refs;
	    stat[hcnt].idx = idx;
	    stat[hcnt].type_mask = w->type_mask;
	    if (*r & 1)
	      stat[hcnt].type_mask &= WORD_TYPES_NO_AUTO_ACCENT;
	    heap[hcnt+1] = (*refs << 20) | hcnt;
	    hcnt++;
	  }
	}
      wpos[idx] = 0;
      wwei[idx] = -INFTY;
    }
  HEAP_INIT(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
  DBG("Phrase: initialized heap with %d entries", hcnt);

  while (hcnt)
    {
      /* Fetch next word and adjust heap entry for the corresponding chain */
      struct phrase_status *s = &stat[heap[1] & 0xffff];
      pos = *s->refs & 0xfff;
      type = *s->refs >> 12;
      s->refs++;
      if (*s->refs & 0xf000)
	{
	  heap[1] = (heap[1] & 0xffff) | (*s->refs << 20);
	  HEAP_INCREASE(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
	}
      else
	HEAP_DELMIN(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
      idx = s->idx;

      /* Match word class */
      DBG("\t\t%04d type=%x idx=%d", pos, type, idx);
      if (!(s->type_mask & (1 << type)))
	continue;

      /* Try to extend the current part of the phrase */
      wei = weight_array[type];
      wrel = wwei[idx];
      if (pos < 4095)
	{
	  if (p->prox_map & (1 << idx))
	    {
	      if (idx)
		wei += wwei[idx-1] - prox_penalty*(uns)(pos - (wpos[idx-1] + p->relpos[idx]));
	      wrel = wwei[idx] - prox_penalty*(uns)(pos - (wpos[idx] + p->width[idx]));
	    }
	  else
	    {
	      wrel = -INFTY;
	      if (idx)
		{
		  if (pos == wpos[idx-1] + p->relpos[idx])
		    wei += wwei[idx-1];
		  else
		    wei = -INFTY;
		}
	    }
	}
      else	/* When we are at position 4095, try to at least guess a match */
	{
	  if (beststart < 4095)		/* Don't override real matches by guessed ones */
	    break;
	  if (p->prox_map & (1 << idx))
	    {
	      if (idx && wpos[idx-1] < 4095)
		wei += wwei[idx-1] - prox_penalty*(uns)(4095 - (wpos[idx-1] + p->relpos[idx]));
	      if (wpos[idx] < 4095)
		wrel -= prox_penalty*(uns)(4095 - (wpos[idx] + p->width[idx]));
	    }
	  else
	    {
	      wrel = -INFTY;
	      if (idx)
		{
		  if (wpos[idx-1] + p->relpos[idx] >= 4095)
		    wei += wwei[idx-1];
		  else
		    wei = -INFTY;
		}
	    }
	}
      if (wrel <= wei && wei >= -INFTY)
	{
	  wpos[idx] = pos;
	  wwei[idx] = wei;
	}
      DBG("\t\t\t-> pos=%d wei=%d", wpos[idx], wwei[idx]);

      /* If it was the last word of the phrase, record the weight */
      if (idx == last_idx && wwei[idx] > -INFTY)
	{
	  qq = wwei[idx];
	  if (qq > bestq)
	    {
	      bestq2 = bestq;
	      beststart2 = beststart;
	      bestend2 = bestend;
	      bestq = qq;
	      beststart = wpos[0];
	      bestend = pos;
	    }
	  else if (qq > bestq2)
	    {
	      bestq2 = qq;
	      beststart2 = wpos[0];
	      bestend2 = pos;
	    }
	}
    }

  if (beststart == ~0U)
    return -1;
  qq = do_record_phrase_match(p, bestq, beststart, bestend, matches);
  if (beststart2 != ~0U)
    do_record_phrase_match(p, bestq2, beststart2, bestend2, matches);
  p->matches++;
  return qq;
#undef INFTY
}

static int
do_near(struct query *q, struct phrase *p, uns *matches)
{
  /* Merging of word chains */
  u32 *heap = phrase_heap;
  struct phrase_status *stat = phrase_status;
  uns hcnt = 0;
  uns pos, type, idx;
  uns type_mask[MAX_PHRASE_LEN];
  int word_weight[MAX_PHRASE_LEN];
  int *weight_array = q->dbase->word_weights;

  /* Currently examined word cluster: a circular buffer */
  uns cr = 0, cw = 0;			/* Read and write index */
  struct {
    uns idx;				/* Word index */
    int q;				/* Q of the word itself */
    int joiner;				/* Weight of space before the word */
    uns pos;				/* Position in the text */
  } cluster[MAX_PHRASE_LEN];
  uns cluster_word_mask = 0;		/* Which words are present in the cluster */
  int running_weight = 0;		/* Total weight of the cluster */
  int running_q = 0;			/* Total Q of the cluster */
  uns last_pos = -10000;		/* Position of previous word */
  uns last_idx = -10000;		/* Which word it was */
  int joiner;
  uns ci;

  /* Current maxima */
  int bestw = -1;
  int bestq = -1, bestq2 = -1;
  uns beststart = ~0U, bestwidth = ~0U;
  uns beststart2 = ~0U, bestwidth2 = ~0U;
  uns this_width;
  int qq;

  /*
   *  How does the near matcher work:
   *
   *  (1) Assign each position in the document near points which is either:
   *	     near_bonus_word for matched words
   *	     + near_bonus_connect more if previous word is also matched
   *	  or -near_penalty_gap for no match.
   *  (2) Among intervals containing each word at most once, find the one
   *      with maximum Q (that is, Q of words inside according to standard
   *      rules + the near points gathered in this interval) and record
   *      it as a normal match covering the whole interval.
   *  (3) Do the same for the second best interval.
   *
   *  The code below does all these steps in parallel and returns maximum number
   *  of near points gained which is then added to the overall Q of the page
   *  (Q's of word occurences are already accounted for).
   */

  for (idx=0; idx<p->length; idx++)
    {
      struct word *w = &q->words[p->word[idx]];
      addr_int_t *r;
      for (r=w->ref_chains; r<w->end_ref_chains; r++)
	{
	  u16 *refs = (u16 *)(*r & ~(addr_int_t)1);
	  if (*refs & 0xf000)
	  {
	    stat[hcnt].refs = refs;
	    stat[hcnt].idx = idx;
	    stat[hcnt].type_mask = w->type_mask;
	    if (*r & 1)
	      stat[hcnt].type_mask &= WORD_TYPES_NO_AUTO_ACCENT;
	    heap[hcnt+1] = (*refs << 20) | hcnt;
	    hcnt++;
	  }
	}
      type_mask[idx] = w->type_mask;
      word_weight[idx] = w->weight;
    }
  HEAP_INIT(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
  DBG("Near: initialized heap with %d entries", hcnt);

  while (hcnt)
    {
      /* Fetch next word and adjust heap entry for the corresponding chain */
      struct phrase_status *s = &stat[heap[1] & 0xffff];
      pos = *s->refs & 0xfff;
      if (pos >= 4095)
	break;
      type = *s->refs >> 12;
      s->refs++;
      if (*s->refs & 0xf000)
	{
	  heap[1] = (heap[1] & 0xffff) | (*s->refs << 20);
	  HEAP_INCREASE(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
	}
      else
	HEAP_DELMIN(u32, heap, hcnt, PHEAP_LESS, PHEAP_SWAP);
      idx = s->idx;

      /* Match word class */
      DBG("\t\t%04d type=%x idx=%d", pos, type, idx);
      if (!(s->type_mask & (1 << type)))
	continue;

      /* Calculate gap weight and adjust the running sum */
      if (pos <= last_pos)
	joiner = 0;
      else if (pos - last_pos > 100)
	joiner = -1000000;
      else
	joiner = (last_pos - pos - 1) * near_penalty_gap;
      if (last_idx + 1 == idx)
	joiner += near_bonus_connect;
      running_weight += joiner;
      if (running_weight <= 0)
	{
	  cr = cw = 0;
	  running_weight = running_q = 0;
	  cluster_word_mask = 0;
	}

      /* Check for duplicate words */
      if (cluster_word_mask & (1 << idx))
	{
	  /* Remove all words until first occurence of the offending one */
	  while (cluster[cr].idx != idx)
	    cr = (cr+1) % MAX_PHRASE_LEN;
	  cr = (cr+1) % MAX_PHRASE_LEN;
	  /* Recalculate weight and word mask */
	  running_weight = running_q = 0;
	  cluster_word_mask = 0;
	  for (ci = cr; ci != cw; ci = (ci+1) % MAX_PHRASE_LEN)
	    {
	      if (ci != cr)
		{
		  running_weight += cluster[ci].joiner;
		  if (running_weight < 0)
		    {
		      cr = ci;
		      running_weight = running_q = 0;
		      cluster_word_mask = 0;
		    }
		}
	      running_weight += near_bonus_word;
	      running_q += cluster[ci].q;
	      cluster_word_mask |= (1 << cluster[ci].idx);
	    }
	  DBG("\t\t\t## rw=%d rq=%d cr=%d cw=%d words=%x", running_weight, running_q, cr, cw, cluster_word_mask);
	}

      /* Add the new word */
      cluster[cw].pos = pos;
      cluster[cw].idx = idx;
      cluster[cw].joiner = joiner;
      cluster[cw].q = word_weight[idx] + weight_array[type];
      running_q += cluster[cw].q;
      cluster_word_mask |= (1 << idx);
      cw = (cw+1) % MAX_PHRASE_LEN;

      /* Update current maxima */
      qq = running_q + running_weight;
      if (qq > bestq2)
	{
	  this_width = MIN(pos - cluster[cr].pos + 1, 15);
	  if (qq > bestq)
	    {
	      if (beststart != cluster[cr].pos)
		{
		  bestq2 = bestq;
		  beststart2 = beststart;
		  bestwidth2 = bestwidth;
		}
	      bestq = qq;
	      bestw = running_weight;
	      beststart = cluster[cr].pos;
	      bestwidth = this_width;
	    }
	  else
	    {
	      bestq2 = qq;
	      beststart2 = cluster[cr].pos;
	      bestwidth2 = this_width;
	    }
	}

      /* And go further */
      running_weight += near_bonus_word;
      last_pos = pos + p->width[idx];
      last_idx = idx;
      DBG("\t\t\t-> rw=%d rq=%d cr=%d cw=%d words=%x (best: %d@%d+%d %d@%d+%d, bestw: %d)",
	  running_weight, running_q, cr, cw, cluster_word_mask,
	  bestq, beststart, bestwidth, bestq2, beststart2, bestwidth2, bestw);
    }

  DBG("\t\tNear matcher score: %d", bestw);
  if (bestw <= 0)
    return 0;
  do_record_match(bestq, beststart, bestwidth, matches);
  if (beststart2 != ~0U)
    do_record_match(bestq2, beststart2, bestwidth2, matches);
  p->matches++;
  return bestw;
}

static int
check_user_attrs(struct query *q UNUSED, struct card_attr *attrs UNUSED)
{
  if (attrs->age < q->age_min || attrs->age > q->age_max)
    return 0;
#define INT_ATTR(id,keywd,gf,pf)				\
  {								\
    u32 a = gf(attrs);						\
    if (a < q->id##_min || a > q->id##_max)			\
      return 0;							\
  }
#define SMALL_SET_ATTR(id,keywd,gf,pf)				\
  {								\
    uns a = gf(attrs);						\
    if (!(q->id##_set & (1 << a)))				\
      return 0;							\
  }
  CUSTOM_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
  return 1;
}

static inline void
get_sec_sort_key(struct result_note *note, struct query *q, struct card_attr *attrs)
{
  u32 key = 0;
  switch (q->custom_sorting)
    {
    case PARAM_CARDID:
      key = note->oid;
      break;
    case PARAM_SITE:
      key = 0;
      break;
    case PARAM_AGE:
      key = attrs->age;
      break;
#define INT_ATTR(id,keywd,gf,pf)			\
    case OFFSETOF(struct query, id##_min):		\
      key = gf(attrs);					\
      break;
#define SMALL_SET_ATTR(id,keywd,gf,pf)			\
    case OFFSETOF(struct query, id##_set):		\
      key = gf(attrs);					\
      break;
  CUSTOM_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
    }
  note->sec_sort_key = key ^ q->custom_sort_reverse;
}

static void
do_refs_card(struct query *q, struct card_attr *attrs, oid_t oid)
{
  struct word *word;
  uns i;
  uns bool = 0;
  int qq = 0;
  struct results *res = q->results;
  struct result_note *note = res->free_note;
  uns matches[HARD_MAX_NOTES];		/* ((q+OFFSET) << 16) | (width << 12) | (pos ^ 0xfff) */
  struct result_note **theap = res->result_heap;
  struct card_attr *obj_attrs = &attrs[oid];

  /* Gather boolean expression bits and word matches and also clean up word status variables */
  bzero(matches, sizeof(matches));
  for (word=q->bool_first_word; word; word=word->bool_next)
    {
      if (word->q >= 0)
	{
	  word->doc_count++;
	  if (word->is_outer)
	    {
	      qq += word->q + word->weight;
	      do_record_match(word->q + word->weight, word->pos, word->width, matches);
	      if (word->q2 >= 0)
		do_record_match(word->q2 + word->weight, word->pos2, word->width, matches);
	    }
	  word->q = -1;
	  word->q2 = -1;
	bool |= 1 << word->boolean_id;
      }
      /* Needs to be done even for empty lists, because do_near() might access them */
      word->end_ref_chains = word->last_ref_chain;
      word->last_ref_chain = word->ref_chains;
    }

  /* Check card attributes */
  if (!check_user_attrs(q, obj_attrs))
    {
      DBG("!user");
      return;
    }

  /* Process phrases */
  for (i=0; i<q->nphrases; i++)
    {
      struct phrase *p = &q->phrases[i];
      int pq;
      if (p->is_near)
	{	
	  u32 have_mask = p->word_mask & bool;
	  DBG("Matching near #%d", i);
	  /* This test is tricky. You are not expected to understand it. */
	  if (!(have_mask & (have_mask-1)))
	    DBG("\tToo few words (have %04x want %04x)", bool, p->word_mask);
	  else
	    qq += do_near(q, p, matches);
	}
      else
	{
	  DBG("Matching phrase #%d", i);
	  if ((p->word_mask & bool) != p->word_mask)
	    DBG("\tMissing words (have %04x need %04x)", bool, p->word_mask);
	  else if ((pq = do_phrase(q, p, matches)) >= 0)
	    {
	      qq += pq;
	      bool |= 1 << p->boolean_id;
	    }
	}
    }

  /* Check boolean expression */
  if (!(bool_map[bool >> 5] & (1 << (bool & 31))))
    {
      DBG("!bool (%04x)", bool);
      return;
    }

  /* Record the match */
  qq += obj_attrs->weight * doc_weight_scale;
  DBG("Matched OID %08x with Q=%d", oid, qq);
  q->matching_docs++;
  note->oid = oid;
  note->q = qq;
  get_sec_sort_key(note, q, obj_attrs);

    {
      if (res->nresults >= num_matches)
	{
	  if (qq < theap[1]->q)		/* Q too low -> throw away */
	    return;
	  res->free_note = theap[1];
	  HEAP_DELMIN(struct result_note *, theap, res->nresults, THEAP_LESS, THEAP_SWAP);
	}
      else
	res->free_note = res->first_note++;
    }
  theap[++res->nresults] = note;
  note->heap = res->nresults;
  HEAP_INSERT(struct result_note *, theap, res->nresults, THEAP_LESS, THEAP_SWAP);

  /* Copy match array and restrict entries to lower 16 bits */
  for (i=0; i<HARD_MAX_NOTES; i++)
    note->best[i] = matches[i];
}

static void
do_process_refs(struct query *q, struct ref_heap_entry *rheap, uns rcnt)
{
  oid_t oid, next;
  struct database *dbase = q->dbase;
  oid_t oid_offset = dbase->first_id;
  struct card_attr *attrs = dbase->card_attrs;
  struct card_attr *offset_attrs = attrs - oid_offset;
  struct word *word, *words = q->words;
  struct ref_chain *ref;
  uns card_flags, type, pos, pos2, type_mask;
  int weight, weight2, *weight_array;
  u16 *current;
  addr_int_t chain_start;	/* bit 0 tells to match only WORD_TYPES_NO_AUTO_ACCENT */

  pos = pos2 = 0;
  while (rcnt > 0)
    {
      oid = rheap[1].oid;
      DBG("OID %x", oid);
      card_flags = attrs[oid].flags;
      while (rcnt > 0 && rheap[1].oid == oid)
	{
	  ref = rheap[1].ref;
	  current = ref->u.mem.pos + 2;
	  chain_start = (addr_int_t) current;
	  word = &words[ref->index];
	  weight = -1;
	  weight2 = -1;
	  weight_array = word->is_string ? dbase->string_weights : dbase->word_weights;
	  type_mask = word->type_mask;
	  if (ref->noaccent_only && (card_flags & CARD_FLAG_ACCENTED))
	    {
	      type_mask &= WORD_TYPES_NO_AUTO_ACCENT;
	      chain_start |= 1;
	    }
	  while (type = ((*current & 0xf000) >> 12))
	    {
	      DBG("\t> %04x", *current);
	      if (type_mask & (1 << type))
		{
		  if (weight < weight_array[type])
		    {
		      weight2 = weight;
		      pos2 = pos;
		      weight = weight_array[type];
		      pos = *current;
		    }
		  else if (weight2 < weight_array[type])
		    {
		      weight2 = weight_array[type];
		      pos2 = *current;
		    }
		}
	      current++;
	    }
	  next = GET_U32_BE16(current);
	  DBG("... chain %d (word %d, weight %d/%d, pos %04x/%04d) next %x", ref - q->first_ref, ref->index, weight, weight2, pos, pos2, next);
	  if (next)
	    {
	      ref->u.mem.pos = current;
	      ASSERT(rheap[1].oid < next);
	      rheap[1].oid = next;
	      HEAP_INCREASE(struct ref_heap_entry, rheap, rcnt, RHEAP_LESS, RHEAP_SWAP);
	    }
	  else
	    HEAP_DELMIN(struct ref_heap_entry, rheap, rcnt, RHEAP_LESS, RHEAP_SWAP);
	  if (weight >= 0)
	    {
	      *word->last_ref_chain++ = chain_start;
	      if (word->q < weight)
		{
		  word->q2 = word->q;
		  word->q = weight;
		  word->pos2 = word->pos;
		  word->pos = pos;
		}
	      if (word->q2 < weight2)
		{
		  word->q2 = weight2;
		  word->pos2 = pos2;
		}
	    }
	}
      do_refs_card(q, offset_attrs, oid + oid_offset);
    }
}

void
process_refs(struct query *q)
{
  uns rcnt = q->last_ref - q->first_ref;
  struct ref_heap_entry rheap[rcnt+1];

  profiler_switch(&prof_reff);
  map_refs(q);
  profiler_switch(&prof_refs);
  init_ref_heap(rheap, q->first_ref, rcnt);
  init_ref_words(q);
  init_ref_phrases(q);
  do_process_refs(q, rheap, rcnt);
}

void
refs_init(void)
{
}

void
query_init_refs(struct query *q)
{
  struct results *r = q->results;

  r->result_heap = mp_alloc(r->pool, sizeof(struct result_note *) * (num_matches + 1));
  r->first_note = mp_alloc(r->pool, sizeof(struct result_note) * (num_matches + 1));
  r->free_note = r->first_note++;
}

void
query_finish_refs(struct query *q)
{
  struct results *r = q->results;
  uns num = r->nresults;

  /* Heap-sort the entries (we misuse HEAP_DELMIN and expect it moves the deleted item at the end) */
  while (num)
    HEAP_DELMIN(struct result_note *, r->result_heap, num, THEAP_LESS, THEAP_SWAP);
  add_cr("N%d", r->nresults);

#ifdef DEBUG_DUMP_HEAP
  {
    uns i, j;
    byte *x, buf[256];
    log(L_DEBUG, "Sorted results:");
    for (i=1; i<=r->nresults; i++)
      {
	struct result_note *n = r->result_heap[i];
	x = buf + sprintf(buf, "%3d %08x %6d :", i, n->oid, n->q);
	for (j=0; j<HARD_MAX_NOTES && n->best[j]; j++)
	  x += sprintf(x, " %04x", n->best[j] ^ 0xfff);
	log(L_DEBUG, buf);
      }
  }
#endif
}
