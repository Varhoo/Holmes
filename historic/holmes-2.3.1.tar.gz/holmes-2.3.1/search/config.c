/*
 *	Sherlock Search Engine -- Configuration
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/chartype.h"
#include "lib/ipaccess.h"
#include "search/sherlockd.h"

#include <string.h>
#include <stdlib.h>

byte *log_name;
uns log_incoming;
uns log_rejected;
uns log_requests;
uns log_replies;
uns port = 4444;
uns listen_queue = 16;
uns connection_timeout = 60;
byte *control_password = "";
struct database *databases;
uns num_matches = 100;
uns cache_size = 1;
uns max_output_matches = ~0;
uns max_words;
uns max_phrases;
uns max_bools;
uns max_word_matches;
uns global_accent_mode;
uns max_wildcard_zone = ~0;
uns min_wildcard_prefix_len;
uns global_allow_approx;
uns global_context_chars;
uns global_title_chars;
uns global_site_max;
uns global_url_max = 0x7fffffff;
uns global_redirect_url_max = 0x7fffffff;
uns global_partial_answers;
uns word_weights[16];
uns string_weights[16];
uns doc_weight_scale = 1;
uns word_bonus;
uns default_word_types = 0xffff;
uns global_debug;
uns mem_map_zone_size = 16;
uns mem_map_elide_gaps = 16384;
uns mem_map_prefetch = 1;
uns prox_penalty;
uns prox_limit;
uns query_watchdog;
uns global_sorting;
uns global_sort_reverse;
uns magic_complexes;
uns magic_merge_words;
uns magic_merge_classes;
uns magic_near;
uns near_bonus_word;
uns near_penalty_gap;
uns near_bonus_connect;
struct ipaccess_list *access_list;

static struct database *current_db;

static byte *
cf_access(struct cfitem *c, byte *b)
{
  return ipaccess_parse(access_list, b, (c->name[0] == 'A'));
}

static byte *
cf_database(struct cfitem *a UNUSED, byte *c)
{
  struct database *d = cfg_malloc(sizeof(struct database));
  struct database *f;
  byte *fields[5];

  if (wordsplit(c, fields, 5) != 5)
    return "Invalid database definition";
  for (f=databases; f; f=f->next)
    if (!strcmp(f->name, fields[0]))
      return "Database of this name already defined";
  if (current_db)
    current_db->next = d;
  else
    databases = d;
  bzero(d, sizeof(*d));
  current_db = d;
  d->name = fields[0];
  d->fn_params = fields[1];
  d->fn_cards = fields[2];
  d->fn_card_attrs = fields[3];
  d->fn_references = fields[4];
  return NULL;
}

static byte *
cf_word_idx(struct cfitem *a UNUSED, byte *c)
{
  byte *fields[1];

  if (!current_db)
    return "No current database";
  if (wordsplit(c, fields, 1) != 1)
    return "Invalid word index definition";
  current_db->fn_lexicon = fields[0];
  return NULL;
}

static byte *
cf_string_idx(struct cfitem *a UNUSED, byte *c)
{
  byte *fields[2];

  if (!current_db)
    return "No current database";
  if (wordsplit(c, fields, 2) != 2)
    return "Invalid string index definition";
  current_db->fn_string_map = fields[0];
  current_db->fn_string_hash = fields[1];
  return NULL;
}

static byte *
cf_weights(struct cfitem *a, byte *c)
{
  byte *fields[16];
  int i;

  if (!current_db)
    return "No current database";
  if (wordsplit(c, fields, 16) != 16)
    return "Invalid weight definition";
  for (i=0; i<16; i++)
    (a->name[0]=='W' ? current_db->word_weights : current_db->string_weights)[i] = atol(fields[i]);
  return NULL;
}

static byte *
cf_default_sort_by(struct cfitem *a UNUSED, byte *c)
{
  int x;

  if (*c == '-')
    {
      global_sort_reverse = ~0U;
      c++;
    }
  else
    global_sort_reverse = 0;
  if ((x = lookup_custom_attr(c)) < 0)
    return "Unknown attribute";
  global_sorting = x;
  return NULL;
}

static struct cfitem ss_config[] = {
  { "Search",		CT_SECTION,	NULL },
  { "LogFile",		CT_STRING,	&log_name },
  { "LogIncoming",	CT_INT,		&log_incoming },
  { "LogRejected",	CT_INT,		&log_rejected },
  { "LogRequests",	CT_INT,		&log_requests },
  { "LogReplies",	CT_INT,		&log_replies },
  { "Port",		CT_INT,		&port },
  { "ListenQueue",	CT_INT,		&listen_queue },
  { "Allow",		CT_FUNCTION,	cf_access },
  { "Deny",		CT_FUNCTION,	cf_access },
  { "ConnTimeOut",	CT_INT,		&connection_timeout },
  { "ControlPassword",	CT_STRING,	&control_password },
  { "Database",		CT_FUNCTION,	cf_database },
  { "WordIndex",	CT_FUNCTION,	cf_word_idx },
  { "StringIndex",	CT_FUNCTION,	cf_string_idx },
  { "WordWeights",	CT_FUNCTION,	cf_weights },
  { "StringWeights",	CT_FUNCTION,	cf_weights },
  { "CacheSize",	CT_INT,		&cache_size },
  { "NumMatches",	CT_INT,		&num_matches },
  { "MaxOutputObjects",	CT_INT,		&max_output_matches },
  { "MaxWords",		CT_INT,		&max_words },
  { "MaxPhrases",	CT_INT,		&max_phrases },
  { "MaxBools",		CT_INT,		&max_bools },
  { "MaxWordMatches",	CT_INT,		&max_word_matches },
  { "AccentMode",	CT_INT,		&global_accent_mode },
  { "MaxWildcardZone",	CT_INT,		&max_wildcard_zone },
  { "MinWildcardPrefix",CT_INT,		&min_wildcard_prefix_len },
  { "AllowApprox",	CT_INT,		&global_allow_approx },
  { "DocWeightScale",	CT_INT,		&doc_weight_scale },
  { "ContextChars",	CT_INT,		&global_context_chars },
  { "TitleChars",	CT_INT,		&global_title_chars },
  { "SiteMax",		CT_INT,		&global_site_max },
  { "URLMax",		CT_INT,		&global_url_max },
  { "RedirectURLMax",	CT_INT,		&global_redirect_url_max },
  { "PartialAnswers",	CT_INT,		&global_partial_answers },
  { "DefaultWordTypes",	CT_INT,		&default_word_types },
  { "Debug",		CT_INT,		&global_debug },
  { "WordBonus",	CT_INT,		&word_bonus },
  { "MemMapZone",	CT_INT,		&mem_map_zone_size },
  { "MemMapElideGaps",	CT_INT,		&mem_map_elide_gaps },
  { "MemMapPrefetch",	CT_INT,		&mem_map_prefetch },
  { "ProxPenalty",	CT_INT,		&prox_penalty },
  { "ProxLimit",	CT_INT,		&prox_limit },
  { "QueryWatchdog",	CT_INT,		&query_watchdog },
  { "DefaultSortBy",	CT_FUNCTION,	cf_default_sort_by },
  { "MagicComplexes",	CT_INT,		&magic_complexes },
  { "MagicMergeWords",	CT_INT,		&magic_merge_words },
  { "MagicMergeClasses",CT_INT,		&magic_merge_classes },
  { "MagicNear",	CT_INT,		&magic_near },
  { "NearBonusWord",	CT_INT,		&near_bonus_word },
  { "NearPenaltyGap",	CT_INT,		&near_penalty_gap },
  { "NearBonusConnect", CT_INT,	&near_bonus_connect },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR ss_conf_init(void)
{
  access_list = ipaccess_init();
  cf_register(ss_config);
}
