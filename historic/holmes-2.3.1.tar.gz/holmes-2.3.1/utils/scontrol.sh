#!/bin/bash
#
#  Sherlock Search Server Control Script
#  (c) 2002 Martin Mares <mj@ucw.cz>
#

set -e

if [ $UID = 0 ] ; then
	cd ${SH_HOME:-~sherlock/run}
	exec su ${SH_USER:-sherlock} -c "exec bin/scontrol $@"
else
	if [ -n "$SH_HOME" ] ; then cd $SH_HOME ; fi
fi
if ! [ -f bin/sherlockd -a -f cf/sherlock ] ; then
	echo >&2 "scontrol: Cannot find Sherlock runtime directory"
	exit 1
fi

eval `bin/config Search Port=8192 '*'`
eval `bin/config SKeeper TestRetry=10 TestWait=3 CrashMail RotateLogs CrashWaitThreshold CrashWaitCeiling DaemonPIDFile KeeperPIDFile @TestQuery SwapLock SwapLockTimeout=10`

function log
{
	bin/logger scontrol I "$1"
}

function errlog
{
	bin/logger scontrol E "$1"
}

case "$1" in
	start)		[ -f $CF_KeeperPIDFile ] && echo >&2 "WARNING: skeeper.pid already present!"
			if [ -n "$CF_CrashWaitThreshold" ] ; then
				echo -n "Starting sherlockd with skeeper..."
				setsid </dev/null >/dev/null 2>&1 bin/skeeper &
				echo $! >$CF_KeeperPIDFile
			else
				echo -n "Starting sherlockd..."
				setsid </dev/null >/dev/null 2>&1 bin/sherlockd &
				echo $! >$CF_DaemonPIDFile
			fi
			RETRY=$CF_TestRetry
			echo -n "."
			while ! bin/query --host localhost --port $CF_Port --silent --control '"databases"' >/dev/null 2>&1 ; do
				if [ $RETRY = 0 ] ; then
					echo " TIMED OUT."
					bin/scontrol stop
					exit 1
				fi
				RETRY=$(($RETRY-1))
				echo -n "."
				sleep $CF_TestWait
			done
			echo " done."
			;;
	stop)		echo -n "Stopping sherlockd... "
			[ -f $CF_KeeperPIDFile ] && kill 2>/dev/null -TERM `cat $CF_KeeperPIDFile` || echo -n "(no skeeper running) "
			[ -f $CF_DaemonPIDFile ] && kill 2>/dev/null -TERM `cat $CF_DaemonPIDFile` || echo -n "(no sherlockd running) "
			rm -f $CF_KeeperPIDFile $CF_DaemonPIDFile
			echo "done."
			;;
	restart)	bin/scontrol stop
			bin/scontrol start
			;;
	cron)		if [ -n "$CF_RotateLogs" ] ; then eval $CF_RotateLogs ; fi
			;;
	test)		[ -z "$CF_TestQuery" ] && exit 0
			echo -n "Testing sherlockd..."
			for test in "${CF_TestQuery[@]}" ; do
				echo -n "."
				MINREPLIES=`echo $test | cut -d ' ' -f 1`
				QUERY=`echo $test | cut -d ' ' -f 2-`
				T=tmp/test-$$
				if ! bin/query --host localhost --port $CF_Port --noheader --nofooter "$QUERY" >$T ; then
					rm $T
					echo "FAILED."
					errlog "Query '$QUERY' failed."
					exit 1
				fi
				c=`grep -c "^B" $T || true`
				rm $T
				if [ $c -lt $MINREPLIES ] ; then
					echo "FAILED."
					errlog "Query '$QUERY' produced only $c replies ($MINREPLIES required)."
					exit 1
				fi
			done
			echo " done."
			;;
	swap)		INDEX=${2:-index}
			log "Swapping $INDEX"
			if [ ! -f $INDEX.new/parameters ] ; then
				log "Nothing to swap"
				exit 0
			fi
			echo -n "Acquiring swap lock..."
			RETRY=$CF_SwapLockTimeout
			while ! mkdir $CF_SwapLock 2>/dev/null ; do
				if [ $RETRY = 0 ] ; then
					echo " TIMED OUT."
					exit 1
				fi
				RETRY=$(($RETRY-1))
				echo -n "."
				sleep 1
			done
			echo " done."
			bin/scontrol stop
			rm -rf $INDEX.old
			if [ -f $INDEX/parameters ] ; then
				mv $INDEX $INDEX.old
			else
				rm -rf $INDEX
			fi
			mv $INDEX.new $INDEX
			if bin/scontrol start ; then
				if bin/scontrol test ; then
					rmdir $CF_SwapLock
					exit 0
				fi
				bin/scontrol stop
			fi
			if [ -d $INDEX.old ] ; then
				log "Falling back to old $INDEX"
				mv $INDEX $INDEX.new
				mv $INDEX.old $INDEX
				if bin/scontrol start ; then
					log "Fallback succeeded"
				else
					errlog "Fallback failed"
				fi
			else
				errlog "No old index to fall back to"
			fi
			rmdir $CF_SwapLock
			exit 1
			;;
	*)		echo >&2 "Usage: [SH_USER=<user>] [SH_HOME=<homedir>] scontrol (start|stop|restart|cron|test|swap [<index>])"
			exit 1
			;;
esac
