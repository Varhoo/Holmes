/*
 * Simple charset to charset convertor
 *
 * Copyright 1998 Pavel Machek, distribute under GPL
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "charset/charconv.h"

struct conv_context ctxt;
typedef unsigned char byte;

static void
die( char *s )
{
fprintf( stderr, s );
exit(1);
}

static void
convert_and_write(struct conv_context *cc, byte *from, int len)
{
char buf[4096];
int flags;

cc->source = from;
cc->source_end = from + len;
cc->dest = cc->dest_start = buf;
cc->dest_end = buf + sizeof(buf);
do
  {
    flags = conv_run(cc);
    if (flags & (CONV_SOURCE_END | CONV_DEST_END))
      {
	fwrite(cc->dest_start, 1, cc->dest - cc->dest_start, stdout);
	cc->dest = buf;
      }
  }
while (! (flags & CONV_SOURCE_END));
}

static void
convert( void )
{
char inbuf[10245];
int n;

while( (n = read( 0, inbuf, 10240 )) > 0 )
  convert_and_write(&ctxt, inbuf, n);
if (n<0)
  die( "Read error.\n" );
}

int
main( int argc, char *argv[] )
{
conv_init( &ctxt );
if (argc != 3)
  die( "cs2cs name name\n" );

{
  int ch_from, ch_to;
  ch_from = find_charset_by_name(argv[1]);
  ch_to = find_charset_by_name(argv[2]);
  if ((ch_from == -1) || (ch_to == -1))
    die( "Unrecognized name of charset.\n" );
    
  conv_set_charset( &ctxt, ch_from, ch_to );
}

convert();
return 0;
}
