#!/bin/bash
#	Handy dumper of cards according to their OID's
#	(c) 2002, Robert Spalek <robert@ucw.cz>

./bin/idxdump -f index/card-attrs -d $* \
| grep ^[^I] \
| while read oid cardid therest
do
	echo "#oid=0x$oid cardid=0x$cardid"
	./bin/idxdump -f index/cards -c $cardid \
	| ./bin/objdump
done \
| less -r
