#!/bin/bash
# Watson -- an elementary monitoring system for Sherlock Holmes (run daily from cron)
# (c) 2002 Martin Mares <mj@ucw.cz>

# Configurable parameters:
# List of search servers (include localhost for a local search server)
SS="sherlock0 sherlock2"
PATH="$PATH:/opt/bin"

# Clean up graph directory
rm -rf log/graph
mkdir -p log/graph

# Download yesterday's logs from search servers
rm -rf log/search
mkdir log/search
d=`date -d yesterday '+%Y%m%d'`
for s in $SS ; do
	echo "Fetching search server log $d from $s"
	dest=log/search/$s
	if [ "$s" == localhost ] ; then
		if [ -f log/sherlockd-$d ] ; then
			ln -s log/sherlockd-$d $dest
		else
			>$dest
		fi
	else
		ssh -C $s "cd run/log ; if [ -f sherlockd-$d ] ; then cat sherlockd-$d ; fi" >$dest
	fi
done

# Here we probably should grep the ss logs for errors

# Plot graphs of search server load
for s in $SS ; do
	echo "Plotting load graph for $s"
	bin/stat-sherlockd $s <log/search/$s
done

# Plot gatherer statistics
echo "Plotting gatherer statistics"
bin/plot-log --suffix short --join-all="[0-9].*" --max-age=4 --quants 600 --force
bin/plot-log --suffix long --join-all="[0-9].*" --max-age=28 --quants 3600 --force
