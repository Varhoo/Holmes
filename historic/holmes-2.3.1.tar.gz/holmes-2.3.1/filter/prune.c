/*
 *	Sherlock Filter Engine --- pruning a filter
 *
 *	(c) 2002 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/pools.h"
#include "filter/filter.h"
#include "filter/parse.tab.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

static int prune_switch_command(struct filter_cmd *cmd);

/* Returns the NEW last command in this chain.  */
static struct filter_cmd *
prune_command(struct filter_cmd **Cmd)
{
	struct filter_cmd *cmd, *replace_by, *new_last;
	int delete;
start:
	cmd = *Cmd;
	if (!cmd)
		return NULL;
	delete = 0;
	replace_by = NULL;
	/* Check whether the command could be deleted.  */
	switch (cmd->op)
	{
		case 0:
			delete = 1;
			break;
		case LOG1:
			if (cmd->c.print.expr->undef)
				delete = 1;
				/* This changes slightly the behaviour of the
				 * filter, since the undefined value would be
				 * otherwise logged.  */
			break;
		case '=':
		case ADD:
		case DELETE:
			if (cmd->c.set.lv->undef)
				delete = 1;
			/* The assignment of an undefined value to a defined
			 * variable should NOT be omitted.  */
			break;
		case IF:
			if (cmd->c.cond.cond->undef)
			{
				prune_command(&cmd->c.cond.undefined);
				replace_by = cmd->c.cond.undefined;
				if (!replace_by)
					delete = 1;
			}
			else
			{
				prune_command(&cmd->c.cond.positive);
				prune_command(&cmd->c.cond.negative);
				prune_command(&cmd->c.cond.undefined);
				if (!cmd->c.cond.positive
				&& !cmd->c.cond.negative
				&& !cmd->c.cond.undefined)
					delete = 1;
			}
			break;
		case SWITCH:
			if (cmd->c.swit.expr->undef)
			{
				prune_command(&cmd->c.swit.undefined);
				replace_by = cmd->c.swit.undefined;
				if (!replace_by)
					delete = 1;
			}
			else
			{
				if (prune_switch_command(cmd))
					delete = 1;
			}
			break;
		default:
			break;
	}
	/* Now perform the desired changes.  */
	if (delete)
	{
		*Cmd = cmd->next;
		goto start;
	}
	if (replace_by)
	{
		*Cmd = replace_by;
		ASSERT(replace_by->last);
		replace_by->last->next = cmd->next;
		cmd = replace_by->last;
	}
	new_last = prune_command(&cmd->next);
	if (new_last)
	{
		ASSERT(cmd->next);
		cmd->last = new_last;
		return new_last;
	}
	else
	{
		cmd->last = cmd;
		return cmd;
	}
}

/* Returns the NEW last case in this chain.  */
static struct filter_case *
prune_switch_case(struct filter_case **Case)
{
	struct filter_case *c, *new_last;
start:
	c = *Case;
	if (!c)
		return NULL;
	ASSERT(c->undef == c->cond->undef);
	prune_command(&c->positive);
	if (c->undef || !c->positive)
	{
		/* This deletes the CASE if the command is empty, hence other
		 * matches can take part in.  If the cases are overlapping, the
		 * variable can match another case.  Tell me if you think it
		 * matters.  */
		*Case = c->next;
		goto start;
	}
	new_last = prune_switch_case(&c->next);
	if (new_last)
	{
		ASSERT(c->next);
		c->last = new_last;
		return new_last;
	}
	else
	{
		c->last = c;
		return c;
	}
}

/* Returns whether the whole SWITCH command should be deleted.  */
static int
prune_switch_command(struct filter_cmd *cmd)
{
	ASSERT(!cmd->c.swit.cmp);	/* should be contructed AFTERwards */
	ASSERT(!cmd->c.swit.icmp);
	prune_command(&cmd->c.swit.negative);
	prune_command(&cmd->c.swit.undefined);
	prune_switch_case(&cmd->c.swit.cases);
	if (!cmd->c.swit.cases
	&& !cmd->c.swit.negative
	&& !cmd->c.swit.undefined)
		return 1;
	else
		return 0;
}

static int
is_hashable(struct filter_case *cs)
{
	struct filter_cond *cond = cs->cond;
	ASSERT(cond->cat == F_CC_EXPR);
	if (cs->type == F_ET_STRING
	&& cond->o.expr.op == EQ
	&& !cond->o.expr.neg
	&& cond->o.expr.r->cat == F_EC_CONST)
	{
		ASSERT(cond->o.expr.r->type == F_ET_STRING);
		if (cond->o.expr.icase)
			return 2;
		else
			return 1;
	}
	else
		return 0;
}

static struct filter_hash_table *
build_hash_table(struct filter *f, struct filter_cmd *cmd, int icase, uns nr_tests)
{
	struct filter_hash_table *ht;
	struct filter_case **cs = &cmd->c.swit.cases;
	ht = filter_ht_new(f->pool, nr_tests, icase);
	while (*cs)
	{
		if (is_hashable(*cs) != icase + 1)
		{
			cs = &(*cs)->next;
			continue;
		}
		filter_ht_add(ht, (*cs)->cond->o.expr.r->o.s, (*cs)->positive);
		*cs = (*cs)->next;
	}
	ASSERT(ht->count == nr_tests);
	return ht;
}

static void
possibly_create_hash_table(struct filter *f, struct filter_cmd *cmd)
{
	uns cmps[3] = {0, 0, 0};
	struct filter_case *cs;
	ASSERT(cmd->op == SWITCH);

	for (cs=cmd->c.swit.cases; cs; cs=cs->next)
		cmps[ is_hashable(cs) ]++;
	if (cmps[1] >= filter_hash_limit)
		cmd->c.swit.cmp = build_hash_table(f, cmd, 0, cmps[1]);
	if (cmps[2] >= filter_hash_limit)
		cmd->c.swit.icmp = build_hash_table(f, cmd, 1, cmps[2]);
}

static void
recursively_hash_tables(struct filter *f, struct filter_cmd *cmd)
{
	struct filter_case *cs;

	for (; cmd; cmd=cmd->next)
	{
		switch (cmd->op)
		{
			case IF:
				recursively_hash_tables(f, cmd->c.cond.positive);
				recursively_hash_tables(f, cmd->c.cond.negative);
				recursively_hash_tables(f, cmd->c.cond.undefined);
				break;
			case SWITCH:
				for (cs=cmd->c.swit.cases; cs; cs=cs->next)
					recursively_hash_tables(f, cs->positive);
				recursively_hash_tables(f, cmd->c.cond.negative);
				recursively_hash_tables(f, cmd->c.cond.undefined);
				possibly_create_hash_table(f, cmd);
				break;
			default:
				break;
		}
	}
}

void
filter_prune(struct filter *f)
{
	if (filter_optimize)
		prune_command(&f->body);
	recursively_hash_tables(f, f->body);
}
