/*
 *	Sherlock Indexer -- Merging Documents According to Checksums
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"
#include "indexer/merges.h"

#include <stdlib.h>

#define SORT_KEY struct csum
#define SORT_PREFIX(x) csum_##x
#define SORT_PRESORT
#define SORT_INPUT_FILE
#define SORT_OUTPUT_FILE

static inline int
csum_compare(struct csum *a, struct csum *b)
{
  return memcmp(a, b, sizeof(struct csum));
}

static inline int
csum_fetch_key(struct fastbuf *f, struct csum *k)
{
  return breadb(f, k, sizeof(struct csum));
}

static inline void
csum_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct csum *k)
{
  bwrite(dest, k, sizeof(struct csum));
}

static inline byte *
csum_fetch_item(struct fastbuf *f UNUSED, struct csum *k, byte *limit UNUSED)
{
  return ((byte *)k) + sizeof(struct csum);
}

static inline void
csum_store_item(struct fastbuf *f, struct csum *k)
{
  bwrite(f, k, sizeof(struct csum));
}

#include "lib/sorter.h"

int
main(int argc, char **argv)
{
  struct card_attr *attrs;
  struct fastbuf *in;
  u32 *merges;
  uns attr_size, merges_size, sum_cnt=0, class_cnt=0, ign_cnt=0;
  struct csum old, this;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }
  log(L_INFO, "Merging documents according to checksums");

  csum_sort(fn_checksums, fn_checksums);
  attrs = mmap_file(fn_attributes, &attr_size, 0);
  merges = mmap_file(fn_merges, &merges_size, 1);

  in = bopen(fn_checksums, O_RDONLY, indexer_fb_size);
  bzero(&old, sizeof(old));		/* We assume nothing gets zero checksum */
  old.cardid = ~0U;
  while (breadb(in, &this, sizeof(this)))
    {
      ASSERT(this.cardid < merges_size/4);
      ASSERT(this.cardid != old.cardid);
      sum_cnt++;
      if (!memcmp(&old.md5, &this.md5, 16) && old.cardid != ~0U)
	{
	  if (attrs[this.cardid].flags & CARD_FLAG_EMPTY)
	    ign_cnt++;
	  else
	    merges_union(merges, old.cardid, this.cardid);
	}
      else
	class_cnt++;
      old = this;
    }
  bclose(in);

  munmap_file(attrs, attr_size);
  munmap_file(merges, merges_size);
  log(L_INFO, "Processed %d checksums (%d ignored) in %d equivalence classes", sum_cnt, ign_cnt, class_cnt);

  return 0;
}
