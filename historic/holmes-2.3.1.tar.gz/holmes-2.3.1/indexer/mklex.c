/*
 *	Sherlock Indexer -- Lexicon Builder
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/unaligned.h"
#include "lib/fastbuf.h"
#include "lib/hashfunc.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>

#undef PROFILE_TSC
#include "lib/profile.h"
static prof_t pr_fetch, pr_map, pr_lex, pr_comp;

#define LH_MKLEX
#include "indexer/lexhash.h"

static enum word_class
lm_lookup(enum word_class orig_class, word *uni, uns ulen, word_id_t *idp)
{
  struct verbum *v;

  if (orig_class != WC_NORMAL)
    return orig_class;
  prof_switch(&pr_map, &pr_lex);
  v = lh_lookup(uni, ulen);
  *idp = v;
  prof_switch(&pr_lex, &pr_map);
  return v->id & 7;
}

static inline void
lm_got_word(uns pos UNUSED, uns cat UNUSED, word_id_t w)
{
  w->u.count++;
}

static inline void
lm_got_compound(uns pos UNUSED, uns cat UNUSED, word_id_t *w, uns l)
{
  struct verbum *v;

  prof_switch(&pr_map, &pr_comp);
  v = ch_lookup(w, l);
  v->u.count++;
  prof_switch(&pr_comp, &pr_map);
}

#include "indexer/lexmap.h"

static void
mklex_card(struct card_attr *attr UNUSED, struct odes *o)
{
  static uns ccnt;
  struct oattr *a;

  prof_switch(&pr_fetch, &pr_map);
  lm_doc_start();
  for (a=obj_find_attr(o, 'X'); a; a=a->same)
    {
      uns len = str_len(a->val);
      lm_map_text(a->val, a->val + len);
    }
  prof_switch(&pr_map, &pr_fetch);

  if (progress && !(++ccnt % progress))
    {
      printf("mklex: %d cards, %d words in %d buckets, %d complexes in %d buckets\r", ccnt,
	     lh_hash_count, lh_hash_size, ch_hash_count, ch_hash_size);
      fflush(stdout);
    }
}

static struct verbum *
lex_merge(void)
{
  uns i;
  struct verbum *l, *first, **last;

  last = &first;
  for (i=0; i<lh_hash_size; i++)
    for (l=lh_hash_table[i]; l; l=l->next)
      {
	*last = l;
	last = &l->next;
      }
  for (i=0; i<ch_hash_size; i++)
    for (l=ch_hash_table[i]; l; l=l->next)
      {
	*last = l;
	last = &l->next;
      }
  *last = NULL;
  return first;
}

static struct verbum **id_to_verbum;

static void
lex_build_idtable(struct verbum *l)
{
  struct verbum *v;
  u32 max = 0;

  for (v=l; v; v=v->next)
    max = MAX(max, v->id);
  id_to_verbum = xmalloc_zero(sizeof(struct verbum *)*(max/8+1));
  for (v=l; v; v=v->next)
    id_to_verbum[v->id/8] = v;
}

static void
lex_renumber(struct verbum *l)
{
  struct verbum *v;
  u32 id = 0;

  for (v=l; v; v=v->next)
    v->id = (v->id & 7) | (id += 8);
}

static inline u32
lex_map_id(u32 id)
{
  return id_to_verbum[id/8]->id;
}

static int
lex_before_count(struct verbum *a, struct verbum *b)
{
  return (a->u.count > b->u.count);
}

static int
lex_before_pass1(struct verbum *a, struct verbum *b)
{
  byte *aa = a->word;
  byte *bb = b->word;
  uns au, bu;
  int s;

  if ((b->id & 7) == WC_COMPOUND)
    return 1;
  if ((a->id & 7) == WC_COMPOUND)
    return 0;
  while (*aa || *bb)
    {
      GET_UTF8(aa, au);
      GET_UTF8(bb, bu);
      au = Uunaccent(au);
      bu = Uunaccent(bu);
      if (au < bu)
	return 1;
      if (au > bu)
	return 0;
    }
  s = strcmp(a->word, b->word);
  ASSERT(s);
  return (s <= 0);
}

static inline u32
lex_get_root(struct verbum *a)
{
  if ((a->id & 7) == WC_COMPOUND)
    {
      uns i=0, id, id2;
      do
	{
	  id = ((u32*)a->word)[i++];
	  id2 = lex_map_id(id);		/* also recovers class bits */
	  if ((id2 & 7) == WC_NORMAL)
	    return id2;
	}
      while (id & 7);
      ASSERT(0);
    }
  return a->id;
}

static int
lex_before_pass2(struct verbum *a, struct verbum *b)
{
  u32 aroot = lex_get_root(a);
  u32 broot = lex_get_root(b);
  uns alen, blen, i;

  if (aroot < broot)
    return 1;
  if (aroot > broot)
    return 0;
  if ((a->id & 7) != WC_COMPOUND)
    {
      ASSERT((b->id & 7) == WC_COMPOUND);
      return 1;
    }
  if ((b->id & 7) != WC_COMPOUND)
    return 0;
  alen = ch_wlen((u32*)a->word);
  blen = ch_wlen((u32*)b->word);
  if (alen < blen)
    return 1;
  if (alen > blen)
    return 0;
  for (i=0; i<alen; i++)
    {
      u32 x = lex_map_id(((u32*)a->word)[i]);
      u32 y = lex_map_id(((u32*)b->word)[i]);
      if (x < y)
	return 1;
      if (x > y)
	return 0;
    }
  ASSERT(0);
}

static struct verbum *
lex_sort(struct verbum *x, int (*before)(struct verbum *, struct verbum *))
{
  struct verbum *f1, **l1, *f2, **l2, **l;

  l1 = &f1;
  l2 = &f2;
  while (x)
    {
      *l1 = x;
      l1 = &x->next;
      x = x->next;
      if (!x)
	break;
      *l2 = x;
      l2 = &x->next;
      x = x->next;
    }
  *l1 = *l2 = NULL;

  if (f1 && f1->next)
    f1 = lex_sort(f1, before);
  if (f2 && f2->next)
    f2 = lex_sort(f2, before);
  l = &x;
  while (f1 && f2)
    {
      if (before(f1, f2))
	{
	  *l = f1;
	  l = &f1->next;
	  f1 = f1->next;
	}
      else
	{
	  *l = f2;
	  l = &f2->next;
	  f2 = f2->next;
	}
    }
  *l = f1 ? : f2;
  return x;
}

static void
lex_write(byte *name, struct verbum *l)
{
  struct fastbuf *b;

  lex_renumber(l);
  b = bopen(name, O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  bputl(b, lh_hash_count + ch_hash_count);
  while (l)
    {
      bputl(b, l->u.count);
      bputc(b, l->id & 7);
      if ((l->id & 7) == WC_COMPOUND)
	{
	  uns c = ch_wlen((u32*)l->word);
	  uns i;
	  bputc(b, 4*c);
	  for (i=0; i<c; i++)
	    bputl(b, lex_map_id(((u32*)l->word)[i]));
	}
      else
	{
	  uns c = strlen(l->word);
	  bputc(b, c);
	  bwrite(b, l->word, c);
	}
      l = l->next;
    }
  bclose(b);
}

int
main(int argc, char **argv)
{
  struct verbum *head;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  lm_init();
  lh_init();

  prof_init(&pr_fetch);
  prof_init(&pr_map);
  prof_init(&pr_lex);
  prof_init(&pr_comp);

  prof_start(&pr_fetch);
  log(L_INFO, "Creating lexicon");
  fetch_cards(NULL, NULL, mklex_card);
  prof_stop(&pr_fetch);

#ifdef PROFILER
  log(L_DEBUG, "Profile: fetch %s, map %s, lex %s, comp %s", PROF_STR(pr_fetch), PROF_STR(pr_map), PROF_STR(pr_lex), PROF_STR(pr_comp));
#endif

  log(L_INFO, "Sorting lexicon: Pass 0");
  head = lex_merge();
  lh_cleanup();
  lex_build_idtable(head);
  if (fn_lexicon_by_cnt)
    {
      head = lex_sort(head, lex_before_count);
      lex_write(fn_lexicon_by_cnt, head);
    }
  log(L_INFO, "Sorting lexicon: Pass 1");
  head = lex_sort(head, lex_before_pass1);
  lex_renumber(head);
  log(L_INFO, "Sorting lexicon: Pass 2");
  head = lex_sort(head, lex_before_pass2);
  lex_write(fn_lex_temp, head);

  log(L_INFO, "Built lexicon with %d words and %d complexes", lh_hash_count, ch_hash_count);
  return 0;
}
