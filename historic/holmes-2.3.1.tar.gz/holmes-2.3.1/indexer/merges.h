/*
 *	Sherlock Indexer -- Handling of Equivalence Classes
 *
 *	(c) 2002 Martin Mares <mj@ucw.cz>
 */

/*
 * The equivalence classes are stored as Tarjan's Union-Find Trees
 * with path compression, but no union by size/rank => the amortized
 * complexity of operations is not O(alpha(n)) as in the original
 * version, but they still should perform very well indeed.
 */

static inline uns
merges_find_root(u32 *merges, uns x)
{
  uns y = x, z;

  while ((int)merges[y] >= 0)
    y = merges[y];
  /* Perform path compression */
  while ((int)merges[x] >= 0)
    {
      z = merges[x];
      merges[x] = y;
      x = z;
    }
  return y;
}

static inline void
merges_union(u32 *merges, uns x, uns y)
{
  x = merges_find_root(merges, x);
  y = merges_find_root(merges, y);
  merges[y] = x;
}
