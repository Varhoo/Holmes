/*
 *	Sherlock Indexer -- Sorting of Fingerprints
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"

#include <stdlib.h>

#define SORT_KEY struct fprint
#define SORT_PREFIX(x) fp_##x
#define SORT_PRESORT
#define SORT_INPUT_FILE
#define SORT_OUTPUT_FILE

static inline int
fp_compare(struct fprint *a, struct fprint *b)
{
  return memcmp(a, b, sizeof(struct fprint));
}

static inline int
fp_fetch_key(struct fastbuf *f, struct fprint *k)
{
  return breadb(f, k, sizeof(struct fprint));
}

static inline void
fp_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct fprint *k)
{
  bwrite(dest, k, sizeof(struct fprint));
}

static inline byte *
fp_fetch_item(struct fastbuf *f UNUSED, struct fprint *k, byte *limit UNUSED)
{
  return ((byte *)k) + sizeof(struct fprint);
}

static inline void
fp_store_item(struct fastbuf *f, struct fprint *k)
{
  bwrite(f, k, sizeof(struct fprint));
}

#include "lib/sorter.h"

int
main(int argc, char **argv)
{
  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  log(L_INFO, "Sorting fingerprints");
  fp_sort(fn_fingerprints, fn_fingerprints);

  return 0;
}
