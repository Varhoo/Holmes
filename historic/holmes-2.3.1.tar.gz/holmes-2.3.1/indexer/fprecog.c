/*
 *	Sherlock Indexer -- Fingerprint Recognition
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#undef LOCAL_DEBUG

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"

#include <stdlib.h>

static struct fprint *fp_table, **fp_index;
static uns fp_shift, fp_size;

void
fp_recog_init(void)
{
  uns count, shift, h, h0, i, hsize;

  fp_table = mmap_file(fn_fingerprints, &fp_size, 0);
  count = fp_size / sizeof(struct fprint);
  for (shift=1; shift < 30 && (1U << shift) < count / 4; shift++)
    ;
  fp_shift = 32 - shift;
  hsize = 1 << shift;
  DBG("fp_recog_init: %d fingerprints, shift set to %d => %d buckets", count, fp_shift, hsize);
  fp_index = xmalloc(sizeof(struct fprint *) * (hsize + 1));
  h0 = 0;
  fp_index[0] = fp_table;
  for (i=0; i<count; i++)
    {
      h = fp_hash(&fp_table[i].fp) >> fp_shift;
      ASSERT(h >= h0);
      if (h == h0)
	continue;
      while (h0 < h)
	fp_index[++h0] = &fp_table[i];
    }
  while (h0 < hsize)
    fp_index[++h0] = &fp_table[count];
}

void
fp_recog_end(void)
{
  munmap_file(fp_table, fp_size);
  xfree(fp_index);
}

uns
fp_recog(struct fingerprint *fp)
{
  uns h = fp_hash(fp) >> fp_shift;
  struct fprint *f;

  for (f=fp_index[h]; f<fp_index[h+1]; f++)
    if (!memcmp(fp, &f->fp, sizeof(*fp)))
      return f->cardid;
  return ~0;
}
