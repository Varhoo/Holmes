/*
 *	Sherlock Indexer -- Processing of Labels
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"

#include <fcntl.h>
#include <stdlib.h>

static u32 *merges;
static struct card_attr *attrs;

struct lab {
  u32 id;
  u32 count;
  byte pri;
} PACKED;

#define SORT_KEY struct lab
#define SORT_PREFIX(x) fp_##x
#define SORT_DELETE_INPUT 1
#define SORT_PRESORT
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static inline uns
fp_weight(struct lab *a)
{
  uns w;

  w = (attrs[a->id].flags & CARD_FLAG_MERGED) ? 0x10000000 : 0;
  w += attrs[a->id].weight << 8;
  return w;
}

static inline int
fp_compare(struct lab *a, struct lab *b)
{
  u32 ia = a->id;
  u32 ib = b->id;
  int wa, wb;

  /* Follow redirects */
  if (attrs[ia].flags & CARD_FLAG_EMPTY)
    ia = merges[ia];
  if (attrs[ib].flags & CARD_FLAG_EMPTY)
    ib = merges[ib];

  /* Primary cards don't exist => put at the end */
  if (ia == ~0U && ib == ~0U)
    return 0;
  if (ia == ~0U)
    return 1;
  if (ib == ~0U)
    return -1;

  /* Sort on primary card */
  if (merges[ia] < merges[ib])
    return -1;
  if (merges[ia] > merges[ib])
    return 1;

  /* Same primary card, sort on weight of the secondary card */
  wa = fp_weight(a);
  wb = fp_weight(b);
  if (wa > wb)
    return -1;
  if (wa < wb)
    return 1;

  /* Tie, sort on secondary card ID */
  if (ia < ib)
    return -1;
  if (ia > ib)
    return 1;

  /* Same secondary card, label priority decides */
  if (a->pri > b->pri)
    return -1;
  if (a->pri < b->pri)
    return 1;

  /* Same secondary card and priority, try pre-redirect card numbers */
  if (a->id < b->id)
    return -1;
  if (a->id > b->id)
    return 1;

  /* Let the nature decide */
  return 0;
}

static inline int
fp_fetch_key(struct fastbuf *f, struct lab *k)
{
  return breadb(f, k, sizeof(*k));
}

static inline void
fp_copy_data(struct fastbuf *src, struct fastbuf *dest, struct lab *k)
{
  bwrite(dest, k, sizeof(*k));
  bbcopy(src, dest, k->count);
}

static inline byte *
fp_fetch_item(struct fastbuf *f, struct lab *k, byte *limit)
{
  byte *pos = (byte *)(k+1);

  if (pos + k->count > limit)
    return NULL;
  breadb(f, pos, k->count);
  return pos + k->count;
}

static inline void
fp_store_item(struct fastbuf *f, struct lab *k)
{
  bwrite(f, k, sizeof(*k) + k->count);
}

#include "lib/sorter.h"

static void
skip_chain(struct fastbuf *c)
{
  int x;
  while (bgetc(c))
    {
      while ((x = bgetc(c)) > 0)
	;
      if (x < 0)
	die("skip_chain: unexpected EOF");
    }
}

int
main(int argc, char **argv)
{
  struct fastbuf *tmp, *in, *out;
  int id;
  uns count = 0;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  tmp = bopen(fn_labels, O_RDWR | O_CREAT | O_TRUNC, indexer_fb_size);

  /* Look at original by-ID labels through our merging lens */
  log(L_INFO, "Searching for labels");
  attrs = mmap_file(fn_attributes, NULL, 0);
  in = bopen(fn_labels_by_id, O_RDONLY, indexer_fb_size);
  while ((id = bgetl(in)) >= 0)
    {
      uns pri = bgetc(in);
      if (pri < 0xff || (attrs[id].flags & (CARD_FLAG_DUP | CARD_FLAG_MERGED)))
	{
	  sh_off_t start = btell(in);
	  uns len;
	  skip_chain(in);
	  bputl(tmp, id);
	  len = btell(in) - start - 1;
	  bputl(tmp, len);
	  bputc(tmp, pri);
	  bsetpos(in, start);
	  bbcopy(in, tmp, len);
	  bgetc(in);
	  count++;
	}
      else
	skip_chain(in);
    }

  log(L_INFO, "Extracted %d labels", count);
  merges = mmap_file(fn_merges, NULL, 0);

  /* Sort the resulting labels */
  bflush(tmp);
  bsetpos(tmp, 0);
  tmp = fp_sort(tmp);

  /* Translate ID's to merged ones and create the output file */
  log(L_INFO, "Translating labels");
  out = bopen(fn_labels, O_RDWR | O_CREAT | O_TRUNC, indexer_fb_size);
  while ((id = bgetl(tmp)) >= 0)
    {
      uns len = bgetl(tmp);
      bgetc(tmp);
      id = (attrs[id].flags & CARD_FLAG_EMPTY) ? (int) merges[id] : id;
      if (id >= 0)
	{
	  bputl(out, merges[id]);
	  bputl(out, len);
	  bbcopy(tmp, out, len);
	}
      else
	bseek(tmp, len, SEEK_CUR);
    }
  bclose(tmp);
  bclose(out);

  return 0;
}
