/*
 *	Sherlock Indexer -- Merging of Identical Documents
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *
 *	This module identifies equivalence classes defined by the Merges
 *	array and merges each class to a single primary card (the card
 *	with largest weight in the class).
 *	The primary card is marked with CARD_FLAG_MERGED and its attributes
 *	are combined with attributes of the other cards which receive
 *	CARD_FLAG_DUP. The mapping secondary -> primary is stored to the
 *	Merges array (which is also used as a work-space), cards with
 *	CARD_FLAG_EMPTY set are not touched (their positions in the array
 *	are used to denote redirects).
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"
#include "indexer/merges.h"

#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int
main(int argc, char **argv)
{
  struct card_attr *attrs;
  uns attr_size, merges_size, card_count, i;
  uns class_cnt=0, max_chain=0;
  u32 *merges, *best;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }
  log(L_INFO, "Merging cards");

  attrs = mmap_file(fn_attributes, &attr_size, 1);
  ASSERT(!(attr_size % sizeof(struct card_attr)));
  card_count = attr_size / sizeof(struct card_attr);

  merges = mmap_file(fn_merges, &merges_size, 1);
  ASSERT(merges_size == 4*card_count);

  /* For each class, find the best card there */
  best = xmalloc(4*card_count);
  for (i=0; i<card_count; i++)
    best[i] = ~0U;
  for (i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY))
      {
	uns root = merges_find_root(merges, i);
	uns j = best[root];
	if (j == ~0U
	    || attrs[i].weight > attrs[j].weight
	    )
	  best[root] = i;
      }

  /* Merge each class to its best card */
  for (i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY))
      {
	/* We assume path compression has been done by the previous pass */
	uns dest;
	if (merges[i] == ~0U)
	  merges[i] = i;
	dest = best[merges[i]];
	ASSERT(dest != ~0U);
	merges[i] = dest;
      }

  /* Calculate merging statistics, reusing the best array */
  bzero(best, 4*card_count);
  for (i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY))
      {
	best[merges[i]]++;
	if (merges[i] == i)
	  class_cnt++;
      }
  for (i=0; i<card_count; i++)
    max_chain = MAX(max_chain, best[i]);

  /* Update card attributes, ignoring single-element classes */
  for (i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY))
      {
	if (merges[i] != i)
	  attrs[i].flags |= CARD_FLAG_DUP;
	else if (best[i] > 1)
	  attrs[i].flags |= CARD_FLAG_MERGED;
      }

  munmap_file(attrs, attr_size);
  munmap_file(merges, merges_size);

  log(L_INFO, "Merged %d cards to %d classes (max class %d)",
      card_count, class_cnt, max_chain);
  return 0;
}
