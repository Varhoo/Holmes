/*
 *	Sherlock Indexer -- Configuration
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *	(c) 2002 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "indexer/indexer.h"

byte *fn_directory = "not/configured";
byte *fn_parameters = "not/configured";
byte *fn_fingerprints = "not/configured";
byte *fn_labels_by_id = "not/configured";
byte *fn_attributes = "not/configured";
byte *fn_checksums = "not/configured";
byte *fn_links = "not/configured";
byte *fn_urls = "not/configured";
byte *fn_ref_texts = "not/configured";
byte *fn_link_graph = "not/configured";
byte *fn_sites = NULL;
byte *fn_labels = "not/configured";
byte *fn_merges = "not/configured";
byte *fn_signatures = "not/configured";
byte *fn_matches = NULL;
byte *fn_lex_temp = "not/configured";
byte *fn_word_index = "not/configured";
byte *fn_string_index = "not/configured";
byte *fn_lexicon = "not/configured";
byte *fn_lexicon_by_cnt = NULL;
byte *fn_references = "not/configured";
byte *fn_string_map = "not/configured";
byte *fn_string_hash = "not/configured";
byte *fn_cards = "not/configured";
byte *fn_card_attrs = "not/configured";
byte *label_attrs = "";
byte *link_attrs = "";
byte *ref_link_types = "";
byte *indexer_filter_name = "not/configured";
uns string_avg_bucket = 1024;
uns indexer_fb_size = 65536;
uns progress;
uns sort_delete_src;
uns max_degree = 4096;
uns ref_max_length = 256;
uns ref_min_length = 1;
uns ref_max_count = 1;
uns ref_hash_size = 16;
uns matcher_signatures = 0;
uns matcher_context = 4;
uns matcher_min_words = 0;
uns matcher_threshold = 0;
uns matcher_passes = 3;
uns matcher_block = 64;
uns max_num_objects = ~0;
uns min_summed_size = 0;

static struct cfitem iconfig[] = {
  { "Indexer",		CT_SECTION,	NULL },
  { "Directory",	CT_STRING,	&fn_directory },
  { "Parameters",	CT_STRING,	&fn_parameters },
  { "Fingerprints",	CT_STRING,	&fn_fingerprints },
  { "LabelsByID",	CT_STRING,	&fn_labels_by_id },
  { "Attributes",	CT_STRING,	&fn_attributes },
  { "Checksums",	CT_STRING,	&fn_checksums },
  { "Links",		CT_STRING,	&fn_links },
  { "URLList",		CT_STRING,	&fn_urls },
  { "RefTexts",		CT_STRING,	&fn_ref_texts },
  { "LinkGraph",	CT_STRING,	&fn_link_graph },
  { "Sites",		CT_STRING,	&fn_sites },
  { "Labels",		CT_STRING,	&fn_labels },
  { "Merges",		CT_STRING,	&fn_merges },
  { "Signatures",	CT_STRING,	&fn_signatures },
  { "Matches",		CT_STRING,	&fn_matches },
  { "LexTemp",		CT_STRING,	&fn_lex_temp },
  { "WordIndex",	CT_STRING,	&fn_word_index },
  { "StringIndex",	CT_STRING,	&fn_string_index },
  { "Lexicon",		CT_STRING,	&fn_lexicon },
  { "LexiconByCount",	CT_STRING,	&fn_lexicon_by_cnt },
  { "References",	CT_STRING,	&fn_references },
  { "StringMap",	CT_STRING,	&fn_string_map },
  { "StringHash",	CT_STRING,	&fn_string_hash },
  { "Cards",		CT_STRING,	&fn_cards },
  { "CardAttributes",	CT_STRING,	&fn_card_attrs },
  { "LabelAttrs",	CT_STRING,	&label_attrs },
  { "LinkAttrs",	CT_STRING,	&link_attrs },
  { "Filter",		CT_STRING,	&indexer_filter_name },
  { "StringAvgBucket",	CT_INT,		&string_avg_bucket },
  { "FileBufSize",	CT_INT,		&indexer_fb_size },
  { "Progress",		CT_INT,		&progress },
  { "SortDeleteSrc",	CT_INT,		&sort_delete_src },
  { "MaxGraphDegree",	CT_INT,		&max_degree },
  { "RefLinkTypes",	CT_STRING,	&ref_link_types },
  { "RefMaxLength",	CT_INT,		&ref_max_length },
  { "RefMinLength",	CT_INT,		&ref_min_length },
  { "RefMaxCount",	CT_INT,		&ref_max_count },
  { "RefHashSize",	CT_INT,		&ref_hash_size },
  { "MaxObjects",	CT_INT,		&max_num_objects },
  { "MinSummedSize",	CT_INT,		&min_summed_size },
  { NULL,		CT_STOP,	NULL }
};

static struct cfitem matcher_config[] = {
  { "Matcher",		CT_SECTION,	NULL },
  { "Signatures",	CT_INT,		&matcher_signatures },
  { "Context",		CT_INT,		&matcher_context },
  { "MinWords",		CT_INT,		&matcher_min_words },
  { "Threshold",	CT_INT,		&matcher_threshold },
  { "Passes",		CT_INT,		&matcher_passes },
  { "Block",		CT_INT,		&matcher_block },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR iconf_init(void)
{
  cf_register(iconfig);
  cf_register(matcher_config);
}
