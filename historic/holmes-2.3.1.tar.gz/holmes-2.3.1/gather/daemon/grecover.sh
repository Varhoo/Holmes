#!/bin/sh
# Script for automatic recovery after gatherer crash.
# (c) 2002 Martin Mares <mj@ucw.cz>

set -e
if [ ! -f db/RECOVERING ] ; then
	[ -f db/GATHERLOCK ] || exit 0
	>db/RECOVERING
fi
rm -f db/GATHERLOCK
# In case we crash in the middle of DB recovery
>db/RECOVERING

# First check and repair the bucket file
if bin/buckettool -q ; then
	echo "Bucket file looks consistent."
else
	echo "Bucket file is inconsistent, checking and fixing it."
	if bin/buckettool -F ; then
		echo "Bucket file fixed."
	else
		echo "Bucket file needs manual fixing."
		exit 1
	fi
fi

# Use the expirer to identify missing buckets, fix minor database
# problems and reconstruct queue.
echo "Recovering databases and queues..."
if bin/expire -f ; then
	echo "Done."
else
	echo "Databases need manual fixing."
	exit 1
fi

rm db/RECOVERING
echo "Gatherer hopefully recovered."
