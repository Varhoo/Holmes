/*
 *	Sherlock Filter Engine
 *
 *	(c) 1999--2000 Martin Mares <mj@ucw.cz>
 *	(c) 2001--2003 Robert Spalek <robert@ucw.cz>
 */

struct fastbuf;

/*
 * Basic enumerations for type checking, switching the cases, ...
 */

enum filter_lvalue_cat { F_LVC_RAW, F_LVC_ATTR, F_LVC_CONF, F_LVC_USER};
enum filter_expr_type { F_ET_INT, F_ET_STRING, F_ET_REGEXP, F_ET_UNKNOWN};
enum filter_expr_cat { F_EC_CONST, F_EC_LVALUE, F_EC_UNOP, F_EC_BINOP, F_EC_FUNC};
enum filter_cond_cat { F_CC_CONST, F_CC_EXPR, F_CC_DEFCOND, F_CC_DEFEXPR, F_CC_UNOP, F_CC_BINOP};

/*
 * Values of the variables may be undefined by the context (not bound) or by
 * the program (undefined result of the operation).  To save the undefined flag
 * into target raw variables, special values are reserved.  This is used for
 * the I/O operations only.
 */

#define	F_UNDEF_INT	0x8000000
#define	F_UNDEF_STRING	NULL
#define	F_UNDEF_REGEXP	NULL

/*
 * Internal data structures for filter parser and interpreter.
 */

struct filter_lvalue {
	enum filter_lvalue_cat cat;
	enum filter_expr_type type;
	byte ro;
	byte undef;
	union {
		struct filter_binding *bind;
		byte *bind_name;	/* when undef */
		uns name;
		struct cfitem *cfg;
		struct filter_declaration *decl;
	} v;
};

struct filter_regex_value {
	byte *source;
	regex *regex;
	byte icase, precompiled;
};
union filter_raw_value {
	int i;
	byte *s;
	struct filter_regex_value *r;
};

struct filter_value {
	enum filter_expr_type type;
	byte undef;
	union filter_raw_value v;		/* allocated in run pool */
};

#define	MAX_FUNC_ARGS	4

struct filter_args;
typedef void (*filter_function) (struct filter_args *args, struct filter_value *ret, struct filter_value arg[MAX_FUNC_ARGS]);

struct filter_expr {
	enum filter_expr_type type;
	enum filter_expr_cat cat;
	byte undef;
	union {
		int i;
		byte *s;
		struct filter_regex_value *r;
		struct filter_lvalue *lv;
		struct {
			struct filter_expr *r;
			int op;
		} un;
		struct {
			struct filter_expr *l, *r;
			int op;
		} bin;
		struct {
			struct filter_expr *a[MAX_FUNC_ARGS];
			struct filter_function *func;
		} func;
	} o;
};

struct filter_cond {
	enum filter_cond_cat cat;
	byte undef;
	union {
		int i;
		struct {
			struct filter_expr *l, *r;	/* l == NULL means partial condition */
			byte neg;
			byte icase;
			int op;
		} expr;
		struct filter_expr *defexpr;
		struct filter_cond *neg;
		struct {
			struct filter_cond *l, *r;
			int op;
		} bin;
	} o;
};

struct filter_case {
	struct filter_case *next, *last;
	enum filter_expr_type type;
	byte undef;
	struct filter_cond *cond;			/* partial condition */
	struct filter_cmd *positive;
};

struct filter_hash_table;
struct filter_trie_table;

struct filter_cmd {
	struct filter_cmd *next, *last;
	int op;
	union {
		struct {
			int level;
			struct filter_expr *expr;
		} print;
		struct {
			struct filter_lvalue *lv;
			struct filter_expr *expr;
		} set;
		struct {
			struct filter_cond *cond;
			struct filter_cmd *positive, *negative, *undefined;
		} cond;
		struct {
			struct filter_expr *expr;
			struct filter_case *cases;
			struct filter_cmd *negative, *undefined;
			struct filter_hash_table *cmp, *icmp;
			struct filter_trie_table *pat, *ipat;
		} swit;
	} c;
};

/*
 * Link list of known names for lexical parser.  It doesn't touch directly the
 * variable declarations, because it doesn't know the context, it would be
 * confusing.
 *
 * Before a program is parsed, all variables must be declared.  Variable can be
 * of raw type (stored at the offset given in the binding), an additional
 * attribute (indexed by name) or a configuration item.  The syntactic parser
 * needs to know about types and access modes of all this variables.
 * filter_variable lists types and modes of type F_LVC_RAW and F_LVC_ATTR.
 * F_LVC_CONF items are exported automatically in read-write mode (because the
 * undo pool is used).
 *
 * Binding of F_LVC_RAW variables only to real variables.
 *
 * Declaration of all functions.  Two sets are used: predefined and
 * user-defined.
 *
 * The list of known functions is also included (usually set to
 * filter_builtin_func).
 *
 * The list of modifiable cfitems is also included (to let filter_run save all
 * the undo information).
 */

struct filter_lex_name {
	struct filter_lex_name *next;
	byte name[0];
};

struct filter_variable {
	byte *name;
	enum filter_lvalue_cat cat;
	enum filter_expr_type type;
	byte ro;
};

struct filter_binding {				/* for cat == F_LVC_RAW only */
	byte *name;
	int offset;
};

struct filter_function {
	byte *name;
	int args;
	enum filter_expr_type arg[MAX_FUNC_ARGS], ret;
	filter_function f;
};

struct filter_declaration {
	struct filter_declaration *next, *last;
	int nr;
	byte is_local;
	struct filter_variable var;
};

struct filter {
	struct mempool *pool;
	struct filter_lex_name name_head;
	struct filter_variable *var;
	struct filter_binding *bind;
	struct filter_function *func;
	int cfg_undos;			/* maximal size of undo stack */
	int user_vars;			/* the number of user-defined variables */
	struct filter_declaration *decl, *deleted_decl;
	struct filter_cmd *body;
};

/*
 * Information save to the configuration undo pool.  Only changed items are
 * stored here.
 *
 * When running the filter, pool for concatenation '.' operator, pointer to the
 * raw variable structure and pointer to the argument list must be set here.
 * cfg_undo should not be touched, filter_rus stored here the undo pool of
 * configuration items.  Original values of configuration variables that are
 * restored by calling filter_undo.
 */

struct filter_undo_pool {
	struct cfitem *cfg;
	union filter_raw_value v;
};

struct filter_args {
	struct filter *filter;
	struct filter_undo_pool *cfg_undo;	/* touched by filter_run and filter_undo */
	union filter_raw_value *user_var;
	struct mempool *pool;			/* for '.' operator only */
	byte *msg;				/* return message or NULL */
	void *raw;
	struct odes *attr;
};

/* parse.y */

#define	TYPE_MISMATCH(x, y)	((x)!=(y) && (x)!=F_ET_UNKNOWN && (y)!=F_ET_UNKNOWN)
#define	TYPE_COMBINE(x, y)	if (x == F_ET_UNKNOWN) x = y

void *filter_alloc(int size);
byte *filter_stralloc(byte *str);

int yyparse(void *);

/* lex.l */

void filter_err(byte *msg) NONRET;
void filter_lex_init(byte *name);
void filter_lex_cleanup(void);
int yylex(void);

/* filter.c */

extern struct filter *filter_current;

struct filter *filter_load(byte *, struct filter_variable *, struct filter_binding *, struct filter_function *);
void filter_delete(struct filter *);

struct filter_args *filter_intr_new(struct filter *);
void filter_intr_delete(struct filter_args *);
int filter_intr_run(struct filter_args *);
void filter_intr_undo_init(struct filter_args *);
void filter_intr_undo(struct filter_args *);

/* Exported for pruning: */
void filter_eval_expr(struct filter_value *dest, struct filter_args *args, struct filter_expr *expr);
int filter_eval_cond(struct filter_args *args, struct filter_cond *cond);

/* prune.c */

void filter_prune(struct filter *);

/* builtin.c */

extern struct filter_function filter_builtin_func[];
extern struct filter_variable filter_builtin_vars[];

/* hashes.c */

struct filter_hash_record {				/* for fast SWITCH testing */
	struct filter_hash_record *next;
	byte *string;
	struct filter_cmd *cmd;
};

struct filter_hash_table
{
	uns size, count;
	uns icase;
	struct mempool *mp;
	struct filter_hash_record *h[0];
};

struct filter_hash_table *filter_ht_new(struct mempool *mp, uns count, uns icase);
void filter_ht_add(struct filter_hash_table *ht, byte *string, struct filter_cmd *cmd);
int filter_ht_find(struct filter_hash_table *ht, byte *string, struct filter_cmd **Cmd);

/* tries.c */

struct filter_trie_record
{
	uns bitnr;				/* which bit is being tested */
	struct filter_trie_record *son[2];	/* tree on its value 0 or 1 */
	int *cmdids;				/* -1 terminated list of command ID's... */
	char prefix[0];				/* ...with exactly this prefix */
};

#include "lib/lists.h"
struct filter_trie_result
{
	struct node n;
	uns number;
	uns trivial_pattern;			/* 1 iff the pattern contains only one * and no ? */
	byte passed;				/* number of tests the wildcard-pattern has matched */
	byte init_passed;			/* its initial value */
};

struct filter_trie_table
{
	uns icase;
	uns cmds;				/* table of commands by their ID */
	struct filter_case **cmd;
	int *cmdid;				/* table of lists of command ID's */
	struct filter_trie_result *results;	/* table of results of pattern matchings */
	struct list tests, incremented_tests, passed_tests;
	struct filter_trie_record *root[2];	/* 0=prefix, 1=suffix */
};

struct filter_trie_table *filter_trie_new(struct mempool *mp, struct filter_cmd *case_cmd, uns icase);
struct filter_cmd *filter_trie_search(struct filter_trie_table *trie, byte *string);
void filter_trie_dump(struct fastbuf *b, struct filter_trie_table *trie);

/* dumper.c */

void filter_dump(struct fastbuf *b, struct filter *f);

/* fconfig.c */

extern uns filter_trace, filter_hash_limit, filter_trie_limit, filter_optimize;
extern byte *filter_dump_to;
