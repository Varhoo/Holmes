/*
 *	Upgrade v2.4 hosts file to v2.5 (and reset the queue)
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/fastbuf.h"

#include <stdio.h>

int
main(int argc UNUSED, char **argv UNUSED)
{
  struct fastbuf *i = bfdopen_shared(0, 65536);
  struct fastbuf *o = bfdopen_shared(1, 65536);
  int c;

  for(;;)
    {
      int proto = bgetc(i);
      if (proto < 0)
	break;
      uns port = bgetw(i);
      bputc(o, proto);
      bputw(o, port);
      do
	{
	  c = bgetc(i);
	  bputc(o, c);
	}
      while (c != '\n');
      bbcopy(i, o, 4*(6 + SHERLOCK_NUM_SECTIONS));
      bputl(o, 0);
    }

  bclose(i);
  bclose(o);
  return 0;
}
