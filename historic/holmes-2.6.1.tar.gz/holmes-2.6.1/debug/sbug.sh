#!/bin/sh
# A simple script for submitting a bug report to Bugzilla

T=`mktemp`
cat >$T <<EOF
To: bugmail@bugzilla.netcentrum.cz

@product=sherlock
@component=front-end
@version=2.5
@priority=P2
@rep_platform=All
@op_sys=other
@bug_severity=enhancement

EOF
mutt -H $T
rm $T
