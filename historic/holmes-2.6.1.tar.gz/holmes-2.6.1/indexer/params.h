/*
 *	Sherlock: The index parameter file
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#ifndef _SHERLOCK_PARAMS_H
#define _SHERLOCK_PARAMS_H

#include "indexer/lexicon.h"

struct index_params {
  u32 version;				/* INDEX_VERSION */
  sh_time_t ref_time;			/* Reference time (for document ages etc.) */
  struct lexicon_config lex_config;
  u32 objects_in;			/* Number of objects on the input of the indexer */
};

#endif
