#!/usr/bin/perl -w

use lib "lib/perl5";
use Sherlock::Watsonlib;
use strict;
use warnings;

stat_options() or die stat_usage();

my $pic = new Sherlock::Watsonlib::picture $stat_picname, "Indexer: documents";
$pic->{INIT_CMD}.="set yrange [0:]\nset data style linespoints\n";
my $b = $pic->new_plot("Buckets");
my $c = $pic->new_plot("Cards");
my $d = $pic->new_plot("Duplicates");

compute_stat($stat_begintime,$stat_endtime,$stat_prefix,\&proc_line);

$pic->draw_picture;

sub proc_line {
	my %r = @_;
	$pic->plot_value($b, $r{'start_time'}, $r{'exp_buck_total'}) if defined $r{'exp_buck_total'};
	$pic->plot_value($c, $r{'start_time'}, $r{'merge_card'}) if defined $r{'merge_card'};
	$pic->plot_value($d, $r{'start_time'}, $r{'merge_dupl'}) if defined $r{'merge_dupl'};
}

