/*
 *	Sherlock Library -- Logging
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU Lesser General Public License.
 */

#include "lib/lib.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <alloca.h>

static char log_progname[32], *log_name_patt, *log_name;
static pid_t log_pid;
static int log_params;
static int log_name_size;
static int log_switching;

void
log_fork(void)
{
  log_pid = getpid();
}

static void
log_switch(struct tm *tm)
{
  int fd, l;
  char name[log_name_size];

  if (!log_name_patt ||
      log_name[0] && !log_params ||
      log_switching)
    return;
  log_switching++;
  l = strftime(name, log_name_size, log_name_patt, tm);
  if (l < 0 || l >= log_name_size)
    die("Error formatting log file name: %m");
  if (strcmp(name, log_name))
    {
      strcpy(log_name, name);
      fd = open(name, O_WRONLY | O_CREAT | O_APPEND, 0666);
      if (fd < 0)
	die("Unable to open log file %s: %m", name);
      close(2);
      dup(fd);
      close(fd);
    }
  log_switching--;
}

static void
vlog(unsigned int cat, const char *msg, va_list args)
{
  time_t tim = time(NULL);
  struct tm *tm = localtime(&tim);
  byte *buf, *p;
  int buflen = 256;
  int l, l0, r;

  log_switch(tm);
  while (1)
    {
      p = buf = alloca(buflen);
      *p++ = cat;
      p += strftime(p, buflen, " %Y-%m-%d %H:%M:%S ", tm);
      if (log_progname[0])
	{
	  if (log_pid)
	    p += sprintf(p, "[%s (%d)] ", log_progname, log_pid);
	  else
	    p += sprintf(p, "[%s] ", log_progname);
	}
      else
	{
	  if (log_pid)
	    p += sprintf(p, "[%d] ", log_pid);
	}
      l0 = p - buf + 1;
      r = buflen - l0;
      l = vsnprintf(p, r, msg, args);
      if (l < 0)
	l = r;
      else if (l < r)
	{
	  while (*p)
	    {
	      if (*p < 0x20 && *p != '\t')
		*p = 0x7f;
	      p++;
	    }
	  *p = '\n';
	  write(2, buf, l + l0);
	  return;
	}
      buflen = l + l0 + 1;
    }
}

void
log_msg(unsigned int cat, const char *msg, ...)
{
  va_list args;

  va_start(args, msg);
  vlog(cat, msg, args);
  va_end(args);
}

void
die(byte *msg, ...)
{
  va_list args;

  va_start(args, msg);
  vlog(L_FATAL, msg, args);
  va_end(args);
  exit(1);
}

#ifdef DEBUG
void
assert_failed(char *assertion, char *file, int line)
{
  log(L_FATAL, "Assertion `%s' failed at %s:%d", assertion, file, line);
  abort();
}
#else
void
assert_failed(void)
{
  die("Internal error: Assertion failed.");
}
#endif

static byte *
log_basename(byte *n)
{
  byte *p = n;

  while (*n)
	if (*n++ == '/')
	  p = n;
  return p;
}

void
log_init(byte *argv0)
{
  if (argv0)
    {
      strncpy(log_progname, log_basename(argv0), sizeof(log_progname)-1);
      log_progname[sizeof(log_progname)-1] = 0;
    }
}

void
log_file(byte *name)
{
  if (name)
    {
      time_t tim = time(NULL);
      struct tm *tm = localtime(&tim);
      if (log_name_patt)
	xfree(log_name_patt);
      if (log_name)
	{
	  xfree(log_name);
	  log_name = NULL;
	}
      log_name_patt = stralloc(name);
      log_params = !!strchr(name, '%');
      log_name_size = strlen(name) + 64;	/* 63 is an upper bound on expansion of % escapes */
      log_name = xmalloc(log_name_size);
      log_name[0] = 0;
      log_switch(tm);
    }
}
