/*
 *	Sherlock Search Engine -- String Index
 *
 *	(c) 1997--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/lfs.h"
#include "lib/fastbuf.h"
#include "lib/url.h"
#include "lib/pools.h"
#include "search/sherlockd.h"
#include "charset/unicode.h"

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

static struct expr *string_analyse(struct query *q, struct expr *e);

static byte *
string_normalize(struct query *q, byte *w, uns types)
{
  byte buf[3*MAX_URL_SIZE];
  int e;
  byte *c;

  if (strlen(w) >= MAX_URL_SIZE-1)
    {
      add_cerr("-115 Word too long");
      eval_err(115);
    }
  if (types & STRING_TYPES_URL)
    {
      if (e = url_auto_canonicalize(w, buf))
	{
	  add_cerr("-112 URL error: %s", url_error(e));
	  eval_err(112);
	}
    }
  else if (types & STRING_TYPES_CASE_INSENSITIVE)
    {
      c = buf;
      while (*w)
	{
	  uns u;
	  GET_UTF8(w, u);
	  u = Utolower(u);
	  PUT_UTF8(c, u);
	}
      *c = 0;
    }
  else
    strcpy(buf, w);

  c = mp_alloc(q->pool, 1 + strlen(buf));
  strcpy(c, buf);
  return c;
}

static struct expr *
string_split(struct query *q, struct expr *e, uns mask)
{
  struct expr *w1, *w2;

  w1 = mp_alloc(q->pool, sizeof(*e));
  *w1 = *e;
  w1->u.match.classmap &= mask;
  w1 = string_analyse(q, w1);

  w2 = mp_alloc(q->pool, sizeof(*e));
  *w2 = *e;
  w2->u.match.classmap &= ~mask;
  w2 = string_analyse(q, w2);

  if (!w1 || !w2)
    return NULL;

  return new_op(EX_OR, w1, w2);
}

static void
string_lookup(struct query *q, struct word *w)
{
  struct database *db = q->dbase;
  struct fingerprint fp;
  uns hash;
  uns buck_start, buck_size;
  byte *bk, *bkend;

  fingerprint(w->word, &fp);
  hash = fp_hash(&fp) >> db->string_hash_order;
  buck_start = db->string_hash[hash];
  buck_size = db->string_hash[hash+1] - buck_start;
  if (!buck_size)
    return;
  bk = mmap_region(q, db->fd_string_map, buck_start, buck_start + buck_size - 1);
  if (!bk)
    return;
  bkend = bk + buck_size;
  while (bk < bkend)
    {
      if (!memcmp(bk, &fp, sizeof(fp)))
	{
	  struct ref_chain *r = q->last_ref++;
	  bk += sizeof(fp);
	  r->u.file.start = GET_O(bk);
	  bk += BYTES_PER_O + sizeof(fp);
	  r->u.file.size = GET_O(bk) - r->u.file.start;
	  r->word_index = w - q->words;
	  r->noaccent_only = 0;
	  r->penalty = 0;
	  r->lang_mask = ~0U;
	  w->ref_count++;
	  w->ref_total_len += r->u.file.size;
	  return;
	}
      bk += sizeof(fp) + BYTES_PER_O;
    }
}

static struct expr *
string_analyse(struct query *q, struct expr *e)
{
  byte *str;
  struct word *w;
  int index;

  if (!q->dbase->string_hash)
    return new_node(EX_NONE);

  uns map = e->u.match.classmap;

  /* Resolve types with different normalization */
  if ((map & STRING_TYPES_URL) && (map & ~STRING_TYPES_URL))
    return string_split(q, e, STRING_TYPES_URL);
  if ((map & STRING_TYPES_CASE_INSENSITIVE) && (map & ~STRING_TYPES_CASE_INSENSITIVE))
    return string_split(q, e, STRING_TYPES_CASE_INSENSITIVE);

  str = string_normalize(q, e->u.match.word, map);
  index = lookup_word(q, e, str);
  w = &q->words[index];
  if (w->weight < e->u.match.o.weight)
    w->weight = e->u.match.o.weight;
  e = new_node(EX_REF_WORD);
  e->u.ref.index = index;

  if (!w->expanded)			/* If not already resolved */
    {
      w->expanded = 2;
      w->is_outer = 1;
      string_lookup(q, w);
    }

  return e;
}

void
string_analyse_simple(struct query *q, clist *l)
{
  struct simple *s;

  CLIST_WALK(s, *l)
    if (s->raw->u.match.is_string)
      s->cooked = string_analyse(q, s->raw);
}

void
strings_init(struct database *db)
{
  uns i;

  if (!db->fn_string_hash || !db->fn_string_map)
    return;
  db->string_hash = mmap_file(db->fn_string_hash, &db->string_hash_file_size, 0);
  db->string_buckets = (db->string_hash_file_size / 4) - 1;
  for (i=1; (1U << i) < db->string_buckets; i++)
    ;
  if ((1U << i) != db->string_buckets)
    die("Invalid string hash size: %d", db->string_buckets);
  db->string_hash_order = 32 - i;
  db->fd_string_map = open(db->fn_string_map, O_RDONLY);
  if (db->fd_string_map < 0)
    die("Unable to open %s: %m", db->fn_string_map);
  db->string_map_file_size = sh_seek(db->fd_string_map, 0, SEEK_END);
  db->string_count = db->string_map_file_size / (sizeof(struct fingerprint) + BYTES_PER_O);
  log(L_INFO, "Loaded string index %s: %d strings, hash order %d",
      db->name,
      db->string_count,
      i);
}
