/*
 *	Sherlock Search Engine -- Query Processing
 *
 *	(c) 1997--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/pools.h"
#include "lib/index.h"
#include "indexer/params.h"
#include "charset/unicode.h"
#include "search/sherlockd.h"

#ifdef CONFIG_LANG
#include "lang/lang.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <setjmp.h>
#include <alloca.h>

struct query *current_query;
struct database *current_dbase;
static jmp_buf query_err_jmp;

/*** Profiling counters ***/

#define P(x) prof_##x
prof_t PROFILERS(COMMA);
prof_t prof_send;
#undef P

static prof_t *profiler_current;

static void
profiler_init(void)
{
  init_timer();
#define P(x) prof_init(&prof_##x)
  PROFILERS(;);	/* Initialize all profilers */
#undef P
  prof_init(&prof_send);
  profiler_current = NULL;
}

static void
profiler_show(struct query *q)
{
#ifdef PROFILER
  byte stats[1024], *x = stats;
#define P(x) str_##x[PROF_STR_SIZE]
  byte PROFILERS(COMMA);
#undef P
#define P(x) prof_format(str_##x, &prof_##x)
  PROFILERS(;);
#undef P
#define P(x) "%.4s=%s"
  x += sprintf(x, PROFILERS(" "),
#undef P
#define P(x) #x, str_##x
	 PROFILERS(COMMA));
#undef P
  if (q->cache_age >= 0)
    x += sprintf(x, " cage:%d", q->cache_age);
  else
    x += sprintf(x, " wrds:%d phrs:%d near:%d chns:%d chKB:%u",
		 q->nwords, q->nphrases, q->nnears,
		 q->stat_num_chains, q->stat_len_chains / 1024);
  uns l = x - stats + 1;
  q->profile_stats = mp_alloc(q->pool, l);
  memcpy(q->profile_stats, stats, l);
  add_qr("T%s", stats);
#endif

  q->time_total = get_timer();
  add_qr("t%d", q->time_total);
}

prof_t *
profiler_switch(prof_t *p)
{
  prof_t *o = profiler_current;
  if (p)
    {
      if (o)
	prof_switch(o, p);
      else
	prof_start(p);
    }
  else if (o)
    prof_stop(o);
  profiler_current = p;
  return o;
}

/*** Debugging dumps ***/

static byte *
format_expr(struct query *q, struct expr *e, byte *buf, byte *bend, uns lastop, uns mode)
{
  if (!buf || buf + 64 > bend)
    return NULL;
  if (!e)
    {
      buf += sprintf(buf, "<null>");
      return buf;
    }
  switch (e->type)
    {
    case EX_MATCH:
      if (buf + 32 + strlen(e->u.match.word) > bend)
	return NULL;
      buf += sprintf(buf, "\"%s\"[C%08x T%d S%d W%d A%d M%d P%d Y%d X%Ld]",
		     e->u.match.word,
		     e->u.match.classmap,
		     e->u.match.is_string,
		     e->u.match.sense,
		     e->u.match.o.weight,
		     e->u.match.o.accent_mode,
		     e->u.match.o.morphing,
		     e->u.match.o.spelling,
		     e->u.match.o.synonyming,
		     e->u.match.o.syn_expand);
      if (e->u.match.next_simple && mode)
	{
	  *buf++ = '.';
	  buf = format_expr(q, e->u.match.next_simple, buf, bend, EX_MATCH, mode);
	}
      break;
    case EX_OPTIONS:
      buf += sprintf(buf, "OPTIONS(W=%d A=%d M=%d P=%d Y=%d X=%Ld ",
		     e->u.options.o.weight,
		     e->u.options.o.accent_mode,
		     e->u.options.o.morphing,
		     e->u.options.o.spelling,
		     e->u.options.o.synonyming,
		     e->u.options.o.syn_expand);
      buf = format_expr(q, e->u.options.inside, buf, bend, EX_OPTIONS, mode);
      if (!buf || buf + 2 >= bend)
	buf = NULL;
      else
	buf += sprintf(buf, ")");
      break;
    case EX_ANY:
      buf += sprintf(buf, "ANY");
      break;
    case EX_NONE:
      buf += sprintf(buf, "NONE");
      break;
    case EX_IGNORE:
      buf += sprintf(buf, "IGNORE");
      break;
    case EX_NOT:
      *buf++ = '!';
      buf = format_expr(q, e->u.op.l, buf, bend, EX_NOT, mode);
      break;
    case EX_AND:
    case EX_OR:
      if (lastop != e->type)
	*buf++ = '(';
      buf = format_expr(q, e->u.op.l, buf, bend, e->type, mode);
      if (!buf || buf + 32 > bend)
	return NULL;
      buf += sprintf(buf, " %c ", (e->type == EX_AND ? '&' : '|'));
      buf = format_expr(q, e->u.op.r, buf, bend, e->type, mode);
      if (buf)
	{
	  if (lastop != e->type)
	    *buf++ = ')';
	  *buf = 0;
	}
      break;
    case EX_REF_WORD:
      buf += sprintf(buf, "REFW(%d)", e->u.ref.index);
      break;
    case EX_REF_PHRASE:
      buf += sprintf(buf, "REFP(%d)", e->u.ref.index);
      break;
    default:
      ASSERT(0);
    }
  return buf;
}

static void
debug_expr(struct query *q, struct expr *e, uns attr)
{
  byte buf[2048];

  if (!(q->debug & DEBUG_ANALYSE))
    return;
  if (!format_expr(q, e, buf, buf+sizeof(buf)-1, EX_RESERVED, 1))
    strcpy(buf, "<too long>");
  add_qr(".%c: %s", attr, buf);
}

static void
debug_simple(struct query *q, clist *l, uns attr)
{
  struct simple *s;
  byte buf[2048], *b=buf, *bend=buf+sizeof(buf)-1;
  uns cnt = 0;

  if (!(q->debug & DEBUG_ANALYSE))
    return;
  CLIST_WALK(s, *l)
    {
      if (b >= bend-2)
	{
	toolong:
	  b = NULL;
	  break;
	}
      if (cnt++)
	*b++ = ' ';
      *b++ = '(';
      if (!(b = format_expr(q, s->raw, b, bend, EX_RESERVED, 0)) || b >= bend)
	goto toolong;
      *b++ = ',';
      if (!(b = format_expr(q, s->cooked, b, bend, EX_RESERVED, 0)) || b >= bend)
	goto toolong;
      *b++ = ')';
    }
  if (b)
    *b = 0;
  else
    strcpy(buf, "<too long>");
  add_qr(".%c: %s", attr, buf);
}

/*** Propagation of query options ***/

static struct expr *
propagate_opts(struct expr *e, struct options *o)
{
  if (!e)
    return e;
  switch (e->type)
    {
    case EX_MATCH:
      merge_options(&e->u.match.o, o, &e->u.match.o);
      e->u.match.next_simple = propagate_opts(e->u.match.next_simple, o);
      return e;
    case EX_OPTIONS:
      merge_options(&e->u.options.o, o, &e->u.options.o);
      return propagate_opts(e->u.options.inside, &e->u.options.o);
    case EX_AND:
    case EX_OR:
    case EX_NOT:
      e->u.op.l = propagate_opts(e->u.op.l, o);
      e->u.op.r = propagate_opts(e->u.op.r, o);
      return e;
    case EX_ANY:
      return e;
    default:
      ASSERT(0);
      return e;
    }
}

static void
process_options(struct query *q)
{
  q->expr = propagate_opts(q->expr, &q->default_options);
}

/*** Generation of normalized string form of the query for cache lookups ***/

static byte *
format_norm_query(struct query *q, byte *buf, uns size)
{
  byte *bend = buf + size - 1;

  buf += sprintf(buf, "[D%08x S%x M%d A%d P%d T%d a%d G%d,%d X%x] ",
		 q->db_mask,
		 q->site_only,
		 q->site_max,
		 q->allow_approx,
		 q->partial_answers,
		 q->custom_sorting ^ q->custom_sort_reverse,
		 q->contains_accents,
		 q->age_raw_min,
		 q->age_raw_max,
		 q->explain_id);
#define INT_ATTR(id,keywd,gf,pf) \
    buf += sprintf(buf, "[" #id "=%d,%d] ", q->id##_min, q->id##_max);
#define SMALL_SET_ATTR(id,keywd,gf,pf) \
    buf += sprintf(buf, "[" #id "=%08x] ", q->id##_set);
  EXTENDED_ATTRS
  FILETYPE_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
  return format_expr(q, q->expr, buf, bend, EX_RESERVED, 1);
}

/*** Reply caching ***/

static clist cache_lru, *cache_hash;
static uns cache_count, hash_size;

void
cache_init(void)
{
  clist_init(&cache_lru);
  hash_size = 1;
  while (hash_size < cache_size)
    hash_size *= 2;
  cache_hash = xmalloc(sizeof(clist) * hash_size);
  for(uns i=0; i<hash_size; i++)
    clist_init(&cache_hash[i]);
}

static uns
cache_hash_fn(byte *x)
{
  struct fingerprint fp;

  fingerprint(x, &fp);
  return fp_hash(&fp) % hash_size;
}

static struct results *
lookup_cache(struct query *q)
{
  byte norm[IOBUF_SIZE];
  uns hash;
  struct results *r;
  time_t now = time(NULL);
  struct mempool *pool;

  if (!format_norm_query(q, norm, sizeof(norm)))
    {
      add_qerr("-101 Normal form of query too long");
      return NULL;
    }
  add_qr(".N: %s", norm);

  hash = cache_hash_fn(norm);
  CLIST_WALK(r, cache_hash[hash])
    if (!strcmp(r->request, norm) && !(q->debug & DEBUG_NOCACHE))
      {
	clist_remove(&r->n);
	clist_add_tail(&cache_lru, &r->n);
	r->access_time = now;
	return r;
      }

  if (cache_count < cache_size)
    {
      pool = mp_new(4096);
      cache_count++;
    }
  else
    {
      r = SKIP_BACK(struct results, n, clist_head(&cache_lru));
      clist_remove(&r->h);
      clist_remove(&r->n);
      pool = r->pool;
      mp_flush(pool);
    }
  r = mp_alloc_zero(pool, sizeof(struct results));
  clist_add_tail(&cache_hash[hash], &r->h);
  clist_add_tail(&cache_lru, &r->n);
  r->pool = pool;
  r->access_time = r->create_time = now;
  r->request = mp_alloc(pool, strlen(norm)+1);
  strcpy(r->request, norm);
  init_reply_buf(&r->rbuf, pool);
  r->status = -1;
  return r;
}

/*** Query analysis ***/

static void
simple_to_list(struct query *q, clist *l, struct expr *e)
{
  struct expr *f;

  clist_init(l);
  while (e)
    {
      struct simple *s = mp_alloc(q->pool, sizeof(struct simple));
      clist_add_tail(l, &s->n);
      s->raw = e;
      s->cooked = NULL;
      f = e->u.match.next_simple;
      e = f;
    }
}

static struct expr *
simple_fold(clist *l)
{
  struct simple *s;
  struct expr *maybes, *sharps;
  uns seen_yes = 0;

  /* Process MAYBE parts of the query */
  maybes = NULL;
  CLIST_WALK(s, *l)
    {
      ASSERT(s->cooked);
      if (!s->raw->u.match.sense && s->cooked->type != EX_IGNORE)
	maybes = maybes ? new_op(EX_OR, maybes, s->cooked) : s->cooked;
    }

  /* Process YES and NO parts */
  sharps = NULL;
  CLIST_WALK(s, *l)
    if (s->raw->u.match.sense && s->cooked->type != EX_IGNORE)
      {
	struct expr *f = (s->raw->u.match.sense > 0) ? s->cooked : new_op(EX_NOT, s->cooked, NULL);
	sharps = sharps ? new_op(EX_AND, sharps, f) : f;
	if (s->raw->u.match.sense > 0)
	  seen_yes++;
      }

  if (!maybes && !sharps)
    {
      add_cerr("-119 Simple search expression contains only non-indexed words");
      eval_err(319);
    }
  if (!maybes || !sharps)
    return maybes ? : sharps;
  if (seen_yes)
    maybes = new_op(EX_OR, new_node(EX_ANY), maybes);
  return new_op(EX_AND, maybes, sharps);
}

static struct expr *
analyse_query(struct query *q, struct expr *e)
{
  struct expr *ll, *rr;
  clist l;

  switch (e->type)
    {
    case EX_MATCH:
      simple_to_list(q, &l, e);
      debug_simple(q, &l, 's');
      string_analyse_simple(q, &l);
      word_analyse_simple(q, &l);
      debug_simple(q, &l, 't');
      e = simple_fold(&l);
      debug_expr(q, e, 'x');
      return analyse_query(q, e);
    case EX_AND:
    case EX_OR:
      ll = analyse_query(q, e->u.op.l);
      rr = analyse_query(q, e->u.op.r);
      if (ll->type == EX_IGNORE)
	return rr;
      if (rr->type == EX_IGNORE)
	return ll;
      if (e->u.op.l != ll || e->u.op.r != rr)
	return new_op(e->type, ll, rr);
      return e;
    case EX_NOT:
      ll = analyse_query(q, e->u.op.l);
      if (ll->type == EX_IGNORE)
	return ll;
      if (e->u.op.l != ll)
	return new_op(e->type, ll, NULL);
      return e;
    default:
      return e;
    }
}

/*** Taking care of words ***/

int
lookup_word(struct query *q, struct expr *e, byte *wd)
{
  uns i;
  struct word *w;

  for (i=0; i<q->nwords; i++)
    {
      w = &q->words[i];
      if (w->type_mask == e->u.match.classmap &&
	  w->is_string == e->u.match.is_string &&
	  w->options.accent_mode == e->u.match.o.accent_mode &&
	  w->options.morphing == e->u.match.o.morphing &&
	  w->options.spelling == e->u.match.o.spelling &&
	  w->options.synonyming == e->u.match.o.synonyming &&
	  w->options.syn_expand == e->u.match.o.syn_expand &&
	  !strcmp(w->word, wd))
	{
	  w->use_count++;
	  return i;
	}
    }
  if (q->nwords >= max_words)
    {
      add_cerr("-103 Too many words");
      eval_err(103);
    }
  w = &q->words[q->nwords++];
  bzero(w, sizeof(*w));
  w->type_mask = e->u.match.classmap;
  w->is_string = e->u.match.is_string;
  memcpy(&w->options, &e->u.match.o, sizeof(struct options));
  w->word = wd;
  w->use_count = 1;
  clist_init(&w->variants);
  return i;
}

void
add_hilited_word(struct query *q, byte *w)
{
  struct results *r = q->results;
  struct hilite_word *h = mp_alloc(r->pool, sizeof(*h) + strlen(w));
  h->next = r->first_hilite;
  r->first_hilite = h;
  strcpy(h->w, w);
}

static void
debug_words(struct query *q)
{
  for (uns i=0; i<q->nwords; i++)
    {
      struct word *w = &q->words[i];
      add_qr(".W%d: <%s> class=%08x is_string=%d outer=%d wei=%d acc=%d mor=%d spl=%d syn=%d sex=%Lx stat=%d docs=%d refs=%d vars=%d wcl=%d uc=%d hc=%d wild=%d",
	     i,
	     w->word,
	     w->type_mask,
	     w->is_string,
	     w->is_outer,
	     w->weight,
	     w->options.accent_mode,
	     w->options.morphing,
	     w->options.spelling,
	     w->options.synonyming,
	     w->options.syn_expand,
	     w->status,
	     w->doc_count,
	     w->ref_count,
	     w->var_count,
	     w->word_class,
	     w->use_count,
	     w->hide_count,
	     w->is_wild);
    }
  for (uns i=0; i<q->nphrases; i++)
    {
      struct phrase *p = &q->phrases[i];
      byte buf[1024], *z = buf;
      for (uns j=0; j<p->length; j++)
	z += sprintf(z, "(%d,%d%s)",
		     p->word[j],
		     p->relpos[j],
		     (p->prox_map & (1 << j)) ? "+" : "");
      *z = 0;
      add_qr(".P: W%d [%s]", p->weight, buf);
    }
  for (uns i=0; i<q->nnears; i++)
    {
      struct phrase *p = &q->nears[i];
      byte buf[1024], *z = buf;
      for (uns j=0; j<p->length; j++)
	z += sprintf(z, "(%d,%d)",
		     p->word[j],
		     p->relpos[j]);
      *z = 0;
      add_qr(".n: [%s]", buf);
    }
}

/*** Check words for errors and assign word ids ***/

static void
check_words(struct query *q)
{
  uns i, j, id;

  id = 0;
  for (i=0; i<q->nwords; i++)
    {
      struct word *w = &q->words[i];
      if (w->use_count && w->status && !q->allow_approx)
	{
	  switch (w->status)
	    {
	    case 105:
	      add_cerr("-105 Too many word matches for <%s>", w->word);
	      break;
	    case 111:
	      add_cerr("-111 Wildcard pattern too long");
	      break;
	    case 113:
	      add_cerr("-113 Maximum wildcard zone exceeded");
	      break;
	    case 114:
	      add_cerr("-114 Wildcard prefix <%s> too short", w->word);
	      break;
	    case 116:
	      add_cerr("-116 Word <%s> not indexed", w->word);
	      break;
	    default:
	      add_cerr("-%d Unknown error for word <%s>", w->status, w->word);
	    }
	  eval_err(w->status + 200);
	}
      word_add_hilites(q, w);
      if (w->ref_count)
	w->boolean_id = id++;
    }
  for (i=0; i<q->nphrases; i++)
    {
      struct phrase *p = &q->phrases[i];
      p->word_mask = 0;
      for (j=0; j<p->length; j++)
	p->word_mask |= 1 << q->words[p->word[j]].boolean_id;
      p->boolean_id = id++;
    }
  for (i=0; i<q->nnears; i++)
    {
      struct phrase *p = &q->nears[i];
      p->word_mask = 0;
      for (j=0; j<p->length; j++)
	p->word_mask |= 1 << q->words[p->word[j]].boolean_id;
    }
  if (id >= max_bools)
    {
      add_cerr("-118 Boolean expression too complex");
      eval_err(118);
    }
  q->n_bool_ids = id;
}

/*** Shortcut checks ***/

static int
shortcut(struct query *q, struct expr *e)
{
  int i,j;

  /* Genuine tri-state logic: 1=yes, -1=no, 0=maybe */
  switch (e->type)
    {
    case EX_REF_WORD:
      return q->words[e->u.ref.index].ref_count ? 0 : -1;
    case EX_AND:
      i = shortcut(q, e->u.op.l);
      j = shortcut(q, e->u.op.r);
      return MIN(i, j);
    case EX_OR:
      i = shortcut(q, e->u.op.l);
      j = shortcut(q, e->u.op.r);
      return MAX(i, j);
    case EX_NOT:
      return -shortcut(q, e->u.op.l);
    case EX_ANY:
      return 1;
    case EX_NONE:
      return -1;
    case EX_REF_PHRASE:
      return 0;
    default:
      ASSERT(0);
      return -1;
    }
}

static void
check_shortcut(struct query *q, struct expr *e)
{
  int err = shortcut(q, e);

  if (err < 0)
    {
      add_cr(". Shortcut: no solutions");
      eval_err(1);
    }
  if (err > 0)
    {
      add_cerr("-104 All documents match");
      eval_err(304);
    }
}

/*** Boolean expression evaluation ***/

static u32 *bool_map_buf;
static uns bool_bytes;

static void
map_bool(struct query *q, struct expr *x, u32 *Z)
{
  u32 *X, *Y;
  uns c, i;

  switch (x->type)
    {
    case EX_AND:
    case EX_OR:
      X = alloca(bool_bytes);
      Y = alloca(bool_bytes);
      map_bool(q, x->u.op.l, X);
      map_bool(q, x->u.op.r, Y);
      if (x->type == EX_AND)
	for(c=0; c<bool_bytes; c += sizeof(u32))
	  *Z++ = *X++ & *Y++;
      else
	for(c=0; c<bool_bytes; c += sizeof(u32))
	  *Z++ = *X++ | *Y++;
      break;
    case EX_NOT:
      X = alloca(bool_bytes);
      map_bool(q, x->u.op.l, X);
      for(c=0; c<bool_bytes; c += sizeof(u32))
	*Z++ = ~*X++;
      break;
    case EX_REF_PHRASE:
      i = q->phrases[x->u.ref.index].boolean_id;
      goto got_id;
    case EX_REF_WORD:
      ASSERT(q->words[x->u.ref.index].use_count);
      if (!q->words[x->u.ref.index].ref_count)
	{
	  memset(Z, 0, bool_bytes);
	  break;
	}
      i = q->words[x->u.ref.index].boolean_id;
    got_id:
      if (i < 5)			/* Fits in u32 */
	{
	  uns k = 1 << i;
	  uns t;
	  u32 j = 0;
	  for(t=0; t < 32; t++)
	    if (t & k)
	      j |= 1 << t;
	  for(c=0; c<bool_bytes; c += sizeof(u32))
	    *Z++ = j;
	}
      else
	{
	  uns per = 1 << (i - 5);
	  uns t = 2*per*sizeof(u32);
	  for(c=0; c<bool_bytes; c += t)
	    {
	      for(i=0; i<per; i++)
		*Z++ = 0;
	      for(i=0; i<per; i++)
		*Z++ = ~0;
	    }
	}
      break;
    case EX_ANY:
      memset(Z, 255, bool_bytes);
      break;
    case EX_NONE:
      memset(Z, 0, bool_bytes);
      break;
    default:
      die("Lost in mist and scared of seeing ghost #%d", x->type);
    }
}

static void
construct_bool(struct query *q, struct expr *x)
{
  uns c;

  if (q->n_bool_ids <= 5)
    bool_bytes = sizeof(u32);
  else
    bool_bytes = 1 << (q->n_bool_ids - 3);
  DBG("Constructing boolean expression map of size %d", bool_bytes);
  map_bool(q, x, bool_map_buf);

  if (bool_map_buf[0] & 1)
    {
      add_cerr("-104 All documents match");
      eval_err(304);
    }
  for (c=0; c<bool_bytes/4; c++)
    if (bool_map_buf[c])
      {
	q->bool_map = bool_map_buf;
	return;
      }
  add_cr(". Boolean check: no solutions");
  eval_err(1);
}

/*** Constructing boolean expression for optimistic matching ***/

static u32 *optimistic_bool_map_buf;

static struct expr *
optimistic_expr(struct expr *x)
{
  struct expr *l, *r;

  switch (x->type)
    {
    case EX_REF_WORD:
      return x;
    case EX_REF_PHRASE:
    case EX_NOT:
      return NULL;
    case EX_ANY:
    case EX_NONE:
      return x;
    case EX_AND:
    case EX_OR:
      l = optimistic_expr(x->u.op.l);
      r = optimistic_expr(x->u.op.r);
      if (!l)
	return r;
      if (!r)
	return l;
      if (l == x->u.op.l && r == x->u.op.r)
	return x;
      return new_op(x->type, l, r);
    default:
      ASSERT(0);
    }
}

static void
construct_optimistic_bool(struct query *q, struct expr *x)
{
  x = optimistic_expr(x) ? : new_op(EX_ANY, NULL, NULL);
  debug_expr(q, x, 'O');
  map_bool(q, x, optimistic_bool_map_buf);
  q->optimistic_bool_map = optimistic_bool_map_buf;
}

/*** Display query statistics ***/

static void
format_phrase_stat(struct query *q, byte *x, struct phrase *p)
{
  for (uns j=0; j<p->length; j++)
    {
      if (j)
	*x++ = ' ';
      for (uns k=2; k<=p->relpos[j]; k++)
	{
	  *x++ = '*';
	  *x++ = ' ';
	}
      struct word *w = &q->words[p->word[j]];
      if (w->root)
	w = w->root;
      for (byte *c=w->word; *c;)
	*x++ = *c++;
    }
  *x = 0;
}

static void
show_query_stats(struct query *q)
{
  for (uns i=0; i<q->nwords; i++)
    {
      struct word *w = &q->words[i];
      if (w->use_count && (w->use_count != w->hide_count || w->doc_count))
	{
	  /* We need to avoid spaces in complexes, so convert them to non-breakable spaces */
	  byte disp[strlen(w->word) + 2];
	  byte *pp = w->word;
	  byte *qq = disp;
	  while (*qq++ = *pp++)
	    if (qq[-1] == ' ')
	      {
		qq--;
		PUT_UTF8(qq, 0xa0);
	      }
	  add_cr("W%s %d %d %d %d %d%d%08x%d%d%d%Lx", disp, w->ref_count, w->ref_total_len / 1024,
		 (q->results->status ? (w->ref_count ? -1 : 0) : (int)w->doc_count),
		 w->status, w->is_string, w->options.accent_mode, w->type_mask,
		 w->options.morphing, w->options.spelling, w->options.synonyming, w->options.syn_expand);
	  q->stat_num_chains += w->ref_count;
	  q->stat_len_chains += w->ref_total_len;
	}
    }
  for (uns i=0; i<q->nphrases; i++)
    {
      struct phrase *p = &q->phrases[i];
      byte pbuf[MAX_PHRASE_LEN*(MAX_WORD_LEN+10)];
      format_phrase_stat(q, pbuf, p);
      add_cr("P\"%s\" %d", pbuf, p->matches);
    }
  for (uns i=0; i<q->nnears; i++)
    {
      struct phrase *p = &q->nears[i];
      byte pbuf[MAX_PHRASE_LEN*(MAX_WORD_LEN+10)];
      format_phrase_stat(q, pbuf, p);
      add_cr("n\"%s\" %d", pbuf, p->matches);
    }
  add_cr("T%d", q->matching_docs);
  q->matching_docs = 0;
#ifdef CONFIG_FILETYPE
  byte ftbuf[8+8*MAX_FILE_TYPES], *z = ftbuf;
  for (uns i=0; i<MAX_FILE_TYPES; i++)
    z += sprintf(z, " %s=%d", custom_file_type_names[i], q->matching_per_type[i]);
  add_cr("t%s", ftbuf+1);
#endif
}

/*** Top-level query processing ***/

static struct word *word_buffer;
static struct phrase *phrase_buffer;
static struct phrase *near_buffer;
static struct ref_chain *ref_buffer;

static int
eval_query_db(struct query *q)
{
  struct expr *e;
  struct results *r = q->results;
  int status;

  if (status = setjmp(query_err_jmp))
    return status;

  db_switch_config(q->dbase);
  q->words = word_buffer;
  q->nwords = 0;
  q->first_ref = q->last_ref = ref_buffer;
  q->phrases = phrase_buffer;
  q->nphrases = 0;
  q->nears = near_buffer;
  q->nnears = 0;
  q->age_min = convert_age(r->create_time - MIN(r->create_time,q->age_raw_min), q->dbase->params->ref_time);
  q->age_max = convert_age(r->create_time - MIN(r->create_time,q->age_raw_max), q->dbase->params->ref_time);
  e = analyse_query(q, q->expr);
  if (e->type == EX_IGNORE)
    e->type = EX_ANY;
  debug_expr(q, e, 'A');
  debug_words(q);
  spell_check(q);
  check_words(q);
  check_shortcut(q, e);
  construct_bool(q, e);
  construct_optimistic_bool(q, e);
  process_refs(q);
  return 0;
}

void
eval_err(int code)
{
  longjmp(query_err_jmp, code);
}

static void
eval_query(struct query *q, struct results *r)
{
  uns i, status;
  uns successful_dbs = 0;
  struct reply *first_error = NULL;
  uns first_err_code = 0;

  r->status = 0;
  cache_rbuf = &r->rbuf;

  query_init_refs(q);
  debug_expr(q, q->expr, 'S');
  for (q->dbase=databases, i=0; q->dbase && !r->status; q->dbase=q->dbase->next, i++)
    if (q->db_mask & (1 << i))
      {
	current_dbase = q->dbase;
	add_cr("(D");
	add_cr("D%s", current_dbase->name);
	add_cr("N%d", current_dbase->num_ids);
	add_cr("I%d", current_dbase->params->objects_in);
	add_cr("L%d", (int) current_dbase->params->ref_time);
	status = eval_query_db(q);
	if (status < 100)	/* OK or no solution */
	  {
	    r->status = status;
	    successful_dbs++;
	  }
	else if (status >= 300 && q->partial_answers)
	  {
	    /* Partial answer: Move the status message at the end */
	    struct reply *err = first_reply_last(&r->rbuf);
	    if (!first_error)
	      {
		first_error = err;
		first_err_code = status - 200;
	      }
	  }
	else
	  r->status = (status >= 300) ? (status - 200) : status;
	show_query_stats(q);
	memory_flush(q);
	add_cr(")");
      }
  if (!successful_dbs && first_error)
    {
      char buf[first_error->len];
      memcpy(buf, first_error->text, first_error->len);
      buf[first_error->len - 1] = 0;
      add_cerr(buf);
      r->status = first_err_code;
    }
  if (r->status < 100)
    {
      query_finish_refs(q);
      add_cerr("+000 OK");
    }
}

void
query_init(void)
{
  if (max_words > HARD_MAX_WORDS)
    die("MaxWords (%d) > HARD_MAX_WORDS (%d)", max_words, HARD_MAX_WORDS);
  word_buffer = xmalloc(sizeof(struct word) * max_words);
  phrase_buffer = xmalloc(sizeof(struct phrase) * max_phrases);
  if (max_nears)
    near_buffer = xmalloc(sizeof(struct phrase) * max_nears);
  ref_buffer = xmalloc(sizeof(struct ref_chain) * max_words * max_word_matches);
  bool_bytes = 1 << (MAX(5, max_bools) - 3);
  bool_map_buf = xmalloc(bool_bytes);
  optimistic_bool_map_buf = xmalloc(bool_bytes);
}

static void
init_query(struct query *q)
{
  q->db_mask = ~0;
  q->debug = global_debug;
  struct options *o = &q->default_options;
  o->accent_mode = global_accent_mode;
  o->weight = word_bonus;
  o->morphing = global_morphing;
  o->spelling = global_spelling;
  o->synonyming = global_synonyming;
  o->syn_expand = (global_syn_expand >= 0x80000000) ? ~0ULL : global_syn_expand;
  q->context_chars = global_context_chars;
  q->title_chars = global_title_chars;
  q->intervals = global_intervals;
  q->site_max = global_site_max;
  q->url_max = global_url_max;
  q->partial_answers = global_partial_answers;
  q->allow_approx = global_allow_approx;
  q->age_raw_max = ~0U;
#define INT_ATTR(id,keywd,gf,pf) q->id##_max = ~0U;
#define SMALL_SET_ATTR(id,keywd,gf,pf) q->id##_set = ~0U;
  EXTENDED_ATTRS
  FILETYPE_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
  q->custom_sorting = global_sorting;
  q->custom_sort_reverse = global_sort_reverse;
}

static void
tidy_query(struct query *q UNUSED)
{
#ifdef CONFIG_LANG
  q->lang_set |= 1 << LANG_NONE;
#endif
}

void
process_query(struct query *q)
{
  byte *err;
  struct results *r;

  current_query = q;
  query_rbuf = &q->rbuf;
  cache_rbuf = NULL;
  init_query(q);

  profiler_init();
  profiler_switch(&prof_analyse);
  add_qr("V" SHER_VER);
  if (!q->iobuf[0])
    {
      add_qerr("-102 Empty request");
      return;
    }
  q->contains_accents = contains_accents(q->iobuf);
  if (err = parse_query(q->iobuf))
    {
      if (err[0] == '-')
	add_qerr("%s", err);
      else
	add_qerr("-102 %s", err);
      return;
    }
  if (!q->expr)
    {
      do_command(q);
      return;
    }
  if (check_result_set(q))
    return;
  tidy_query(q);

  debug_expr(q, q->expr, 'I');
  process_options(q);
  q->results = lookup_cache(q);

  if (r = q->results)
    {
      if (r->status >= 0)
	{
	  q->cache_age = r->access_time - r->create_time;
	  add_qr("C%d", q->cache_age);
	}
      else
	{
	  q->cache_age = -1;
	  eval_query(q, r);
	}
      ship_reply_buf(q, &r->rbuf);
      q->q_status = r->status;
    }
  flush_reply_buf(q, &q->rbuf);
  reply_f("%s", "");	/* Avoid format string warning */
  if (r && !r->status)
    show_results(q);
  reply_f("+");
  profiler_switch(NULL);
  profiler_show(q);
}
