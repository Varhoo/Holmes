/*
 *	Sherlock Gatherer: Calling External Parsers
 *
 *	(c) 2003 Robert Spalek <robert@ucw.cz>
 *
 *	Pieces of code taken from gather/format/validate.c by
 *
 *	(c) 2002 Martin Mares <mj@ucw.cz>
 */

#undef	LOCAL_DEBUG

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/lists.h"
#include "lib/fastbuf.h"
#include "gather/gather.h"

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

#define	MAX_PARAMETERS	16
struct parser {
  struct node n;
  byte *source_ct;
  byte *dest_ct;
  byte *command[MAX_PARAMETERS+1];
};

static struct list parsers;

static byte *
add_external_parser(struct cfitem *c UNUSED, byte *l)
{
  struct parser *p = cfg_malloc(sizeof(struct parser));
  byte *w[MAX_PARAMETERS+2];
  int pars = wordsplit(l, w, MAX_PARAMETERS+2);
  if (pars < 0)
    return "Too many parameters of the parser";
  p->source_ct = w[0];
  p->dest_ct = w[1];
  DBG("Added parser %s -> %s: ", p->source_ct, p->dest_ct);
  for (int i=2; i<pars; i++)
  {
    DBG("%d: %s", i-2, w[i]);
    p->command[i-2] = w[i];
  }
  p->command[pars-2] = NULL;
  add_tail(&parsers, &p->n);
  /* Hack: insert this parser also into the main list of parsers.  */
  struct cfitem cf;
  byte *value = cfg_malloc(strlen(p->source_ct) + 20);
  cf.name = "T";
  sprintf(value, "%s external", p->source_ct);
  return parse_add_hook(&cf, value);
}

static struct cfitem external_config[] = {
  { "ExternalParser",	CT_SECTION,	NULL },
  { "AddParser",	CT_FUNCTION,	&add_external_parser },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR external_init(void)
{
  cf_register(external_config);
  init_list(&parsers);
}

static void
parser_parent(int srcfd, int resfd)
{
  struct fastbuf *in, *out;
  in = fbmem_clone_read(gthis->contents);
  bclose(gthis->contents);
  out = gthis->contents = fbmem_create(16384);
  fcntl(srcfd, F_SETFL, fcntl(srcfd, F_GETFL, 0) | O_NONBLOCK);
  fcntl(resfd, F_SETFL, fcntl(resfd, F_GETFL, 0) | O_NONBLOCK);

  fd_set rset, wset;
  FD_ZERO(&rset);
  FD_ZERO(&wset);
  DBG("Transferring data to/from the parser");
  for(;;)
    {
      int nfd = MAX(srcfd, resfd) + 1;
      int len;
      byte *buf;
      if (srcfd >= 0)
	FD_SET(srcfd, &wset);
      FD_SET(resfd, &rset);
      if (select(nfd, &rset, &wset, NULL, NULL) < 0)
	die("select: %m");
      if (srcfd >= 0 && FD_ISSET(srcfd, &wset))
	{
	  len = bdirect_read_prepare(in, &buf);
	  if (len > 0)
	    {
	      len = write(srcfd, buf, len);
	      DBG("Written %d bytes", len);
	      if (len < 0)
		gerror(2601, "Error writing parser input: %m");
	      bdirect_read_commit(in, buf+len);
	    }
	  else
	    {
	      FD_CLR(srcfd, &wset);
	      close(srcfd);
	      DBG("Closed output stream");
	      srcfd = -1;
	    }
	}
      if (FD_ISSET(resfd, &rset))
	{
	  len = bdirect_write_prepare(out, &buf);
	  len = read(resfd, buf, len);
	  DBG("Read %d bytes", len);
	  if (len < 0)
	    gerror(2601, "Error reading parser output: %m");
	  if (!len)
	    break;
	  bdirect_write_commit(out, buf+len);
	}
    }
  if (srcfd >= 0)
    close(srcfd);
  close(resfd);
  bclose(in);
  bflush(out);
}

static void
parser_child(byte **command, int srcfd, int resfd)
{
  dup2(srcfd, 0);
  dup2(resfd, 1);
  dup2(resfd, 2);
  close(srcfd);
  close(resfd);
  execvp(command[0], (char **) command);
  die("execvp(%s): %m", command[0]);
}

int
external_parse(void)
{
  struct parser *p, *found = NULL;

  WALK_LIST(p, parsers)
    if (!strcmp(gthis->content_type, p->source_ct))
    {
      found = p;
      break;
    }
  if (!found)
    die("No parser is tied to content-type %s", gthis->content_type);

  int pipesrc[2], piperes[2];
  if (pipe(pipesrc) || pipe(piperes))
    die("pipe: %m");
  pid_t pid = fork();
  if (pid < 0)
    die("fork: %m");
  else if (pid > 0)
  {
    close(pipesrc[0]);
    close(piperes[1]);
    signal(SIGPIPE, SIG_IGN);
    parser_parent(pipesrc[1], piperes[0]);
    int status;
    pid_t p = wait(&status);
    if (p != pid)
      die("wait: received pid %d instead of %p", p, pid);
    if (!WIFEXITED(status))
      gerror(2203, "External parser crashed with status %x", status);
  }
  else
  {
    log_fork();
    close(pipesrc[1]);
    close(piperes[0]);
    parser_child(p->command, pipesrc[0], piperes[1]);
  }
  gthis->content_type = p->dest_ct;
  gthis->file_name = "";	// avoid detection of the same content-type
  return 0;
}
