/*
 *	Sherlock Gatherer -- Simple Testing Program
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/url.h"
#include "gather/gather.h"

#include <setjmp.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

static jmp_buf gath_err_jmp;

static void
error_hook(void)
{
  alarm(0);				/* To be sure */
  longjmp(gath_err_jmp, 1);
}

static void
set_url(byte *u)
{
  struct url cwurl, url;
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE], buf3[MAX_URL_SIZE], buf4[MAX_URL_SIZE], buf5[MAX_URL_SIZE];
  int e;

  if (!getcwd(buf1, sizeof(buf1) - 25))
    die("Cannot get cwd: %m");
  strcat(buf1, "/.");
  cwurl.protocol = "file";
  cwurl.protoid = URL_PROTO_FILE;
  cwurl.user = NULL;
  cwurl.pass = NULL;
  cwurl.host = "localhost";
  cwurl.port = ~0;
  cwurl.rest = buf1;

  if ((e = url_deescape(u, buf2)) ||
      (e = url_split(buf2, &url, buf3)) ||
      (e = url_normalize(&url, &cwurl)) ||
      (e = url_canonicalize(&url)) ||
      (e = url_pack(&url, buf4)) ||
      (e = url_enescape(buf4, buf5)))
    die("URL error on %s: %s", u, url_error(e));
  gthis->url = gstrdup(buf5);
}

static char *options = CF_SHORT_OPTS "adfiqrstL:E:P:T:";

static char *help = "\
Usage: gtest <options> <URL>\n\
\n\
Options:\n"
CF_USAGE
"-a\t\tAvoid filtering (undefines Gather.Filter)\n\
-d\t\tStop after downloading the document\n\
-f\t\tTest filters only\n\
-i\t\tAvoid initial content-type filtering\n\
-q\t\tResolve queue key only\n\
-r\t\tRefresh, original version passed on stdin\n\
-s\t\tTest charset detection instead of parsing\n\
-t\t\tTest content type detection instead of parsing\n\
-tt\t\tTest content type detection before downloading only\n\
-L <lang>\tForce language\n\
-E <enc>\tForce content encoding\n\
-P <set>\tForce charset\n\
-T <type>\tForce content type\n\
";

static int mode_dwnonly;
static int mode_charset;
static int mode_type;
static byte *force_ctype;
static byte *force_cenc;
static byte *force_charset;
static byte *force_language;
static int mode_qkey;
static int avoid_trans;
static int mode_filter_only;
static int mode_refresh;
static int kill_filter;

static void NONRET
usage(void)
{
  fputs(help, stderr);
  exit(1);
}

int
main(int argc, char **argv)
{
  struct fastbuf *b;
  int opt;

  log_init("gtest");
  while ((opt = cf_getopt(argc, argv, options, CF_NO_LONG_OPTS, NULL)) >= 0)
    switch (opt)
      {
      case 'a':
	kill_filter = 1;
	break;
      case 'd':
	mode_dwnonly = 1;
	break;
      case 'f':
	mode_filter_only = 1;
	break;
      case 'i':
	avoid_trans = 1;
	break;
      case 'r':
	mode_refresh = 1;
	break;
      case 's':
	mode_charset = 1;
	break;
      case 't':
	mode_type++;
	break;
      case 'L':
	force_language = optarg;
	break;
      case 'E':
	force_cenc = optarg;
	break;
      case 'P':
	force_charset = optarg;
	break;
      case 'T':
	force_ctype = optarg;
	break;
      case 'q':
	mode_qkey = 1;
	break;
      default:
	usage();
      }
  if (optind != argc - 1)
    usage();

  if (kill_filter)
    gather_filter_name = NULL;
  gatherer_init();
  gthis = gobj_new(NULL);
  gthis->error_hook = error_hook;
  set_url(argv[optind]);
  if (mode_refresh)
    {
      b = bfdopen_shared(0, 4096);
      gthis->refreshing = obj_new(gthis->pool);
      obj_read(b, gthis->refreshing);
      bclose(b);
    }
  if (!setjmp(gath_err_jmp))
    {
      gthis->url = gobj_parse_url(&gthis->url_s, gthis->url, "document", 0);
      if (mode_qkey)
	create_key();
      if (mode_filter_only)
	gather_filter();
      else if (mode_type < 2)
	download();
      if (force_charset)
	gthis->charset = force_charset;
      if (force_ctype)
	{
	  if (avoid_trans)
	    gthis->content_type = force_ctype;
	  else
	    set_content_type(force_ctype);
	}
      if (force_cenc)
	{
	  if (avoid_trans)
	    gthis->content_encoding = force_cenc;
	  else
	    set_content_encoding(force_cenc);
	}
      if (force_language)
	gthis->language = force_language;
      if (mode_dwnonly || mode_filter_only)
	;
      else if (mode_charset)
	convert_charset(NULL);
      else if (mode_type)
	guess_content();
      else
	parse();
      if (mode_refresh)
	gobj_check_really_new();
      gthis->error_msg = "OK";
    }
  b = bfdopen_shared(1, 4096);
  gobj_write(b, -1);
  bclose(b);
  gobj_free(gthis);

  return 0;
}
