/*
 *	Sherlock Gatherer -- Gathering Objects
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/fastbuf.h"
#include "lib/pools.h"
#include "lib/chartype.h"
#include "lib/md5.h"
#include "lib/base224.h"
#include "lib/index.h"
#include "lib/tagged-text.h"
#include "gather/gather.h"

#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <time.h>

struct gobject *gthis;		/* Current gatherer object we're working on */

void
gatherer_init(void)		/* Before using libgather, you need to call this function */
{
  gather_init_filter();
}

struct gobject *
gobj_new(struct mempool *pool)
{
  struct gobject *g;

  if (!pool)
    pool = mp_new(4096);
  g = mp_alloc_zero(pool, sizeof(struct gobject));
  g->pool = pool;
  g->aa = obj_new(pool);
  init_list(&g->ref_list);
  g->download_time = time(NULL);
  return g;
}

void
gobj_free(struct gobject *g)
{
  bclose(g->contents);
  bclose(g->text);
  bclose(g->meta);
  bclose(g->thumbnail);
  bclose(g->temp);
  mp_delete(g->pool);
}

byte *
gstrdup(byte *s)
{
  int l;
  byte *n;

  if (!s)
    return s;
  l = strlen(s) + 1;
  n = mp_alloc_fast_noalign(gthis->pool, l);
  memcpy(n, s, l);
  return n;
}

void
gerror(int code, char *msg, ...)
{
  va_list args;
  byte buf[2048];			/* A URL must fit here */
  int n;

  va_start(args, msg);
  n = vsnprintf(buf, sizeof(buf), msg, args);
  if (n >= (int) sizeof(buf) || n < 0)
    die("gerror: message too long");
  gthis->error_code = code;
  gthis->error_msg = gstrdup(buf);
  va_end(args);
  gthis->error_hook();
  die("error_hook has returned");
}

static void
gobj_calc_fb_sum(byte *md5, struct fastbuf *f)
{
  struct MD5Context m;
  byte block[4096];
  uns len;

  MD5Init(&m);
  f = fbmem_clone_read(f);
  while (len = bread(f, block, sizeof(block)))
    MD5Update(&m, block, len);
  bclose(f);
  MD5Final(md5, &m);
}

void
gobj_calc_sum(void)
{
  if (gthis->error_code || !min_summed_size || gthis->orig_size < min_summed_size)
    return;
  gobj_calc_fb_sum(gthis->MD5, gthis->contents);
  gthis->MD5_valid = 1;
}

static void
gobj_write_str(struct fastbuf *b, int type, byte *s)
{
  if (!s)
    return;
  bputc(b, type);
  bputs(b, s);
  bputc(b, '\n');
}

static void
gobj_write_num(struct fastbuf *b, int type, unsigned int n)
{
  byte buf[32];
  if (!n)
    return;
  sprintf(buf, "%d", n);
  bputc(b, type);
  bputs(b, buf);
  bputc(b, '\n');
}

static void
gobj_write_stream(struct fastbuf *b, int type, struct fastbuf *f)
{
  int w = 0;
  int c;

  if (!f)
    return;
  f = fbmem_clone_read(f);
  while ((c = bgetc(f)) >= 0)
    {
      if (w > 256 && (c <= ' ' || (c >= 0x80 && c < 0xa0)) || w > 512)
	{
	  bputc(b, '\n');
	  w = 0;
	  if (c <= ' ')
	    continue;
	}
      if (!w)
	bputc(b, type);
      bputc(b, c);
      if (c == '\n')
	w = 0;
      else
	w++;
      if (c >= 0xc0)
	{
	  /* Copy the whole UTF-8 character to avoid line breaks inside */
	  while (c & 0x40)
	    {
	      bputc(b, bgetc(f));
	      c <<= 1;
	      w++;
	    }
	}
      else if (c >= 0xa0 && c < 0xb0)
	{
	  c = bgetc(f);
	  ASSERT(c >= 0x80);
	  bputc(b, c);
	  w++;
	}
    }
  if (w)
    bputc(b, '\n');
  bclose(f);
}

static void
gobj_write_base224_stream(struct fastbuf *b, int type, struct fastbuf *f)
{
  byte ib[BASE224_IN_CHUNK*6], ob[BASE224_OUT_CHUNK*6];
  uns l;

  if (!f)
    return;
  f = fbmem_clone_read(f);
  while (l = bread(f, ib, sizeof(ib)))
    {
      l = base224_encode(ob, ib, l);
      bputc(b, type);
      bwrite(b, ob, l);
      bputc(b, '\n');
    }
  bclose(f);
}

static void
gobj_write_sum(struct fastbuf *b)
{
  byte sum[MD5_HEX_SIZE];

  if (!gthis->MD5_valid)
    return;
  md5_to_hex(gthis->MD5, sum);
  gobj_write_str(b, 'C', sum);
}

static void
gobj_write_ref(struct fastbuf *b, struct gobj_ref *ref)
{
  byte id[16];

  bputc(b, ref->type);
  bputs(b, ref->url);
  sprintf(id, " %d", ref->id);
  bputs(b, id);
  if (ref->dont_follow || gthis->dont_follow_links)
    bputs(b, " 1");
  bputc(b, '\n');
}

static void
gobj_write_meta_stream(struct fastbuf *b, struct fastbuf *f)
{
  if (!f)
    return;
  f = fbmem_clone_read(f);
  uns c, len = 0;
  while ((c = bget_tagged_char(f)) != ~0U)
    {
      if (c >= 0x80000000)
	{
	  ASSERT(c >= 0x80000090 && c < 0x80010000);
	  if (len)
	    bputc(b, '\n');
	  bputc(b, 'M');
	  bputc(b, c);
	  len = 1;
	}
      else
	{
	  ASSERT(len);
	  if (len > 512)
	    continue;
	  if (c <= ' ')
	    {
	      if (len > 256)
		{
		  len = 513;
		  continue;
		}
	      c = ' ';
	    }
	  bput_utf8(b, c);
	  len += UTF8_SPACE(c);
	}
    }
  if (len)
    bputc(b, '\n');
  bclose(f);
}

void
gobj_write(struct fastbuf *b, int trim)
{
  byte buf[32];
  struct gobj_ref *ref;

  gobj_write_str(b, 'U', gthis->url);
  gobj_write_str(b, 'v', "1");
  gobj_write_num(b, 'D', gthis->download_time);
  gobj_write_num(b, 'L', gthis->lastmod_time);
  gobj_write_num(b, 'e', gthis->expires_time);
  gobj_write_str(b, 'E', gthis->content_encoding);
  gobj_write_str(b, 'T', gthis->content_type);
  gobj_write_str(b, 'S', gthis->http_server);
  gobj_write_str(b, 'g', gthis->etag);
  gobj_write_str(b, 'c', gthis->charset);
  gobj_write_str(b, 'l', gthis->language);
  gobj_write_num(b, 's', gthis->orig_size);
  if (gthis->truncated)
	  gobj_write_str(b, '.', "Truncated");
  gobj_write_sum(b);
  WALK_LIST(ref, gthis->ref_list)
    gobj_write_ref(b, ref);
  obj_write(b, gthis->aa);
  gobj_write_meta_stream(b, gthis->meta);
  if (trim < 0 && gthis->content_type && !strncasecmp(gthis->content_type, "text/", 5))
    gobj_write_stream(b, 'Z', gthis->contents);
  if (trim <= 0 && !gthis->dont_save_contents)
    {
      gobj_write_stream(b, 'X', gthis->text);
      gobj_write_base224_stream(b, 'N', gthis->thumbnail);
    }
  sprintf(buf, "!%04d ", gthis->error_code);
  bputs(b, buf);
  bputs(b, gthis->error_msg ?: (byte *)"OK");
  bputc(b, '\n');
}

byte *
gobj_parse_url(struct url *url, byte *u, byte *msg, uns allow_rel)
{
  int e;
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE], buf3[MAX_URL_SIZE], buf4[MAX_URL_SIZE];
  struct url ur;

  if ((e = url_deescape(u, buf1)) ||
      (e = url_split(buf1, &ur, buf2)))
    goto urlerr;
  if (e = url_normalize(&ur, NULL))
    {
      if (e != URL_ERR_REL_NOTHING)
	goto urlerr;
      if (!gthis->url && !gthis->base_url)	/* We really have no base */
	goto urlerr;
      if (!allow_rel && log_base_errors)
	log(L_ERROR_R, "Relative %s URL encountered: %s", msg, u);
      if (gthis->base_url)
	e = url_normalize(&ur, &gthis->base_url_s);
      else
	e = url_normalize(&ur, &gthis->url_s);
      if (e)
	goto urlerr;
    }
  if ((e = url_canonicalize(&ur)) ||
      (e = url_pack(&ur, buf3)) ||
      (e = url_enescape(buf3, buf4)))
    goto urlerr;
  ur.protocol = gstrdup(ur.protocol);
  ur.user = gstrdup(ur.user);
  ur.pass = gstrdup(ur.pass);
  ur.host = gstrdup(ur.host);
  ur.rest = gstrdup(ur.rest);
  *url = ur;	/* We need a local copy as we might have used the same URL as a base */
  return gstrdup(buf4);

 urlerr:
  gerror(2000+e, "Error parsing %s URL %s: %s", msg, u, url_error(e));
}

struct gobj_ref *
gobj_add_ref_full(int type, byte *url, byte *ctype, struct url *base)
{
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE], buf3[MAX_URL_SIZE], buf4[MAX_URL_SIZE];
  int e;
  struct url u;
  struct gobj_ref *r;

  if (!url)
    return NULL;
  if (!base)
    {
      if (gthis->base_url)
	base = &gthis->base_url_s;
      else
	base = &gthis->url_s;
    }
  if ((e = url_deescape(url, buf1)) ||
      (e = url_split(buf1, &u, buf2)) ||
      (e = url_normalize(&u, base)) ||
      (e = url_canonicalize(&u)) ||
      (e = url_pack(&u, buf3)) ||
      (e = url_enescape(buf3, buf4)))
    {
      if (log_ref_errors)
	log(L_WARN_R, "Invalid ref to %s: %s", url, url_error(e));
      return NULL;
    }
  url = buf4;

  if (!ctype)
    {
      byte *cenc = NULL;
      guess_content_by_name(u.rest, &ctype, &cenc);
      if (!ctype)
	ctype = "";
    }
  else
    {
      byte *x = ctype;
      ctype = mp_alloc(gthis->pool, strlen(x)+1);
      strcpy(ctype, x);
    }

  WALK_LIST(r, gthis->ref_list)
    {
      /* FIXME: This is quadratic. */
      if (r->type == type && !strcmp(r->url, url) && !strcmp(r->content_type, ctype))
	return r;
    }

  r = mp_alloc(gthis->pool, sizeof(struct gobj_ref) + strlen(url));
  r->type = type;
  r->content_type = ctype;
  r->id = gthis->ref_count++;
  r->dont_follow = 0;
  strcpy(r->url, url);
  add_tail(&gthis->ref_list, &r->n);
  return r;
}

struct gobj_ref *
gobj_add_ref(int type, byte *url)
{
  return gobj_add_ref_full(type, url, NULL, NULL);
}

void
gobj_check_really_new(void)
{
  struct odes *old = gthis->refreshing;
  byte *old_md5_txt, *x;
  byte old_md5[MD5_SIZE], types_used[128/8];
  struct gobj_ref *ref, *r;
  struct oattr *attr;

  if (!old)				/* Not refreshing */
    return;

  /* Check Forced Reload and attach download time of the old object to the new one */
  x = obj_find_aval(old, 'D');
  if (!x)
    return;
  obj_set_attr(gthis->aa, 'p', x);
  if (gthis->download_time - (sh_time_t)atol(x) > max_refresh_age)
    return;

  /* Check MD5 sum of document text */
  if (!(old_md5_txt = obj_find_aval(old, 'C')) || !gthis->MD5_valid)
    return;
  hex_to_md5(old_md5_txt, old_md5);
  if (memcmp(gthis->MD5, old_md5, MD5_SIZE))
    return;

  /* Check references; missing ones are ignored, new ones cause object to be replaced */
  bzero(types_used, sizeof(types_used));
  WALK_LIST(ref, gthis->ref_list)
    if (!(types_used[ref->type >> 3] & (1 << (ref->type & 7))))
      {
	types_used[ref->type >> 3] |= 1 << (ref->type & 7);
	attr = obj_find_attr(old, ref->type);
	for (r=ref; r->n.next; r=(struct gobj_ref *)r->n.next)
	  {
	    if (r->type != ref->type)
	      continue;
	    if (!attr || strcmp(attr->val, r->url))
	      return;
	    attr = attr->same;
	  }
      }

  /* If only the ETag has changed, consider the document changed, but keep the
   * 'p' attribute from the previous version if possible, so that the average
   * delay between changes will be calculated correctly.
   */
  if (gthis->etag && gthis->if_different_etag && strcmp(gthis->etag, gthis->if_different_etag))
    {
      obj_set_attr(gthis->aa, 'p', obj_find_aval(old, 'p'));
      return;
    }

  gerror(4, "Not changed");
}

void
gobj_truncate(void)
{
  gthis->truncated = 1;
  if (!allow_truncate)
    gerror(2405, "Object too large");
}
