/*
 *	Sherlock Language Processing Library -- Stemming
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lang/lang.h"
#include "lang/stemmer.h"

static list *(*stemmer_funcs[])(struct stemmer *, byte *, struct mempool *) = {
#define STEMMER(name) stem_##name,
#include "lang/stemmers.h"
#undef STEMMER
};

static void (*stemmer_init_funcs[])(struct stemmer *) = {
#define STEMMER(name) stem_init_##name,
#include "lang/stemmers.h"
#undef STEMMER
};

list *
lang_stem(struct stemmer *st, byte *src, struct mempool *mp)
{
  ASSERT(st->id < ARRAY_SIZE(stemmer_funcs));
  return stemmer_funcs[st->id](st, src, mp);
}

void
lang_init_stemmers(void)
{
  struct stemmer *st;
  WALK_LIST(st, stemmer_list)
    stemmer_init_funcs[st->id](st);
}
