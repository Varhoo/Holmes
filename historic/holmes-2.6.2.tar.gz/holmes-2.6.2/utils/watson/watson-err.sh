#!/bin/bash
# trivial Watson control script, add it into crontab

if [ -s log/watsonerr ]; then
	echo "Watson encountered some errors durings periodical runs"
	echo "Please read log/watsonerr and delete it afterwards"
	echo
	tail log/watsonerr
fi 1>&2
