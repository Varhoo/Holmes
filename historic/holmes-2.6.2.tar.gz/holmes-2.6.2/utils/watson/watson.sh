#!/bin/bash
# Watson -- an elementary monitoring system for Sherlock Holmes
#
# (c) 2003 Tomas Valla <tom@ucw.cz>

# Configurable parameters:

SS="sherlock0 sherlock4 sherlock6"
GS="sherlock5:run/log/gatherd*"
CS="sherlock5:run/log/sched*"

for s in $SS ; do
	echo "Fetching search server logs from $s"
	if [ ! -e "log/$s" ]; then
		mkdir log/$s
	fi
	if [ ! -e "log/inter/$s" ]; then
		mkdir log/inter/$s
	fi
	rsync -vuat "$s:run/log/sherlock*" log/$s
	for i in log/$s/*.gz; do
		j=`echo -n "$i"|sed 's/\.gz$//'`
		if [ -e "$j" ]; then
			echo "Deleting old $j"
			rm $j
		fi
	done
done

# commented in Centrum installation

# echo "Fetching gatherer logs from $GS"
# rsync -vuat "$GS" log
# echo "Fetching scheduler logs from $CS"
# rsync -vuat "$CS" log

function check () {
	PRG="$1"
	for l ; do
		i=`echo -n "$l"|sed 's:^log:log/inter:' | sed 's/\.[bg]z2\?//'`
		if [ ! \( -e "$i" \) -o \( "$l" -nt "$i" \) ]; then
			echo "Processing $l into $i"
			$PRG "$l" "$i"
		fi
	done
}

check bin/analyze-search log/sher*/*
check bin/analyze-gatherd log/gath*
check bin/analyze-scheduler log/sched*
