#!/usr/bin/perl -w

# Precomputing data from scheduler logs
#
# (c) 2003 Tomas Valla <tom@ucw.cz>
#

use lib 'lib/perl5';
use Sherlock::Watsonlib;
use strict;
use warnings;

analyze_options() or die
"Reads Sherlock scheduler logfile and generates interfile\n".analyze_usage();

chew_schedulerlog($ARGV[0],$ARGV[1]);

sub chew_schedulerlog {
	my ($infile,$outfile) = @_;

	my @keys = qw(
		exp_total
		exp_spectrum_expired
		exp_spectrum_requeued
		exp_spectrum_filtered
		exp_queued_new
		exp_queued_rfsh
		exp_queued_prior
		exp_static
		exp_error
		exp_queue_in
		exp_robot_total
		exp_robot_expired
		exp_robot_filtered
		exp_qkeys_total
		exp_qkeys_expired
		exp_buck_total
		exp_buck_deleted
		exp_md5_total
		exp_md5_dups
		scan_obj
		scan_card
		merge_card
		merge_dupl
		merge_classes
		merge_penal
		mklex_words
		size_md5
		size_url
		size_hosts
		size_objs
		size_queue
		size_attrs
		size_cards
		size_lexicon
		size_refs
		size_string
		size_total );

	my $max_hist_bucket = 0;
	my @histogram_buckets = ();
	
	my $hdr_string="#@\n";

	my ($in, $out, $fname, $seekpos)=analyze_init($infile,$outfile,$hdr_string);

	my $start_time;
	my $lastpos=$seekpos;
	my %d=();

	while (<$in>) {
		/^I/ or next;
		/^. (\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}) / or next;
		my $time=parse_timestamp($1,$2);
		if ($time==-1) {
			warning("Bad timestamp");
			next;
		}

		defined $start_time or $start_time = $time - ($time % $quantum);
		
		if ($time>$start_time+$quantum) {
			for my $k (sort @keys) {
				defined $d{$k} and print $out "$start_time\t$k\t$d{$k}\n";
			}
			if ($max_hist_bucket) {
				my @new = map { (split /\//,$_)[0] } @histogram_buckets;
				my @rfsh = map { (split /\//,$_)[1] } @histogram_buckets;
				my @prio = map { (split /\//,$_)[2] } @histogram_buckets;
				my @err = map { (split /\//,$_)[3] } @histogram_buckets;
				my @stat = map { (split /\//,$_)[4] } @histogram_buckets;

				print $out "$start_time\texp_hist_new\t".join(",", @new)."\n";
				print $out "$start_time\texp_hist_rfsh\t".join(",", @rfsh)."\n";
				print $out "$start_time\texp_hist_prio\t".join(",", @prio)."\n";
				print $out "$start_time\texp_hist_err\t".join(",", @err)."\n";
				print $out "$start_time\texp_hist_stat\t".join(",", @stat)."\n";

				$max_hist_bucket = 0;
				@histogram_buckets = ();
			}

			$start_time = $time - ($time % $quantum);
			$lastpos=$in->tell;
			%d=();
		}

		if (/\[expire\]/)
		{
			if (/Total URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) expired, (\d+) requeued, (\d+) filtered out, (\d+) lost/) {
				# warning("Caution! Inconsistency found: $_") if $1 != $2 + $3 + $5 + $6;
				$d{'exp_total'} = $2;
				$d{'exp_spectrum_expired'} = $4;
				$d{'exp_spectrum_requeued'} = $5;
				$d{'exp_spectrum_filtered'} = $6;
			} elsif (/Queued new URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_queued_new'} = $2;
			} elsif (/Queued refresh URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_queued_rfsh'} = $2;
			} elsif (/Queued priority URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_queued_prior'} = $2;
			} elsif (/Static URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_static'} = $2;
			} elsif (/Error URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_error'} = $2;
			} elsif (/Queue: (\d+) items, (\d+) inactive, (\d+) postponed/) {
				$d{'exp_queue_in'} = $1;
			} elsif (/Robots: (\d+) total, (\d+) expired, (\d+) filtered out/) {
				$d{'exp_robot_total'} = $1;
				$d{'exp_robot_expired'} = $2;
				$d{'exp_robot_filtered'} = $3;
			} elsif (/Queue keys: (\d+) total .*, (\d+) expired/) {
				$d{'exp_qkeys_total'} = $1;
				$d{'exp_qkeys_expired'} = $2;
			} elsif (/Buckets: (\d+) total, (\d+) old \+ (\d+) new deleted, (\d+) bad/) {
				$d{'exp_buck_total'} = $1 - ($2 + $3 + $4);
				$d{'exp_buck_deleted'} = $2 + $3 + $4;
			} elsif (/MD5: (\d+) sums \+ (\d+) duplicates/) {
				$d{'exp_md5_total'} = $1 + $2;
				$d{'exp_md5_dups'} = $2;
			} elsif (/hist\[(\d+)\.\.(\d+)\]: (.*)/) {
				$max_hist_bucket=$2 if $2 > $max_hist_bucket;
				push @histogram_buckets, split / /,$3;
			}
		}
		elsif (/\[scanner] Scanned (\d+) objects, created (\d+) cards/)
		{
			$d{'scan_obj'} = $1;
			$d{'scan_card'} = $2;
		}
		elsif (/\[merger] Merged (\d+) cards: (\d+) non-trivial classes \(max \d+\), (\d+) duplicates, (\d+) penalized/)
		{
			$d{'merge_card'} = $1;
			$d{'merge_classes'} = $2;
			$d{'merge_dupl'} = $3;
			$d{'merge_penal'} = $4;
		}
		elsif (/\[mklex] Built lexicon with (\d+) words/)
		{
			$d{'mklex_words'} = $1;
		}
		elsif (/\[sizer]/)
		{
			$d{'size_times'} = 1;
			if (/MD5.db=(\d+)\b/) { $d{'size_md5'} = $1; }
			if (/URL.db=(\d+)\b/) { $d{'size_url'} = $1; }
			if (/hosts=(\d+)\b/) { $d{'size_hosts'} = $1; }
			if (/objects=(\d+)\b/) { $d{'size_objs'} = $1; }
			if (/queue=(\d+)\b/) { $d{'size_queue'} = $1; }
			if (/card-attrs=(\d+)\b/) { $d{'size_attrs'} = $1; }
			if (/cards=(\d+)\b/) { $d{'size_cards'} = $1; }
			if (/lexicon=(\d+)\b/) { $d{'size_lexicon'} = $1; }
			if (/references=(\d+)\b/) { $d{'size_refs'} = $1; }
			if (/string-map=(\d+)\b/) { $d{'size_string'} = $1; }
			if (/total index size is (\d+)\b/) { $d{'size_total'} = $1; }
		}
	}

	analyze_finish($in,$out,$infile,$lastpos);
}

