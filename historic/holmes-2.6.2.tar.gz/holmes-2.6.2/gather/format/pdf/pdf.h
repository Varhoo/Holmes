/*
 *  Sherlock Gatherer: PDF parser
 *
 *  (c) 2002--2003 Milan Vancura <milan@ucw.cz>
 *  (c) 2003 Martin Mares <mj@ucw.cz>
 *
 *  see pdf.c for TODO list
 */

/*
 * Error codes for fatal errors (22xx)
 *
 * 20 base structure of objects is corrupted (xref tables etc.)
 * 21 document is encrypted
 * 22 filepos stack (under|over)flow
 * 23 PDF stream error
 */

#define LOG(f...) log(L_DEBUG, f)
#define TRACE(t,f...) do { if(trace>=(t)) LOG(f); } while(0)
#define BTRACE(t,p,l,f...) do { int i; if(trace>=(t)) { LOG(f); for(i=0;i<(l);i++) fputc((p)[i],stderr); fputc('\n',stderr); } } while(0)
#define HTRACE(t,p,l,f...) do { uns i; byte *T=(char *)(p); if(trace>=(t)) { LOG(f); for(i=0;i<(l);i++) fprintf(stderr,"%.2x",*T++); } } while(0)
#ifdef LOCAL_DEBUG
#   define PRINTOBJ(t,o) do { if (trace>=(t)) printobj(o); } while(0)
#else
#   define PRINTOBJ(t,o)
#endif

#define STRINGBUFLEN	 65536
/* TEMPBUFLEN must be > 256 */
#define TEMPBUFLEN	  1024
#define STREAMBLKLEN	   263
#define UNICODESTRINGCNT   256
#define UNICODESTRMAXLEN   512

#define MAX_BUFF_SIZE	100
#define MAX_TOK_SIZE	100
#define MAX_TREE_SIZE  1000
#define MAX_SEEK_POS	 10
#define MAX_SUB_PAGES	 10
#define MAX_STREAMS	 15
#define LOOK4STARTXREF	 50
#define GS_MAX_DEPTH	128

/* space types */

#define SP_NOEOL	1
#define SP_EOL		2
#define SP_COMMENT	4
#define SP_DELIM	8
#define SP_ANYSPACE	(SP_NOEOL | SP_EOL)
#define SP_ANYWCOMM	(SP_NOEOL | SP_EOL | SP_COMMENT)
#define SP_ANYWDELIM	(SP_NOEOL | SP_EOL | SP_DELIM)

typedef struct {
    s32 position;
    word generation;
} OBJ_START;

/* OBJECT types */

enum ot_type {
    OT_UNKNOWN,
    OT_BOOL,
    OT_INT,
    OT_REAL,
    OT_OBJREF,
    OT_STRING,
    OT_NAME,
    OT_ARRAY,
    OT_DICT,
    OT_STREAM,
    OT_NULL,
    OT_UTOK,
    OT_MAX
};

typedef struct object {
    enum ot_type type;
    union {
	s32 n;			/* for bool, int (values), references (obj id) */
	byte *s;		/* for names */
	struct dict_entry *d;	/* for dictionaries */
	struct array_entry *a;	/* for arrays */
	float r;		/* for reals */
	struct {		/* for strings: pointer and length */
	    byte *i;
	    int l;
	} str;
    } value;
} OBJECT;

typedef struct dict_entry {
    char *name;
    OBJECT obj;
    struct dict_entry *next;
} DICT_ENTRY;

typedef struct array_entry {
    OBJECT obj;
    struct array_entry *next;
} ARRAY_ENTRY;

typedef struct {
    char *name;
    OBJECT *obj;
} OBJ_GET;

struct fchain;

typedef int(*fcf_t)(struct fchain *);

struct fchain {
    fcf_t	    func;
    byte	    buf[STREAMBLKLEN];
    byte	    *data;
    byte	    *end;
    struct fchain   *prev;
    addr_int_t	    priv;
};

/*
 * VERY incomplete struct of PDF graphic state. Store the needed parts only.
 * For complete list and default values see PDF Reference Manual.
 */
struct gsdata {
    s32 ctm_sy;		/* CTM.scale_y; default=1 */
    struct fencoding *tf;/* text font; no default */
    s32 tfs;		/* text font size; no default */
    s32 tm_sy;		/* TM.scale_y; default=1 */
    enum {
	trm_nochange=-1,
	trm_fill,
	trm_stroke,
	trm_fillstroke,
	trm_nothing,
	trm_fillclip,
	trm_strokeclip,
	trm_fillstrokeclip,
	trm_clip,
	trm_max
    } trm;		/* text rendering mode; default=fill */
};

struct gstate {
    struct gstate *next;
    uns obj;
    struct gsdata *data;
};

struct gsname {
    struct gsname *next;
    uns obj;
    uns namehash;
    byte *name;
    struct gsdata *gsd;
};

/*
 * Font data structures
 */

struct unichar {
    word fcode;
    word unicode;
};

struct fencoding {
    byte bytes;
    struct unichar *table;
    uns len;
    uns start;
};

struct font {
    struct font *next;
    uns obj;
    struct fencoding *enc;
};

struct fontname {
    struct fontname *next;
    uns obj;
    uns namehash;
    byte *name;
    struct fencoding *enc;
};

struct resources {
    struct resources *next;
    uns obj;
    struct fontname *fonts;
    struct gsname *gstates;
};

struct rc4_state {
    byte x;
    byte y;
    byte m[256];
};
