/*
 *  Sherlock Gatherer: PDF parser
 *
 *  (c) 2002--2003 Milan Vancura <milan@ucw.cz>
 *  (c) 2003 Martin Mares <mj@ucw.cz>
 */

/*
 * TODO:
 *
 *    + out_pdftext_string() - text of bookmarks, anotations etc. can be coded
 *      in Unicode (PLRM->Syntax->Common data structures->PDF Text string)
 *    + code cleanups: better order of functions in a file, create lookup
 *      function for searching in a table of strings etc.
 */

/*
 * Warning: All tracing messages (Trace 10000) can cause HUGE log files.
 *          Example: Log of parsing the PDF Reference Manual > 0.5GB
 *          => use appropriate Trace level &&/|| raise Trace level for debugged
 *          parts of code only
 */

#undef LOCAL_DEBUG

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/chartype.h"
#include "lib/index.h"
#include "lib/pools.h"
#include "lib/hashfunc.h"
#include "lib/math.h"
#include "lib/md5.h"
#include "gather/gather.h"
#include "gather/format/pdf/pdf.h"
#include "gather/format/pdf/glyphs.h"
#include "gather/format/pdf/adobeencs.h"
#include "charset/unicode.h"
#include "charset/unistream.h"

#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <alloca.h>
#include <zlib.h>

/* Configuration parameters */

static int trace;
static int xreft_size=1000;
static int respect_user_rights=0;
static int encrypted=0;			/* bit 0: decrypt now; bit 1: document is encrypted */

static struct cfitem pdf_config[] = {
    { "PDF",		  CT_SECTION, NULL},
    { "Trace",		  CT_INT,     &trace },
    { "XrefTabSize",	  CT_INT,     &xreft_size },
    { "RespectUserRights",CT_INT,     &respect_user_rights },
    { NULL,		  CT_STOP,    NULL}
};

static void CONSTRUCTOR
pdf_init(void) {
    cf_register(pdf_config);
}

static byte stringbuf[STRINGBUFLEN];
static byte decryptkey[10];
static struct rc4_state rc4s,rc4ss,rc4sss;
static u32  lastobj;
static word lastgen;

/*
 * Memory allocation.
 */

static struct mempool *page_pool;	/* Page-local stuff; discarded in out_pages() */
static struct mempool *global_pool;	/* Global stuff; discarded at the end of parsing */
static struct mempool *sf_pool;		/* Stream functions' data */

/* I/O functions */

static struct fastbuf *pdf_in, *pdf_out, *meta_out, fb_stream, *stream_in=&fb_stream, *input;

static struct fchain *sf_top;
static int check_i_stream(s32 n);
static uns stream_array[MAX_STREAMS+1], *sa_top;

static int
stream_refill(struct fastbuf *f) {
    struct fchain *c=sf_top;

    if(!sf_top)
	    return 0;
    if(c->data==c->end)
	c->func(c);
    TRACE(10001,"(stream_refill) Buffer %d-%d",c->data-c->buf,c->end-c->buf);
    if(c->data<c->end) {
	f->buffer=f->bptr=c->data;
	f->bufend=f->bstop=c->end;
	f->pos+=c->end-c->data;
	c->data=c->end;
	return 1;
    } else {
	TRACE(200,"(stream_refill) Stream object #%d([%d])",*sa_top,sa_top-stream_array);
	input=pdf_in;
	if(*sa_top && !check_i_stream(*sa_top++)) {
	    input=stream_in;
	    return stream_refill(f);
	} else {
	    input=stream_in;
	    return 0;
	}
    }
}

static void
stream_init(struct fastbuf *f) {
    bzero(f,sizeof(*f));
    f->refill=stream_refill;
    f->name="PDF stream";
    sa_top=stream_array;
    if(check_i_stream(*sa_top++))
	sf_top=NULL;
    encrypted&=~1;		/* no RC4 decryption in a stream */
}

/*
 * Basic input calls
 *
 * there are input calls defined. They can read from PDF file (pdf_in) or from
 * PDF stream object (stream_in). Function set_input_method() switches between
 * these two.
 */

static int skip_space(uns);

static inline int
ingetc(struct fastbuf *in) {
    int c;
    c=bgetc(in);
    if(c==EOF && in==pdf_in)
	gerror(2200,"(ingetc) Unexpected EOF");
    if(c==EOF && in==stream_in)
	TRACE(10001,"End of stream");
    return c;
}

#define in_get_char()	    ingetc(input)
#define in_check_char()	    bpeekc(input)
#define in_unget_char()	    bungetc(input)
#define in_read(b,l)	    bread(input,b,l)
#define in_tell()	    ((int)btell(input))

static inline int
in_check_nschar(int spacetype) {
    if(skip_space(spacetype)==EOF)
	return EOF;
    return in_check_char();
}

/*
 * input method selector
 *
 * note that after switching to stream_in stream_in is inicialized
 */

static void
set_input_method(struct fastbuf *inf) {
    if(inf!=pdf_in && inf!=stream_in)
	gerror(2203,"(set_input_method) Unknown input method");
    if(inf==stream_in)
	stream_init(stream_in);
    input=inf;
}

/*
 * PDF file input calls
 *
 * switching between pdf_in and stream_in has sense only in some parts of code.
 * Otherwise we can use pdf_* version of input calls which works always with
 * pdf_in.
 * Additionally pdf_seek* are defined because (only) pdf_in is seekable.
 */

#define pdf_get_char()	    ingetc(pdf_in)
#define pdf_check_char()    bpeekc(pdf_in)
#define pdf_unget_char()    bungetc(pdf_in)
#define pdf_read(b,l)	    bread(pdf_in,b,l)
#define pdf_tell()	    ((int)btell(pdf_in))

static inline int
pdf_check_nschar(int spacetype) {
    struct fastbuf *tmp=input;

    input=pdf_in;
    skip_space(spacetype);
    input=tmp;
    return pdf_check_char();
}

#define pdf_seek(pos)	    bsetpos(pdf_in, pos)
#define pdf_seek_end(pos)   bseek(pdf_in, pos, SEEK_END)

/* advanced input calls */

static sh_off_t seekposbuf[MAX_SEEK_POS];
static int seekpos=0;

static void
restorefilepos(void) {
    if(seekpos<=0)
	gerror(2222,"(restorefilepos) Empty filepos buffer (seekpos=%d)",seekpos);
    seekpos--;
    pdf_seek(seekposbuf[seekpos]);
}

static void
savefilepos(void) {
    seekposbuf[seekpos]=pdf_tell();
    seekpos++;
    if(seekpos>=MAX_SEEK_POS)
	gerror(2222,"(savefilepos) Seekpos buffer overflow (filepos: %d)",pdf_tell());
}

static int
in_get_line(char * buf) {
    int c;
    int i=0;

    do {
	c=in_get_char();
	if(c!=EOF && buf)
	    buf[i]=c;
	i++;
    } while (c!=EOF && c!=10 && c!=13 && i<MAX_BUFF_SIZE);
    if(c==EOF)
	return EOF;
    if(buf)
	buf[i-1]=0;
    if(c==13) {
	c=in_get_char();
	if(c==EOF)
	    return EOF;
	if(c!=10)
	    in_unget_char();
	else
	    i++;
    }
    return i;
}

static int
is_numchar(int c) {
    return(c>='0' && c<='9');
}

static int
is_intchar(int c) {
    return(is_numchar(c) || c=='+' || c=='-');
}

static int
is_space(int c, uns type) {
    return (((type & SP_EOL) && (c==10 || c==13)) ||
	    ((type & SP_NOEOL) && (c==0 || c==9 || c==12 || c==' ')) ||
	    ((type & SP_DELIM) && (c=='(' || c==')' || c=='<' || c=='>' || c=='[' || c==']' || c=='{' || c=='}' || c=='/' || c=='%')) ||
	    ((type & SP_COMMENT) && (c=='%')));
}

static int
skip_space(uns type) {
    int c;
    int i=0;

    while(is_space(c=in_get_char(),type) && c!=EOF) {
	TRACE(10001,"(skip_space) char %d",c);
	if((type & SP_COMMENT) && c=='%') {
	    if(in_get_line(NULL)==EOF)
		break;
	}
	i++;
    }
    TRACE(10001,"(skip_space) end char %d",c);
    if(c==EOF)
	return EOF;
    in_unget_char();
    return (i>0);
}

static OBJ_START **xreftroot;

static OBJ_START
obj_off(int i) {
    OBJ_START out={0,0};
    int j=i/xreft_size;

    if(j>=xreft_size || !xreftroot[j])
	return out;
    return xreftroot[j][i%xreft_size];
}

static struct rc4_state
rc4_setup(struct rc4_state *s) {
    struct MD5Context md5c;
    byte rc4key[16];
    int i;
    int l=10;
    byte *m, j, k, a;

    decryptkey[5]=lastobj        & 0xff;
    decryptkey[6]=(lastobj >> 8) & 0xff;
    decryptkey[7]=(lastobj >>16) & 0xff;
    decryptkey[8]=lastgen        & 0xff;
    decryptkey[9]=(lastgen >> 8) & 0xff;
    MD5Init(&md5c);
    MD5Update(&md5c,decryptkey,10);
    MD5Final(rc4key, &md5c);
    
    s->x = 0;
    s->y = 0;
    m = s->m;

    for(i=0; i< 256; i++) m[i] = i;

    j=k=0;

    for(i=0; i<256; i++) {
        a=m[i];
        j=j+a+rc4key[k];
        m[i]=m[j];
	m[j]=a;
        if(++k>=l) k=0;
    }
    return *s;
}

static int
rc4_conv(struct rc4_state *rs, void *dest, void *src, u32 n) {
    u32 i;
    byte *s=src, *d=dest;
    byte *m=rs->m, a, b;

    for(i=0;i<n;i++) {
	a=m[++rs->x];
	rs->y+=a;
	m[rs->x]=b=m[rs->y];
	m[rs->y]=a;
	d[i]=s[i]^m[(a+b) & 0xFF];
    }
    return n;
}

static OBJECT
get_tok(void) {
    OBJECT obj;
    int c;
    byte *b=stringbuf, *e=stringbuf+STRINGBUFLEN;

    obj.type=OT_UTOK;
    while(!is_space(c=in_get_char(),SP_ANYWDELIM) && c!=EOF && b<e)
	*b++=c;
    if(c!=EOF)
	in_unget_char();
    *b=0;
    c=b-stringbuf+1;
    if(c<0 || c>=STRINGBUFLEN)
	gerror(2203,"(get_tok) stringbuf overflow: %d",c);
    obj.value.s=mp_alloc(page_pool,b-stringbuf+1);
    memcpy(obj.value.s,stringbuf,b-stringbuf+1);
    return obj;
}

static s32
getint(void) {
    OBJECT obj;
    s32 val;
    char *b,*ptr;

    obj=get_tok();
    if(!is_intchar(*obj.value.s))
	gerror(2200,"(getint) Wrong int number: %s",obj.value.s);
    for(b=obj.value.s+1;is_numchar(*b);b++);
    if(*b)
	gerror(2200,"(getint) Wrong int number: %s (%c)",obj.value.s,*b);
    val=strtol(obj.value.s,&ptr,10);
    if(ptr!=b)
	gerror(2200,"(getint) Wrong int number: %s",obj.value.s);
    return val;
}

static OBJECT
get_int_real(void) {
    OBJECT out;
    int i=0,c;
    char *b=stringbuf, *e=stringbuf+STRINGBUFLEN;
    char *ptr;

    if((is_intchar(c=in_get_char()) || c=='.') && (i+=(c=='.'))<2)
	*b++=c;
    else
	gerror(2200,"(get_int_real) Wrong int/real number: %s (start)",stringbuf);
    while((is_numchar(c=in_get_char()) || c=='.') && (i+=(c=='.'))<2 && b<e)
	*b++=c;
    if(c!=EOF)
	in_unget_char();
    *b=0;
    if(i>=1) {
	out.value.r=strtod(stringbuf,&ptr);
	out.type=OT_REAL;
    } else {
	out.value.n=strtol(stringbuf,&ptr,10);
	out.type=OT_INT;
    }
    if(ptr!=b)
	gerror(2200,"(get_int_real) Wrong int/real number: %s",stringbuf);
    return out;
}

static uns
hexnibble(uns n) {
    if(is_numchar(n))
	n-='0';
    else if(n>='a' && n<='f')
	n=n+10-'a';
    else if(n>='A' && n<='F')
	n=n+10-'A';
    else
	gerror(2223,"(hexnibble) Wrong HEX char '%c'",n);
    return n;
}

static uns
hexbyte(uns hi, uns lo) {
    return 16*hexnibble(hi)+hexnibble(lo);
}

static OBJECT
get_hexastring(void) {
    OBJECT obj;
    int c,d;
    byte *b=stringbuf,*e=stringbuf+STRINGBUFLEN;

    obj.type=OT_STRING;
    do {
	if(skip_space(SP_ANYSPACE)==EOF)
	    break;
	c=in_get_char();
	if(c=='>' || c==EOF)
	    break;
	if(skip_space(SP_ANYSPACE)==EOF)
	    break;
	d=in_get_char();
	*b++=(d=='>' || d==EOF) ? hexbyte(c,'0') : hexbyte(c,d);
	if(b>=e)
	    gerror(2203,"(get_hexastring) stringbuf overflow at %d",in_tell());
    } while(d!='>' && d!=EOF);

    obj.value.str.i=mp_alloc(page_pool,b-stringbuf);
    obj.value.str.l=b-stringbuf;
    if((encrypted&0x03)==3) {
	rc4s=rc4ss;
	rc4_conv(&rc4s,obj.value.str.i,stringbuf,obj.value.str.l);
    } else
	memcpy(obj.value.str.i,stringbuf,obj.value.str.l);

    return obj;
}

static OBJECT
get_string(void) {
    OBJECT obj;
    int c='(';
    int parenlev=1;	    /* level of nesting in () */
    int i;
    byte *b=stringbuf, *e=stringbuf+STRINGBUFLEN;

    obj.type=OT_STRING;
    in_get_char();	    /* '(' */
    for(;parenlev;b++) {
	if(b>=e)
	    gerror(2203,"(get_string) stringbuf overflow at %d",in_tell());
	c=in_get_char();
	if(c==EOF)
	    break;
	*b=c;
	switch(c) {
	    case '(': parenlev++; break;
	    case ')': parenlev--; break;
	    case '\r':
		c=in_get_char();
		if(c!='\n')
		    in_unget_char();
	    case '\n':
		*b='\n';
		break;
	    case '\\':
		c=in_get_char();
		switch(c) { /* table of special chars */
		    case EOF:
			parenlev=0;
			break;
		    case '\r':
			c=in_get_char();
			if(c!='\n')
			    in_unget_char();
		    case '\n':
			b--;
			break;
		    case 'n': *b=c='\n'; break;
		    case 'r': *b=c='\r'; break;
		    case 't': *b=c='\t'; break;
		    case 'b': *b=c='\b'; break;
		    case 'f': *b=c='\f'; break;
		    case '0': /* octal code */
		    case '1':
		    case '2':
		    case '3':
		    case '4':
		    case '5':
		    case '6':
		    case '7':
			*b=0;
			i=0;
			while(c>='0' && c<='7' && i<3 && *b<32) {
			    *b=*b*8+c-'0';
			    c=in_get_char();
			    i++;
			}
			if(c==EOF) {
			    parenlev=0;	/* break from for cycle */
			    break;
			}
			in_unget_char();
			break;
		    default: *b=c; break;
		}
		break;
	    default: ;
	}
    }
    if(c==')')
	b--;
    obj.value.str.i=mp_alloc(page_pool,b-stringbuf);
    obj.value.str.l=b-stringbuf;
    TRACE(100,"(get_string) Encrypt: %d(%d,%d)",encrypted,lastobj,lastgen);
    if((encrypted&0x03)==3) {
	rc4s=rc4ss;
	rc4_conv(&rc4s,obj.value.str.i,stringbuf,obj.value.str.l);
    } else
	memcpy(obj.value.str.i,stringbuf,obj.value.str.l);

    return obj;
}

static OBJECT
get_name(void) {
    OBJECT obj;
    int c,d;
    byte *b=stringbuf, *e=stringbuf+STRINGBUFLEN;

    obj.type=OT_NAME;
    in_get_char(); /* '/' */
    while(!is_space(c=in_get_char(),SP_ANYWDELIM) && c>=0 && b<e) {
	*b++=c;
	if(c=='#') {
	    c=in_get_char();
	    d=in_get_char();
	    if(d==EOF) {
		b--;
		break;
	    }
	    if((b[-1]=hexbyte(c,d))==0)
		gerror(2200,"(get_name) NULL byte not allowed in the object name: %s",stringbuf);
	}
    }
    if(c!=EOF)
	in_unget_char();
    *b=0;
    obj.value.s=mp_alloc(page_pool,b-stringbuf+1);
    memcpy(obj.value.s,stringbuf,b-stringbuf+1);

    return obj;
}

static OBJECT
check_ref(OBJECT in1) {
    OBJECT in2;
    int c;

    savefilepos();
    c=in_check_nschar(SP_ANYWCOMM);
    if(is_numchar(c) || c=='+') {
	in2=get_int_real();
	if(in2.type==OT_INT) {
	    c=in_check_nschar(SP_ANYWCOMM);
	    c=in_get_char();
	    if(c=='R' && is_space(in_check_char(),SP_ANYWDELIM)) {
		c=in1.value.n;
		if(xreftroot[c/xreft_size] && xreftroot[c/xreft_size][c%xreft_size].position>0)
		    in1.type=OT_OBJREF;
		else
		    in1.type=OT_NULL;
	    }
	}
    }
    if(in1.type==OT_INT)
	restorefilepos();
    else
	seekpos--;  /* forgetpos() */
    return in1;
}

static OBJECT get_dict(void);
static OBJECT get_array(void);

static OBJECT
get_obj(void) {
    int c;
    OBJECT obj;

    c=in_check_nschar(SP_ANYWCOMM);
    TRACE(500,"get_obj: filepos=%d; TYPECHAR=%c",in_tell(),c);
    switch(c) {
	case EOF:
	    gerror(2200,"(get_obj) Unexpected EOF");
	    break;
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	case '.':
	case '-':
	case '+':
	    obj=get_int_real();
	    break;
	case '(':
	    obj=get_string();
	    break;
	case '[':
	    in_get_char();
	    obj=get_array();
	    break;
	case '<':
	    /* test next char */
	    c=in_get_char();
	    c=in_check_char();
	    TRACE(500,"get_obj: TYPECHAR2=%c",c);
	    if(c=='<') {
		in_get_char();
		obj=get_dict();
	    } else {
		obj=get_hexastring();
	    }
	    break;
	case '/':
	    obj=get_name();
	    break;
	default:
	    if(!is_space(c,SP_ANYWDELIM)) {
		obj=get_tok();
		if(!memcmp(obj.value.s,"null",5)) {
		    obj.type=OT_NULL;
		    obj.value.n=0;
		    break;
		}
		if(!memcmp(obj.value.s,"true",5)) {
		    obj.type=OT_BOOL;
		    obj.value.n=1;
		    break;
		}
		if(!memcmp(obj.value.s,"false",6)) {
		    obj.type=OT_BOOL;
		    obj.value.n=0;
		    break;
		}
	    } else {
		gerror(2200,"(get_obj) Unknown token type (char %d at %d)",c,in_tell());
	    }
    }
    if(input==pdf_in && obj.type==OT_INT) {
	TRACE(500,"get_obj: check_ref()");
	obj=check_ref(obj);
    }
    return obj;
}

static OBJECT
get_i_obj(s32 n) {
    char buf[3];
    OBJECT out;
    OBJ_START oi=obj_off(n);

    if(oi.position==0) {
	out.type=OT_NULL;
	out.value.n=n;
	return out;
    }
    TRACE(100,"(get_i_obj) Encryption: %d,%d",encrypted,lastobj);
    if((encrypted&0x03)==3) {
	lastobj=n;
	lastgen=oi.generation;
	rc4ss=rc4_setup(&rc4s);
    }
    pdf_seek(oi.position);
    if(n!=getint())
	gerror(2220,"(get_i_obj) Can't find object #%d",n);
    skip_space(SP_ANYSPACE);
    if(oi.generation!=getint())
	gerror(2220,"(get_i_obj) Wrong G number of object #%d",n);
    skip_space(SP_ANYSPACE);

    pdf_read(buf,3); /* dies with "short read" message if EOF */
    if(memcmp(buf,"obj",3) || skip_space(SP_ANYWCOMM)==0)
	gerror(2220,"(get_i_obj) Keyword \"obj\" expected (obj #%d)",n);
    return get_obj();
}

static int po_shift=0;

static void
printobj(OBJECT obj) {
    ARRAY_ENTRY *ap;
    DICT_ENTRY *dp;

    switch(obj.type) {
	case OT_BOOL:
	    LOG("%*s(bool: %s)",po_shift,"",obj.value.n?"true":"false");
	    break;
	case OT_INT:
	    LOG("%*s(int: %d)",po_shift,"",obj.value.n);
	    break;
	case OT_REAL:
	    LOG("%*s(real: %f)",po_shift,"",obj.value.r);
	    break;
	case OT_OBJREF:
	    LOG("%*s(ref: (%d %d R))",po_shift,"",obj.value.n,obj_off(obj.value.n).generation);
	    break;
	case OT_STRING:
	    LOG("%*s(string: (%d %.*s))",po_shift,"",obj.value.str.l,obj.value.str.l,obj.value.str.i);
	    break;
	case OT_NAME:
	    LOG("%*s(name: /%s)",po_shift,"",obj.value.s);
	    break;
	case OT_ARRAY:
	    LOG("%*s(array)",po_shift,"");
	    po_shift+=3;
	    for (ap=obj.value.a;ap;ap=ap->next) 
		printobj(ap->obj);
	    po_shift-=3;
	    break;
	case OT_DICT:
	    LOG("%*s(dict)",po_shift,"");
	    po_shift+=3;
	    for (dp=obj.value.d;dp;dp=dp->next) {
		LOG("%*s/%s: ",po_shift,"",dp->name);
		printobj(dp->obj);
	    }
	    po_shift-=3;
	    break;
	case OT_STREAM:
	    LOG("%*s(stream)",po_shift,"");
	    break;
	case OT_NULL:
	    if(obj.value.n) 
		LOG("%*s(unknown ref to obj %d)",po_shift,"",obj.value.n);
	    else
		LOG("%*s(null)",po_shift,"");
	    break;
	case OT_UTOK:
	    LOG("%*s(token: %s)",po_shift,"",obj.value.s);
	    break;
	default:
	    gerror(2203,"(printobj) Unknown object: %d",obj.type);
    }
}

static OBJECT
get_array(void) {
    OBJECT obj;
    ARRAY_ENTRY *start=NULL,*cur=NULL;

    TRACE(200,"Array:");
    while(in_check_nschar(SP_ANYWCOMM)!=']') {
	if(!cur)
	    cur=start=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	else
	    cur=cur->next=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	cur->obj=get_obj();
	PRINTOBJ(200,cur->obj);
    }
    in_get_char();
    if(!cur)			    /* empty dict */
	TRACE(200,"(empty)");
    else
	cur->next=NULL;		    /* the last element's next pointer is a terminator */
    TRACE(200,"End of Array");

    obj.type=OT_ARRAY;
    obj.value.a=start;
    return obj;
}

static OBJECT
get_dict(void) {
    OBJECT obj;
    DICT_ENTRY *start=NULL,*cur=NULL;
    int c;

    TRACE(200,"Dict:");
    while(in_check_nschar(SP_ANYWCOMM)!='>') {
	if(!cur)
	    cur=start=mp_alloc_zero(page_pool,sizeof(DICT_ENTRY));
	else
	    cur=cur->next=mp_alloc_zero(page_pool,sizeof(DICT_ENTRY));
	obj=get_obj();		    /* key - must be a name object */
	PRINTOBJ(200,obj);
	if(obj.type!=OT_NAME)
	    gerror(2200,"(get_dict) Key in the dictionary isn't a name object! (%d)",obj.type);
	cur->name=obj.value.s;
	obj=get_obj();		    /* value */
	PRINTOBJ(200,obj);
	cur->obj=obj;
    }
    in_get_char();
    c=in_get_char();
    if(c!='>')
	gerror(2200,"(get_dict) Syntax error at the end of dictionary (char %c)",c);
    if(!cur)			    /* empty dict */
	TRACE(200,"(empty)");
    else
	cur->next=NULL;		    /* the last element's next pointer is a terminator */
    TRACE(200,"End of Dict");

    obj.type=OT_DICT;
    obj.value.d=start;
    return obj;
}

static void
parse_dict(DICT_ENTRY *dict_start,OBJ_GET *items) {
    int j;
    DICT_ENTRY *dp;

    for(j=0;items[j].name;items[j++].obj->type=OT_UNKNOWN);
    for (dp=dict_start;dp;dp=dp->next) {
	for(j=0;items[j].name;j++) {
	    if(strncmp(dp->name,items[j].name,127)==0) {
		*items[j].obj = dp->obj;
		break;
	    }
	}
    }
}

static inline void
obj_deref(OBJECT *obj) {
    if(obj->type==OT_OBJREF)
	*obj=get_i_obj(obj->value.n);
}

static s32
obj_int_real(OBJECT obj) {
    if(obj.type==OT_INT)
	return obj.value.n;
    if(obj.type==OT_REAL)
	return obj.value.r;
    return 0;
}

/* stream block_filter functions */

static int
sf_get_nschar(int sptype, struct fchain *g) {
    int c,r=0;

    while(r==0) {
	if(g->data==g->end)
	    r=g->func(g);
	while(g->data < g->end) {
	    c=*g->data++;
	    if(!is_space(c,sptype))
		return c;
	}
    }
    return EOF;
}

static inline void
bufshift(struct fchain *f, int i) {
    memmove(f->buf,f->data,i);
    f->end=f->buf+i;
    f->data=f->buf;
}

static int
sf_read(struct fchain *cur) {
    int l=cur->end-cur->data;
    int m;

    bufshift(cur,l);

    TRACE(10001, "(sf_read) before: Buffer %d-%d, remains: %d",cur->data-cur->buf,cur->end-cur->buf,(int)cur->priv);
    if(cur->priv==0)
	return 1;
    l=MIN(STREAMBLKLEN-l,(int)cur->priv);
    m=pdf_read(cur->end,l);
    ASSERT(m);
    cur->end+=m;
    cur->priv-=m;
    TRACE(10001, "(sf_read) after: Buffer %d-%d, remains: %d",cur->data-cur->buf,cur->end-cur->buf,(int)cur->priv);
    return 0;
}

static int
sf_ahex(struct fchain *cur) {
    int c,d=cur->end-cur->data;
    int ret=0;

    bufshift(cur,d);
    while(cur->end < cur->buf+STREAMBLKLEN) {
	if((c=sf_get_nschar(SP_ANYSPACE,cur->prev))<0) {
	    ret=1;
	    break;
	}
	if((d=sf_get_nschar(SP_ANYSPACE,cur->prev))<0) {
	    *cur->end++=hexbyte(c,'0');
	    ret=1;
	    break;
	} else {
	    *cur->end++=hexbyte(c,d);
	}
    }
    TRACE(100, "(sf_ahex) Buffer %d-%d",cur->data-cur->buf,cur->end-cur->buf);
    return ret;
}

static int
sf_inflate(struct fchain *cur) {
    z_stream *d_stream = (z_stream *) cur->priv;
    int err=Z_OK;

    bufshift(cur,cur->end-cur->data);
    if (!d_stream) {
	d_stream = mp_alloc_zero(sf_pool, sizeof(*d_stream));
	cur->priv = (addr_int_t) d_stream;
	err=inflateInit(d_stream);
	if(err!=Z_OK)
	    gerror(2223,"(sf_inflate) InflateInit error: %d",err);
    } else if (d_stream->next_in==NULL) {
	TRACE(100, "(sf_inflate) Signalling EOF");
	return 1;
    }

    d_stream->next_out=cur->end;
    d_stream->avail_out=cur->buf+STREAMBLKLEN-cur->end;

    for(;d_stream->avail_out>0 && err==Z_OK;) {
	if (cur->prev->data >= cur->prev->end)
	    cur->prev->func(cur->prev);
	d_stream->next_in=cur->prev->data;
	d_stream->avail_in=cur->prev->end-cur->prev->data;
	TRACE(100,"(sf_inflate) before decompression: avail_in=%d, total_in=%ld, avail_out=%d, total_out=%ld",d_stream->avail_in,d_stream->total_in,d_stream->avail_out,d_stream->total_out);
	err=inflate(d_stream,Z_SYNC_FLUSH);
	cur->prev->data=d_stream->next_in;
	cur->end=d_stream->next_out;
    }

    TRACE(100, "(sf_inflate) Buffer %d-%d, zlib_err: %d",cur->data-cur->buf,cur->end-cur->buf,err);
    if(err==Z_STREAM_END) {
	if((err=inflateEnd(d_stream))!=Z_OK)
	     gerror(2223,"(sf_inflate) Error while inflateEnd: %d",err);
	d_stream->next_in=NULL;
	return (cur->end <= cur->data);
    }
    if(err!=Z_OK)
	gerror(2223,"(sf_inflate) Error while inflate: %d",err);
    return 0;
}

static int
sf_a85(struct fchain *cur) {
    int n,c=cur->end-cur->data;
    u32 out;

    if (cur->priv)
	return 1;
    bufshift(cur,c);
    while(cur->end < cur->buf+STREAMBLKLEN-4) {
	out=0;
	for(n=0;n<5;n++) {
	    c=sf_get_nschar(SP_ANYSPACE,cur->prev);
	    if(c==EOF)
		gerror(2223,"(sf_a85) Input error: unexpected EOD");
	    if(c=='z' && n==0) {
		cur->end[0]=cur->end[1]=cur->end[2]=cur->end[3]=0;
		cur->end+=4;
		break;
	    }
	    if(c=='~')
		if(sf_get_nschar(SP_ANYSPACE,cur->prev)=='>' && sf_get_nschar(SP_ANYSPACE,cur->prev)==EOF) {
		    cur->priv=1;
		    return 1;
		}
	    if(c<'!' || c>'u')
		gerror(2223,"(sf_a85) Input error: unexpected char %c",c);
	    out=out*85+c-'!';
	}
	if(c=='z' && n==0)
	    continue;
	for(c=n;c<5;c++)
	    out=out*85;
	for(c=0;c<n-1;c++) {
	    cur->end[n-2-c]=out&255;
	    out>>=8;
	}
	cur->end+=n-1;
    }
    TRACE(100, "(sf_a85) Buffer %d-%d",cur->data-cur->buf,cur->end-cur->buf);
    return 0;
}

static int
sf_rc4(struct fchain *cur) {
    int avail_in=0,avail_out,n;

    bufshift(cur,cur->end-cur->data);
    if (!cur->priv) {
	TRACE(100, "(sf_rc4) Signalling EOF");
	return 1;
    }

    avail_out=cur->buf+STREAMBLKLEN-cur->end;

    for(;avail_out>0;) {
	if (cur->prev->data >= cur->prev->end)
	    cur->prev->func(cur->prev);
	if(!(avail_in=cur->prev->end-cur->prev->data))
	    break;
	TRACE(100,"(sf_rc4) before decryption: avail_in=%d, avail_out=%d",avail_in,avail_out);
	n=MIN(avail_out,avail_in);
	rc4_conv((struct rc4_state *) cur->priv,cur->end,cur->prev->data,n);
	cur->prev->data+=n;
	cur->end+=n;
	avail_out-=n;
    }

#if 0
    HTRACE(100,cur->data,(u32) (cur->end-cur->data),"(rc4 log)");
#endif

    TRACE(100, "(sf_rc4) Buffer %d-%d, avail_in: %d",cur->data-cur->buf,cur->end-cur->buf,avail_in);
    if(!avail_in) {
	cur->priv=(addr_int_t) NULL;
	return (cur->end <= cur->data);
    }
    return 0;
}

static fcf_t
sf_func(byte *fname) {
    if(!memcmp(fname,"ASCIIHexDecode",14))
	return sf_ahex;
    if(!memcmp(fname,"ASCII85Decode",13))
	return sf_a85;
    if(!memcmp(fname,"FlateDecode",11))
	return sf_inflate;
    return NULL;
}

static int
check_stream(s32 l) {
    char buf[10];
    int i;

    skip_space(SP_ANYWCOMM);
    pdf_read(buf,6);
    if(memcmp(buf,"stream",6))
	return -1;
    switch(pdf_get_char()) {
	case '\r':
	    if(pdf_get_char()!='\n')
		return -1;
	    break;
	case '\n':
	    break;
	default:
	    return -1;
    }

    i=pdf_tell();
    pdf_seek(i+l);
    skip_space(SP_ANYWCOMM);
    pdf_read(buf,9);
    if(memcmp(buf,"endstream",9) || skip_space(SP_ANYWCOMM)==0)
	return -1;
    pdf_seek(i);
    return 0;
}

static int
check_i_stream(s32 n) {
    OBJECT obj,length,filter,dpar,extfile;
    OBJ_GET streamdict[]={{"Length",&length},{"Filter",&filter},{"DecodeParms",&dpar},{"F",&extfile},{NULL,NULL}};
    ARRAY_ENTRY atmp,*ai;
    fcf_t sff;
    struct fchain *tf;
    int streamobj,streamgen;
    struct rc4_state rc4l;

    sf_top=NULL;
    TRACE(100,"(check_i_stream) Encrypt: %d(%d,%d)",encrypted,lastobj,lastgen);
    encrypted|=0x01;
    obj=get_i_obj(lastobj=n);
    TRACE(100,"(check_i_stream) Encrypt: %d(%d,%d)",encrypted,lastobj,lastgen);
    if(obj.type!=OT_DICT)
	return -1;
    parse_dict(obj.value.d,streamdict);
    if(extfile.type!=OT_UNKNOWN || dpar.type!=OT_UNKNOWN)
	return -1;
    
    /* deref length without any wrong side-effect */
    savefilepos();
    rc4l=rc4ss;
    streamobj=lastobj;
    streamgen=lastgen;
    
    obj_deref(&length);
    if(length.type!=OT_INT)
	return -1;

    restorefilepos();
    rc4ss=rc4s=rc4l;
    lastobj=streamobj;
    lastgen=streamgen;

    if(filter.type!=OT_UNKNOWN && filter.type!=OT_NAME && filter.type!=OT_ARRAY)
	return -1;
    mp_flush(sf_pool);
    sf_top=mp_alloc(sf_pool,sizeof(struct fchain));
    sf_top->func=sf_read;
    sf_top->end=sf_top->data=sf_top->buf;
    sf_top->priv=length.value.n;
    if((encrypted&0x03)==3) {
	tf=mp_alloc(sf_pool,sizeof(struct fchain));
	tf->prev=sf_top;
	sf_top=tf;
	tf->end=tf->data=tf->buf;
	rc4sss=rc4ss;
	tf->priv=(addr_int_t) &rc4sss;
	tf->func=sf_rc4;
	TRACE(200,"(check_i_stream) sff=RC4DECRYPT");
    }
    if(filter.type!=OT_UNKNOWN) {
	if(filter.type==OT_ARRAY) {
	    ai=filter.value.a;
	} else {
	    atmp.obj=filter;
	    atmp.next=NULL;
	    ai=&atmp;
	}
	for(;ai;ai=ai->next) {
	    if(ai->obj.type!=OT_NAME)
		return -1;
	    if(!(sff=sf_func(ai->obj.value.s)))
		return -1;
	    TRACE(200,"(check_i_stream) sff=%s",sff==sf_ahex?"ASCII HEX":(sff==sf_a85?"ASCII 85":"INFLATE"));
	    tf=mp_alloc(sf_pool,sizeof(struct fchain));
	    tf->prev=sf_top;
	    sf_top=tf;
	    tf->end=tf->data=tf->buf;
	    tf->priv=0;
	    tf->func=sff;
	}
    }
    return check_stream(length.value.n);
}

static void
decrypt_init(OBJECT encrypt, OBJECT fileid) {
    OBJECT filter,rev,opass,upass,privs,fver,len;
    OBJ_GET encryptdict[]={{"Filter",&filter},{"R",&rev},{"O",&opass},{"U",&upass},{"P",&privs},{"V",&fver},{"Length",&len},{NULL,NULL}};
    struct MD5Context md5c;
    byte md5[16],temp[84];
    s32 priv32;
    byte padstr[32]={0x28,0xbf,0x4e,0x5e,0x4e,0x75,0x8a,0x41,0x64,0x00,0x4e,0x56,0xff,0xfa,0x01,0x08,0x2e,0x2e,0x00,0xb6,0xd0,0x68,0x3e,0x80,0x2f,0x0c,0xa9,0xfe,0x64,0x53,0x69,0x7a};

    if(encrypt.type!=OT_DICT || fileid.type!=OT_ARRAY || fileid.value.a->obj.type!=OT_STRING || fileid.value.a->obj.value.str.l!=16)
	gerror(2220,"/Encrypt or /ID object of incorrect type");
    parse_dict(encrypt.value.d,encryptdict);
    if(filter.type!=OT_NAME || rev.type!=OT_INT || opass.type!=OT_STRING || upass.type!=OT_STRING ||
	    privs.type!=OT_INT || ( fver.type!=OT_INT && fver.type!=OT_UNKNOWN))
	gerror(2220,"/Encrypt contents incorrect");
    if(memcmp(filter.value.s,"Standard",9) || ( rev.value.n!=2 && rev.value.n!=3 ) || fver.value.n!=1 ||
	    opass.value.str.l!=32 || upass.value.str.l!=32)
	gerror(2220,"Encrypt: unknown Filter or filter settings");
    if(respect_user_rights && privs.value.n & 528 == 0)
	gerror(2224,"Encrypt: no rights to extract text");

    /*
     * key1=substr(pass . padstr,32); but pass==""
     */
    encrypted=3;

    memcpy(temp,padstr,32);
    memcpy(temp+32,opass.value.str.i,32);
    priv32=privs.value.n;
    temp[64]=priv32 & 0xff;
    temp[65]=( priv32 >> 8 ) & 0xff;
    temp[66]=( priv32 >> 16) & 0xff;
    temp[67]=( priv32 >> 24) & 0xff;
    memcpy(temp+68,fileid.value.a->obj.value.str.i,16);
    MD5Init(&md5c);
    MD5Update(&md5c,temp,84);
    MD5Final(md5, &md5c);
    memcpy(decryptkey,md5,5);
    TRACE(100,"(decrypt_init) Encrypt: %d(%d,%d)",encrypted,lastobj,lastgen);
}

static s32 rootref, inforef;

static void
getxrefsec(s32 start) {
    char buf[MAX_BUFF_SIZE], *ptr;
    int i,j,o_first, o_count;
    OBJECT trailer,root,info,encrypt,fileid,prev;
    OBJ_GET trailerdict[]={{"Root",&root},{"Prev",&prev},{"Info",&info},{"Encrypt",&encrypt},{"ID",&fileid},{NULL,NULL}};
    int prevxrefsect=0;
    int xb,xi;
    int saveencr;

    TRACE(200,"xref pos: %d",start);
    pdf_seek(start);
    in_get_line(buf);
    if(memcmp(buf,"xref",5))
	gerror(2220,"(getxrefsec) 'xref' expected at pos %d",start);
    do {
	/*
	 * start of xref subsection: first line with start and count numbers and
	 * than line for each object follows
	 */
	in_get_line(buf);
	o_first=strtol(buf,&ptr,10);
	o_count=strtol(ptr,&ptr,10);
	TRACE(200,"Subsection start at %d with %d items",o_first,o_count);

	for(i=o_first;i<o_first+o_count;i++) {
	    if((j=in_get_line(buf))!=20)
		gerror(2220,"(getxrefsec) wrong length of xref line: %d (object %d)",j,i);
	    if(i>=xreft_size*xreft_size)
		gerror(2220,"(getxrefsec) Object number out of range: %d",i);
	    if(i==0)
		continue;
	    xb=i/xreft_size;
	    xi=i%xreft_size;
	    if(!xreftroot[xb])
		xreftroot[xb]=mp_alloc_zero(global_pool,sizeof(OBJ_START)*xreft_size);
	    if(xreftroot[xb][xi].position!=0)    /* already known object? */
		continue;
	    xreftroot[xb][xi].position  =strtol(buf,&ptr,10);
	    xreftroot[xb][xi].generation=strtol(ptr,&ptr,10);
	    switch(ptr[1]) {
		case 'n': break;	    /* everything is done */
		case 'f': xreftroot[xb][xi].position=-1;  /* a flag that this object was deleted */
		      break;
		default:  gerror(2220,"(getxrefsec) 'xref' table corrupted. 'n' or 'f' expected, '%c' found",ptr[1]);
	    }
	    TRACE(200,"Object %d stored: (%d,%d)",i,xreftroot[xb][xi].position,xreftroot[xb][xi].generation);
	}
    } while (is_numchar(pdf_check_char()));

    /* xref subsections are done, now look for the trailer */

    skip_space(SP_ANYSPACE);
    pdf_read(buf,7);
    if(memcmp(buf,"trailer",7) || skip_space(SP_ANYWCOMM)==0)
	gerror(2220,"(getxrefsec) Trailer keyword not found: %s at %d",buf,pdf_tell());
    TRACE(200,"The trailer dictionary at %d",pdf_tell());

    saveencr=encrypted;
    encrypted&=~2;		/* Trailer with file ID and Encrypt objects are never encrypted */

    trailer=get_obj();

    if(trailer.type!=OT_DICT)
	gerror(2220,"(getxrefsec) Trailer isn't a dictionary, but type %d",trailer.type);

    TRACE(100,"Trailer:");
    PRINTOBJ(100,trailer);
    parse_dict(trailer.value.d,trailerdict);
    obj_deref(&encrypt);
    obj_deref(&fileid);

    encrypted=saveencr;

    if(encrypt.type!=OT_UNKNOWN && encrypt.type!=OT_NULL)
	decrypt_init(encrypt,fileid);
    if(prev.type!=OT_UNKNOWN)
	    if(prev.type==OT_INT)
		    prevxrefsect=prev.value.n;
	    else
		    gerror(2220,"(getxrefsec) Can't locate Prev xref table");
    if(root.type==OT_OBJREF || root.type==OT_NULL) {
	TRACE(200,"Root: %d",root.value.n);
	if(!rootref && root.value.n)
	    rootref=root.value.n;
    }
    if(info.type==OT_OBJREF || info.type==OT_NULL) {
	TRACE(200,"Info: %d",info.value.n);
	if(!inforef && info.value.n)
	    inforef=info.value.n;
    }

    mp_flush(page_pool);

    if(prevxrefsect)
	getxrefsec(prevxrefsect);
}

static void
getxref(void) {
    char buf[MAX_BUFF_SIZE];
    int i;
    s32 pos;

    if(gthis->orig_size<LOOK4STARTXREF)
	gerror(2200,"(getxref) PDF file too small");
    pdf_seek_end(-LOOK4STARTXREF);
    pdf_read(buf,LOOK4STARTXREF);
    TRACE(1,"BUF: %s",buf);

    buf[LOOK4STARTXREF]=0;
     /* 12=strlen("startxref 1 %%EOF") */
    for(i=LOOK4STARTXREF-12;i>0 && memcmp("startxref",buf+i,9);i--);
    if(i<=0)
	gerror(2220,"(getxref) 'startxref' not found");
    pos=i+=9; /* length("startxref") */
    while(is_space(buf[i],SP_ANYSPACE))
	i++;
    if(pos==i)
	gerror(2220,"(getxref) 'startxref ' not found");
    if((pos=atol(buf+i))==0)
	gerror(2220,"(getxref) no value of 'startxref'");

    xreftroot=(OBJ_START **)mp_alloc_zero(global_pool,sizeof(void *) * xreft_size);

    getxrefsec(pos);	/* file offset of the first xref section */
}

static jmp_buf recoverable_error_jump;

static inline void
check_overflow(void) {
    if (btell(pdf_out) > max_decode_size) {
	gobj_truncate();
	longjmp(recoverable_error_jump, 1);
    }
}

/* output decoded stream to log */

#if 0
static void
cs_tee(void) {
    int c;
    byte *b=stringbuf, *tmp=stringbuf;

    TRACE(200,"Content stream");
    while((c=in_get_char())!=EOF) {
	if(b-stringbuf<STRINGBUFLEN)
	    *b++=c;
    }
    *b=0;
    /* walkaround the nul-in-the-middle attack problem :-) */
    for(tmp=stringbuf;tmp<b;tmp++)
	if(!*tmp)
	    *tmp=' ';
    TRACE(200,"Value: (%d) %s",b-stringbuf,stringbuf);
}

/* parse content stream - and log the result object tree */
static void
cs_parse(void) {
    OBJECT obj={OT_ARRAY,{0}};
    ARRAY_ENTRY *cur=NULL,*prev=NULL;
    int save_trace=trace;

    TRACE(200,"Content stream parsing");
    trace=0;	/* don't log parsing, log the result object tree only */
    while(in_check_nschar(SP_ANYWCOMM)!=EOF) {
	if(!cur) {
	    cur=obj.value.a=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	} else {
	    prev=cur;
	    cur=cur->next=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	}
	cur->obj=get_obj();
	if(cur->obj.type==OT_UTOK && !memcmp(cur->obj.value.s,"ID",3))
	    do {
		if(skip_space(SP_ANYWDELIM)==EOF)
		    break;
		cur->obj=get_tok();
	    } while(memcmp(cur->obj.value.s,"EI",3));
    }
    trace=save_trace;
    TRACE(200,"End of parsing Content stream");

    if(!cur) {			    /* empty dict */
	TRACE(200,"(empty)");
    } else {
	cur->next=NULL;		    /* the last element's next pointer is a terminator */
	PRINTOBJ(200,obj);
    }
    TRACE(200,"End of Content stream");
}
#endif

/* Font handling functions */

static struct mempool *global_pool;
static struct resources *restop;
static struct font *fonttop;

static struct mempool *global_pool;
static struct gstate *gstop;

static s32
so2i(OBJECT obj, byte lmin, byte lmax, byte *olen) {
    s32 ret=0;
    int i;

    if(obj.type!=OT_STRING || obj.value.str.l<lmin || obj.value.str.l>lmax)
	return -1;
    if(olen)
	*olen=obj.value.str.l;
    for(i=0;i<obj.value.str.l;i++)
	ret=ret*256+obj.value.str.i[i];
    return ret;
}

/*
 * This range disallow Adobe additional Unicode Values too
 * http://partners.adobe.com/asn/developer/type/corporateuse.txt
 */
static inline int
in_unirange(int u) {
    return ((u>=0x20 && u<0xe000) || (u>=0xf900 && u<=0xffff));
}

static struct unichar tempbuf[TEMPBUFLEN];
static word *unistr[UNICODESTRINGCNT];
static int unistrp;

static struct fencoding *
enc_hash(struct unichar *buf, uns len, int bytes) {
    struct unichar *tt,*bend=buf+len;
    struct fencoding *out;

    if(!len || bytes>2)
	return NULL;
    out=mp_alloc(global_pool,sizeof(struct fencoding));
    out->bytes=bytes;
    if(bytes==1) {
	int min=255,max=0;
	
	for(tt=buf;tt<bend;tt++) {
	    if(tt->fcode<min)
		min=tt->fcode;
	    if(tt->fcode>max)
		max=tt->fcode;
	}
	TRACE(200,"(enc_hash) MINMAX %d, %d",min,max);
	ASSERT(max<256);
	out->len=max-min+1;
	out->start=min;
	out->table=mp_alloc_zero(global_pool,out->len*sizeof(struct unichar));
	for(tt=buf;tt<bend;tt++)
	    (out->table)[tt->fcode-min]=*tt;
	return out;
    } else {			/* bytes==2 */
	int ts,skip,fc;
	struct unichar *ht;
	
	ts=nextprime(MAX(24,len*14/10));
	skip=nextprime(ts*3/4);
	ASSERT(ts!=skip);
	ht=mp_alloc_zero(global_pool,ts*sizeof(struct unichar));
	for(tt=buf;tt<bend;tt++) {
	    fc=tt->fcode % ts;
	    while(ht[fc].fcode)
		fc=(fc+skip)%ts;
	    ht[fc]=*tt;
	    TRACE(200,"(enc_hash) (2 bytes) Stored %d at %d(%d)",tt->unicode,fc,tt->fcode);
	}
	out->len=ts;
	out->start=skip;
	out->table=ht;
	return out;
    }
}

static int
parse_one_unichar(ARRAY_ENTRY *temp, struct unichar *tt) {
    s32 u;

    if(temp->obj.value.str.l==2) {
	if(!in_unirange(u=so2i(temp->obj,2,2,NULL))) {
	    TRACE(200,"(uni_parse) Unicode <%.4x> out of range",u);
	    tt--;
	    return 1;
	}
	tt->unicode=u;
	TRACE(200,"(uni_parse) Unicode char <%.4x> -> <%.4x> stored",tt->fcode,tt->unicode);
    } else {
	int j,jj;
	if(unistrp>=UNICODESTRINGCNT || temp->obj.value.str.l>UNICODESTRMAXLEN) {
	    TRACE(0,"Max. count of ToUnicode strings or length of the current string exceeded application's limits");
	    tt--;
	    return 1;
	}
	tt->unicode=0xe000+unistrp;
	temp->obj.value.str.l-=temp->obj.value.str.l%2;
	unistr[unistrp]=mp_alloc_zero(global_pool,temp->obj.value.str.l+2);
	for(j=0,jj=0;j<temp->obj.value.str.l;j+=2)
	    if(in_unirange(u=temp->obj.value.str.i[j]*256+temp->obj.value.str.i[j+1]))
		unistr[unistrp][jj++]=u;
	unistr[unistrp][jj]=0;
	TRACE(200,"(uni_parse) Unicode string <%.4x> -> <%.4x> stored",tt->fcode,tt->unicode);
	unistrp++;
    }
    return 0;
}

static struct fencoding *
uni_parse(void) {
    ARRAY_ENTRY *start=NULL,*cur=NULL,*temp=NULL,*ta=NULL;
    struct fencoding *enc;

    int i;
    struct unichar *tt=tempbuf;
    s32 s,e;
    byte lcode;

    TRACE(200,"ToUnicode stream parsing");
    /*
     * Parse the input stream and store encoding table in tempbuf.
     */
    lcode=0;
    while(in_check_nschar(SP_ANYWCOMM)!=EOF) {
	if(!cur)
	    cur=start=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	else
	    cur=cur->next=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	cur->next=NULL;
	cur->obj=get_obj();
	if(cur->obj.type==OT_UTOK) { /* an operator means action */
	    TRACE(200,"ToUnicode op %s",cur->obj.value.s);
	    if(!memcmp(cur->obj.value.s,"endbfrange",11)) {
/*
 * possible syntax of one argument of bfrange:
 *
 * <from> <to> <UNI>  range from-to filled with values UNI..UNI+to-from
 * <from> <to> <uni_string>                     strings, last byte incremented
 * <from> <to> [ <UNI | uni_string> ... ]       values from the array
 */
		for(temp=start;temp && temp!=cur;temp=temp->next) {
		    if((s=so2i(temp->obj,lcode?lcode:1,lcode?lcode:2,&lcode))<0)
			return NULL;
		    if(!(temp=temp->next))
			return NULL;
		    if((e=so2i(temp->obj,lcode,lcode,&lcode))<0)
			return NULL;
		    if(!(temp=temp->next))
			return NULL;
		    TRACE(200,"(uni_parse) bfrange %d-%d (%d)",s,e,e-s+1);
		    if(temp->obj.type==OT_STRING) {
			temp->obj.value.str.l-=temp->obj.value.str.l%2;
			for(i=0;i<e-s+1 && tt<tempbuf+TEMPBUFLEN;i++,tt++) {
			    tt->fcode=s+i;
			    if(parse_one_unichar(temp,tt))
				continue;
			    temp->obj.value.str.i[temp->obj.value.str.l-1]++;
			    TRACE(200,"added range part: %d %d",tt->fcode,tt->unicode);
			}
			if(i<e-s+1)
			    return NULL;
		    } else if(temp->obj.type==OT_ARRAY) {
			for(i=0,ta=temp->obj.value.a;tt<tempbuf+TEMPBUFLEN && i<e-s+1 && ta;i++,ta=ta->next,tt++) {
			    if(ta->obj.type!=OT_STRING || ta->obj.value.str.l<2)
				return NULL;
			    tt->fcode=s+i;
			    if(parse_one_unichar(ta,tt))
				continue;;
			}
			if(i<e-s+1)
			    return NULL;
		    } else
			return NULL;
		}
	    } else if(!memcmp(cur->obj.value.s,"endbfchar",10)) {
/*
 * possible syntax of one argument of fbchar:
 * <char> <UNI | uni_str>
 */

		for(temp=start;temp && temp!=cur && tt<tempbuf+TEMPBUFLEN;temp=temp->next,tt++) {
		    if((s=so2i(temp->obj,lcode?lcode:1,lcode?lcode:2,&lcode))<0)
			return NULL;
		    if(!(temp=temp->next))
			return NULL;
		    if(temp->obj.type!=OT_STRING)
			return NULL;
		    tt->fcode=s;
		    if(parse_one_unichar(temp,tt))
			continue;;
		}
	    }
	    cur=start=NULL;
	}
    }
/*
 * create encoding structure
 */
    enc=enc_hash(tempbuf,tt-tempbuf,lcode);
    if(enc) {
	TRACE(200,"End of parsing ToUnicode stream, %d entries",enc->len);
	HTRACE(200,enc->table,enc->len *sizeof(struct unichar), "Encoding table (%d), values %dbit",enc->len,enc->bytes*8);
    } else
	TRACE(200,"ERROR while parsing ToUnicode stream");
    return enc;
}

/* Four built-in encoding vectors */
static struct fencoding *
builtinenc(byte *enc) {
    if(!memcmp(enc,"MacRomanEncoding",17))
	return &MacRomanEncoding;
    if(!memcmp(enc,"WinAnsiEncoding",16))
	return &WinAnsiEncoding;
    if(!memcmp(enc,"PDFDocEncoding",15))
	return &PDFDocEncoding;
    if(!memcmp(enc,"MacExpertEncoding",18))
	return &MacExpertEncoding;
    return NULL;
}

/*
 * FIXME:
 * Apply the full algorithm published by Adobe at URL:
 * http://partners.adobe.com/asn/developer/typeforum/unicodegn.html
 */

static struct fencoding *
addencdiffs(struct unichar *tt, uns start, uns end, ARRAY_ENTRY *sdiff) {
    ARRAY_ENTRY *cur;
    byte code;
    byte *n;
    const struct glyph *g;
    struct fencoding *oenc;

    for(cur=sdiff;cur && cur->obj.type==OT_INT;) {
	code=cur->obj.value.n;
	TRACE(200,"(addencdiffs) Block sdiff at %d",code);
	for(cur=cur->next;cur && cur->obj.type==OT_NAME;cur=cur->next) {
	    TRACE(200,"(addencdiffs) Got name %s",cur->obj.value.s);
	    for(n=cur->obj.value.s;*n;n++)
		if(*n=='.')
		    *n=0;
	    g=is_glyph(cur->obj.value.s,0);
	    TRACE(200,"(addencdiffs) Name %s = glyph %.4x placed at %d",cur->obj.value.s,g ? g->unival : 0xfffff,code);
	    if(g) {
		tt[code].fcode=code;
		tt[code].unicode=g->unival;
		start=MIN(code,start);
		end=MAX(code,end);
	    }
	    code++;
	}
    }
    oenc=mp_alloc(global_pool,sizeof(struct fencoding));
    oenc->bytes=1;
    oenc->len=end-start+1;
    oenc->start=start;
    oenc->table=mp_alloc(global_pool,(end-start+1) * sizeof(struct unichar));
    memmove(oenc->table,tempbuf+start,(end-start+1) * sizeof(struct unichar));
    HTRACE(200,oenc->table,oenc->len *sizeof(struct unichar), "Encoding table (%d), values %dbit",oenc->len,oenc->bytes*8);
    return oenc;
}

/*
 * This code is as terrible as Adobe specification about Encoding vectors :-|
 * (see chapter 5 in PDF Reference Manual and additional notes placed in the
 * whole document)
 */

static struct fencoding *
enc_parse(OBJECT enc,OBJECT subtype,OBJECT basefont) {
    OBJECT baseenc, diffs;
    OBJ_GET encdict[]={{"BaseEncoding",&baseenc},{"Differences",&diffs},{NULL,NULL}};
    struct fencoding *benc;

    obj_deref(&enc);

    TRACE(200,"(enc_parse) Std 14?");
    /* 14 built-in fonts */
    if(enc.type==OT_UNKNOWN && subtype.type==OT_NAME && !memcmp(subtype.value.s,"Type1",6) && basefont.type==OT_NAME) {
	if(!strcmp(basefont.value.s,"Times-Roman") || !strcmp(basefont.value.s,"Times-Bold") ||
		!strcmp(basefont.value.s,"Times-Italic") || !strcmp(basefont.value.s,"Times-BoldItalic") ||
		!strcmp(basefont.value.s,"Helvetica") || !strcmp(basefont.value.s,"Helvetica-Bold") ||
		!strcmp(basefont.value.s,"Helvetica-Oblique") || !strcmp(basefont.value.s,"Helvetica-BoldOblique") ||
		!strcmp(basefont.value.s,"Courier") || !strcmp(basefont.value.s,"Courier-Bold") ||
		!strcmp(basefont.value.s,"Courier-Oblique") || !strcmp(basefont.value.s,"Courier-BoldOblique"))
	    return &StandardEncoding;
	if(!strcmp(basefont.value.s,"Symbol"))
	    return &SymbolEncoding;
	if(!strcmp(basefont.value.s,"ZapfDingbats"))
	    return NULL;    /* no unicode values */
	/*
	 * FIXME: In future versions, we may add font file parsing and setting
	 * up the encoding vector according this information.
	 */
	return NULL;
    }

    TRACE(200,"(enc_parse) Std Enc Name?");
    if(enc.type==OT_NAME)
	return builtinenc(enc.value.s);

    TRACE(200,"(enc_parse) Dict?");
    if(enc.type==OT_DICT) {
	parse_dict(enc.value.d,encdict);
	TRACE(200,"(enc_parse) BaseEnc %d, Diffs %d",baseenc.type,diffs.type);
	if(baseenc.type==OT_NAME) {
	    switch(diffs.type) {
		case OT_UNKNOWN:
		    return builtinenc(baseenc.value.s);
		case OT_ARRAY:
		    bzero(tempbuf,256);
		    benc=builtinenc(baseenc.value.s);
		    memmove(tempbuf+benc->start,benc->table,benc->len*sizeof(struct unichar));
		    benc=addencdiffs(tempbuf,benc->start,benc->len,diffs.value.a);
		    return benc;
		default:
		    return NULL;
	    }
	} else {
	    TRACE(200,"(enc_parse) Diffs.type-OT_ARRAY=%d",diffs.type-OT_ARRAY);
	    if(diffs.type!=OT_ARRAY)
		return NULL;
	    TRACE(200,"(enc_parse) calling addencdiffs");
	    benc=addencdiffs(tempbuf,0,0,diffs.value.a);
	    if(benc)
		HTRACE(200,benc->table,benc->len *sizeof(struct unichar), "Encoding table (%d), values %dbit",benc->len,benc->bytes*8);
	    return benc;
	}
    }
    return NULL;
}

static struct fencoding *
parse_fontenc(uns fobj) {
    OBJECT touni,encoding,subtype,basefont;
    OBJ_GET fontdict[]={{"ToUnicode",&touni},{"Encoding",&encoding},
	{"Subtype",&subtype},{"BaseFont",&basefont},{NULL,NULL}};
    struct font *t;
    OBJECT fn;

    for(t=fonttop;t;t=t->next) {
	if(t->obj==fobj)
	    break;
    }
    if(t)
	return t->enc;
    fn=get_i_obj(fobj);
    if(fn.type!=OT_DICT)
	return NULL;
    t=mp_alloc(global_pool,sizeof(struct font));
    parse_dict(fn.value.d,fontdict);
    if(touni.type==OT_OBJREF && check_i_stream(touni.value.n)==0) {
	TRACE(200,"ToUnicode object #%d",touni.value.n);
	stream_array[0]=touni.value.n;
	stream_array[1]=0;
	set_input_method(stream_in);
	t->enc=uni_parse();
	set_input_method(pdf_in);
	t->next=fonttop;
	t->obj=fobj;
	fonttop=t;
	return fonttop->enc;
    }
    TRACE(200,"Encoding object #%d",encoding.type==OT_OBJREF?(uns)encoding.value.n:fobj);
    t->enc=enc_parse(encoding,subtype,basefont);
    t->next=fonttop;
    t->obj=fobj;
    fonttop=t;
    return fonttop->enc;

    return NULL;
}

static struct gsdata gsnull={-1,NULL,-1,-1,trm_nochange};

static struct gstate *
parse_gstate(uns gobj, struct fontname *resfonttop) {
    OBJECT gs,font;
    OBJ_GET gsdict[]={{"Font",&font},{NULL,NULL}};
    struct gstate *gg;
    struct fontname *fn;

    for(gg=gstop;gg;gg=gg->next)
	if(gg->obj=gobj)
	    break;
    if(gg) {
	TRACE(200,"(parse_gstate) Returning already known value");
	return gg;
    }
    gs=get_i_obj(gobj);
    if(gs.type!=OT_DICT)
	return NULL;
    parse_dict(gs.value.d,gsdict);
    gg=mp_alloc(global_pool,sizeof(struct gstate));
    gg->obj=gobj;
    gg->next=gstop;
    gstop=gg;
    if(font.type==OT_ARRAY && font.value.a && font.value.a->obj.type==OT_OBJREF) {
	for(fn=resfonttop;fn;fn=fn->next)
	    if(fn->obj==(uns)font.value.a->obj.value.n)
		break;
	if(fn) {
	    gg->data=mp_alloc(global_pool,sizeof(struct gsdata));
	    gg->data[0]=gsnull;
	    gg->data->tf=fn->enc;
	} else {
	    gg->data=&gsnull;
	}
    } else {
	gg->data=&gsnull;
    }
    return gg;
}

static struct resources *
parse_resources(OBJECT res, uns robj) {
    OBJECT fonts,gstate;
    OBJ_GET resdict[]={{"Font",&fonts},{"ExtGState",&gstate},{NULL,NULL}};
    struct resources *t;
    struct fontname *fn;
    struct gsname *gn;
    struct gstate *gs;
    DICT_ENTRY *d;
    int i;

    if(res.type==OT_OBJREF)
	res=get_i_obj(robj=res.value.n);
    if(res.type!=OT_DICT)
	return NULL;

    for(t=restop;t;t=t->next) {
	if(t->obj==robj)
	    break;
    }
    if(t)
	return t;
    t=mp_alloc_zero(global_pool,sizeof(struct resources));
    t->next=restop;
    t->obj=robj;
    restop=t;
    parse_dict(res.value.d,resdict);
    obj_deref(&fonts);
    if(fonts.type==OT_DICT) {
	for(d=fonts.value.d;d;d=d->next) {
	    if(d->obj.type!=OT_OBJREF)
		continue;
	    i=strlen(d->name)+1;
	    fn=mp_alloc_zero(global_pool,sizeof(struct fontname));
	    fn->next=restop->fonts;
	    fn->obj=d->obj.value.n;
	    fn->namehash=hash_string(d->name);
	    fn->name=mp_alloc(global_pool,i);
	    memcpy(fn->name,d->name,i);
	    restop->fonts=fn;
	}
	for(fn=restop->fonts;fn;fn=fn->next)
	    fn->enc=parse_fontenc(fn->obj);
    }
    obj_deref(&gstate);
    if(gstate.type==OT_DICT) {
	for(d=gstate.value.d;d;d=d->next) {
	    if(d->obj.type!=OT_OBJREF)
		continue;
	    i=strlen(d->name)+1;
	    gn=mp_alloc(global_pool,sizeof(struct gsname));
	    gn->next=restop->gstates;
	    gn->namehash=hash_string(d->name);
	    gn->name=mp_alloc(global_pool,i);
	    memcpy(gn->name,d->name,i);
	    gn->obj=d->obj.value.n;
	    restop->gstates=gn;
	    TRACE(200,"(parse_resources) GState: %s(%d)=obj %d",d->name,gn->namehash,gn->obj);
	}
	for(gn=restop->gstates;gn;gn=gn->next) {
	    gs=parse_gstate(gn->obj,restop->fonts);
	    gn->gsd=gs ? gs->data : NULL;
	    if(gn->gsd)
		TRACE(200,"(parse_resources) GState data: %d={obj %d, ctm_sy %d, tf %d, tfs %d, tm_sy %d, trm %d}", gn->namehash, gs->obj, gn->gsd->ctm_sy,(int)gn->gsd->tf, gn->gsd->tfs, gn->gsd->tm_sy, gn->gsd->trm);
	    else
		TRACE(200,"(parse_resources) GState data: NULL");
	}
    }
    return restop;
}

/*
 * Graphic State stack; default value is stored in [0] element
 */

static struct gsdata gstack[GS_MAX_DEPTH]={{1,NULL,0,1,trm_fill}}, *gsmax=gstack+GS_MAX_DEPTH, *gscur;

static void
change_font(byte *fname, OBJECT fsize, struct fontname *fntop) {
    struct fontname *fn;
    uns fnh;

    if(!fname || !fname[0] || !fntop ||!gscur || (fsize.type!=OT_INT && fsize.type!=OT_REAL)) {
	TRACE(200,"(change_font) RETURN fname(%s), fntop(%d), fsize.type(%d)",fname,(int)fntop,fsize.type);
	return;
    }
    fnh=hash_string(fname);
    for(fn=fntop;fn;fn=fn->next)
	if(fn->namehash==fnh && !strcmp(fn->name,fname))
	    break;
    if(fn) {
	gscur->tf=fn->enc;
	if((fnh=obj_int_real(fsize)))
	    gscur->tfs=fnh;
	TRACE(200,"(change_font) Font set to font obj #%d",fn->obj);
    } else {
	TRACE(200,"(change_font) Unknown font name");
	gscur->tf=NULL;
    }
}

static void
change_gs(byte *gsname, struct gsname *gntop) {
    struct gsname *gn;
    uns gnh,gnl;

    if(!gsname || !gntop ||!gscur)
	return;
    gnl=strlen(gsname)+1;
    if(gnl<2)
	return;
    gnh=hash_string(gsname);
    for(gn=gntop;gn;gn=gn->next)
	if(gn->namehash==gnh && !memcmp(gn->name,gsname,gnl))
	    break;
    if(gn && gn->gsd) {
	if(gn->gsd->ctm_sy>=0)
	    gscur->ctm_sy=gn->gsd->ctm_sy;
	if(gn->gsd->tf)
	    gscur->tf=gn->gsd->tf;
	if(gn->gsd->tfs>=0)
	    gscur->tfs=gn->gsd->tfs;
	if(gn->gsd->tm_sy>=0)
	    gscur->tm_sy=gn->gsd->tm_sy;
	if(gn->gsd->trm>=0)
	    gscur->trm=gn->gsd->trm;
    } else {
	TRACE(0,"Unknown GS name");
	*gscur=gstack[0];
    }
}

static uns current_class;				/* Current class in current output stream */
static uns queued_class;				/* Class of the next character we'll write */
#define WC_TYPE_MASK	0x0f				/* Lower bits are word type number WT_... or MT_... */
#define WC_BREAK	0x10				/* Force sentence break */
#define WC_SPACE	0x20				/* Force word break */
#define WC_META		0x80				/* We're writing meta-information */
static uns wordbuf[MAX_WORD_LEN];
static uns wordlen;

static void
flush_word(void) {
    struct fastbuf *s_out = (queued_class & WC_META) ? meta_out : pdf_out;

    TRACE(200, "(flush_word) Wordlen=%d current_class=%x queued_class=%x", wordlen, current_class, queued_class);
    if (!wordlen)
	return;
    if (wordlen >= MAX_WORD_LEN) {
	/* Oversize words are ignored and replaced by breaks */
	wordlen = 0;
	queued_class |= WC_BREAK;
	return;
    }
    if (current_class != queued_class) {
	if ((current_class ^ queued_class) & (WC_TYPE_MASK | WC_BREAK))
	    bputc(s_out, 0x80 + (queued_class & (WC_TYPE_MASK | WC_BREAK)));
	else
	    bputc(s_out, ' ');
	queued_class = current_class = queued_class & (WC_TYPE_MASK | WC_META);
    }
    for (uns i=0; i<wordlen; i++)
	bput_utf8(s_out, wordbuf[i]);
    if (trace >= 200) {
	byte buf[3*MAX_WORD_LEN+1], *p=buf;
	for (uns i=0; i<wordlen; i++)
	    PUT_UTF8(p, wordbuf[i]);
	*p++ = 0;
	LOG("(flush_word) out word: %s", buf);
    }
    check_overflow();
    wordlen=0;
}

static void
switch_class(uns class) {
    flush_word();
    if (class & (WC_META | WC_TYPE_MASK)) {
	if ((class ^ queued_class) & WC_META) {
	    ASSERT(class & WC_BREAK);
	    current_class = class & WC_META;
	}
	queued_class = (queued_class & ~(WC_META | WC_TYPE_MASK)) | (class & (WC_META | WC_TYPE_MASK));
    }
    queued_class |= class & (WC_BREAK | WC_SPACE);
}

static inline void
word_break(void) {
    switch_class(WC_SPACE);
}

static void
add_uchar(uns unicode) {
    int i;

    if(unicode>=0xe000 && unicode<0xe000+UNICODESTRINGCNT && unistr[unicode-0xe000]) {
	TRACE(200,"(add_uchar) char means unicode string");
	for(i=0;unistr[unicode-0xe000][i];i++)
	    add_uchar(unistr[unicode-0xe000][i]);
	TRACE(200,"(add_uchar) end of unicode string");
	return;
    }
    if(!in_unirange(unicode)) {
	TRACE(200,"(add_uchar) RETURN char out of unirange %.4x",unicode);
	return;
    }

    if (Uprint(unicode) && !Uspace(unicode)) {
	/*
	 * What about some non-word chars? (c),(R),<TM> etc.
	 */
	TRACE(200,"(add_uchar) add word char %.4x",unicode);
	if (wordlen < MAX_WORD_LEN)
	    wordbuf[wordlen++] = unicode;
    } else {
	TRACE(200,"(add_uchar) End of word");
	word_break();
    }
}

static void
output_enc_string(OBJECT in, struct fencoding *sf) {
    uns c,uc;
    int i;
    struct unichar cc;

    if(sf->bytes==1) {
	TRACE(200,"(output_enc_string) printing the string; encoding table %d-%d",sf->start,sf->start+sf->len);
	PRINTOBJ(200,in);
	for(i=0;i<in.value.str.l;i++) {
	    c=in.value.str.i[i];
	    if(c<sf->start || c>=sf->start+sf->len) {
		TRACE(200,"(output_enc_string) invalid input char %d",c);
		continue;
	    }
	    cc=sf->table[c-sf->start];
	    if(cc.fcode)
		add_uchar(cc.unicode);
	}
    } else { /* bytes==2 */
	for(i=0;i<in.value.str.l;i+=2) {
	    uc=c=in.value.str.i[i]*256+in.value.str.i[i+1];
	    do {
		cc=sf->table[c%sf->len];
		c=(c+sf->start)%sf->len;
	    } while(cc.fcode>0 && cc.fcode!=uc);
	    if(cc.fcode)
		add_uchar(cc.unicode);
	}
    }
}

static void
out_enc_string(OBJECT in) {
    struct fencoding *sf=gscur->tf;
    uns c, class;

    if(in.type!=OT_STRING) {
	TRACE(200,"(out_enc_string) RETURN !OT_STRING");
	return;
    }
    if(!sf) {
	TRACE(200,"(out_enc_string) RETURN !sf");
	return;
    }
    /*
     * don't output invisible text
     */
    if(gscur->trm==trm_nothing || gscur->trm==trm_nochange) {
	TRACE(200,"(out_enc_string) RETURN invisible text");
	return;
    }
    /*
     * guess string class from the text size
     */
    c=gscur->ctm_sy * gscur->tm_sy * gscur->tfs;
    TRACE(200,"(out_enc_string) Text size: %d*%d*%d=%d",gscur->ctm_sy,gscur->tm_sy,gscur->tfs,c);
    if(c>13)
	class=WT_BIG_HEADING;
    else if(c>11)
	class=WT_SMALL_HEADING;
    else if(c>8)
	class=WT_TEXT;
    else if(c>0)
	class=WT_SMALL;
    else {
	TRACE(200,"(out_enc_string) RETURN strange text size %d",c);
	return;
    }
    switch_class(class);
    output_enc_string(in, sf);
}

static inline void
out_pdfstring(OBJECT obj, uns class) {
    switch_class(class | WC_BREAK);
    output_enc_string(obj, &PDFDocEncoding);
}

/* parse content stream */

static void
cs_gettexts(struct resources *res) {
    OBJECT obj;
    ARRAY_ENTRY *start=NULL,*cur=NULL,*prev=NULL;

    int i,h,textmode=0;
    byte *s;
    s32 tm[4],tms;

    TRACE(200,"Content stream out text");
    gstack[1]=gstack[0];	/* initializing gs current state */
    gscur=gstack+1;
    
    while(in_check_nschar(SP_ANYWCOMM)!=EOF) {
	if(!cur) {
	    cur=start=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	} else {
	    prev=cur;
	    cur=cur->next=mp_alloc_zero(page_pool,sizeof(ARRAY_ENTRY));
	}
	cur->next=NULL;
	cur->obj=get_obj();
	if(cur->obj.type==OT_UTOK) { /* an operator */
	    /*
	     * No operator we are intersted in is longer than 2 chars
	     */
	    for(h=0,i=0,s=cur->obj.value.s;*s && i<2;s++)
		h=h*256+*s;
	    if(*s)
		h=0;
	    switch(h) {
		case 25453:       /* cm */
		    TRACE(200,"(cs_gettexts - cm)");
		    for(cur=start,i=0;i<3 && cur;i++)
		       cur= cur->next;
		    if(!cur)
			break;
		    if(cur->obj.type==OT_INT)
			gscur->ctm_sy*=cur->obj.value.n;
		    if(cur->obj.type==OT_REAL)
			gscur->ctm_sy*=cur->obj.value.r;
		    break;
		case 113:       /* q */
		    TRACE(200,"(cs_gettexts - q)");
		    if(gscur>gsmax) {
			TRACE(0,"Gstack overflow");
			break;
		    }
		    gscur[1]=gscur[0];
		    gscur++;
		    break;
		case 81:        /* Q */
		    TRACE(200,"(cs_gettexts - Q)");
		    if(gscur<=gstack+1) {
			TRACE(0,"Gstack underflow");
			break;
		    }
		    gscur--;
		    break;
		case 26483:       /* gs */
		    TRACE(200,"(cs_gettexts - gs)");
		    if(start->obj.type==OT_NAME)
			change_gs(start->obj.value.s,res->gstates);
		    break;
		case 21618:       /* Tr */
		    TRACE(200,"(cs_gettexts - Tr)");
		    if(textmode && start->obj.type==OT_INT && start->obj.value.n>trm_nochange && start->obj.value.n<trm_max)
			gscur->trm=start->obj.value.n;
		    break;
		case 21613:       /* Tm */
		    TRACE(200,"(cs_gettexts - Tm)");
		    for(cur=start,i=0;i<4 && cur;tm[i++]=obj_int_real(cur->obj),cur=cur->next);
		    if(!cur)
			break;
		    tms=hypot(tm[0],tm[1]);
		    tms=tms?ABS(tm[1]*tm[2]-tm[0]*tm[3])/tms:0;
		    if(tms)
			TRACE(200,"(cs_gettexts - Tm) scale=%d",tms);
		    else
			TRACE(200,"(cs_gettexts - Tm) matrix=[%d,%d,%d,%d]",tm[0],tm[1],tm[2],tm[3]);
		    gscur->tm_sy=tms;
		    if(!(cur=cur->next))
			break;
		    /*
		     * finding word boundaries - little magic
		     * idea: if shift is greater than charsize, flush_word
		     *       if shift_x is greater than charsize*5 or
		     *        if shift_y is greater than charsize, schedule
		     *        sentence break
		     *  FIXME:
		     *       (check the units of translation move in PLRM, it
		     *       looks unit is 1/1000 of charsize but who knows?)
		     */
		    i=ABS(obj_int_real(cur->obj));
		    if(i>gscur->tm_sy*gscur->tfs*1000) {
			if(i>gscur->tm_sy*gscur->tfs*5*1000) {
			    TRACE(200,"(cs_gettexts - Tm) shift=%d, tm: %d, tfs: %d, all: %d", i, gscur->tm_sy, gscur->tfs, gscur->tm_sy*gscur->tfs*5);
			    switch_class(WC_BREAK);
			}
			word_break();
		    }
		    if(!(cur=cur->next))
			break;
		    i=ABS(obj_int_real(cur->obj));
		    if(i>gscur->tm_sy*gscur->tfs*1000)
			switch_class(WC_BREAK);
		    break;
		case 16980:       /* BT */
		    TRACE(200,"(cs_gettexts - BT)");
		    textmode=1;
		    gscur->tm_sy=1;	/* Specification says BT resets Tm matrix */
		    break;
		case 17748:       /* ET */
		    TRACE(200,"(cs_gettexts - ET)");
		    textmode=0;
		    break;
		case 16969:       /* BI */
		    TRACE(200,"(cs_gettexts - BI)");
		    /* not nice trick but BI..ID..EI is a not-nice
		     * exception from Content Stream syntax
		     */
		    do {
			if(skip_space(SP_ANYWCOMM)==EOF)
			    break;
			obj=get_obj();
		    } while(obj.type!=OT_UTOK || memcmp(obj.value.s,"ID",3));
		    do {
			if(skip_space(SP_ANYWDELIM)==EOF)
			    break;
			obj=get_tok();
		    } while(memcmp(obj.value.s,"EI",3));
		    break;
		case 21606:       /* Tf */
		    TRACE(200,"(cs_gettexts - Tf)");
		    if(textmode && start->obj.type==OT_NAME)
			change_font(start->obj.value.s,start->next->obj,res->fonts);
		    else
			TRACE(200,"(cs_gettexts - Tf) syntax error: textmode %d, obj.type %d",textmode,start->obj.type);
		    break;
		case 21604:       /* Td */
		    TRACE(200,"(cs_gettexts - Td)");
		    if(textmode)
			word_break();
		    break;
		case 21572:       /* TD */
		    TRACE(200,"(cs_gettexts - TD)");
		    if(textmode)
			word_break();
		    break;
		case 21546:       /* T* */
		    TRACE(200,"(cs_gettexts -  T*)");
		    if(textmode)
			word_break();
		    break;
		case 39:        /* ' */
		    TRACE(200,"(cs_gettexts - ')");
		    if(textmode) {
			word_break();
			out_enc_string(start->obj);
		    }
		    break;
		case 21610:       /* Tj */
		    TRACE(200,"(cs_gettexts - Tj)");
		    if(textmode)
			out_enc_string(start->obj);
		    break;
		case 34:        /* " */
		    TRACE(200,"(cs_gettexts - \")");
		    if(textmode && start->next && start->next->next)
			out_enc_string(start->next->next->obj);
		    break;
		case 21578:       /* TJ */
		    TRACE(200,"(cs_gettexts - TJ) textmode=%d, obj.type=%d",textmode,start->obj.type);
		    if(textmode && start->obj.type==OT_ARRAY)
			for(cur=start->obj.value.a;cur;) {
			    out_enc_string(cur->obj);
			    if(!(cur=cur->next))
				break;
			    /*
			     * "kern" bigger than average char width means
			     * flush_word()
			     */
			    if(obj_int_real(cur->obj)<=-100)
				word_break();
			    cur=cur->next;
			}
		    break;
		default: ;
	    }
	    cur=start=NULL;
	    mp_flush(page_pool);
	}
    }
    word_break();
    TRACE(200,"End of parsing Content stream (out text)");
}

static void
out_info(void) {
    OBJECT info,author,title;
    OBJ_GET infodict[]={{"Author",&author},{"Title",&title},{NULL,NULL}};

    if(!inforef)
	return;
    TRACE(100,"(out_info) Encrypt before: %d(%d,%d)",encrypted,lastobj,lastgen);
    info=get_i_obj(inforef);
    TRACE(100,"(out_info) Encrypt after: %d(%d,%d)",encrypted,lastobj,lastgen);
    printobj(info);
    if(info.type!=OT_DICT)
	return;
    parse_dict(info.value.d,infodict);
    obj_deref(&author);
    if(author.type==OT_STRING) {
	out_pdfstring(author, WC_META | MT_MISC | WC_BREAK);
    }
    obj_deref(&title);
    if(title.type==OT_STRING) {
	out_pdfstring(title, WC_META | MT_TITLE | WC_BREAK);
    }
}

static uns bookmarkcnt;

static s32
out_bookmarks(s32 outlines) {
    OBJECT root,first,next,title;
    OBJ_GET bookrootdict[]={{"First",&first},{"Next",&next},{"Title",&title},{NULL,NULL}};
    s32 n;

    if(++bookmarkcnt>MAX_TREE_SIZE) {
	TRACE(100,"Maximum amount of bookmarks reached");
	gobj_truncate();
	longjmp(recoverable_error_jump, 1);
    }
    root=get_i_obj(outlines);
    if(root.type!=OT_DICT)
	return 0;
    parse_dict(root.value.d,bookrootdict);
    obj_deref(&title);
    if(title.type==OT_STRING)
	out_pdfstring(title, WT_SMALL_HEADING | WC_BREAK);
    if(first.type==OT_OBJREF) {
	n=first.value.n;
	while((n=out_bookmarks(n))>0);
    }
    return next.type==OT_OBJREF ? next.value.n : 0;
}

static char *Annots[26]={
    "Popup",
    "",
    "Ink",
    "",
    "Highlight",
    "",
    "Movie",
    "Squiggly",
    "Line",
    "",
    "Widget",
    "Stamp",
    "Text",
    "FreeText",
    "Link",
    "Sound",
    "",
    "",
    "Circle",
    "Underline",
    "",
    "FileAttachment",
    "StrikeOut",
    "Square",
    "",
    ""
};

static void
out_annots(OBJECT annots) {
    OBJECT type,subtype,contents,action,filespec,uri;
    OBJ_GET annotdict[]={{"Type",&type},{"Subtype",&subtype},{"Contents",&contents},{"A",&action},{NULL,NULL}};
    OBJ_GET actiondict[]={{"Type",&type},{"S",&subtype},{"F",&filespec},{"URI",&uri},{NULL,NULL}};
    OBJ_GET filespecdict[]={{"FS",&subtype},{"F",&uri},{NULL,NULL}};
    int h;
    int oclass;
    byte *b;
    ARRAY_ENTRY *ai;

    obj_deref(&annots);
    if(annots.type!=OT_ARRAY)
	return;
    for(ai=annots.value.a;ai;ai=ai->next) {
	obj_deref(&ai->obj);
	if(ai->obj.type!=OT_DICT)
	    continue;
	parse_dict(ai->obj.value.d,annotdict);
	if(subtype.type!=OT_NAME)
	    return;
	for(h=0,b=subtype.value.s;*b>0;h=(h+(*b++)-96)%26);
	if((h==11 || h==18) && *subtype.value.s>'S') h++;
	if(h<0 || memcmp(subtype.value.s,Annots[h],b-subtype.value.s) || !Annots[h])
	    return;
	obj_deref(&contents);
	if(contents.type==OT_STRING) {
	    oclass=(h==0 || h==6 || h==10 || h==14 || h==15) ? WT_ALT : WT_SMALL;
	    TRACE(100,"Annots (%d):%*s",h,contents.value.str.l,contents.value.str.i);
	    out_pdfstring(contents,oclass);
	}
	if(h==14) { /* Link */
	    obj_deref(&action);
	    if(action.type==OT_DICT) {
		parse_dict(action.value.d,actiondict);
		if(subtype.type==OT_NAME && !memcmp(subtype.value.s,"URI",4)) {
		    obj_deref(&uri);
		    if(uri.type==OT_STRING) {
			uri.value.str.i[uri.value.str.l]=0;
			gobj_add_ref('R',uri.value.str.i);
		    }
		} else if(subtype.type==OT_NAME && !memcmp(subtype.value.s,"GoToR",6)) {
		    obj_deref(&filespec);
		    if(filespec.type==OT_DICT) {
			parse_dict(filespec.value.d,filespecdict);
			if(subtype.type==OT_NAME && !memcmp(subtype.value.s,"URL",4)) {
			    obj_deref(&uri);
			    if(uri.type==OT_STRING) {
				uri.value.str.i[uri.value.str.l]=0;
				gobj_add_ref('R',uri.value.str.i);
			    }
			}
		    }
		}
	    }
	}
    }
}

static uns pagescnt;

static void
out_pages(s32 pagesref, struct resources *resref) {
    /* resref==NULL means no resources known up to this level of page tree
     * if this is a leaf (Page) and still resref==NULL, skip this page
     */
    OBJECT root,type,nres,kids,annots,contents,contentest;
    OBJ_GET rootdict[]={{"Type",&type},{"Resources",&nres},
	{"Kids",&kids},
	{"Annots",&annots},{"Contents",&contents},
	{NULL,NULL}};
    ARRAY_ENTRY *ai;
    uns i;

    switch_class(WC_BREAK | WT_TEXT);
    if(++pagescnt>=MAX_TREE_SIZE) {
	TRACE(100,"Maximum amount of pages reached");
	gobj_truncate();
	longjmp(recoverable_error_jump, 1);
    }
    if(pagesref<=0)
	return;
    root=get_i_obj(pagesref);
    if(root.type!=OT_DICT)
	return;
    parse_dict(root.value.d,rootdict);
    if(nres.type!=OT_UNKNOWN)
	resref=parse_resources(nres,pagesref);
    if (type.type != OT_NAME)
      return;
    if (!memcmp(type.value.s,"Page",5)) {	/* Type Page */
	TRACE(200,"(out_pages) Page; obj #%d",pagesref);
	if (!resref) {
	    TRACE(200,"(out_pages) RETURN !resref");
	    return;
	}
	out_annots(annots);
	contentest=contents;
	obj_deref(&contentest);
	if(contentest.type==OT_ARRAY)
	    contents=contentest;
	if (contents.type!=OT_ARRAY && contents.type!=OT_OBJREF) {
	    TRACE(200,"(out_pages) RETURN !contents (type %d)",contents.type);
	    return;
	}
	if(contents.type==OT_ARRAY) {
	    uns lca;

	    for(ai=contents.value.a,lca=0;ai && ai->obj.type==OT_OBJREF;ai=ai->next,lca++);
	    lca=lca>MAX_STREAMS ? MAX_STREAMS : lca;
	    for(ai=contents.value.a,i=0;i<lca;ai=ai->next,i++)
		stream_array[i]=ai->obj.value.n;
	    stream_array[i]=0;
	} else {	/* contents.type==OT_OBJREF */
	    stream_array[0]=contents.value.n;
	    stream_array[1]=0;
	}
#if 0
	set_input_method(stream_in);
	cs_parse();
	set_input_method(pdf_in);
#endif
	set_input_method(stream_in);
	cs_gettexts(resref);
	set_input_method(pdf_in);
    } else if (!memcmp(type.value.s,"Pages",6)) {
	int kidsc,i;
	s32 *kidsa;
	ARRAY_ENTRY *ai;

	TRACE(200,"(out_pages) Pages; obj #%d",pagesref);
	obj_deref(&kids);
	if (kids.type!=OT_ARRAY)
	    return;
	for(kidsc=0,ai=kids.value.a;ai;ai=ai->next,kidsc++);
	if(kidsc>MAX_SUB_PAGES)
	    kidsc=MAX_SUB_PAGES;
	kidsa = alloca(sizeof(s32)*kidsc);
	for(i=0,ai=kids.value.a;i<kidsc && ai;ai=ai->next) {
	    if(ai->obj.type!=OT_OBJREF)
		continue;
	    kidsa[i]=ai->obj.value.n;
	    i++;
	}
	kidsc=i;
	for(i=0;i<kidsc;out_pages(kidsa[i++],resref));
    }
    mp_flush(page_pool);
}

static void
out_document(void) {
    OBJECT root,bookmarkroot,pageroot,baseurl;
    OBJ_GET rootdict[]={{"Outlines",&bookmarkroot},{"Pages",&pageroot},{"Base",&baseurl},{NULL,NULL}};

    if(!rootref)
	return;
    root=get_i_obj(rootref);
    if(root.type!=OT_DICT)
	return;
    parse_dict(root.value.d,rootdict);
    obj_deref(&baseurl);
    if(baseurl.type==OT_STRING)
	gthis->base_url = gobj_parse_url(&gthis->base_url_s, baseurl.value.str.i, "base", 0);

    mp_flush(page_pool);
    bookmarkcnt=0;
    if(bookmarkroot.type==OT_OBJREF)
	out_bookmarks(bookmarkroot.value.n);
    mp_flush(page_pool);
    
    pagescnt=0;
    if(pageroot.type==OT_OBJREF)
	out_pages(pageroot.value.n,NULL);
}

int
pdf_parse(void) {

    if(gthis->truncated)
	gerror(2200, "PDF file truncated");

    pdf_in = fbmem_clone_read(gthis->contents);
    pdf_out = gthis->text = fbmem_create(16384);
    meta_out = gthis->meta = fbmem_create(256);
    set_input_method(pdf_in);
    current_class = queued_class = 0;

    if (!page_pool) {
	page_pool=mp_new(16384);
	global_pool=mp_new(16384);
	sf_pool=mp_new(2048);
    }

    if (!setjmp(recoverable_error_jump)) {
	getxref();
	out_info();

	out_document();
    }

    bclose(pdf_in);
    flush_word();

    mp_delete(page_pool);
    mp_delete(global_pool);
    mp_delete(sf_pool);
    page_pool = NULL;

    return 1;
}
