/*
 *	Language detector
 *
 * 	(c) 2003, Robert Spalek <robert@ucw.cz>
 */

#include "lib/lists.h"
#include "lang/lang.h"

#define	MAX_SEQ_LENGTH	4
	/* maximum hard-length of a scanned sequence */
#define	MAX_DETECTED	(2*MAX_LANGUAGES)
	/* because every language can containt coefficients for both accented
	 * and unaccented variant */

struct lang_detect_lang_flag
{
	int id;
	byte is_accented;		/* just for debugging purposes, used nowhere */
	uns nr_seq, threshold;
};
struct lang_detect_sequence
{
	uns len;
	int order[MAX_LANGUAGES];
	byte text[1];
};

struct sequence_freq {
	uns id, occur;
};

struct kmp_result;
struct lang_detect_results
{
	uns total_occur;		/* number of sequences found */
	uns nonzero_seq;		/* sequences with non-zero number of occurences */
	struct list nonzeroes;		/* and their link-list */
	struct kmp_result *occurences;	/* and their array */
	struct sequence_freq *sf;	/* sorted array of frequences of all sequences */
	uns *variances;			/* of the languages */
	int lang1, lang2;		/* best 2 languages or -1 if the detector has failed */
	int ratio;			/* between the variance of the 2 best languages */
	int min_ratio;			/* if ratio < min_ratio, then the guesses does not know */
};

extern uns lang_detect_nr_langs;
extern struct lang_detect_lang_flag lang_detect_lang_flags[];

extern uns lang_detect_nr_sequences, lang_detect_max_sequences, lang_detect_total_seq_len;
extern struct lang_detect_sequence **lang_detect_sequences;

extern uns lang_detect_min_doc_length;
extern byte *lang_detect_tables_file;

void lang_detect_build_automaton(void);
void lang_detect_start(void);
void lang_detect_add_string(byte *str);
struct lang_detect_results *lang_detect_compute(void);
uns lang_detect_choose_best(void);
