/*
 *	Sherlock Language Processing Library -- Stemmer Internals
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#define STEMMER(name) \
	list *stem_##name(struct stemmer *, byte *, struct mempool *); \
	void stem_init_##name(struct stemmer *);
#include "lang/stemmers.h"
#undef STEMMER
