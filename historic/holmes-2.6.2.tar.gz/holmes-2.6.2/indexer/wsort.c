/*
 *	Sherlock Indexer -- Sorting of Word Index
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/unaligned.h"
#include "lib/pools.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"
#include "indexer/params.h"

#include <stdlib.h>

#define SORT_KEY u32
#define SORT_PREFIX(x) ws_##x
#define SORT_UNIFY
#define SORT_DELETE_INPUT sort_delete_src
#define SORT_INPUT_FILE
#define SORT_OUTPUT_FB

static inline int
ws_compare(u32 *xx, u32 *yy)
{
  u32 x = *xx;
  u32 y = *yy;

  if (x < y)
    return -1;
  else if (x > y)
    return 1;
  else
    return 0;
}

static inline int
ws_fetch_key(struct fastbuf *f, u32 *x)
{
  *x = bgetl(f);
  return *x != 0xffffffff;
}

static inline void
ws_copy_data(struct fastbuf *src, struct fastbuf *dest, u32 *x)
{
  uns len = bgetl(src);

  bputl(dest, *x);
  bputl(dest, len);
  bbcopy(src, dest, len);
}

static void
ws_merge_data(struct fastbuf *src1, struct fastbuf *src2, struct fastbuf *dest, u32 *x, u32 *y UNUSED)
{
  uns len1 = bgetl(src1);
  uns len2 = bgetl(src2);
  u32 id1, id2;
  uns cnt;

  bputl(dest, *x);
  bputl(dest, len1+len2);
  id1 = bgetl(src1);
  len1 -= 4;
  id2 = bgetl(src2);
  len2 -= 4;
  for(;;)
    {
      ASSERT(id1 != id2);
      if (id1 <= id2)
	{
	  bputl(dest, id1);
	  cnt = bgetw(src1);
	  bputw(dest, cnt);
	  bbcopy(src1, dest, 2*cnt);
	  len1 -= 2 + 2*cnt;
	  if (!len1)
	    goto end1;
	  id1 = bgetl(src1);
	  len1 -= 4;
	}
      else
	{
	  bputl(dest, id2);
	  cnt = bgetw(src2);
	  bputw(dest, cnt);
	  bbcopy(src2, dest, 2*cnt);
	  len2 -= 2 + 2*cnt;
	  if (!len2)
	    goto end2;
	  id2 = bgetl(src2);
	  len2 -= 4;
	}
    }

 end1:
  bputl(dest, id2);
  bbcopy(src2, dest, len2);
  return;

 end2:
  bputl(dest, id1);
  bbcopy(src1, dest, len1);
  return;
}

#include "lib/sorter.h"

static void
split(struct fastbuf *sorted)
{
  struct fastbuf *lex_tmp, *lex, *refs;
  u32 wid_lex;
  uns wid_ref, wlen, wcount;
  enum word_class wclass;
  byte word[MAX_WORD_LEN];

  lex_tmp = bopen(index_name(fn_lex_ordered), O_RDONLY, indexer_fb_size);
  refs = bopen(index_name(fn_references), O_WRONLY | O_CREAT | O_APPEND, indexer_fb_size);
  lex = bopen(index_name(fn_lex_words), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  wid_ref = bgetl(sorted);
  wid_lex = 1;
  wcount = bgetl(lex_tmp);
  bputl(lex, wcount);
  while (wid_lex <= wcount)
    {
      u32 in_id = bgetl(lex_tmp);
      ASSERT(in_id/8 == wid_lex);
      uns wfreq = bgetl(lex_tmp);
      wclass = in_id & 7;
      uns ctxt = bget_context(lex_tmp);
      wlen = bgetc(lex_tmp);
      breadb(lex_tmp, word, wlen);
      bputo(lex, btell(refs));
      if (wid_lex >= wid_ref)
	{
	  uns rsize, rcnt;
	  rsize = bgetl(sorted);
	  if (rsize >= 0x10000000)
	    die("Reference chain for word #%d too long, maximum is 256MB. Ask a wizard to enlarge me.", wid_ref);
	  bputw(lex, (rsize + 0xfff) >> 12U);
	  while (rsize)
	    {
	      u32 oid = bgetl(sorted);
	      bputw(refs, oid >> 16);
	      bputw(refs, oid);
	      rcnt = bgetw(sorted);
	      bputw(refs, rcnt);
	      bbcopy(sorted, refs, 2*rcnt);
	      rsize -= 6 + 2*rcnt;
	    }
	  bputl(refs, 0);
	  wid_ref = bgetl(sorted);
	}
      else
	bputw(lex, 0);
      bputc(lex, wclass);
#ifdef CONFIG_SPELL
      bputc(lex, wfreq);
#endif
      bput_context(lex, ctxt);
      bputc(lex, wlen);
      bwrite(lex, word, wlen);
      wid_lex++;
    }
  ASSERT(wid_ref = 0xffffffff);
  bclose(lex_tmp);
  bclose(refs);
  bclose(lex);
}

int
main(int argc, char **argv)
{
  struct fastbuf *sorted;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  log(L_INFO, "Sorting word index");
  sorted = ws_sort(index_name(fn_word_index));
  log(L_INFO, "Splitting word index");
  split(sorted);
  bclose(sorted);
  return 0;
}
