/*
 *	Detecting similar documents
 *
 *	(c) 2002, Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"

struct hash_permuter
{
	u32 mult;
};

struct hash_permuter *permuter_new(void);
uns matcher_compute_minima(u32 *min, struct hash_permuter *perm, struct oattr *oa);
