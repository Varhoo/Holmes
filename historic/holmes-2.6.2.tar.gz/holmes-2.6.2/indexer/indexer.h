/*
 *	Sherlock Indexer
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 *	(c) 2002--2003 Robert Spalek <robert@ucw.cz>
 */

#include "lib/index.h"

/* iconfig.c */

/* File names */
extern byte *fn_directory;
extern byte *fn_fingerprints, *fn_labels_by_id, *fn_attributes, *fn_checksums;
extern byte *fn_links, *fn_urls, *fn_link_graph, *fn_link_graph_index, *fn_sites, *fn_labels, *fn_merges, *fn_signatures, *fn_matches;
extern byte *fn_word_index, *fn_string_index, *fn_references, *fn_string_map;
extern byte *fn_string_hash, *fn_cards, *fn_card_attrs, *fn_parameters, *fn_ref_texts;
extern byte *fn_lexicon, *fn_lex_raw, *fn_lex_ordered, *fn_lex_words, *fn_lex_by_freq;
extern byte *fn_stems, *fn_stems_ordered, *fn_lex_classes, *fn_notes, *fn_keywords;
extern uns default_weight;
byte *index_name(byte *file);

/* Miscellaneous */
extern byte *label_attrs, *link_attrs, *ref_link_types;
extern uns string_avg_bucket, indexer_fb_size, sort_delete_src, max_degree;
extern uns progress, progress_screen, progress_status_line;
extern uns ref_max_length, ref_min_length, ref_max_count, ref_hash_size;
extern uns matcher_signatures, matcher_context, matcher_min_words, matcher_threshold, matcher_passes, matcher_block;
extern uns max_num_objects, min_summed_size, auto_lang, frameset_to_redir;

/* Filters */
extern byte *indexer_filter_name;

#define PROGRESS(i, msg, args...) do { if (progress && !((i) % progress)) { \
	if (progress_status_line) setproctitle(msg, args); \
	if (progress_screen) { printf(msg "\r", args); fflush(stdout); } } } while (0)

/* fprecog.c */

void fp_recog_init(void);
void fp_recog_end(void);
uns fp_recog(struct fingerprint *fp);

/* Structure of files */

struct csum {
  byte md5[16];
  u32 cardid;
};

struct fprint {
  struct fingerprint fp;
  u32 cardid;
};

#define	CARD_NOTE_GIANT		1	/* Belongs to a very large class, subject to penalties */
#define	CARD_NOTE_HAS_LINKS	2	/* even the unknown ones */

struct card_note {
  u32 useful_size;			/* Useful size (number of alnum characters) */
  /* These fields track how did the card weight evolve */
  byte weight_scanner;			/* Weight assigned by the scanner */
  byte weight_merged;			/* Weight after card merging (includes merger penalties) */
  byte flags;
};

static inline struct card_note *
bring_note(struct partmap *p, oid_t card)
{
  return partmap_map(p, sizeof(struct card_note) * (sh_off_t)card, sizeof(struct card_note));
}

/* fetch.c */

struct card_hdr {
  struct card_hdr *next;
  struct card_hdr *redirects;
  struct odes *odes;
};

void fetch_cards(void (*got_card)(struct card_attr *attr, struct odes *obj, struct card_hdr *hdr, struct card_note *note, int bonus));

/* Graph edge types */

#define ETYPE_NORMAL 0
#define ETYPE_REDIRECT 0x40000000
#define ETYPE_FRAME 0x80000000
#define ETYPE_IMAGE 0xc0000000
#define ETYPE_MASK 0xc0000000
