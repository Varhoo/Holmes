/*
 *	Sherlock Indexer -- Merging Documents According to Fingerprints
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.c"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"
#include "indexer/merges.h"

#include <stdlib.h>

int
main(int argc, char **argv)
{
  struct card_attr *attrs;
  struct fastbuf *in;
  uns attr_size, merges_size, sum_cnt=0, dup_cnt=0, ign_cnt=0;
  struct fprint old, this;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }
  log(L_INFO, "Merging documents according to fingerprints");

  attrs = mmap_file(index_name(fn_attributes), &attr_size, 0);
  merges = mmap_file(index_name(fn_merges), &merges_size, 1);

  in = bopen(index_name(fn_fingerprints), O_RDONLY, indexer_fb_size);
  bzero(&old, sizeof(old));
  old.cardid = ~0U;
  while (breadb(in, &this, sizeof(this)))
    {
      ASSERT(this.cardid < merges_size/4);
      ASSERT(this.cardid != old.cardid);
      sum_cnt++;
      if (attrs[this.cardid].flags & (CARD_FLAG_EMPTY | CARD_FLAG_FRAMESET))
	ign_cnt++;
      else
	{
	  if (!memcmp(&old.fp, &this.fp, sizeof(struct fingerprint)) && old.cardid != ~0U)
	    {
	      merges_union(old.cardid, this.cardid);
	      dup_cnt++;
	    }
	  old = this;
	}
    }
  bclose(in);

  munmap_file(attrs, attr_size);
  munmap_file(merges, merges_size);
  log(L_INFO, "Processed %d fingerprints (%d ignored), found %d duplicates", sum_cnt, ign_cnt, dup_cnt);

  return 0;
}
