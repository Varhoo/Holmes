/*
 *	Sherlock Indexer -- Initial Object Scanning
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 *	(c) 2002--2003 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/md5.h"
#include "lib/bucket.h"
#include "lib/pools.h"
#include "lib/url.h"
#include "lib/object.h"
#include "lib/tagged-text.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"
#include "indexer/matcher.h"
#include "indexer/params.h"
#include "filter/filter.h"
#include "lang/detect.h"

#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>

static struct mempool *scanner_pool;
static struct index_params parameters;

struct scan_filter_data {
  int site_id, bonus;
  byte *url;
  struct url url_s;
  byte *language;
  byte *title;
};
static struct filter_args *scan_filter_args;
static struct scan_filter_data scan_filter_data;

struct filter_binding scan_bindings[] = {
  /* URL and its parts */
  { "url",		OFFSETOF(struct scan_filter_data, url) },
  { "protocol",		OFFSETOF(struct scan_filter_data, url_s.protocol) },
  { "host",		OFFSETOF(struct scan_filter_data, url_s.host) },
  { "port",		OFFSETOF(struct scan_filter_data, url_s.port) },
  { "path",		OFFSETOF(struct scan_filter_data, url_s.rest) },
  { "username",		OFFSETOF(struct scan_filter_data, url_s.user) },
  { "password",		OFFSETOF(struct scan_filter_data, url_s.pass) },
  /* Attributes */
  { "bonus",		OFFSETOF(struct scan_filter_data, bonus) },
  { "siteid",		OFFSETOF(struct scan_filter_data, site_id) },
  { "language",		OFFSETOF(struct scan_filter_data, language) },
  { "title",		OFFSETOF(struct scan_filter_data, title) },
  { NULL,		0 }
};

static void
scan_filter_init(void)
{
  if (!indexer_filter_name || !indexer_filter_name[0])
    return;
  scan_filter_args = filter_intr_new(filter_load(indexer_filter_name, filter_builtin_vars, scan_bindings, NULL));
  filter_intr_undo_init(scan_filter_args);
}

static int
scan_filter(byte *url, struct odes *obj)
{
  struct filter_args *a = scan_filter_args;
  struct scan_filter_data *d = &scan_filter_data;
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];

  d->site_id = 0;
  d->bonus = 0;
  d->url = url;
  if (url_canon_split(d->url, buf1, buf2, &d->url_s))
    die("scan_filter: error parsing URL");
  d->language = obj_find_aval(obj, 'l');
  d->title = NULL;
  if (!a)
    return 1;
  for (struct oattr *t = obj_find_attr(obj, 'M'); t; t=t->same)
    {
      byte *v = t->val;
      if (*v >= '0' && *v <= '9')
	v++;
#ifdef MT_TITLE
      if (*v == 0x90 + MT_TITLE)
	{
	  d->title = v+1;
	  break;
	}
#endif
    }
  a->attr = obj;
  a->raw = d;
  a->pool = scanner_pool;
  return filter_intr_run(a);
}

static inline void
scan_filter_undo(void)
{
  if (scan_filter_args)
    filter_intr_undo(scan_filter_args);
}

static void
prepare_parameters(void)
{
  parameters.version = INDEX_VERSION;
  parameters.ref_time = time(NULL);
}

static void
write_parameters(void)
{
  struct fastbuf *params = bopen(index_name(fn_parameters), O_CREAT | O_TRUNC | O_WRONLY, 1024);
  bwrite(params, &parameters, sizeof(parameters));
  bclose(params);
}

static void
gen_fingerprint(struct fastbuf *b, byte *url, uns id)
{
  struct fprint fp;

  url_fingerprint(url, &fp.fp);
  fp.cardid = id;
  bwrite(b, &fp, sizeof(fp));
}

static void
gen_labels_by_id(struct fastbuf *b, struct odes *o, byte *url, uns id)
{
  struct oattr *a, *v;

  bputl(b, id);
  bputl(b, ~0U);
  bputc(b, 'U');
  bputs0(b, url);
  for (a=o->attrs; v=a; a=a->next)
    if (strchr(label_attrs, a->attr))
      while (v)
	{
	  bputc(b, v->attr);
	  bputs0(b, v->val);
	  v = v->same;
	}
  bputc(b, 0);
}

static void
gen_checksums(struct fastbuf *b, struct odes *o, uns id, struct card_attr *attr, struct card_note *note)
{
  word buf[4096];
  uns cnt = 0;
  struct oattr *a;
  struct MD5Context ct;
  struct csum csum;
  uns accents = 0;
  uns chars = 0;
  uns lastc = ' ';

  MD5Init(&ct);
  for (byte *aname="XM"; *aname; aname++)
    for (a=obj_find_attr(o, *aname); a; a=a->same)
      {
	byte *z = a->val;
	uns x, c, u;
	do
	  {
	    GET_TAGGED_CHAR(z, x);
	    if (x >= 0x80000000 || !x)
	      {
		if (x >= 0x80010000)
		  continue;
		c = ' ';
	      }
	    else
	      c = x;
	    if (c != lastc || c != ' ')
	      {
		lastc = c;
		u = Uunaccent(c);
		if (c != u)
		  accents++;
		if (Ualnum(c))
		  chars++;
		buf[cnt++] = u;
		if (cnt >= ARRAY_SIZE(buf))
		  {
		    MD5Update(&ct, (byte *) buf, cnt * sizeof(buf[0]));
		    cnt = 0;
		  }
	      }
	  }
	while (x);
      }

  note->useful_size = chars;

  if (a = obj_find_attr(o, 'N'))
    {
      attr->flags |= CARD_FLAG_IMAGE;
      for (; a; a=a->same)
	{
	  byte *z = a->val;
	  uns len = strlen(z);
	  MD5Update(&ct, z, len);
	  chars += len;
	}
    }

  if (accents > chars/128)
    attr->flags |= CARD_FLAG_ACCENTED;
  if (!chars)
    attr->flags |= CARD_FLAG_EMPTY;
  if (chars <= min_summed_size)
    return;

  MD5Update(&ct, (byte *) buf, cnt * sizeof(buf[0]));
  MD5Final(csum.md5, &ct);
  csum.cardid = id;
  bwrite(b, &csum, sizeof(csum));
}

static void
gen_links(struct fastbuf *b, struct odes *o, uns id, struct card_note *note)
{
  struct oattr *a, *v;
  byte *c;

  for (a=o->attrs; v=a; a=a->next)
    if (strchr(link_attrs, a->attr))
      while (v)
	{
	  note->flags |= CARD_NOTE_HAS_LINKS;
	  struct fingerprint fp;
	  u32 type = (a->attr == 'Y') ? ETYPE_REDIRECT :
	             (a->attr == 'F') ? ETYPE_FRAME :
	             (a->attr == 'I') ? ETYPE_IMAGE :
	             ETYPE_NORMAL;
	  if (c = strchr(v->val, ' '))
	    *c = 0;
	  url_fingerprint(v->val, &fp);
	  if (c)
	    *c = ' ';
	  bwrite(b, &fp, sizeof(fp));
	  bputl(b, id | type);
	  v = v->same;
	}
}

#ifdef CONFIG_LANG
#include "lang/lang.h"
static void
gen_lang(struct card_attr *ca, struct oattr *attr_X)
{
  byte *lang = scan_filter_data.language;

  if (CA_GET_FILE_TYPE(ca) >= 4)	/* Not a text */
    return;

  int id;
  if (!lang || !lang[0])
  {
    if (auto_lang)
      {
	lang_detect_start();
	for (struct oattr *a=attr_X; a; a=a->same)
	  lang_detect_add_string(a->val);
	id = lang_detect_choose_best();
      }
    else
      id = 0;
  }
  else
    id = lang_list_to_code(lang);
  if (id > 0)
    ca->type_flags |= id;
}
#else
static void gen_lang(struct card_attr *ca UNUSED, struct oattr *attr_X UNUSED) { }
#endif

static void
gen_attrs(struct odes *o, struct card_attr *ca, struct card_note *cn)
{
  ca->weight = CLAMP(default_weight + scan_filter_data.bonus, 0, 255);
  cn->weight_scanner = ca->weight;

  if (frameset_to_redir && obj_find_attr(o, 'F'))
    ca->flags |= CARD_FLAG_FRAMESET | CARD_FLAG_EMPTY;

#ifdef CONFIG_LASTMOD
  byte *lm;
  int age = -1;
  if ((lm = obj_find_aval(o, 'L')) || (lm = obj_find_aval(o, 'D')))
    age = convert_age(atol(lm), parameters.ref_time);
  ca->age = MAX(0, age);
#endif

  custom_create_attrs(o, ca);
  gen_lang(ca, obj_find_attr(o, 'X'));	/* Needs type_flags set by custom_create_attrs */
}

static void
gen_signatures(struct fastbuf *signatures, struct odes *o, struct hash_permuter *permuter, uns id)
{
  struct oattr *oa;
  u32 sign[matcher_signatures];
  uns words;

  oa = obj_find_attr(o, 'X');
  if (!oa)
	  return;
  words = matcher_compute_minima(sign, permuter, oa);
  if (words < matcher_min_words)
	  return;
  bwrite(signatures, &id, sizeof(uns));
  bwrite(signatures, sign, sizeof(sign));
}

#ifndef WT_EXT

static void gen_ref_texts(struct fastbuf *reftexts UNUSED, struct odes *o UNUSED, uns id UNUSED) { }

#else

static void
gen_ref_texts(struct fastbuf *reftexts, struct odes *o, uns id)
{
#define MAX_REFS 1024
#define MAX_REF_DEPTH 3

  /* Map of references */
  byte ref_word_types[MAX_REFS];
  struct fingerprint fp[MAX_REFS];
  uns last_ref = 0;

  /* Currently open references */
  uns refstack[MAX_REF_DEPTH];
  int refsp = -1;
  static byte *rtext[MAX_REF_DEPTH];
  uns over[MAX_REF_DEPTH], nalpha[MAX_REF_DEPTH];
  byte *rthis[MAX_REF_DEPTH], *rlimit[MAX_REF_DEPTH];

  byte *b, *c, *l;
  struct oattr *a;
  byte *wstart, *wend;
  uns nalphas;

  /* Find all references we're interested in */
  for (b=ref_link_types; *b; b++)
    for (a=obj_find_attr(o, *b); a; a=a->same)
      {
	byte url[MAX_URL_SIZE];
	byte *x = a->val;
	byte *y = url;
	uns rid;
	while (*x && *x != ' ')
	  *y++ = *x++;
	if (!*x++)
	  continue;
	*y = 0;
	rid = atol(x);
	if (rid >= MAX_REFS)
	  continue;
	DBG("Ref <%s> id %d", url, rid);
	while (last_ref <= rid)
	  ref_word_types[last_ref++] = 0;
	ref_word_types[rid] = WT_EXT;
	url_fingerprint(url, &fp[rid]);
      }

  /* And scan the text for bracketed parts */
  for (a=obj_find_attr(o, 'X'); a; a=a->same)
    {
      byte *z = a->val;
      uns x;
      wstart = wend = z;
      nalphas = 0;
      do
	{
	  GET_TAGGED_CHAR(z, x);
	  if (x < 0x80000000 && x != ' ')
	    {
	      if (Ualnum(x))
		nalphas++;
	      wend = z;
	      continue;
	    }
	  if (refsp >= 0 && wstart < wend && !over[refsp])
	    {
	      uns len = wend - wstart;
	      if (rthis[refsp] + len > rlimit[refsp])
		over[refsp] = 1;
	      else
		{
		  memcpy(rthis[refsp], wstart, len);
		  rthis[refsp] += len;
		  nalpha[refsp] += nalphas;
		}
	    }
	  wstart = wend = z;
	  nalphas = 0;
	  if (x < 0x80010000)		/* Word break */
	    {
	      if (refsp >= 0 && rthis[refsp][-1] != ' ')
		*rthis[refsp]++ = ' ';
	      /* We know it will fit in the buffer */
	    }
	  else if (x < 0x80020000)	/* Open */
	    {
	      refsp++;
	      ASSERT(refsp < MAX_REF_DEPTH);
	      refstack[refsp] = x & 0xffff;
	      if (!rtext[refsp])
		{
		  rtext[refsp] = xmalloc(ref_max_length + 4) + 1;
		  rtext[refsp][-1] = 0;
		}
	      rthis[refsp] = rtext[refsp];
	      rlimit[refsp] = rtext[refsp] + ref_max_length;
	      over[refsp] = 0;
	      nalpha[refsp] = 0;
	    }
	  else				/* Close */
	    {
	      uns rid;
	      ASSERT(refsp >= 0);
	      rid = refstack[refsp];
	      *rthis[refsp] = 0;
	      if (rid < last_ref && ref_word_types[rid])
		{
		  b = rtext[refsp];
		  if (*b == ' ')
		    b++;
		  c = rthis[refsp];
		  if (c > b && c[-1] == ' ')
		    c--;
		  if (c > b && nalpha[refsp] >= ref_min_length)
		    {
		      bputl(reftexts, id);
		      bwrite(reftexts, &fp[rid], sizeof(struct fingerprint));
		      bputw(reftexts, c-b+1);
		      bputc(reftexts, 0x90 + ref_word_types[rid]);
		      bwrite(reftexts, b, c-b);
		    }
		}
	      if (refsp > 0 && !over[refsp-1])
		{
		  byte *cut;
		  b = rtext[refsp];
		  c = rthis[refsp-1];
		  l = rlimit[refsp-1];
		  if (b[0] == ' ')
		    {
		      if (c[-1] != ' ')
			*c++ = ' ';
		      b++;
		    }
		  cut = c;
		  while (*b && c <= l)
		    {
		      if (*b == ' ')
			cut = c;
		      *c++ = *b++;
		    }
		  if (c > l)
		    {
		      c = cut;
		      over[refsp-1] = 1;
		    }
		  over[refsp-1] |= over[refsp];
		  nalpha[refsp-1] += nalpha[refsp];
		  rthis[refsp-1] = c;
		}
	      refsp--;
	    }
	}
      while (x);
    }
  if (refsp >= 0)
    log(L_ERROR, "Unbalanced reference brackets for card %08x", id);
}

#endif

int
main(int argc, char **argv)
{
  struct odes *o;
  uns id, count;
  struct obuck_header bh;
  struct fastbuf *b;
  struct fastbuf *fingerprints;
  struct fastbuf *labels_by_id;
  struct fastbuf *attributes;
  struct fastbuf *checksums;
  struct fastbuf *links;
  struct fastbuf *urls;
  struct fastbuf *merges;
  struct fastbuf *signatures;
  struct fastbuf *reftexts;
  struct fastbuf *notes;
  struct hash_permuter *permuter;
  oid_t last_oid;

  log_init(argv[0]);
  setproctitle_init(argc, argv);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

#ifdef CONFIG_LANG
  lang_detect_build_automaton();
#endif
  prepare_parameters();
  fingerprints = bopen(index_name(fn_fingerprints), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  labels_by_id = bopen(index_name(fn_labels_by_id), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  attributes = bopen(index_name(fn_attributes), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  checksums = bopen(index_name(fn_checksums), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  links = bopen(index_name(fn_links), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  urls = bopen(index_name(fn_urls), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  merges = bopen(index_name(fn_merges), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  if (matcher_signatures)
  {
    signatures = bopen(index_name(fn_signatures), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
    permuter = permuter_new();
    srand(time(NULL));
  }
  else
    signatures = NULL, permuter = NULL;
  reftexts = bopen(index_name(fn_ref_texts), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);
  notes = bopen(index_name(fn_notes), O_CREAT | O_TRUNC | O_WRONLY, indexer_fb_size);

  obuck_init(0);
  last_oid = obuck_predict_last_oid();	/* Guaranteed not to be 0 */
  scan_filter_init();
  url_key_init();
  scanner_pool = mp_new(16384);
  log(L_INFO, "Scanning objects");

  id = count = 0;
  while ((b = obuck_slurp_pool(&bh)) && count < max_num_objects)
    {
      struct card_attr attr;
      struct card_note note;
      byte *url;

      mp_flush(scanner_pool);
      o = obj_new(scanner_pool);
      obj_read(b, o);

      url = obj_find_aval(o, 'U');
      if (!url)
	die("Object %x has no URL, probably broken bucket file", bh.oid);
      PROGRESS(count, "scanner: %d objects -> %d cards (%d%%)", count, id, (int)((float)bh.oid/last_oid*100));
      count++;
      if (obj_find_aval(o, 'r'))	/* Skip robots.txt buckets */
	continue;
      bzero(&attr, sizeof(attr));
      attr.card = bh.oid;
      bzero(&note, sizeof(note));
      if (scan_filter(url, o))
	{
	  gen_fingerprint(fingerprints, url, id);
	  gen_labels_by_id(labels_by_id, o, url, id);
	  gen_checksums(checksums, o, id, &attr, &note);
	  gen_links(links, o, id, &note);
	  gen_attrs(o, &attr, &note);
	  if (signatures)
	    gen_signatures(signatures, o, permuter, id);
	  gen_ref_texts(reftexts, o, id);
	  bputsn(urls, url);
	  bputl(merges, ~0U);
	  bwrite(attributes, &attr, sizeof(attr));
	  bwrite(notes, &note, sizeof(note));
	  id++;
	  if (id > 100000)
	    die("Document limit exceeded (this version is licensed only up to 100000 documents)");
	}
      scan_filter_undo();
    }

  obuck_cleanup();
  parameters.objects_in = id;
  write_parameters();
  bclose(fingerprints);
  bclose(labels_by_id);
  bclose(attributes);
  bclose(checksums);
  bclose(links);
  bclose(urls);
  bclose(merges);
  if (signatures)
  {
    bclose(signatures);
    xfree(permuter);
  }
  bclose(reftexts);
  bclose(notes);

  log(L_INFO, "Scanned %d objects, created %d cards", count, id);
  return 0;
}
