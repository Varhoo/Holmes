/*
 *	Sherlock Gatherer Daemon -- Queue Management
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#undef LOCAL_DEBUG

#include "lib/lib.h"
#include "gather/daemon/gatherd.h"
#include "lib/url.h"
#include "lib/fastbuf.h"
#include "lib/pools.h"
#include "lib/pagecache.h"
#include "lib/heap.h"
#include "lib/lfs.h"

#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

/*** HOST QUEUE ***/

/*
 *  The data structures are somewhat complicated due to our requirements
 *  for per-host queueing as opposed to per-IP-address timing.
 *
 *  We keep a set of qnodes (they correspond to IP addresses, some of them
 *  are reserved for hosts with not yet resolved address), each qnode contains
 *  a linked list of hosts. No two active hosts can share a qnode. Timings
 *  are defined on qnodes, item queues are connected to hosts.
 *
 *  qnode states:
 *     -  idle (has no hosts; not linked anywhere)
 *     -  serviced (linked in active_nodes list)
 *     -  waiting (stored in node_heap)
 *
 *  host states:
 *     -  idle (no items queued; linked in idle_hosts list; QHF_RELINK always set)
 *     -  serviced (linked in its active qnode), the key can be altered now
 *     -  waiting (linked in its waiting qnode)
 *
 *  One of the hosts (pointed to by free_list) serves as dummy header
 *  of the list of free queue file blocks. It's always kept in the
 *  idle_hosts list.
 *
 *  Assignment of queue keys (see also create_key())
 *     00000000 - 00ffffff	Hosts waiting for resolving of real key
 *     7f010000 - 7f01ffff	Non-IP hosts (file:// etc.)
 *     7f020000 - 7f02ffff	Keys for unresolvable hosts
 *     everything else		IP address of the host
 *
 *  Resolver nodes (keys 00xxxxxx) take precedence over normal nodes (this is
 *  achived by their wait time being always zero), but normal nodes cannot starve
 *  as the number of resolver nodes is limited by max_resolvers.
 */

#define INITIAL_HEAP_SIZE	256
#define NUM_RESOLVER_KEYS	0x01000000	/* Number of keys reserved for resolvers */

#define NHEAP_LESS(a,b) (a->wait_until < b->wait_until || (a->wait_until == b->wait_until && a->sequence < b->sequence))
#define NHEAP_SWAP(heap,a,b,t) (t=heap[a], heap[a]=heap[b], heap[b]=t)

static list active_nodes;		/* Currently dequeued queue nodes */
static struct qnode **node_heap;
static uns node_heap_cnt, node_heap_max;
static struct qnode **node_hash;

static list idle_hosts;			/* Hosts carrying no queued items */
static struct qhost **host_hash;

static struct qhost *free_list;
static struct fastbuf *host_file;
static struct mempool *host_pool;
static uns sequence_counter;
static uns host_file_size;
uns host_count;

static inline uns			/* Calculate hash value of given string */
name_hash(byte *name)
{
  uns h = strlen(name);

  while (*name)
    h = h*37 + *name++;
  return h & (host_hash_size - 1);
}

static inline uns
key_hash(u32 a)
{
  a ^= a >> 16;
  a ^= a << 10;
  return a & (key_hash_size - 1);
}

static void				/* Write host entry at current position of host file */
write_host_entry(struct qhost *h)
{
  struct fastbuf *f = host_file;

  bputc(f, h->protocol);
  bputw(f, h->port);
  bputs(f, h->name);
  bputc(f, '\n');
  h->hf_pos = btell(f);
  bputl(f, h->qf_pos);
  bputl(f, h->qf_last);
  bwrite(f, h->obj_count, sizeof(h->obj_count));
  bputl(f, h->robot_id);
  bputl(f, h->robot_time);
  bputl(f, h->rec_err_count);
  bputl(f, h->qkey);
}

static void				/* Rewrite host entry with new data */
flush_host_entry(struct qhost *h)
{
  if (!(h->flags & QHF_DIRTY))
    return;
  DBG("Flushing <%s> %x %x %02x", h->name, h->qf_pos, h->qf_last, h->flags);
  h->flags &= ~QHF_DIRTY;
  if (h->flags & QHF_ALLOCATE)
    {
      h->flags &= ~QHF_ALLOCATE;
      bsetpos(host_file, host_file_size);
      write_host_entry(h);
      host_file_size = btell(host_file);
      return;
    }
  bflush(host_file);
  bseek(host_file, h->hf_pos, SEEK_SET);
  bputl(host_file, h->qf_pos);
  bputl(host_file, h->qf_last);
  bwrite(host_file, h->obj_count, sizeof(h->obj_count));
  bputl(host_file, h->robot_id);
  bputl(host_file, h->robot_time);
  bputl(host_file, h->rec_err_count);
  bputl(host_file, h->qkey);
  bflush(host_file);
}

void					/* Schedule host entry for re-writing */
touch_host(struct qhost *h)
{
  DBG("Touching <%s>", h->name);
  h->flags |= QHF_DIRTY;
}

static void
node_heap_insert(struct qnode *n)
{
  if (node_heap_cnt >= node_heap_max)
    {
      node_heap_max = 2*node_heap_max;
      node_heap = xrealloc(node_heap, node_heap_max * sizeof(struct qnode *));
    }
  node_heap[++node_heap_cnt] = n;
  HEAP_INSERT(struct qnode *, node_heap, node_heap_cnt, NHEAP_LESS, NHEAP_SWAP);
}

void
enqueue_host(struct qhost *h, struct qnode *oldn, uns delay)
{
  u32 key;
  uns khash;
  sh_time_t wait_until = now + delay;
  struct qnode *n;

  flush_host_entry(h);

  DBG("Enqueue host <%s> (node %p), delay=%d", h->name, oldn, delay);

  /* Unlink the host node */
  if (!oldn && !(h->flags & QHF_RELINK))
    return;
  rem_node(&h->n);
  h->flags &= ~QHF_RELINK;

  /* Determine which node it will have to be linked to */
  if (!h->qf_pos)			/* Idle host */
    n = NULL;
  else
    {
      key = h->qkey;
      if (!key)
	key = (name_hash(h->name) % max_resolvers) + 1;
      khash = key_hash(key);
      for (n=node_hash[khash]; n && n->key != key; n=n->hash_next)
	;
      if (!n)
	{
	  n = mp_alloc(host_pool, sizeof(struct qnode));
	  n->hash_next = node_hash[khash];
	  node_hash[khash] = n;
	  n->key = key;
	  n->wait_until = now;
	  init_list(&n->hosts);
	}
    }

  /* Remove oldn from the active_nodes list */
  if (oldn)
    rem_node(&oldn->n);

  /* If we are now using a different node, re-insert the old one to the heap */
  if (oldn && oldn != n)
    {
      DBG("Relinking: %08x -> %08x", oldn->key, n ? n->key : 0);
      /* No timing changes since it must be a resolver node */
      /* FIXME: This needs to be changed if we allow online changes of qkeys */
      if (!EMPTY_LIST(oldn->hosts))
	node_heap_insert(oldn);
    }

  /* Idle hosts require special treatment */
  if (!n)
    {
      DBG("Is idle");
      h->flags |= QHF_RELINK;
      add_tail(&idle_hosts, &h->n);
      return;
    }

  /* Are we adding to an already linked node? */
  if (oldn != n && !EMPTY_LIST(n->hosts))
    {
      DBG("Adding to already linked %08x", n->key);
      add_tail(&n->hosts, &h->n);
      return;
    }

  /* Now we know that n is unlinked and if n != oldn, oldn has been cleaned up */
  add_tail(&n->hosts, &h->n);
  if (n->key < NUM_RESOLVER_KEYS)	/* Always prefer resolvers */
    n->wait_until = 0;
  else if (n->wait_until < wait_until)
    n->wait_until = wait_until;
  n->sequence = ++sequence_counter;
  node_heap_insert(n);
  DBG("Inserted with key %08x wait +%d seq %08x", n->key, n->wait_until - now, n->sequence);

  /* Happy end */
}

struct qhost *
dequeue_host(sh_time_t *waiting, struct qnode **pnode)
{
  struct qhost *h;
  struct qnode *n;

  *waiting = 0;
  if (!node_heap_cnt)
    return NULL;
  n = node_heap[1];
  if (n->wait_until > now)
    {
      *waiting = n->wait_until - now;
      DBG("waiting %d seconds", *waiting);
      return NULL;
    }
  HEAP_DELMIN(struct qnode *, node_heap, node_heap_cnt, NHEAP_LESS, NHEAP_SWAP);
  add_tail(&active_nodes, &n->n);
  h = HEAD(n->hosts);
  ASSERT(h->n.next);
  *pnode = n;
  DBG("Dequeued host <%s> key %08x", h->name, n->key);
  return h;
}

struct qhost *				/* Find (possibly queued) host by its signature */
find_host(uns proto, byte *name, uns port)
{
  struct qhost *h;

  for(h = host_hash[name_hash(name)];
      h && (h->protocol != proto || h->port != port || strcmp(h->name, name));
      h = h->hash_next)
    ;
  return h;
}

struct qhost *				/* Create new host entry */
new_host(uns proto, byte *name, uns port)
{
  struct qhost *h = mp_alloc_zero(host_pool, sizeof(struct qhost) + strlen(name));
  uns hh = name_hash(name);

  h->hash_next = host_hash[hh];
  host_hash[hh] = h;
  h->port = port;
  h->protocol = proto;
  h->flags = QHF_RELINK | QHF_DIRTY | QHF_ALLOCATE;
  h->robot_id = OID_UNDEFINED;
  strcpy(h->name, name);
  add_tail(&idle_hosts, &h->n);
  host_count++;
  return h;
}

static void
flush_host_cache(void)
{
  struct qnode *n;
  struct qhost *h;

  WALK_LIST(n, active_nodes)
    WALK_LIST(h, n->hosts)
      flush_host_entry(h);
}

void
walk_hosts(void (*f)(struct qhost *h))
{
  struct qhost *h;
  struct qnode *n;
  uns i;

  for (i=1; i <= node_heap_cnt; i++)
    WALK_LIST(h, node_heap[i]->hosts)
      f(h);
  WALK_LIST(n, active_nodes)
    WALK_LIST(h, n->hosts)
      f(h);
  WALK_LIST(h, idle_hosts)
    f(h);
}

static void
reset_hosts(void)
{
  struct qhost *h;
  uns i;

  /* All waiting hosts become idle, active hosts are assumed not to exist */
  for (i=1; i <= node_heap_cnt; i++)
    {
      struct qnode *n = node_heap[i];
      add_tail_list(&idle_hosts, &n->hosts);
      init_list(&n->hosts);
    }
  node_heap_cnt=0;

  /* Walk all hosts and reset them */
  WALK_LIST(h, idle_hosts)
    {
      h->qf_pos = h->qf_last = 0;
      bzero(h->obj_count, sizeof(h->obj_count));
    }
}

/* ITEM QUEUE */

static int queue_fd;			/* File handle for the queue file */
static struct page_cache *queue_cache;
static uns queue_size;

static uns				/* Return pointer to next page */
qbuf_get_next(struct page *p)
{
  byte *d = p->data;
  return (d[0] << 24) | (d[1] << 16) | (d[2] << 8) | d[3];
}

static void
qbuf_set_next(struct page *p, uns next)	/* Set pointer to next page */
{
  byte *d = p->data;
  d[0] = next >> 24;
  d[1] = next >> 16;
  d[2] = next >> 8;
  d[3] = next;
}

static struct page *			/* Allocate new page in the queue and lock it */
qblock_alloc(void)
{
  struct page *b;
  uns pos;

  if (pos = free_list->qf_pos)
    {
      pos &= ~QUEUE_PAGE_MASK;
      b = pgc_read(queue_cache, queue_fd, pos);
      free_list->qf_pos = qbuf_get_next(b);
      touch_host(free_list);
      DBG("Got block %x from free list", pos);
    }
  else
    {
      pos = queue_size;
      queue_size += QUEUE_PAGE_SIZE;
      if (queue_size >= 0xffff0000)
	die("Oops, queue file too large, consult a wizard.");
      b = pgc_get(queue_cache, queue_fd, pos);
      DBG("Got block %x from end of file", pos);
    }
  bzero(b->data, QUEUE_PAGE_SIZE);
  return b;
}

static void				/* Return page to the page pool */
qblock_free(struct page *b)
{
  DBG("Returning block %x to the pool", (int) b->pos);
  bzero(b->data, QUEUE_PAGE_SIZE);
  qbuf_set_next(b, free_list->qf_pos);
  free_list->qf_pos = b->pos + 4;	/* Beware of page 0 */
  touch_host(free_list);
  pgc_mark_dirty(queue_cache, b);
}

struct qitem *				/* Get one item without dequeueing it first */
peek_item(struct qhost *h)
{
  uns pos;
  struct page *b;
  byte *d;
  static struct qitem *qi = NULL;

  if (!qi)
    qi = xmalloc(sizeof(struct qitem) + MAX_URL_SIZE - 1);

  DBG("peek_item(%s)", h->name);
  while (pos = h->qf_pos)
    {
      DBG("...peeking at %x", pos);
      b = pgc_read(queue_cache, queue_fd, pos & ~QUEUE_PAGE_MASK);
      pos &= QUEUE_PAGE_MASK;
      if (b->data[pos])
	{
	  d = qi->text;
	  while (*d = b->data[pos])
	    d++, pos++;
	  qi->aux = b->pos + pos + 1;
	  pgc_put(queue_cache, b);
	  return qi;
	}
      pos = qbuf_get_next(b);
      h->qf_pos = pos;
      qblock_free(b);
      pgc_put(queue_cache, b);
      if (!pos)
	h->qf_last = 0;
      touch_host(h);
    }
  return NULL;
}

struct qitem *				/* Fetch item and dequeue it */
dequeue_item(struct qhost *h)
{
  struct qitem *i = peek_item(h);

  if (i)
    {
      h->qf_pos = i->aux;
      touch_host(h);
    }
  return i;
}

void					/* Add new item to the queue */
enqueue_item(struct qhost *h, byte *name)
{
  struct page *b;
  uns last;
  uns len = strlen(name) + 1;

  DBG("enqueue_item(%s,%s)", h->name, name);
  if (!h->qf_last)
    {
      b = qblock_alloc();
      last = 4;
      DBG("...allocated first block at %x", (int) b->pos);
    }
  else
    {
      b = pgc_read(queue_cache, queue_fd, h->qf_last & ~QUEUE_PAGE_MASK);
      last = h->qf_last & QUEUE_PAGE_MASK;
      DBG("...block at %x, last=%x", (int) b->pos, last);
      if (last + len >= QUEUE_PAGE_SIZE)
	{
	  struct page *o = b;
	  b = qblock_alloc();
	  qbuf_set_next(o, b->pos + 4);
	  pgc_mark_dirty(queue_cache, o);
	  pgc_put(queue_cache, o);
	  last = 4;
	  DBG("...overflow, new block at %x, last=%x", (int) b->pos, last);
	}
    }
  strcpy(b->data + last, name);
  b->data[last+len-1] = 0;
  if (!h->qf_pos)
    h->qf_pos = b->pos + last;
  h->qf_last = b->pos + last + len;
  pgc_mark_dirty(queue_cache, b);
  pgc_put(queue_cache, b);
  touch_host(h);
}

void
requeue_item(struct qhost *h)
{
  struct qitem *q;

  q = dequeue_item(h);
  if (q)
    enqueue_item(h, q->text);
}

uns
queue_walk_start(struct qhost *h)
{
  return h->qf_pos;
}

byte *
queue_walk_next(uns *pos)
{
  static struct page *b;
  uns p = *pos;
  byte *t, *start;

  for(;;)
    {
      if (!p)
	{
	  *pos = 0;
	  return NULL;
	}
      if (!b)
	b = pgc_read(queue_cache, queue_fd, p & ~QUEUE_PAGE_MASK);
      t = start = b->data + (p & QUEUE_PAGE_MASK);
      if (*t)
	{
	  do p++; while (*t++);
	  *pos = p;
	  return start;
	}
      t = b->data;
      p = (t[0] << 24) | (t[1] << 16) | (t[2] << 8) | t[3];
      pgc_put(queue_cache, b);
      b = NULL;
    }
}

void
queue_reset(void)
{
  DBG("Resetting the queue");
  reset_hosts();
  pgc_cleanup(queue_cache);
  sh_ftruncate(queue_fd, 0);
  queue_size = 0;
}

/* INITIALIZATION AND CLEANUP */

static void				/* Load list of all hosts from the host file */
load_host_list(void)
{
  struct fastbuf *f;

  DBG("Loading host list");
  host_file = f = bopen(host_file_name, O_RDWR | O_CREAT, 4096);
  if (bgetc(f) == EOF)
    {
      log(L_INFO, "Host database doesn't exist, creating new one");
      free_list = new_host(0, "", 0);
      flush_host_entry(free_list);
    }
  else
    {
      bsetpos(f, 0);
      for(;;)
	{
	  int proto, port;
	  struct qhost *h;
	  byte name[MAX_URL_SIZE];
		  
	  proto = bgetc(f);
	  if (proto == EOF)
	    break;
	  port = bgetw(f);
	  if (!bgets(f, name, MAX_URL_SIZE))
	    die("Malformed host file: truncated record");
	  h = new_host(proto, name, port);
	  h->hf_pos = btell(f);
	  h->qf_pos = bgetl(f);
	  h->qf_last = bgetl(f);
	  breadb(f, h->obj_count, sizeof(h->obj_count));
	  h->robot_id = bgetl(f);
	  h->robot_time = bgetl(f);
	  h->rec_err_count = bgetl(f);
	  h->qkey = bgetl(f);
	  h->flags = QHF_RELINK;
	  if (!h->port && !h->protocol)
	    {
	      if (free_list)
		die("Malformed host file: multiple free list entries");
	      free_list = h;
	    }
	  else
	    enqueue_host(h, NULL, 0);
	}
      host_file_size = btell(f);
    }
  if (!free_list)
    die("Malformed host file: missing free list entry");
}

static void				/* Dump all known hosts to the host file */
write_host_db(void)
{
  DBG("Flushing host database");
  bclose(host_file);
  unlink(host_bak_name);
  if (rename(host_file_name, host_bak_name) < 0)
    die("Cannot rename %s to %s: %m", host_file_name, host_bak_name);
  host_file = bopen(host_file_name, O_RDWR|O_CREAT|O_TRUNC, 16384);
  walk_hosts(write_host_entry);
  bclose(host_file);
  unlink(host_bak_name);
}

void					/* Initialize the queueing mechanism */
queue_init(void)
{
  DBG("queue_init");
  host_pool = mp_new(16384);
  init_list(&active_nodes);
  node_heap_cnt = 0;
  node_heap_max = INITIAL_HEAP_SIZE;
  node_heap = xmalloc(INITIAL_HEAP_SIZE * sizeof(struct qnode *));
  init_list(&idle_hosts);
  host_hash = xmalloc_zero(host_hash_size * sizeof(struct qhost *));
  node_hash = xmalloc_zero(key_hash_size * sizeof(struct qhost *));
  load_host_list();
  if ((queue_fd = sh_open(queue_file_name, O_RDWR | O_CREAT, 0666)) < 0)
    die("Unable to open queue file: %m");
  queue_cache = pgc_open(QUEUE_PAGE_SIZE, queue_cache_size);
  queue_size = sh_seek(queue_fd, 0, SEEK_END);
}

void					/* Cleanup of the queue machinery */
queue_cleanup(void)
{
  DBG("queue_cleanup");
  write_host_db();
  pgc_close(queue_cache);
}

void					/* Write out all modified records */
queue_sync(void)
{
  DBG("queue_sync");
  pgc_flush(queue_cache);
  flush_host_cache();
  flush_host_entry(free_list);
  bflush(host_file);
}
