#!/bin/bash
#
#  Sherlock Index Distribution Script
#  (c) 2002 Martin Mares <mj@ucw.cz>
#

set -e
SENDONLY=
if [ "$1" == --sendonly ] ; then
	shift
	SENDONLY=1
fi
if [ -z "$4" -o -n "$5" ] ; then
	echo >&2 "Usage: send-index [--sendonly] [<user>@]<search-server> <remote-homedir> <local-index-name> <remote-index-name>"
	exit 1
fi
SERVER=$1
SDIR=$2
LOCALINDEX=$3
REMINDEX=$4
SERVHOST=`echo $SERVER | sed 's/^.*@//'`

function log
{
	bin/logger send-index I "$1"
}

function debug
{
	bin/logger send-index D "$1"
}

function cmd
{
	debug "Sending: set -e ; cd $SDIR ; $1"
	ssh $SERVER "set -e ; cd $SDIR ; $1"
}

function die
{
	bin/logger send-index ! "$1"
	exit 1
}

log "Sending index to $SERVER"
cmd "rm -rf $REMINDEX.old $REMINDEX.new ; mkdir -p $REMINDEX.new"
FILES=""
for a in parameters cards card-attrs references lexicon string-map string-hash ; do
	if [ -f $LOCALINDEX/$a ] ; then
		FILES="$FILES $a"
	fi
done
[ -n "$FILES" ] || die "No files to transfer!"
cmd "bin/file-recv $REMINDEX.new$FILES" | bin/file-send $LOCALINDEX

if [ -n "$SENDONLY" ] ; then
	log "Index transferred, switch indices manually."
	exit 0
fi

log "Switching indices..."
cmd "bin/scontrol swap $REMINDEX" || die "Swapping of indices FAILED! Please fix manually."
log "New index installed."
