/*
 *	Sherlock Gatherer -- ObjDump
 *
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/bucket.h"
#include "lib/index.h"
#include "charset/unicode.h"
#include "charset/charconv.h"
#include "utils/dumpconfig.h"

#include <stdlib.h>
#include <string.h>

static int term_charset_id;
static uns attr_name_len;
static byte verbose;				/* Expand object attribute names?  */
static struct conv_context conv_utf8;

/* Maximal input line length.  */
#define	BUFSIZE	512

static char *options = CF_SHORT_OPTS "vf:";

static char *help = "\
Usage: objdump <options> [object-id list]\n\
\t(if none object-id is specified, stdin is dumped)\n\
\n\
Options:\n"
CF_USAGE
"-f\t\t\tOverride default bucket filename\n\
-v\t\t\tSet verbose mode\n\
";

static void NONRET
usage(void)
{
	fputs(help, stderr);
	exit(1);
}

static oid_t
parse_id(char *c)
{
	char *e;
	oid_t o = strtoul(c, &e, 16);
	if (e && *e)
		die("Invalid object ID: %s", c);
	return o;
}

static byte *attr_names[] =
{
	"Aapplet reference",
	"Dlast downloaded",
	"Econtent-encoding",
	"Fframe reference",
	"Iimage reference",
	"Llast modified",
	"Ooid",
	"Rurl reference",
	"Shttp server header",
	"Tcontent-type",
	"Uurl",
	"Wwait",
	"Xtext",
	"Yredirected to",
	"Zstream",
	"bbacklink",
	"ccharset",
	"ddescription reference",
	"eexpires",
	"fform reference",
	"llanguage list",
	"noriginal content-encoding",
	"rfiltering rule",
	"sdocument size",
	"tsection tag",
	"wreference weight",
	"yback-redirect",
	".remark",
	"!gathering result",
	""
};

static inline uns
dump_attr_name(int c)
{
	if (!verbose)
	{
		putc(c, stdout);
		return 1;
	}
	else
	{
		byte **attr;
		for (attr = attr_names; **attr && **attr != c; attr++);
		if (!**attr)
			return printf("unknown attr %c: ", c);
		else
			return printf("%s: ", (*attr)+1);
	}
}

static uns
dump_attr_name_space(int c)
{
	uns len = dump_attr_name(c);
	uns maxlen;
	if (!verbose)
		return len;
	maxlen = (c == 'Z' || c== 'X') ? 8 : 28;
	while (len++ < maxlen)
		putc(' ', stdout);
	return maxlen;
}

static void
objdump_init(oid_t oid)
{
	attr_name_len = verbose ? 8 : 1;
	dump_attr_name_space('O');
	printf("%d\n", oid);
}

static byte outtext[BUFSIZE];			/* formatted output text */
static byte *outend = outtext;
static uns out_space;

static void
flush_outtext(void)
{
	dump_attr_name_space('X');
	printf("%s\n", outtext);
	outtext[0] = 0;
	outend = outtext;
}

static void
add_word(byte *b, byte *e)
{
	if (outend-outtext + 1 + e-b >= (int)(line_len - attr_name_len))
		flush_outtext();
	if (out_space && outend != outtext)
		*outend++ = ' ';
	strncpy(outend, b, e-b);
	outend[e-b] = 0;
	outend += e-b;
	out_space = 0;
}

static byte *wt_names[16] = { WORD_TYPE_USER_NAMES };

static void
objdump_line(byte *line)
{
	if (!line[0])
		return;
	if (line[0] != 'X' && outend != outtext)
		flush_outtext();
	if (line[0] != 'X' && line[0] != 'Z')
	{
		dump_attr_name_space(line[0]);
		printf("%s\n", line+1);
	}
	else if (line[0] == 'Z')
	{
		struct conv_context *cc = &conv_utf8;
		byte recoded[BUFSIZE];
		int flags;
		dump_attr_name_space(line[0]);
		cc->source = line + 1;
		cc->source_end = line + strlen(line);
		cc->dest = cc->dest_start = recoded;
		cc->dest_end = recoded+BUFSIZE;
		do
		{
			flags = conv_run(cc);
			if (flags & (CONV_SOURCE_END | CONV_DEST_END))
			{
				fwrite(cc->dest_start, 1, cc->dest - cc->dest_start, stdout);
				cc->dest = recoded;
			}
		}
		while (! (flags & CONV_SOURCE_END));
		printf("\n");
	}
	else if (line[0] == 'X')
	{
		struct conv_context *cc = &conv_utf8;
		byte recoded[BUFSIZE], *end;
		int flags;
		cc->dest = cc->dest_start = recoded;
		cc->dest_end = recoded+BUFSIZE;
		cc->source = line + 1;
		end = line + strlen(line);
		out_space = 1;
		while (cc->source < end)
		{
			byte *c;
			uns tag;
			int len;
			c = (byte*)cc->source;
			do
			{
				cc->source_end = c;
				GET_TAGGED_CHAR(c, tag);
			}
			while (tag && tag != ' ' && tag < 0x80000000);
			do
			{
				flags = conv_run(cc);
				if (flags & (CONV_SOURCE_END | CONV_DEST_END))
				{
					if (cc->dest != cc->dest_start)
						add_word(cc->dest_start, cc->dest);
					cc->dest = recoded;
				}
			}
			while (! (flags & CONV_SOURCE_END));
			cc->source = c;
			if (tag < 0x80000000)	/* space, end of string */
			{
				out_space = 1;
				continue;
			}
			if (tag < 0x80010000)
			{
				if ( tag & 0x10)
				{
					out_space = 1;
					len = sprintf(recoded, "<break>");
					add_word(recoded, recoded+len);
				}
				out_space = 1;
				len = sprintf(recoded, "<%s>", wt_names[tag & 0x0f]);
				add_word(recoded, recoded+len);
				out_space = 1;
			}
			else if (tag < 0x80020000)
			{
				len = sprintf(recoded, "<ref %d>", tag & 0x03ff);
				add_word(recoded, recoded+len);
			}
			else
			{
				len = sprintf(recoded, "</ref>");
				add_word(recoded, recoded+len);
			}
		}
	}
}

static void
objdump_done(void)
{
	if (outend != outtext)
		flush_outtext();
	printf("\n");
}

static void
extract(byte *oid_s)
{
	struct obuck_header h;
	struct fastbuf *b;
	byte buf[BUFSIZE];
	h.oid = parse_id(oid_s);
	obuck_find_by_oid(&h);
	b = obuck_fetch();
	objdump_init(h.oid);
	while (bgets(b, buf, BUFSIZE))
		objdump_line(buf);
	objdump_done();
	obuck_fetch_end(b);
}

static void
dump_stdin(void)
{
	struct fastbuf *b;
	byte buf[BUFSIZE];
	b = bfdopen_shared(0, 4096);
	bgets(b, buf, BUFSIZE);
	if (strncmp(buf, "###", 3))		/* a single object */
	{
		objdump_init(0);
		do
		{
			objdump_line(buf);
		}
		while (bgets(b, buf, BUFSIZE));
		objdump_done();
	}
	else					/* multiple objects divided by ### lines */
	{
		do
		{
			oid_t oid;
			sscanf(buf+4, "%x", &oid);
			objdump_init(oid);
			while(1)
			{
				if (!bgets(b, buf, BUFSIZE))
				{
					buf[0] = 0;
					break;
				}
				if (!strncmp(buf, "###", 3))
					break;
				objdump_line(buf);
			}
			objdump_done();
		}
		while (buf[0]);
	}
	bclose(b);
}

int
main(int argc, char **argv)
{
	byte *filename = NULL;
	int opt;

	log_init(argv[0]);
	while ((opt = cf_getopt(argc, argv, options, CF_NO_LONG_OPTS, NULL)) >= 0)
		switch (opt)
		{
			case 'f':
				filename = optarg;
				break;
			case 'v':
				verbose++;
				break;
			default:
				usage();
				break;
		}
	term_charset_id = find_charset_by_name(terminal_charset);
	if (term_charset_id < 0)
		die("Unknown terminal charset %s", terminal_charset);
	conv_init(&conv_utf8);
	conv_set_charset(&conv_utf8, CONV_CHARSET_UTF8, term_charset_id);
	if (optind < argc)
	{
		if (filename)
			obuck_name = filename;
		obuck_init(0);
		while (optind < argc)
			extract(argv[optind++]);
		obuck_cleanup();
	}
	else
	{
		dump_stdin();
	}
	return 0;
}
