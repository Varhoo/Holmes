/*
 *	Sherlock Gatherer -- Index Dumper
 *
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 *	(c) 2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/bucket.h"
#include "lib/chartype.h"
#include "charset/unicode.h"
#include "charset/charconv.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"
#include "utils/dumpconfig.h"

#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

static int term_charset_id;
static struct conv_context conv_utf8;
static int verbose;				/* Expand object attribute names?  */
static int bare;				/* Avoid headings */

/* Maximal input line length.  */
#define	BUFSIZE	512

static void
dump_card_attr(u64 id, void *tmp)
{
	struct card_attr *a = tmp;
	byte *attrs = "EADMI***";
	byte at[9];
	uns i;

	if (!a)
	{
		if (!verbose)
			printf("ID       Card     SiteID   Wgt %s Age\n", attrs);
		return;
	}
	for (i=0; i<8; i++)
	  at[i] = (a->flags & (1<<i)) ? attrs[i] : '-';
	at[i] = 0;
	if (verbose)
	{
		printf("Attribute %x:\n", (u32) id);
		printf("Card:\t%x\n", a->card);
		printf("Weight:\t%d\n", a->weight);
		printf("Flags:\t%s\n", at);
		printf("Age:\t%d\n", a->age);
#define INT_ATTR(id,keywd,gf,pf) printf("Custom " #id ":\t%x\n", gf(a));
#define SMALL_SET_ATTR(id,keywd,gf,pf) printf("Custom " #id ":\t%x\n", gf(a));
  CUSTOM_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
		putchar('\n');
	}
	else
	{
		printf("%8x %8x %08x %3d %s %3d\n",
			(u32) id, a->card,
		       0,
		       a->weight, at, a->age);
	}
}

static void
dump_checksum(u64 id, void *tmp)
{
	struct csum *c = tmp;
	int i;
	if (!tmp)
	{
		if (!verbose)
			printf("Pos      MD5                              CardID\n");
		return;
	}
	if (verbose)
	{
		printf("Checksum at %x:\n", (u32) id);
		printf("MD5:\t");
		for (i=0; i<16; i++)
			printf("%02x", c->md5[i]);
		printf("\n");
		printf("Card:\t%08x\n\n", c->cardid);
	}
	else
	{
		printf("%08x ", (u32) id);
		for (i=0; i<16; i++)
			printf("%02x", c->md5[i]);
		printf(" %08x\n", c->cardid);
	}
}

static void
dump_fingerprint(u64 id, void *tmp)
{
	struct fprint *c = tmp;
	int i;
	if (!c)
	{
		if (!verbose)
			printf("ID       Fingerprint              CardID\n");
		return;
	}
	if (verbose)
	{
		printf("Fingerprint at %x:\n", (u32) id);
		printf("Hash:\t");
		for (i=0; i<12; i++)
			printf("%02x", c->fp.hash[i]);
		printf("\n");
		printf("Card:\t%08x\n\n", c->cardid);
	}
	else
	{
		printf("%08x ", (u32) id);
		for (i=0; i<12; i++)
			printf("%02x", c->fp.hash[i]);
		printf(" %08x\n", c->cardid);
	}
}

static void
dump_signatures(u64 id, void *tmp)
{
	uns *c = tmp;
	uns i;
	if (!tmp)
	{
		if (!verbose)
			printf("Pos      CardID   Signatures\n");
		return;
	}
	if (verbose)
	{
		printf("Checksum at %x:\n", (u32) id);
		printf("Card:\t%08x\n", *c++);
		printf("Signatures:\t");
		for (i=0; i<matcher_signatures; i++)
			printf("%08x ", c[i]);
		printf("\n\n");
	}
	else
	{
		printf("%08x ", (u32) id);
		printf("%08x", *c++);
		for (i=0; i<matcher_signatures; i++)
			printf(" %08x", c[i]);
		printf("\n");
	}
}

static void
dump_card(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	byte newline = 1, breakline = 0;
	byte attr = 0;
	uns len = 0;
	u32 id;

	if (!f)
		return;
	ASSERT(!(start & ((1 << CARD_POS_SHIFT) - 1)));
	id = start >> CARD_POS_SHIFT;
	printf("### %08x %d %d\n", id, 0, 0);
	for(;;)
	{
		int c = bgetc(f);
		if (c == EOF)
			die("Incomplete card entry");
		if (!c)
			break;
		if (c == '\n')
		{
			newline = 1;
			breakline = 0;
			len = 0;
		}
		else
		{
			if (newline)
			{
				attr = c;
				newline = 0;
			}
			len++;
		}
		if (len >= line_len)
			breakline = 1;
		if (breakline &&
			(Cspace(c)
			|| len >= 192 && Cctrl(c)
			|| len >= 256 && (c < 0x80 || c >= 0xc0)) )
		{
			printf("\n%c", attr);
			if (!Cspace(c))
				putc(c, stdout);
			breakline = 0;
			len = 0;
		}
		else
		{
			/* We will *NOT* recode the UTF-8 characters,
			 * because the output in this mode should be
			 * piped to objdump, which recodes the data
			 * itself and performs the formatting.
			 */
			putc(c, stdout);
		}
	}
	while (btell(f) & ((1 << CARD_POS_SHIFT) - 1))
		bgetc(f);
}

struct lab {
	u32 id;
	u32 count;
} PACKED;

static void
dump_labels(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct lab label;
	uns i;

	if (!f)
		return;
	breadb(f, &label, sizeof(struct lab));
	printf("Label at %08qx:\n", start);
	printf("ID:\t%08x\n", label.id);
	printf("Count:\t%d\n", label.count);
	printf("Labels:\n\t");
	for (i=0; i<label.count; i++)
	{
		byte c = bgetc(f);
		if (!c)
			printf("\n\t");
		else
			putc(c, stdout);
		start++;
	}
	printf("\n");
}

static void
dump_labels_id(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u32 id;
	uns pri;

	if (!f)
		return;

	id = bgetl(f);
	pri = bgetc(f);
	printf("Label block at %08qx for ID %08x, priority %d\n\t", start, id, pri);
	while (1)
	{
		int c;
		while ((c = bgetc(f)) != 0 && c != EOF)
			putc(c, stdout);
		printf("\n\t");
		c = bgetc(f);
		if (!c || c == EOF)
			break;
		bungetc(f);
	}
	printf("\n");
}

static void
print_recoded_string(byte *str, uns len)
{
	struct conv_context *cc = &conv_utf8;
	byte recoded[MAX_WORD_LEN+1];
	int flags;
	cc->source = str;
	cc->source_end = str + len;
	cc->dest = cc->dest_start = recoded;
	cc->dest_end = recoded + MAX_WORD_LEN+1;
	do
	{
		flags = conv_run(cc);
		if (flags & (CONV_SOURCE_END | CONV_DEST_END))
		{
			fwrite(cc->dest_start, 1, cc->dest - cc->dest_start, stdout);
			cc->dest = recoded;
		}
	}
	while (! (flags & CONV_SOURCE_END));
}

static char *word_classes[] = { "????", "ignr", "word", "garb", "prep", "post", "brek", "comp" };

static void
dump_lex_word(struct fastbuf *f, uns len, uns class)
{
  byte word[MAX_WORD_LEN+1];
  uns i;

  breadb(f, word, len);
  if (class == WC_COMPOUND)
    {
      for (i=0; i<len/4; i++)
	printf("%c%x", i?' ':'<', ((u32*)word)[i]);
      putchar('>');
    }
  else
    print_recoded_string(word, len);
}

static void
dump_lexicon(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	static uns wordid;

	if (!f)
	{
		if (!verbose)
			printf("ID       RefPos   Flgs Len Word\n");
		return;
	}
	if (!start)
	{
		u32 wc = bgetl(f);
		printf("# Entry count:\t%d\n", wc);
		wordid = 8;
	}
	else
	{
		sh_off_t ref_pos;
		int length, class, id;
		ref_pos = bgeto(f);
		class = bgetc(f);
		length = bgetc(f);
		id = wordid | class;
		if (verbose)
		{
			printf("Word ID %x:\n", id);
			printf("References:\t%08qx\n", (long long) ref_pos);
			printf("Class:\t\t%s\n", (class > 7 ? "????" : word_classes[class]));
			printf("Length:\t\t%d\n", length);
			printf("Word:\t\t");
		}
		else
		{
			printf("%8x %8qx %s %3d ", id, (long long) ref_pos, (class > 7 ? "????" : word_classes[class]), length);
		}
		dump_lex_word(f, length, class);
		printf(verbose ? "\n\n" : "\n");
		wordid += 8;
	}
}

static void
dump_lex_temp(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	static uns wordid;

	if (!f)
	{
		if (!verbose)
			printf("ID       Count      Flgs Len Word\n");
		return;
	}
	if (!start)
	{
		u32 wc = bgetl(f);
		printf("# Word count:\t%d\n", wc);
		wordid = 8;
	}
	else
	{
		u32 count;
		int length, class, id;
		count = bgetl(f);
		class = bgetc(f);
		length = bgetc(f);
		id = wordid | class;
		if (verbose)
		{
			printf("Word ID %x:\n", id);
			printf("Count:\t\t%d\n", count);
			printf("Class:\t\t%s\n", (class > 7 ? "????" : word_classes[class]));
			printf("Length:\t\t%d\n", length);
			printf("Word:\t\t");
		}
		else
		{
			printf("%8x %10d %s %3d ", id, count, (class > 7 ? "????" : word_classes[class]), length);
		}
		dump_lex_word(f, length, class);
		printf(verbose ? "\n\n" : "\n");
		wordid += 8;
	}
}

static void
dump_graph(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	uns src, deg;
	byte *vtypes[4] = { "", " [redir]", " [frame]", " [img]" };

	if (!f)
		return;
	src = bgetl(f);
	deg = bgetw(f);
	printf("Vertex %d (degree %d) at %08qx:\n", src, deg, start);
	while (deg--)
	{
		u32 x = bgetl(f);
		printf("\t-> %d%s\n",
		       x & ~ETYPE_MASK,
		       vtypes[x >> 30U]);
	}
}

static void
dump_u32(u64 id, void *tmp)
{
	u32 *u = tmp;
	if (!u)
		return;
	printf("%08x -> %08x\n", (u32) id, *u);
}

static void
dump_refs(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u16 hi, lo;

	if (!f)
	{
		if (!verbose)
			printf("Pos      OID      pos:type\n");
		return;
	}
	if (verbose)
		printf("Reference block at %08qx:\n", start);
	hi = bgetw(f);
	while (1)
	{
		lo = bgetw(f);
		if (!hi && !lo)
			break;
		if (verbose)
			printf("OID:\t%08x\n", hi<<16 | lo);
		else
			printf("%8qx %8x ", (long long)btell(f)-4, hi<<16 | lo);
		while (1)
		{
			word ref = bgetw(f);
			if (!(ref >> 12))
			{
				hi = ref;
				break;
			}
			if (verbose)
				printf("Ref:\t%03x %x\n", ref & 0xfff, ref >> 12);
			else
				printf("%03x:%x ", ref & 0xfff, ref >> 12);
		}
		if (!verbose)
			printf("\n");
	}
	printf("\n");
}

static void
dump_ref_texts(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;
	uns i, l;
	struct fingerprint fp;

	if (!f)
	{
		if (!verbose)
			printf("ID       FingerPrint              Text\n");
		return;
	}
	printf("%08x ", bgetl(f));
	breadb(f, &fp, sizeof(fp));
	for (i=0; i<12; i++)
		printf("%02x", fp.hash[i]);
	putchar(' ');
	l = bgetw(f);
	while (l--) {
		i = bgetc(f);
		putchar(i);
	}
	putchar('\n');
}

static void
dump_ascii(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;
	byte line[BUFSIZE];

	if (!f)
		return;
	bgets(f, line, BUFSIZE);
	puts(line);
}

static void
dump_string_index(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct fingerprint fp;
	u32 size;
	uns i;

	if (!f)
		return;
	breadb(f, &fp, sizeof(struct fingerprint));
	breadb(f, &size, sizeof(u32));
	if (verbose)
	{
		printf("String index entry at %08qx:\n", start);
		printf("Finger:\t");
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf("\n");
		printf("Size:\t%d\n", size);
	}
	else
	{
		printf("S%8qx ", start);
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf(" %8d\n", size);
	}
	while (size > 0)
	{
		u32 oid;
		u16 count;
		u64 estart = btell(f);
		oid = bgetl(f);
		count = bgetw(f);
		size -= sizeof(u32) + (count+1)*sizeof(u16);
		if (verbose)
		{
			printf("OID:\t%08x\n", oid);
			printf("Count:\t%d\n", count);
		}
		else
		{
			printf("O%8qx %8x %5d  ", estart, oid, count);
		}
		for (i=0; i<count; i++)
		{
			u16 ref = bgetw(f);
			if (verbose)
				printf("Ref:\t%04x\n", ref);
			else
				printf("%04x ", ref);
		}
		if (!verbose)
			printf("\n");
	}
	printf("\n");
}

static void
dump_string_map(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct fingerprint fp;
	sh_off_t ref_pos;
	uns i;

	if (!f)
	{
		if (!verbose)
			printf("Pos      Fingerprint              RefPos\n");
		return;
	}
	breadb(f, &fp, sizeof(struct fingerprint));
	ref_pos = bgeto(f);
	if (verbose)
	{
		printf("String map entry at %08qx:\n", start);
		printf("Finger:\t");
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf("\n");
		printf("RefPos:\t%08qx\n\n", (long long) ref_pos);
	}
	else
	{
		printf("%8qx ", start);
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf(" %08qx\n", (long long) ref_pos);
	}
}

static void
dump_word_index(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u32 wordid, size;
	uns i;

	if (!f)
		return;
	breadb(f, &wordid, sizeof(u32));
	breadb(f, &size, sizeof(u32));
	if (verbose)
	{
		printf("Word index entry at %08qx:\n", start);
		printf("Word:\t%x\n", wordid);
		printf("Size:\t%d\n", size);
	}
	else
	{
		printf("S%8qx %8x %8d\n", start, wordid, size);
	}
	while (size > 0)
	{
		u32 oid;
		u16 count;
		u64 estart = btell(f);
		oid = bgetl(f);
		count = bgetw(f);
		size -= sizeof(u32) + (count+1)*sizeof(u16);
		if (verbose)
		{
			printf("OID:\t%08x\n", oid);
			printf("Count:\t%d\n", count);
		}
		else
		{
			printf("O%8qx %8x %5d  ", estart, oid, count);
		}
		for (i=0; i<count; i++)
		{
			u16 ref = bgetw(f);
			if (verbose)
				printf("Ref:\t%04x\n", ref);
			else
				printf("%04x ", ref);
		}
		if (!verbose)
			printf("\n");
	}
	printf("\n");
}

static void
dump_params(u64 start UNUSED, void *tmp)
{
	struct index_params *par = tmp;

	if (!par)
		return;
	printf("Reference time: %d\n", (uns) par->ref_time);
}

struct index_file {
	int option;
	byte **default_filename;
	int record_size;
		/* 
		 * record_size > 0:	uniform sequence with records of size record_size
		 * record_size == 0:	non-uniform sequence
		 * record_size < 0:	non-uniform sequence with records aligned to -record_size
		 */
	void (*dump_single)(u64 id, void *in);
};

static struct index_file index_files[] = {
	{ 'a', &fn_attributes, 		sizeof(struct card_attr),	dump_card_attr	},
	{ 'c', &fn_cards,		-(1 << CARD_POS_SHIFT),		dump_card	},
	{ 'd', &fn_card_attrs,		sizeof(struct card_attr),	dump_card_attr	},
	{ 'h', &fn_checksums,		sizeof(struct csum),		dump_checksum	},
	{ 'F', &fn_fingerprints,	sizeof(struct fprint),		dump_fingerprint},
	{ 'l', &fn_labels,		0,				dump_labels	},
	{ 'L', &fn_labels_by_id,	0,				dump_labels_id	},
	{ 'x', &fn_lexicon,		0,				dump_lexicon	},
	{ 'y', &fn_lex_temp,		0,				dump_lex_temp	},
	{ 'Y', &fn_lexicon_by_cnt,	0,				dump_lex_temp	},
	{ 'k', &fn_links,		sizeof(struct fprint),		dump_fingerprint},
	{ 'g', &fn_link_graph,		0,				dump_graph	},
	{ 'm', &fn_merges,		sizeof(u32),			dump_u32	},
	{ 'p', &fn_parameters,		sizeof(struct index_params),	dump_params	},
	{ 'r', &fn_references,		0,				dump_refs	},
	{ 't', &fn_ref_texts,		0,				dump_ref_texts	},
	{ 's', &fn_sites,		0,				dump_ascii	},
	{ 'G', &fn_signatures,		0, /* computed run-time */	dump_signatures	},
	{ 'H', &fn_string_hash,		sizeof(u32),			dump_u32	},
	{ 'I', &fn_string_index,	0,				dump_string_index },
	{ 'M', &fn_string_map,		0,				dump_string_map },
	{ 'u', &fn_urls,		0,				dump_ascii	},
	{ 'w', &fn_word_index,		0,				dump_word_index },
	{ 0,   NULL,			0,				NULL		}
};

static char *shortopts = CF_SHORT_OPTS "bvf:acdhFlLxyYkgmrtsGHIMuwp";
static struct option longopts[] =
{
	CF_LONG_OPTS
	{ "bare",		0, 0, 'b' },
	{ "filename",		0, 0, 'f' },
	{ "verbose",		0, 0, 'v' },
	{ "attr",		0, 0, 'a' },
	{ "card",		0, 0, 'c' },
	{ "card-attr",		0, 0, 'd' },
	{ "checksum",		0, 0, 'h' },
	{ "finger",		0, 0, 'F' },
	{ "label",		0, 0, 'l' },
	{ "labels-id",		0, 0, 'L' },
	{ "lexicon",		0, 0, 'x' },
	{ "tmp-lexicon",	0, 0, 'y' },
	{ "tmp-lexicon-freq",	0, 0, 'Y' },
	{ "link",		0, 0, 'k' },
	{ "link-graph",		0, 0, 'g' },
	{ "merge",		0, 0, 'm' },
	{ "parameters",		0, 0, 'p' },
	{ "reference",		0, 0, 'r' },
	{ "reference-texts",	0, 0, 't' },
	{ "site",		0, 0, 's' },
	{ "signature",		0, 0, 'G' },
	{ "string-hash",	0, 0, 'H' },
	{ "string-index",	0, 0, 'I' },
	{ "string-map",		0, 0, 'M' },
	{ "url",		0, 0, 'u' },
	{ "word",		0, 0, 'w' },
	{ NULL,			0, 0, 0 }
};

static char *help = "\
Usage: idxdump [<options>] <index-file> [<id> | [<first-id>]-[<last-id>]]\n\
\n\
Options:\n"
CF_USAGE
"-b, --bare\t\tDon't print table heading\n\
-f, --filename\t\tOverride default filename for given index file\n\
-v, --verbose\t\tSet verbose mode\n\n\
Index files:\n\
-a, --attr\t\tAttributes\n\
-c, --card\t\tCards\n\
-d, --card-attr\t\tCard attributes\n\
-h, --checksum\t\tChecksums\n\
-F, --finger\t\tFingerprints\n\
-l, --label\t\tLabels\n\
-L, --labels-id\t\tLabels by id\n\
-x, --lexicon\t\tLexicon\n\
-y, --tmp-lexicon\tTemporary lexicon\n\
-Y, --tmp-lexicon-freq\tTemporary lexicon by freq\n\
-k, --link\t\tLinks by url\n\
-g, --link-graph\tLink graph\n\
-m, --merge\t\tMerges\n\
-p, --parameters\tIndex parameters\n\
-r, --reference\t\tReferences\n\
-t, --reftexts\t\tReference texts\n\
-s, --site\t\tSites\n\
-G, --signature\t\tSignatures\n\
-H, --string-hash\tString hash\n\
-I, --string-index\tString index\n\
-M, --string-map\tString map\n\
-u, --url\t\tUrl list\n\
-w, --word\t\tWord index\n\
";

static void NONRET
usage(byte *msg)
{
	if (msg)
	{
		fputs(msg, stderr);
		fputc('\n', stderr);
	}
	fputs(help, stderr);
	exit(1);
}

static u64
xtol64(byte *c)
{
	u64 x = 0;
	int n = 0;

	while (*c)
	{
		if (++n > 16)
			die("Number too long");
		if (!Cxdigit(*c))
			die("Invalid hexadecimal number");
		x = (x << 4) | Cxvalue(*c);
		c++;
	}
	return x;
}

static void
dump_index_file(struct index_file *f, struct fastbuf *b, int argc, char **argv)
{
	u64 start = 0;
	u64 stop = ~0ULL;

	if (argc >= 2)
		usage("Only one ID expected");
	if (argc >= 1)
	{
		byte *c;
		if (c = strchr(argv[0], '-'))
		{
			*c++ = 0;
			if (*c)
				stop = xtol64(c);
			if (*argv[0])
				start = xtol64(argv[0]);
		}
		else
			start = stop = xtol64(argv[0]);
		if (start > stop)
			usage("Invalid ID range");
	}
	if (!bare)
		f->dump_single(0, NULL);
	if (f->option == 'G')
	{
		/* The file dumped is just a temporary file of the process of
		 * building the index, hence we ignore the contingency that
		 * matcher_signatures could have changed.  The user can modify
		 * its value by setting -Smatcher.signatures anyway.  */
		f->record_size = sizeof(uns) + matcher_signatures * sizeof(u32);
	}
	if (f->record_size > 0)
	{
		byte *buf = alloca(f->record_size);
		bsetpos(b, f->record_size * start);
		while (start <= stop)
		{
			if (!breadb(b, buf, f->record_size))
				break;
			f->dump_single(start, buf);
			start++;
		}
	}
	else
	{
		if (f->record_size < 0)
		{
			start *= -f->record_size;
			if (stop != ~0ULL)
				stop = (stop * -f->record_size) + 1;
		}
		if (stop == ~0ULL)
		{
			bseek(b, 0, SEEK_END);
			stop = btell(b);
		}
		bsetpos(b, start);
		while ((u64) (start = btell(b)) < stop)
			f->dump_single(start, b);
	}
}

int
main(int argc, char **argv)
{
	byte *force_filename = NULL;
	struct index_file *f = NULL;
	int opt, i;
	struct fastbuf *b;

	log_init(argv[0]);
	while ((opt = cf_getopt(argc, argv, shortopts, longopts, NULL)) >= 0)
		switch (opt)
		{
			case 'f':
				force_filename = optarg;
				break;
			case 'v':
				verbose++;
				break;
			case 'b':
				bare++;
				break;
			default:
				for (i=0; ; i++)
					if (opt == index_files[i].option)
					{
						if (f)
							usage("More index files specified");
						f = &index_files[i];
						break;
					}
					else if (!index_files[i].option)
						usage("Invalid option");
		}
	if (!f)
		usage("No index file specified");
	if (!force_filename)
		force_filename = *f->default_filename;
	term_charset_id = find_charset_by_name(terminal_charset);
	if (term_charset_id < 0)
		die("Unknown terminal charset %s", terminal_charset);
	conv_init(&conv_utf8);
	conv_set_charset(&conv_utf8, CONV_CHARSET_UTF8, term_charset_id);
	b = bopen(force_filename, O_RDONLY, 1<<20);
	dump_index_file(f, b, argc - optind, argv + optind);
	bclose(b);
	return 0;
}
