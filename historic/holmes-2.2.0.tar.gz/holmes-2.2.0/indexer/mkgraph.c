/*
 *	Sherlock Indexer -- Graph Builder
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"

#include <fcntl.h>
#include <stdlib.h>

int
main(int argc, char **argv)
{
  struct fastbuf *links, *graph;
  struct fingerprint fp;
  uns src, dest, last_src, deg, x, type;
  uns *neighbors;
  uns total_v, total_e;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  links = bopen(fn_links, O_RDONLY, indexer_fb_size);
  graph = bopen(fn_link_graph, O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  fp_recog_init();
  neighbors = xmalloc(sizeof(uns) * max_degree);
  last_src = ~0;
  deg = 0;
  total_v = total_e = 0;
  log(L_INFO, "Generating link graph");

  while (bread(links, &fp, sizeof(fp)))
    {
      x = bgetl(links);
      src = x & ~ETYPE_MASK;
      type = x & ETYPE_MASK;
      dest = fp_recog(&fp);
      if (dest != ~0U && dest != src)
	{
	  if (last_src != src)
	    {
	      if (deg)
		{
		  bputl(graph, last_src);
		  bputw(graph, deg);
		  bwrite(graph, neighbors, sizeof(uns) * deg);
		}
	      last_src = src;
	      deg = 0;
	      total_v++;
	    }
	  if (deg < max_degree)
	    {
	      neighbors[deg++] = dest | type;
	      total_e++;
	    }
	}
    }
  if (deg)
    {
      bputl(graph, last_src);
      bputw(graph, deg);
      bwrite(graph, neighbors, sizeof(uns) * deg);
    }

  fp_recog_end();
  bclose(graph);
  bclose(links);
  log(L_INFO, "Built link graph with %d vertices and %d edges", total_v, total_e);
  return 0;
}
