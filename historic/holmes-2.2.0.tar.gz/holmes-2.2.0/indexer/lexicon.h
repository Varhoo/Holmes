/*
 *	Sherlock Indexer -- Lexicon Functions
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 */

#ifndef _INDEXER_LEXICON_H
#define _INDEXER_LEXICON_H

#include "lib/lists.h"

/* Word classes */

enum word_class {
  WC_UNUSED,				/* Unused type */
  WC_IGNORED,				/* Silently ignored */
  WC_NORMAL,				/* Just an ordinary word */
  WC_GARBAGE,				/* Takes place (word number), but isn't indexed */
  WC_PREPOSITION,			/* Forms pairs with WC_NORMAL behind */
  WC_POSTPOSITION,			/* Forms pairs with WC_NORMAL before */
  WC_BREAK,				/* Explicit sentence break */
  WC_COMPOUND,				/* Word complex */
  /* lexhash.h assumes that word_class fits in 3 bits */
};

/* Configuration */

extern uns lex_min_len_ign, lex_min_len, lex_max_len, lex_max_hex_len, lex_max_ctrl_len, lex_cats;
extern uns lex_max_preps, lex_max_postps, lex_max_gap;

struct exception {
  node n;
  enum word_class class;
  byte *w;
};

extern struct list lex_exceptions;

#endif /* _INDEXER_LEXICON_H */
