/*
 *	Sherlock Indexer -- Filtering Glue
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/url.h"
#include "lib/pools.h"
#include "indexer/indexer.h"
#include "filter/filter.h"

struct ifargs {
  int site_id, weight;
  byte *url;
  struct url url_s;
};

static struct filter_args *indexer_filter_args;
static struct mempool *indexer_filter_pool;

struct filter_binding indexer_bindings[] = {
  /*** BEWARE! ifilter_init() indexes this array! ***/
  /* URL and its parts */
  { "url",		OFFSETOF(struct ifargs, url) },
  { "protocol",		OFFSETOF(struct ifargs, url_s.protocol) },
  { "host",		OFFSETOF(struct ifargs, url_s.host) },
  { "port",		OFFSETOF(struct ifargs, url_s.port) },
  { "path",		OFFSETOF(struct ifargs, url_s.rest) },
  /* Attributes */
  { "weight",		OFFSETOF(struct ifargs, weight) },
  { "siteid",		OFFSETOF(struct ifargs, site_id) },
  { NULL,		0 }
};

void
ifilter_init(int mode)
{
  struct filter *f;

  if (!indexer_filter_name)
    return;
  if (mode)
    {
      indexer_bindings[5].name = "final_weight"; /* rename "weight" */
      indexer_bindings[6].name = NULL;		 /* remove "siteid" */
    }
  f = filter_load(indexer_filter_name, filter_builtin_vars, indexer_bindings, NULL);
  indexer_filter_args = filter_intr_new(f);
  filter_intr_undo_init(indexer_filter_args);
  indexer_filter_pool = mp_new(4096);
}

int
ifilter_filter(struct odes *obj, struct card_attr *attr)
{
  struct filter_args *a = indexer_filter_args;
  struct ifargs q;
  int res;
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];

  if (!a)
    return 1;

  filter_intr_undo(a);
  a->attr = obj;
  q.weight = attr->weight;
  q.url = obj_find_aval(obj, 'U');
  ASSERT(q.url);
  if (url_canon_split(q.url, buf1, buf2, &q.url_s))
    die("ifilter_filter: error parsing URL");
  a->raw = &q;
  a->pool = indexer_filter_pool;
  mp_flush(a->pool);
  res = filter_intr_run(a);
  if (res)
    {
      attr->weight = CLAMP(q.weight, 0, 255);
    }
  return res;
}
