/*
 *	Sherlock Search Engine -- Word Index
 *
 *	(c) 1997-2002 Martin Mares <mj@ucw.cz>
 */

#undef LOCAL_DEBUG

#include "lib/lib.h"
#include "lib/lfs.h"
#include "lib/fastbuf.h"
#include "lib/unaligned.h"
#include "lib/pools.h"
#include "lib/wildmatch.h"
#include "lib/hashfunc.h"
#include "search/sherlockd.h"
#include "indexer/lexicon.h"
#include "charset/unicode.h"

#include <fcntl.h>
#include <unistd.h>
#include <string.h>

/*** The lexicon: all known words and complexes, order is described in doc/file-formats ***/

struct lexicon_entry {			/* Beware, these structures are unaligned! */
  byte ref_pos[BYTES_PER_O];
  byte class;
  byte length;
  byte word[0];
} PACKED;

static uns
word_unaccent_utf8(byte *w, byte *to)
{
  uns u;
  byte *stop = to + MAX_WORD_LEN - 4;
  byte *buf = to;

  while (*w)
    {
      GET_UTF8(w, u);
      u = Uunaccent(u);
      PUT_UTF8(buf, u);
      if (buf >= stop)
	return 0;
    }
  *buf = 0;
  return buf - to;
}

static uns
word_extract(struct lexicon_entry *l, byte *buf, uns noacc)
{
  uns u;
  byte *w, *we;
  byte *stop = buf + MAX_WORD_LEN - 4;
  uns cnt = 0;

  w = l->word;
  we = w + l->length;
  while (w < we)
    {
      GET_UTF8(w, u);
      if (noacc)
	u = Uunaccent(u);
      PUT_UTF8(buf, u);
      cnt++;
      if (buf >= stop)
	{
	  log(L_ERROR, "word_normalize: Buffer too small");
	  break;
	}
    }
  *buf = 0;
  return cnt;
}

int
contains_accents(byte *s)
{
  uns u;

  for(;;)
    {
      GET_UTF8(s, u);
      if (!u)
	return 0;
      if (u != Uunaccent(u))
	return 1;
    }
}

static inline struct lexicon_entry *
get_lex_word(uns i)
{
  return current_query->dbase->lexicon[i];
}

static inline uns
id_to_pos(uns id)
{
  return id/8 - 1;
}

static inline uns
pos_to_id(uns id, uns class)
{
  return ((id+1) << 3) | class;
}

static u32
cplx_get_stem(byte *cplx, uns len)
{
  uns i;
  for (i=0; i<len; i+=4)
    {
      u32 id = GET_U32(cplx+i);
      if ((id & 7) == WC_NORMAL)
	return id;
    }
  ASSERT(0);
}

/*
 *  Find first lexicon entry greater or equal to the given word
 *  in accent-less ordering (it's primary order of the lexicon).
 */

static uns
word_find_first(byte *key)
{
  int l, r, m, res;
  byte lex[MAX_WORD_LEN];
  struct lexicon_entry *e;

  l = 0;
  r = current_query->dbase->lexicon_entries - 1;
  while (l < r)
    {
      m = (l+r)/2;
      e = get_lex_word(m);
      if (e->class == WC_COMPOUND)
	e = get_lex_word(id_to_pos(cplx_get_stem(e->word, e->length)));
      word_extract(e, lex, 1);
      res = strcmp(lex, key);
      DBG("(%d,%d,%d) <%s> %c <%s>", l, r, m, lex, (res ? (res < 0) ? '<' : '>' : '='), key);
      if (res < 0)
	l = m + 1;
      else
	r = m;
    }
  return l;
}

/*** Searching for complexes (again binary search) ***/

static int
cplx_cmp(u32 *x, uns len, u32 m)
{
  struct lexicon_entry *l = get_lex_word(m);
  u32 stem1, stem2;
  uns i;

  stem1 = cplx_get_stem((byte*)x, 4*len);
  stem2 = (l->class == WC_COMPOUND) ? cplx_get_stem(l->word, l->length) : pos_to_id(m, l->class);
  if (stem1 < stem2)
    return -1;
  if (stem1 > stem2)
    return 1;

  if (l->class != WC_COMPOUND)
    return 1;

  if (4*len < l->length)
    return -1;
  if (4*len > l->length)
    return 1;

  for (i=0; i<len; i++)
    {
      u32 xx = x[i];
      u32 yy = GET_U32(&((u32*)l->word)[i]);
      if (xx < yy)
	return -1;
      if (xx > yy)
	return 1;
    }
  return 0;
}

static int
cplx_find(u32 *cplx, uns len)
{
  uns l, r, m;
  int c;

  l = 0;
  r = current_query->dbase->lexicon_entries - 1;
  while (l <= r)
    {
      m = (l+r)/2;
      c = cplx_cmp(cplx, len, m);
      if (!c)
	return m;
      if (c < 0)
	r = m-1;
      else
	l = m+1;
    }
  return -1;
}

/*
 *  The exception hash: we need very fast access to the list of exceptional
 *  words (those with class != WC_NORMAL) as we need them for lexical mapping
 *  of cards.
 */

struct word_exc {
  struct database *db;
  byte len;
  byte class;
  byte word[1];
};

#define HASH_NODE struct word_exc
#define HASH_PREFIX(p) wexc_##p
#define HASH_KEY_COMPLEX(x) x db, x word, x len
#define HASH_KEY_DECL struct database *db, byte *word, uns len
#define HASH_WANT_FIND
#define HASH_WANT_NEW
#define HASH_CONSERVE_SPACE

#define HASH_GIVE_HASHFN
static inline uns
wexc_hash(struct database *db, byte *word, uns len)
{
  return (uns)db ^ hash_block(word, len);
}

#define HASH_GIVE_EQ
static inline uns
wexc_eq(struct database *d1, byte *w1, uns l1, struct database *d2, byte *w2, uns l2)
{
  return (d1 == d2 && l1 == l2 && !memcmp(w1, w2, l1));
}

#define HASH_GIVE_EXTRA_SIZE
static inline uns
wexc_extra_size(struct database *d UNUSED, byte *w UNUSED, uns l)
{
  return l;
}

#define HASH_GIVE_INIT_KEY
static inline void
wexc_init_key(struct word_exc *e, struct database *d, byte *w, uns l)
{
  e->db = d;
  e->len = l;
  e->class = 0;
  strcpy(e->word, w);
}

#define HASH_USE_POOL word_exc_pool
static struct mempool *word_exc_pool;

#include "lib/hashtable.h"

static void
word_exc_init(void)
{
  if (!word_exc_pool)
    {
      word_exc_pool = mp_new(4096);
      wexc_init();
    }
}

static void
word_exc_add(struct database *db, byte *word, uns len, enum word_class class)
{
  byte buf[MAX_WORD_LEN+5], w[MAX_WORD_LEN+5];
  uns l;
  struct word_exc *e;

  memcpy(buf, word, len);
  buf[len] = 0;
  if (!(l = word_unaccent_utf8(buf, w)))
    return;
  if (e = wexc_find(db, w, l))
    ASSERT(e->class == class);
  else
    {
      e = wexc_new(db, w, l);
      e->class = class;
    }
}

int
word_classify(struct database *db, byte *word)
{
  byte w[MAX_WORD_LEN+5];
  uns l;
  struct word_exc *e;

  if (!(l = word_unaccent_utf8(word, w)))
    return WC_GARBAGE;
  if (e = wexc_find(db, w, l))
    return e->class;
  return -1;
}

/*
 *  We represent each phrase by a list of ph_word's (corresponding to words
 *  written in the phrase), each of them pointing to a single struct word
 *  (we cannot use struct word directly since they can occur multiple times
 *  in a single phrase).
 *
 *  When we expand a word, its variants are represented by a list of ph_variant's
 *  connected to struct word.
 */

struct ph_word {
  node n;
  struct simple *simple;		/* Simple search component this came from */
  struct word *word;
  uns pos;				/* Relative position inside phrase */
  byte *unacc;				/* Unaccented version of the word */
  byte idx;				/* Word index corresponding to ph_word->word */
  byte wild;				/* Contains wildcards */
  byte magic;				/* Has been generated by magic transformations of simples */
  byte prox_after;			/* Followed by "*" */
  byte w[0];				/* Accented version of the word */
};

struct ph_variant {
  struct ph_variant *next;
  uns lex_id;
  uns noaccent_only;
};

typedef struct ph_word *word_id_t;
static struct simple *ph_current_simple;
static list *ph_current_list;
static int ph_seen_garbage;
static struct ph_word *ph_word_for_current_star;

static void
word_dump_phrase(list *phrase, char *comment)
{
  struct ph_word *p;
  struct ph_variant *v;
  byte buf[MAX_WORD_LEN*MAX_COMPLEX_LEN];

  if (!(current_query->debug & DEBUG_WORDS))
    return;

  add_cr(".X %s phrase:", comment);
  WALK_LIST(p, *phrase)
    {
      struct word *w = p->word;
      add_cr(".X\tpos=%d idx=%d class=%d wid=%d stat=%d wild=%d magic=%d prox=%d '%s' '%s'", p->pos, p->idx, w->word_class, w->width, w->status, p->wild, p->magic, p->prox_after, p->w, p->unacc ? : (byte*)"");
      for (v=w->variants; v; v=v->next)
	{
	  struct lexicon_entry *l = get_lex_word(v->lex_id);
	  if (w->word_class == WC_COMPOUND)
	    {
	      byte *t = buf;
	      uns i;
	      for (i=0; i<l->length; i+=4)
		{
		  struct lexicon_entry *m = get_lex_word(id_to_pos(GET_U32(l->word+i)));
		  ASSERT(m->class != WC_COMPOUND);
		  if (i)
		    *t++ = ' ';
		  word_extract(m, t, 0);
		  while (*t)
		    t++;
		}
	      add_cr(".X\t\t<%s>", buf);
	    }
	  else
	    {
	      word_extract(l, buf, 0);
	      add_cr(".X\t\t%s(%d)", buf, l->class);
	    }
	}
    }
}

/*** Lexical mapping of phrases ***/

static enum word_class
lm_lookup(enum word_class orig_class, word *uni, uns ulen, word_id_t *thisw)
{
  struct ph_word *p;
  byte wbuf[3*MAX_WORD_LEN+1], *wp=wbuf;
  byte ubuf[3*MAX_WORD_LEN+1], *up=ubuf;
  uns u, wl, ul, i;
  struct word *w;

  if (!uni)
    {
      ph_word_for_current_star = NULL;
      return orig_class;
    }
  for (i=0; i<ulen; i++)
    {
      u = uni[i];
      u = Utolower(u);
      PUT_UTF8(wp, u);
      u = Uunaccent(u);
      PUT_UTF8(up, u);
    }
  *wp = *up = 0;
  wl = wp - wbuf + 1;
  ul = up - ubuf + 1;
  p = mp_alloc_zero(current_query->pool, sizeof(struct ph_word) + wl + ul);
  memcpy(p->w, wbuf, wl);
  p->unacc = p->w + wl;
  memcpy(p->unacc, ubuf, ul);
  p->idx = lookup_word(current_query, ph_current_simple->raw, p->w);
  p->word = w = &current_query->words[p->idx];
  p->simple = ph_current_simple;
  if (orig_class != WC_NORMAL)
    w->word_class = orig_class;
  else if (ulen == 1 && uni[0] == '*')
    {
      w->word_class = WC_IGNORED;
      w->use_count--;
      if (ph_word_for_current_star)
	ph_word_for_current_star->prox_after = 1;
    }
  else
    {
      int c = word_classify(current_query->dbase, p->w);
      if (c < 0)
	{
	  if (ulen < lex_min_len_ign)
	    c = WC_IGNORED;
	  else if (ulen < lex_min_len)
	    c = WC_GARBAGE;
	  else
	    c = WC_NORMAL;
	}
      w->word_class = c;
      if (strchr(p->w, '*') || strchr(p->w, '?'))
	p->wild = 1;
      ph_word_for_current_star = p;
    }
  if (w->word_class == WC_GARBAGE)
    ph_seen_garbage++;
  if (w->word_class == WC_NORMAL)
    w->cover_count++;
  else
    w->status = 116;
  p->pos = ~0U;
  add_hilited_word(current_query, p->w); /* record it even if it isn't indexed */
  *thisw = p;
  return w->word_class;
}

static void
lm_got_word(uns pos, uns cat UNUSED, word_id_t p)
{
  if (p->pos != ~0U)
    rem_node(&p->n);
  add_tail(ph_current_list, &p->n);
  p->pos = pos;
}

static void
lm_got_compound(uns pos, uns cat UNUSED, word_id_t *ps, uns l)
{
  uns i;
  for (i=0; i<l; i++)
    {
      if (ps[i]->pos != ~0U)
	rem_node(&ps[i]->n);
      ps[i]->pos = pos+i;
      add_tail(ph_current_list, &ps[i]->n);
    }
}

#define LM_SEARCH
#include "indexer/lexmap.h"

/*** Expansion of words to variants ***/

static int
word_add_variant(struct word *w, uns lex_id, uns noaccent_only)
{
  struct ph_variant *v;

  if (w->var_count++ >= max_word_matches)
    {
      w->status = 105;
      return 0;
    }
  v = mp_alloc(current_query->pool, sizeof(struct ph_variant));
  v->next = w->variants;
  w->variants = v;
  v->lex_id = lex_id;
  v->noaccent_only = noaccent_only;
  return 1;
}

static void
word_expand(struct ph_word *p)
{
  struct word *w = p->word;
  byte lex[MAX_WORD_LEN], lexu[MAX_WORD_LEN];
  uns idx, nonacc_only;
  struct lexicon_entry *l;

  for (idx = word_find_first(p->unacc); idx < current_query->dbase->lexicon_entries; idx++)
    {
      l = get_lex_word(idx);
      if (l->class == WC_COMPOUND)
	continue;
      word_extract(l, lex, 0);
      word_extract(l, lexu, 1);
      if (strcmp(lexu, p->unacc))
	break;
      nonacc_only = 0;
      switch (w->accent_mode)
	{
	case ACCENT_STRIP:
	  break;
	case ACCENT_STRICT:
	  if (strcmp(lex, p->w))
	    {
	      DBG("= %d <%s> <%s> !strict", idx, lex, lexu);
	      continue;
	    }
	  break;
	default:			/* ACCENT_AUTO */
	  if (current_query->contains_accents && strcmp(lex, p->w))
	    {
	      if (strcmp(lex, lexu))
		{
		  DBG("= %d <%s> <%s> !misaccented", idx, lex, lexu);
		  continue;
		}
	      nonacc_only = 1;
	    }
	}
      DBG("= %d <%s> <%s> %d %s", idx, lex, lexu, l->class, nonacc_only ? "[nonacc]" : "");
      ASSERT(l->class == w->word_class);
      if (!word_add_variant(w, idx, nonacc_only))
	return;
    }
}

static void
word_expand_wild(struct ph_word *p)
{
  struct word *w = p->word;
  int first, last, idx;
  uns accented, old, nonacc_only;
  static struct mempool *wild_pool;
  struct wildpatt *patt, *pattu;
  struct lexicon_entry *l;
  byte *px;
  uns ignore_count = 0;

  /* Find non-wildcard prefix */
  px = p->unacc;
  while (*px != '*' && *px != '?')
    px++;
  if (px - p->unacc < (int) min_wildcard_prefix_len)
    {
      w->status = 114;
      return;
    }

  /* Compile both accented and unaccented pattern */
  accented = strcmp(p->w, p->unacc);
  if (!wild_pool)
    wild_pool = mp_new(16384);
  else
    mp_flush(wild_pool);
  patt = wp_compile(p->w, wild_pool);
  if (accented)
    pattu = wp_compile(p->unacc, wild_pool);
  else
    pattu = patt;
  if (!patt || !pattu)
    {
      w->status = 111;
      return;
    }

  /* Find the lexicon zone */
  if (px == p->unacc)
    {
      first = 0;
      last = current_query->dbase->lexicon_entries;
    }
  else
    {
      old = *px;
      *px = 0;
      first = word_find_first(p->unacc);
      (*(px-1))++;			/* We know 0xff is not a valid character code */
      last = word_find_first(p->unacc);
      (*(px-1))--;			/* We know 0xff is not a valid character code */
      *px = old;
    }
  DBG("Zone: [%d,%d)", first, last);
  if (last - first > (int) max_wildcard_zone)
    {
      w->status = 113;
      return;
    }

  /* Scan the zone */
  for (idx=first; idx < last; idx++)
    {
      byte lex[MAX_WORD_LEN], lexu[MAX_WORD_LEN];

      l = get_lex_word(idx);
      if (l->class == WC_COMPOUND)
	continue;
      nonacc_only = 0;
      word_extract(l, lex, 0);
      switch (w->accent_mode)
	{
	case ACCENT_STRIP:
	  word_extract(l, lexu, 1);
	  if (!wp_match(pattu, lexu))
	    {
	      DBG("* %d <%s> !strip", idx, lexu);
	      continue;
	    }
	  break;
	case ACCENT_STRICT:
	  if (!wp_match(patt, lex))
	    {
	      DBG("* %d <%s> !strict", idx, lex);
	      continue;
	    }
	  break;
	default:			/* ACCENT_AUTO */
	  if (!wp_match(patt, lex))
	    {
	      word_extract(l, lexu, 1);
	      if (!wp_match(pattu, lexu))
		{
		  DBG("* %d <%s> !auto", idx, lex);
		  continue;
		}
	      if (current_query->contains_accents)
		{
		  if (strcmp(lex, lexu))
		    {
		      DBG("* %d <%s> <%s> !misaccented", idx, lex, lexu);
		      continue;
		    }
		  nonacc_only = 1;
		}
	    }
	}
#ifdef LOCAL_DEBUG
      word_extract(l, lexu, 1);
      DBG("* %d <%s> <%s> %d %s", idx, lex, lexu, l->class, nonacc_only ? "[nonacc]" : "");
#endif
      if (l->class == WC_NORMAL)
	{
	  if (!word_add_variant(w, idx, nonacc_only))
	    return;
	}
      else
	ignore_count++;
    }
  if (ignore_count && !w->variants)
    w->status = 116;
}

static void
word_expand_all(list *phrase)
{
  struct ph_word *p;

  WALK_LIST(p, *phrase)
    {
      struct word *w = p->word;
      if (!w->expanded)
	{
	  w->expanded = 1;
	  w->width = 1;
	  (p->wild ? word_expand_wild : word_expand)(p);
	}
    }
}

/*** Processing of complexes ***/

static void
find_complex_var(struct word *w, struct word **words, struct ph_variant **vars, uns i, uns len)
{
  if (i < len)
    {
      while (vars[i] && w->var_count < max_word_matches)
	{
	  find_complex_var(w, words, vars, i+1, len);
	  vars[i] = vars[i]->next;
	}
    }
  else
    {
      u32 ids[MAX_COMPLEX_LEN];
      uns j;
      uns noacc = 0;
      int id;
      for (j=0; j<len; j++)
	{
	  ids[j] = pos_to_id(vars[j]->lex_id, words[j]->word_class);
	  noacc |= vars[j]->noaccent_only;
	}
      id = cplx_find(ids, len);
      if (id >= 0)
	word_add_variant(w, id, noacc);
    }
}

static struct ph_word *
find_complex(struct ph_word **cplx, uns len)
{
  struct ph_word *p;
  struct word *w;
  uns i, tl;
  byte *z, *y;
  struct word *words[MAX_COMPLEX_LEN];
  struct ph_variant *vars[MAX_COMPLEX_LEN];

  tl = len;
  for (i=0; i<len; i++)
    tl += strlen(cplx[i]->w);
  p = mp_alloc_zero(current_query->pool, sizeof(struct ph_word) + tl);
  z = p->w;
  for (i=0; i<len; i++)
    {
      if (i)
	*z++ = ' ';
      for (y=cplx[i]->w; *y; y++)
	*z++ = *y;
      words[i] = cplx[i]->word;
      vars[i] = words[i]->variants;
      words[i]->cover_count++;
    }
  *z = 0;
  p->pos = cplx[0]->pos;
  p->simple = cplx[0]->simple;
  p->unacc = NULL;
  p->prox_after = cplx[len-1]->prox_after;
  DBG("Searching for complex <%s>", p->w);
  p->idx = lookup_word(current_query, p->simple->raw, p->w);
  p->word = w = &current_query->words[p->idx];
  if (!w->expanded)
    {
      w->expanded = 1;
      w->word_class = WC_COMPOUND;
      w->width = len;
      find_complex_var(w, words, vars, 0, len);
    }
  return p;
}

static void
word_condense_magic(struct ph_word **cplx, uns len, uns is_prep)
{
  uns i, j;
  int last_sense;
  struct ph_word *p;
  uns is_magic = 1;

  /* All components from the same simple => ignored (actually, inserted as non-magic) */
  j = 0;
  for (i=1; i<len; i++)
    if (cplx[i]->simple != cplx[i-1]->simple)
      j++;
  if (!j)
    is_magic = 0;

  /* Do we really want magic complexes? */
  if (!magic_complexes && is_magic)
    return;

  /* Combine matching senses. Rules:
   * (1) Words have incompatible senses (+ vs. -) => throw away.
   * (2) Use sense of the first prep / last postp [by setting p->simple below]
   */
  last_sense = 0;
  for (i=0; i<len; i++)
    {
      int sense = cplx[i]->simple->raw->u.match.sense;
      if (last_sense < 0 && sense > 0 ||
	  last_sense > 0 && sense < 0)
	return;
      if (!last_sense)
	last_sense = sense;
    }

  /* If any of the words hasn't been covered yet, decrease it's use_count,
   * so that it won't be reported as non-indexed.
   */
  for (i=0; i<len; i++)
    if (!cplx[i]->word->cover_count)
      cplx[i]->word->use_count--;

  /* Look it up as a phrase and set the magic flag. Such a fragment can
   * arise multiple times in a single simple query, but we don't take
   * care of them, they will be merged properly by the boolean optimizer.
   */
  p = find_complex(cplx, len);
  p->magic = is_magic;
  p->simple = cplx[is_prep ? 0 : len-1]->simple;
  insert_node(&p->n, is_prep ? cplx[len-1]->n.prev : &cplx[0]->n);
}

static uns
word_condense_complex(struct ph_word **cplx, uns len, uns is_prep, uns do_magic)
{
  if (do_magic)
    {
      /* "Magic mode": Try all sub-phrases whose components came from different simples */
      uns i;
      if (is_prep)
	for(i=len; i>=2; i--)
	  word_condense_magic(cplx+len-i, i, is_prep);
      else
	for(i=2; i<=len; i++)
	  word_condense_magic(cplx, i, is_prep);
      return 0;
    }
  else
    {
      struct ph_word *p  = find_complex(cplx, len);
      insert_node(&p->n, is_prep ? cplx[len-1]->n.prev : &cplx[0]->n);
      return 1;
    }
}

static void
word_find_complexes(list *phrase, uns do_magic)
{
  struct ph_word *p, *q, *r;
  struct ph_word *cplx[MAX_COMPLEX_LEN];
  uns clen, discard;

  WALK_LIST_DELSAFE(p, r, *phrase)
    if (p->word->word_class == WC_NORMAL)
      {
	discard = 0;
	clen = 1;
	while ((q=(void *)p->n.prev)->n.prev &&
	       q->word->word_class == WC_PREPOSITION &&
	       q->pos == p->pos - clen)
	  {
	    cplx[MAX_COMPLEX_LEN - ++clen] = q;
	    rem_node(&q->n);
	    q->word->use_count--;
	  }
	if (clen != 1)
	  {
	    cplx[MAX_COMPLEX_LEN-1] = p;
	    discard |= word_condense_complex(cplx + MAX_COMPLEX_LEN-clen, clen, 1, do_magic);
	  }
	cplx[0] = p;
	clen = 1;
	while ((q=(void *)p->n.next)->n.next &&
	       q->word->word_class == WC_POSTPOSITION &&
	       q->pos == p->pos + clen)
	  {
	    cplx[clen++] = q;
	    rem_node(&q->n);
	    q->word->use_count--;
	  }
	if (clen != 1)
	  discard |= word_condense_complex(cplx, clen, 0, do_magic);
	if (discard)
	  {
	    rem_node(&p->n);
	    p->word->use_count--;
	  }
      }
  WALK_LIST(p, *phrase)
    ASSERT(p->word->word_class == WC_NORMAL || p->word->word_class == WC_COMPOUND);
}

/*** Transformation of query expressions for phrases ***/

static void
word_xform_expr(struct query *q, struct simple *s)
{
  struct expr *e = s->raw;
  struct expr *f;

  if (!s->phrase.head->next)		/* The phrase is empty */
    e = new_node(ph_seen_garbage ? EX_NONE : EX_IGNORE);
  else if (!s->phrase.head->next->next)	/* Just a single word */
    {
      struct ph_word *p = HEAD(s->phrase);
      struct word *w = p->word;
      w->is_outer = 1;
      w->weight = MAX(w->weight, e->u.match.o.weight);
      e = new_node(EX_REF_WORD);
      e->u.ref.index = p->idx;
    }
  else
    {
      struct ph_word *p;
      struct phrase *phrase = &q->phrases[q->nphrases++];
      uns firstpos = 0;
      uns lastpos = ~0U;
      uns is_prox = 0;
      if (q->nphrases >= max_phrases)
	{
	  add_cerr("-103 Too many phrases");
	  eval_err(103);
	}
      bzero(phrase, sizeof(*phrase));
      phrase->type_mask = e->u.match.classmap;
      phrase->weight = e->u.match.o.weight;
      e = new_node(EX_REF_PHRASE);
      e->u.ref.index = q->nphrases-1;
      WALK_LIST(p, s->phrase)
	{
	  struct word *w = p->word;
	  if (phrase->length >= MAX_PHRASE_LEN)
	    {
	      add_cerr("-110 Phrase too complex");
	      eval_err(110);
	    }
	  phrase->word[phrase->length] = p->idx;
	  if (!phrase->length)
	    firstpos = lastpos = p->pos;
	  phrase->relpos[phrase->length] = p->pos - lastpos;
	  phrase->width[phrase->length] = w->width;
	  if (is_prox)
	    phrase->prox_map |= 1 << phrase->length;
	  lastpos = p->pos;
	  phrase->length++;
	  f = new_node(EX_REF_WORD);
	  f->u.ref.index = p->idx;
	  e = new_op(EX_AND, e, f);
	  is_prox = p->prox_after;
	}
    }
  s->cooked = e;
}

/*** Association of reference chains to words ***/

static void
word_find_refs(list *phrase)
{
  struct ph_word *p;

  WALK_LIST(p, *phrase)
    {
      struct word *w = p->word;
      struct ph_variant *v;
      if (w->expanded >= 2)
	continue;
      w->expanded = 2;
      for (v=w->variants; v; v=v->next)
	{
	  struct lexicon_entry *l = get_lex_word(v->lex_id);
	  struct lexicon_entry *m = get_lex_word(v->lex_id+1);
	  struct ref_chain *ref;
	  w->ref_count++;
	  ref = current_query->last_ref++;
	  ref->u.file.start = GET_O(l->ref_pos);
	  ref->u.file.stop = GET_O(m->ref_pos);
	  ref->index = p->idx;
	  ref->noaccent_only = v->noaccent_only;
	  w->ref_total_len += ref->u.file.stop - ref->u.file.start;
	}
    }
}

/*** Analysis of a single word/phrase match ***/

static void
word_analyse(struct query *q, struct simple *s)
{
  ph_current_simple = s;
  ph_current_list = &s->phrase;
  ph_seen_garbage = 0;
  ph_word_for_current_star = NULL;

  init_list(&s->phrase);
  lm_doc_start();
  if (!lm_map_text(s->raw->u.match.word))
    {
      add_cerr("-115 Word too long");
      eval_err(115);
    }
  word_dump_phrase(&s->phrase, "Initial");
  word_expand_all(&s->phrase);
  word_dump_phrase(&s->phrase, "Expanded");
  word_find_complexes(&s->phrase, 0);
  word_dump_phrase(&s->phrase, "Complexified");
  word_xform_expr(q, s);
  word_find_refs(&s->phrase);
}

/*** Magic transformations of simple queries ***/

static void
word_add_magic_complexes(list *magic, list *simp)
{
  struct ph_word *p;

  WALK_LIST(p, *magic)
    if (p->magic)
      {
	struct simple *s = mp_alloc_zero(current_query->pool, sizeof(struct simple));
	struct word *w = p->word;
	add_tail(simp, &s->n);
	s->raw = p->simple->raw;
	s->cooked = new_node(EX_REF_WORD);
	s->cooked->u.ref.index = p->idx;
	w->is_outer = 1;
	w->weight = MAX(w->weight, s->raw->u.match.o.weight);
	w->use_count++;
      }
}

static void
word_add_magic_near(list *magic)
{
  struct query *q = current_query;
  struct ph_word *pw, *pwlast;
  struct phrase *p;
  uns cnt = 0;
  uns lastpos = 0;

  if (q->nphrases >= max_phrases)
    return;
  pwlast = NULL;
  WALK_LIST(pw, *magic)
    if (pw->simple->raw->u.match.sense >= 0)
      {
	if ((!pwlast || pwlast->simple != pw->simple) && !pw->magic)
	  cnt++;
	pwlast = pw;
      }
  if (cnt < 2)
    return;

  DBG("Adding near match for %d words", cnt);
  p = &q->phrases[q->nphrases++];
  bzero(p, sizeof(*p));
  p->is_near = 1;
  WALK_LIST(pw, *magic)
    if (pw->simple->raw->u.match.sense >= 0 && p->length < MAX_PHRASE_LEN)
    {
      uns i = p->length++;
      p->word[i] = pw->idx;
      p->relpos[i] = pw->pos - lastpos;
      lastpos = pw->pos;
      p->width[i] = pw->word->width;
      pw->word->use_count++;
    }
}

static void
word_add_magic_merges(list *magic, list *simp)
{
  struct ph_word *p;
  struct simple *s;
  struct expr *e;
  byte w[MAX_WORD_LEN+1];
  uns len = 0;
  int maxwt = 0;
  uns cnt = 0;

  /* Require all words positive, without wildcards and no strict accents and merge non-accented variants */
  WALK_LIST(p, *magic)
    {
      struct expr *e = p->simple->raw;
      uns l1 = strlen(p->unacc);
      if (e->u.match.sense < 0 ||
	  p->wild ||
	  strcmp(p->w, p->unacc) && e->u.match.o.accent_mode == ACCENT_STRICT)
	return;
      if (len + l1 >= MAX_WORD_LEN)
	return;
      memcpy(w+len, p->unacc, l1);
      len += l1;
      maxwt = MAX(maxwt, e->u.match.o.weight);
      cnt++;
    }
  if (cnt < 2)
    return;
  w[len] = 0;

  if (current_query->debug & DEBUG_WORDS)
    add_cr(".U <%s>", w);

  e = new_node(EX_MATCH);
  e->u.match.o.weight = maxwt;
  e->u.match.o.accent_mode = ACCENT_STRICT;
  e->u.match.word = mp_alloc(current_query->pool, len+1);
  memcpy(e->u.match.word, w, len+1);
  e->u.match.classmap = magic_merge_classes;

  s = mp_alloc_zero(current_query->pool, sizeof(*s));
  s->raw = e;
  add_tail(simp, &s->n);
  word_analyse(current_query, s);
}

static void
word_apply_magic(list *simp)
{
  struct simple *s;
  list phrase;
  struct ph_word *p;

  init_list(&phrase);
  ph_current_list = &phrase;
  ph_seen_garbage = 0;
  lm_doc_start();
  WALK_LIST(s, *simp)
    if (!s->raw->u.match.is_string)
      {
	ph_current_simple = s;
	ph_word_for_current_star = NULL;
	lm_map_text(s->raw->u.match.word);
      }
  word_dump_phrase(&phrase, "Initial magic");
  if (magic_merge_words)
    word_add_magic_merges(&phrase, simp);
  if (magic_complexes || magic_near)
    {
      word_expand_all(&phrase);
      word_dump_phrase(&phrase, "Expanded");
      word_find_complexes(&phrase, 1);
      word_dump_phrase(&phrase, "Complexified");
      word_find_refs(&phrase);
      if (magic_complexes)
	word_add_magic_complexes(&phrase, simp);
      if (magic_near)
	word_add_magic_near(&phrase);
    }
  WALK_LIST(p, phrase)
    p->word->use_count--;
}

/*** Main entry point: analysis of simple queries ***/

void
word_analyse_simple(struct query *q, list *l)
{
  struct simple *s;
  uns i, cnt = 0;

  if (!q->dbase->lexicon)
    {
      WALK_LIST(s, *l)
	if (!s->raw->u.match.is_string)
	  s->cooked = new_node(EX_NONE);
      return;
    }

  /* Reset per-word flag for the words already known */
  for (i=0; i<q->nwords; i++)
    q->words[i].cover_count = 0;

  /* Analyse individual words/phrases */
  WALK_LIST(s, *l)
    if (!s->raw->u.match.is_string)
      {
	word_analyse(q, s);
	cnt++;
      }

  /* Scan the whole simple query as a phrase and perform all the magic tricks */
  if (cnt >= 2 && (magic_complexes || magic_near || magic_merge_words))
      word_apply_magic(l);
}

/*** Highlighting of all known word variants ***/

void
words_add_hilites(struct query *q, struct word *w)
{
  struct ph_variant *v;

  if (w->is_string || w->word_class == WC_COMPOUND)
    return;
  for (v=w->variants; v; v=v->next)
    {
      byte buf[MAX_WORD_LEN];
      word_extract(get_lex_word(v->lex_id), buf, 0);
      add_hilited_word(q, buf);
    }
}

/*** Initialization and loading of the lexicon ***/

void
words_init(struct database *db)
{
  uns i, ecount=0;
  byte *lex;
  static uns lm_inited;

  if (!db->fn_lexicon)
    return;
  word_exc_init();
  if (!lm_inited++)
    lm_init();
  lex = mmap_file(db->fn_lexicon, &db->lexicon_file_size, 0);
  if (db->lexicon_file_size < 8)
    die("Corrupted lexicon %s", db->fn_lexicon);
  db->lexicon_entries = *(u32*)lex;
  db->lexicon = xmalloc(sizeof(struct lexicon_entry) * (db->lexicon_entries+1));
  lex += 4;
  for (i=0; i<=db->lexicon_entries; i++)
    {
      struct lexicon_entry *l = (struct lexicon_entry *) lex;
      byte buf[MAX_WORD_LEN];
      db->lexicon[i] = l;
      switch (l->class)
	{
	case WC_UNUSED:
	  break;
	case WC_NORMAL:
	  db->lexicon_words++;
	  if (word_extract(l, buf, 0) < lex_min_len)
	    {
	      word_exc_add(db, l->word, l->length, l->class);
	      ecount++;
	    }
	  break;
	case WC_COMPOUND:
	  db->lexicon_complexes++;
	  break;
	default:
	  db->lexicon_words++;
	  word_exc_add(db, l->word, l->length, l->class);
	  ecount++;
	}
      lex += BYTES_PER_O + 2 + db->lexicon[i]->length;
    }
  log(L_INFO, "Loaded word index %s: %d words, %d complexes, %d exceptions",
      db->name, db->lexicon_words, db->lexicon_complexes, ecount);
  ASSERT(db->lexicon_words + db->lexicon_complexes == db->lexicon_entries);
}
