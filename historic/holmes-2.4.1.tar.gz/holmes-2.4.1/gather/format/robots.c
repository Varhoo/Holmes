/*
 *	Sherlock Gatherer: Parser for robots.txt Files
 *
 *	(c) 2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "gather/gather.h"
#include "charset/unicode.h"
#include "charset/unistream.h"

#include <string.h>

static int robots_trace;
static int robots_work_arounds;
static byte *my_robot_name = "???";

static struct cfitem robots_config[] = {
  { "Robots",		CT_SECTION,	NULL },
  { "Trace",		CT_INT,		&robots_trace },
  { "WorkArounds",	CT_INT,		&robots_work_arounds },
  { "RobotName",	CT_STRING,	&my_robot_name },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR robots_init(void)
{
  cf_register(robots_config);
}

#define TRACE(x,y...) do { if (robots_trace) log(L_DEBUG, x,##y); } while (0)
#define XTRACE(x,y...) do { if (robots_trace > 1) log(L_DEBUG, x,##y); } while (0)

int
robots_parse(void)
{
  byte buf[1024], *i, *j, *k;
  struct fastbuf *in;
  int c;
  uns cnt;
  int inside = 0;
  int itsme = 0;

  convert_charset(NULL);
  in = gthis->temp = fbmem_clone_read(gthis->contents);

  for(;;)
    {
      cnt = 0;
      while ((c = bget_utf8(in)) >= 0 && c != '\r' && c != '\n')
	if (cnt < sizeof(buf) - 1)
	  buf[cnt++] = (c < 256 ? c : 255);
      if (c < 0 && !cnt)
	break;
      while (c == '\r')
	c = bgetc(in);
      if (c >= 0 && c != '\n')
	bungetc(in);
      if (cnt == sizeof(buf) - 1)
	gerror(2201, "Robots: Line too long");
      buf[cnt] = 0;
      XTRACE("Robots: %s", buf);
      i = buf;
      while (Cspace(*i))
	i++;
      if (*i == '#')
	continue;
      if (!*i)				/* Record separator */
	{
	  inside = 0;
	  if (itsme && !robots_work_arounds)
	    {
	      /* Extra blank lines are a common error */
	      XTRACE("Resetting context");
	      itsme = 0;
	    }
	  continue;
	}
      for(j=i; *j && !Cspace(*j) && *j !=':'; j++)	/* Find the argument */
	;
      if (*j)
	{
	  if (*j == ':')
	    *j++ = 0;
	  while (Cspace(*j))
	    *j++ = 0;
	}
      for(k=j; *k && !Cspace(*k); k++)	/* Chop off trailing blanks */
	;
      *k = 0;
      if (!strcasecmp(i, "User-Agent"))
	{
	  if (!inside && itsme)
	    itsme = 0;
	  inside = 1;
	  if (!strncasecmp(my_robot_name, j, strlen(my_robot_name)) || !strcmp(j, "*"))
	    {
	      XTRACE("Matched name");
	      itsme = 1;
	    }
	  else
	    XTRACE("Mismatched name");
	  continue;
	}
      if (!inside && !robots_work_arounds)
	log(L_ERROR_R, "Robots: %s before first User-Agent", i);
      inside = 1;
      if (!strcasecmp(i, "Disallow") || (robots_work_arounds && !strcasecmp(i, "Disalow")))
	{
	  if (itsme)
	    {
	      if (!*j)			/* Allow all */
		{
		  TRACE("Allowing all");
		  obj_set_attr(gthis->aa, 'r', NULL);
		}
	      else			/* Disallow something */
		{
		  TRACE("Disallowing %s", j);
		  if (j[0] == '/')
		    obj_add_attr(gthis->aa, 'r', j);
		  else
		    log(L_ERROR_R, "Robots: Misplaced relative path %s", j);
		}
	    }
	}
      else if (robots_work_arounds && (j = strchr(i, '<')) && strchr(j+1, '>'))
	gerror(2200, "Robot file contains HTML tags");
      else
	log(L_ERROR_R, "Robots: Unknown keyword %s", i);
    }

  bclose(in);
  gthis->temp = NULL;
  return 1;
}
