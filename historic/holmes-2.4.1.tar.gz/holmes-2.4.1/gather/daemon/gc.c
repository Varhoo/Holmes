/*
 *	Sherlock Gatherer Control Utility
 *
 *	(c) 1997--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "gather/daemon/gatherd.h"
#include "lib/url.h"
#include "lib/conf.h"
#include "lib/db.h"
#include "lib/pools.h"
#include "lib/index.h"

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

/* Globals */

static int verbose;
sh_time_t now;

/* Support functions */

static struct url url;
static byte ubuf0[MAX_URL_SIZE], ubuf1[MAX_URL_SIZE], ubuf2[MAX_URL_SIZE], ubuf3[MAX_URL_SIZE];

static void
parse_url(byte *u)
{
  int err = url_canon_split(u, ubuf0, ubuf1, &url);
  if (err)
    die("Error parsing %s: %s", u, url_error(err));
}

static byte *
canon_url(byte *u)
{
  int err = url_auto_canonicalize(u, ubuf0);
  if (err)
    die("Error parsing %s: %s", u, url_error(err));
  return ubuf0;
}

/* List hosts and queued objects */

static void
show_host(struct qhost *h)
{
  uns i;

  if (!h->protocol)			/* Free list entry */
    return;
  printf("%s://%s:%d [robots %08x age %d] [",
	 url_proto_names[h->protocol], h->name, h->port,
	 h->robot_id,
	 (h->robot_id == OID_UNDEFINED) ? 0 : (now - h->robot_time));
  for (i=0; i<SHERLOCK_NUM_SECTIONS; i++)
    {
      if (i)
	putchar('+');
      printf("%d", h->obj_count[i]);
    }
  printf(" objects] [key %08x]%s\n",
	 h->qkey,
	 h->qf_pos ? "" : " [IDLE]");
}

static void
show_host_queue(struct qhost *h)
{
  uns pos;
  byte *q;

  if (!h->protocol)			/* Free list entry */
    return;
  show_host(h);
  putchar('\n');
  pos = queue_walk_start(h);
  while (q = queue_walk_next(&pos))
    {
      putchar('\t');
      puts(q);
    }
  putchar('\n');
}

static void
list_queue(byte *u)
{
  struct qhost *h;
 
  queue_init();
  if (u)
    {
      parse_url(u);
      h = find_host(url.protoid, url.host, url.port);
      if (!h)
	die("Host not found");
      show_host_queue(h);
    }
  else
    walk_hosts(show_host_queue);
}

static void
list_hosts(byte *u)
{
  struct qhost *h;

  queue_init();
  if (u)
    {
      parse_url(u);
      h = find_host(url.protoid, url.host, url.port);
      if (!h)
	die("Host not found");
      show_host(h);
    }
  else
    walk_hosts(show_host);
}

static void
unqueue(byte *ur)
{
  struct qhost *h;
  struct qitem *a;
  struct urlrec u;
  int err;

  parse_url(ur);
  gather_lock(0);
  urldb_open();
  queue_init();
  if (! (h = find_host(url.protoid, url.host, url.port)))
    log(L_ERROR, "Unknown host");
  else
    {
      while (a = dequeue_item(h))
	{
	  printf("%s: ", a->text);
	  url.rest = a->text;
	  if (err = url_pack(&url, ubuf2))
	    die("url_pack: %s", url_error(err));
	  if (err = url_enescape(ubuf2, ubuf3))
	    die("url_enescape: %s", url_error(err));
	  if (urldb_lookup(ubuf3, &u))
	    {
	      if (! (u.flags & URF_QUEUED))
		printf("BAD DB RECORD\n");
	      else if (u.oid)
		{
		  printf("keeping object %08x\n", u.oid);
		  u.flags &= ~(URF_QUEUED | URF_REGATHER);
		  urldb_store(ubuf3, &u);
		}
	      else if (urldb_delete(ubuf3))
		printf("DELETED\n");
	      else
		printf("DELETE FAILED\n");
	    }
	  else
	    printf("NO DB ITEM\n");
	}
    }
  queue_cleanup();
  urldb_close();
  gather_unlock();
}

/* Sorting of URL's by db hashes */

struct uhash_key {
  uns len;
  byte url[MAX_URL_SIZE];
};

#define SORT_KEY struct uhash_key
#define SORT_PREFIX(x) uhash_##x
#define SORT_PRESORT
#define SORT_UNIFY
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static struct fastbuf *uhash_src_fb;

static int
uhash_compare(struct uhash_key *a, struct uhash_key *b)
{
  u32 ha = sdbm_hash(a->url, a->len);
  u32 hb = sdbm_hash(b->url, b->len);

  if (ha < hb)
    return -1;
  if (ha > hb)
    return 1;
  return strcmp(a->url, b->url);
}

static int
uhash_fetch_key(struct fastbuf *f, struct uhash_key *k)
{
  if (f)
    {
      byte *x = bgets(f, k->url, MAX_URL_SIZE);
      if (!x)
	return 0;
      k->len = x - k->url;
      return 1;
    }
  else
    {
      byte buf[MAX_URL_SIZE];
      int err;
      for(;;)
	{
	  if (!bgets(uhash_src_fb, buf, MAX_URL_SIZE))
	    return 0;
	  if (!buf[0] || buf[0] == '#')
	    continue;
	  if (!(err = url_auto_canonicalize(buf, k->url)))
	    {
	      k->len = strlen(k->url);
	      return 1;
	    }
	  if (log_ref_errors)
	    log(L_ERROR, "%s: %s", buf, url_error(err));
	}
    }
}

static inline void
uhash_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct uhash_key *k)
{
  bwrite(dest, k->url, k->len);
  bputc(dest, '\n');
}

static inline void
uhash_merge_data(struct fastbuf *src1, struct fastbuf *src2 UNUSED, struct fastbuf *dest,
	       struct uhash_key *k1, struct uhash_key *k2 UNUSED)
{
  uhash_copy_data(src1, dest, k1);
}

static inline byte *
uhash_fetch_item(struct fastbuf *f UNUSED, struct uhash_key *k, byte *limit UNUSED)
{
  return k->url + k->len + 1;
}

static inline void
uhash_store_item(struct fastbuf *f, struct uhash_key *k)
{
  uhash_copy_data(NULL, f, k);
}

static struct uhash_key *
uhash_merge_items(struct uhash_key *a, struct uhash_key *b UNUSED)
{
  return a;
}

#include "lib/sorter.h"

static void
for_each_url(byte *arg, void (*fn)(byte *url), byte *msg)
{
  if (arg)
    {
      arg = canon_url(arg);
      fn(arg);
    }
  else
    {
      byte buf[MAX_URL_SIZE];
      uns cnt = 0;
      struct fastbuf *f = bfdopen_shared(0, 4096);
      uhash_src_fb = f;
      log(L_INFO, "Pre-sorting URL's");
      f = uhash_sort(NULL);
      log(L_INFO, "%s URL's", msg);
      while (bgets(f, buf, sizeof(buf)))
	{
	  if (buf[0] && buf[0] != '#')
	    {
	      fn(buf);
	      cnt++;
	    }
	}
      bclose(f);
      log(L_INFO, "Processed %d URL's", cnt);
    }
}

/* URLs */

static void
show_url0(byte *n, struct urlrec *z)
{
  struct tm *tm;

  printf("%s%s%s%s ", n,
	 (z->flags & URF_QUEUED) ? " [QUEUED]" : "",
	 (z->flags & URF_INITIAL) ? " [INIT]" : "",
	 (z->flags & URF_REGATHER) ? " [REGATHER]" : "");
  if (z->oid == OID_UNDEFINED)
    printf("<unknown>");
  else if (z->oid >= OID_FIRST_ERROR)
    printf("Error %d", z->oid - OID_FIRST_ERROR);
  else
    printf("%08x", z->oid);
  if (verbose)
    {
      time_t t;
      t = z->access;
      if (! (tm = localtime(&t)))
	die("Time parse error");
      printf (" T=%04d%02d%02d:%02d%02d",
	      tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
	      tm->tm_hour, tm->tm_min);
      if (t = z->http_last_mod)
	{
	  if (! (tm = localtime(&t)))
	    die("Lastmod parse error");
	  printf (" L=%04d%02d%02d:%02d%02d",
		  tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
		  tm->tm_hour, tm->tm_min);
	}
      if (z->avg_change_time)
	printf(" C=%d", z->avg_change_time);
      if (z->retries)
	printf(" R=%d", z->retries);
    }
  putchar('\n');
}

static void
show_url_single(byte *url)
{
  struct urlrec z;
  if (!urldb_lookup(url, &z))
    log(L_ERROR, "%s: Not found", url);
  else
    show_url0(url, &z);
}

static void
show_url(byte *u)
{
  gather_lock(1);
  urldb_open();
  if (!u)
    {
      struct urlrec z;
      byte url[MAX_URL_SIZE];
      urldb_rewind();
      while (urldb_get_next(url, &z))
	show_url0(url, &z);
    }
  else
    {
      if (!strcmp(u, "-"))
	u = NULL;
      for_each_url(u, show_url_single, "Listing");
    }
  urldb_close();
  gather_unlock();
}

static void
del_url_single(byte *u)
{
  if (!urldb_delete(u))
    log(L_ERROR, "%s: Not found", u);
}

static void
del_url(byte *u)
{
  gather_lock(0);
  urldb_open();
  for_each_url(u, del_url_single, "Deleting");
  urldb_close();
  gather_unlock();
}

static void
del_obj_single(byte *u)
{
  struct urlrec ur;

  if (!urldb_lookup(u, &ur))
    log(L_ERROR, "%s: Not found", u);
  else
    {
      if (ur.oid != OID_UNDEFINED && ur.oid < OID_FIRST_ERROR)
	obuck_delete(ur.oid);
      if (!urldb_delete(u))
	log(L_ERROR, "%s: Delete failed, don't ask me why", u);
    }
}

static void
delete_objects(byte *u)
{
  gather_lock(0);
  urldb_open();
  obuck_init(1);
  for_each_url(u, del_obj_single, "Deleting");
  obuck_cleanup();
  urldb_close();
  gather_unlock();
}

/* MD5 Database */

static void
show_md5(byte *m)
{
  struct md5rec z;

  gather_lock(1);
  md5db_open();
  if (m)
    {
      if (!md5db_lookup(m, &z))
	log(L_ERROR, "%s: Not found", m);
      else
	printf("%s: %08x\n", m, z.oid);
    }
  else
    {
      byte M[MD5_HEX_SIZE];
      md5db_rewind();
      while (md5db_get_next(M, &z))
	printf("%s: %08x\n", M, z.oid);
    }
  md5db_close();
  gather_unlock();
}

static void
del_md5(byte *m)
{
  gather_lock(0);
  md5db_open();
  if (!md5db_delete(m))
    log(L_ERROR, "%s: Not found", m);
  md5db_close();
  gather_unlock();
}

/* Insertion of new URL's */

static void
insert_url(byte *url)
{
  add_ref(url, URF_INITIAL);
}

static void
insert_urls(byte *arg)
{
  gather_lock(0);
  obuck_init(1);
  obuck_cleanup();
  queue_init();
  urldb_open();
  refs_init(1);
  for_each_url(arg, insert_url, "Inserting");
  urldb_close();
  queue_cleanup();
  gather_unlock();
}

/* Calculation of statistics */

struct hs {
  struct hs *next;
  uns okays, errs, queued, requeued;
  word port;
  byte protocol;
  byte hostname[1];
};

#define HASH_NODE struct hs
#define HASH_PREFIX(x) hs_##x
#define HASH_KEY_COMPLEX(x) x hostname, x protocol, x port
#define HASH_KEY_DECL byte *hostname, uns protocol, uns port
#define HASH_WANT_LOOKUP

#define HASH_GIVE_HASHFN
#include "lib/hashfunc.h"
static inline uns hs_hash(byte *host, uns proto UNUSED, uns port UNUSED)
{
  return hash_string(host);
}

#define HASH_GIVE_EQ
static inline uns hs_eq(byte *h1, uns p1, uns t1, byte *h2, uns p2, uns t2)
{
  return !strcmp(h1, h2) && p1 == p2 && t1 == t2;
}

#define HASH_GIVE_EXTRA_SIZE
static inline int hs_extra_size(byte *h, uns p UNUSED, uns t UNUSED)
{
  return strlen(h);
}

#define HASH_GIVE_INIT_KEY
static inline void hs_init_key(struct hs *n, byte *h, uns p, uns t)
{
  strcpy(n->hostname, h);
  n->protocol = p;
  n->port = t;
  /* Does data initialization as well */
  n->okays = n->errs = n->queued = n->requeued = 0;
}

#define HASH_USE_POOL hs_pool
static struct mempool *hs_pool;

#include "lib/hashtable.h"

static void
host_stats(void)
{
  struct urlrec z;
  byte url[MAX_URL_SIZE], buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];
  struct url ur;
  int e;
  struct hs *h;

  hs_pool = mp_new(65536);
  hs_init();
  gather_lock(1);
  urldb_open();
  urldb_rewind();
  while (urldb_get_next(url, &z))
    {
      if (e = url_canon_split(url, buf1, buf2, &ur))
	{
	  log(L_ERROR, "Unable to parse %s: %s", url, url_error(e));
	  continue;
	}
      h = hs_lookup(ur.host, ur.protoid, ur.port);
      if (z.flags & URF_QUEUED)
	{
	  if (z.oid == OID_UNDEFINED)
	    h->queued++;
	  else
	    h->requeued++;
	}
      if (z.oid == OID_UNDEFINED)
	;
      else if (z.oid >= OID_FIRST_ERROR)
	h->errs++;
      else
	h->okays++;
    }
  urldb_close();
  gather_unlock();
  HASH_FOR_ALL(hs, h)
    {
      printf("%d\t%d\t%d\t%d\t%s://%s:%d\n", h->okays, h->errs, h->queued, h->requeued,
	     url_proto_names[h->protocol], h->hostname, h->port);
    }
  HASH_END_FOR;
}

/* Testing of ref filter */

static void
test_ref_filter(void)
{
  struct fastbuf *f = bfdopen_shared(0, 4096);
  byte buf[MAX_URL_SIZE], url[MAX_URL_SIZE], *msg;
  struct rfilter_data rfdata;
  int err;

  refs_init(1);
  while (bgets(f, buf, sizeof(buf)))
    {
      if (err = url_auto_canonicalize(buf, url))
	puts(url_error(err));
      else
	{
	  rfdata.url = url;
	  if (msg = ref_filter(&rfdata))
	    puts(msg);
	  else
	    printf("OK: sec=%d sectmax=%d/%d ct=%s ce=%s url_key=%s\n",
		   rfdata.section, rfdata.section_soft_max, rfdata.section_hard_max,
		   rfdata.content_type, rfdata.content_encoding, rfdata.url_key);
	  ref_filter_undo();
	}
    }
}

/* Requeueing */

static uns requeue_delete_orig;

static void
requeue_url(byte *url)
{
  struct url ur;
  struct urlrec u;
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];

  if (url_canon_split(url, buf1, buf2, &ur))
    ASSERT(0);
  if (urldb_lookup(url, &u))
    {
      struct qhost *h = find_host(ur.protoid, ur.host, ur.port);
      ASSERT(h);
      u.access = now;
      u.flags |= URF_QUEUED | URF_REGATHER;
      if (u.oid >= OID_FIRST_ERROR)
	u.oid = OID_UNDEFINED;
      if (requeue_delete_orig && u.oid != OID_UNDEFINED)
	{
	  obuck_delete(u.oid);
	  u.oid = OID_UNDEFINED;
	}
      u.retries = 0;
      urldb_store(url, &u);
      enqueue_item(h, ur.rest);
    }
  else
    add_ref(url, URF_REGATHER);
}

static void
requeue(uns delete_orig, byte *arg)
{
  requeue_delete_orig = delete_orig;
  gather_lock(0);
  queue_init();
  urldb_open();
  refs_init(1);
  obuck_init(1);
  for_each_url(arg, requeue_url, "Requeueing");
  obuck_cleanup();
  urldb_close();
  queue_cleanup();
  gather_unlock();
}

/* Rebuilding of databases */

struct reb_key {
  uns len;				/* URL length */
  u32 hash;				/* SDBM hash */
  struct fingerprint fp;
  oid_t oid;
  uns lastmod;
  byte url[MAX_URL_SIZE];
};

static struct mempool *reb_pool;
static uns reb_counter;

#undef SORT_KEY
#undef SORT_PREFIX
#undef SORT_PRESORT
#undef SORT_UNIFY
#undef SORT_INPUT_FB
#undef SORT_OUTPUT_FB

#define SORT_KEY struct reb_key
#define SORT_PREFIX(x) reb_##x
#define SORT_PRESORT
#define SORT_UNIFY
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static int
reb_compare(struct reb_key *a, struct reb_key *b)
{
  if (a->hash < b->hash)
    return -1;
  if (a->hash > b->hash)
    return 1;
  return memcmp(&a->fp, &b->fp, sizeof(a->fp));
}

static int
reb_fetch_key(struct fastbuf *f, struct reb_key *k)
{
  if (f)
    {
      if (!breadb(f, k, sizeof(struct reb_key) - MAX_URL_SIZE))
	return 0;
      breadb(f, k->url, k->len);
      return 1;
    }
  else
    {
      struct fastbuf *fb;
      struct obuck_header bhdr;
      struct odes *obj;
      byte *url, *x;

    restart:
      if (!(fb = obuck_slurp_pool(&bhdr)))
	return 0;
      mp_flush(reb_pool);
      obj = obj_new(reb_pool);
      obj_read(fb, obj);
      url = obj_find_aval(obj, 'U');
      if (!url)
	{
	  log(L_ERROR, "Bucket %08x has no URL", bhdr.oid);
	  goto restart;
	}
      if ((x = obj_find_aval(obj, 'T')) && !strcmp(x, "x-sherlock/robots"))
	goto restart;
      if (x = obj_find_aval(obj, 'D'))
	k->lastmod = atol(x);
      else
	k->lastmod = now;
      k->len = strlen(url) + 1;
      memcpy(k->url, url, k->len);
      k->oid = bhdr.oid;
      k->hash = sdbm_hash(url, k->len-1);
      fingerprint(url, &k->fp);
      if (!(reb_counter++ % 1024) && verbose)
	{
	  printf("%d\r", reb_counter);
	  fflush(stdout);
	}
      return 1;
    }
}

static inline void
reb_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct reb_key *k)
{
  bwrite(dest, k, sizeof(*k) - MAX_URL_SIZE + k->len);
}

static inline struct reb_key *
reb_select(struct reb_key *x, struct reb_key *y)
{
  if (x->oid > y->oid)
    return x;
  if (x->oid < y->oid)
    return y;
  ASSERT(0);
}

static inline void
reb_merge_data(struct fastbuf *src1 UNUSED, struct fastbuf *src2 UNUSED, struct fastbuf *dest,
	       struct reb_key *k1, struct reb_key *k2)
{
  reb_copy_data(NULL, dest, reb_select(k1, k2));
}

static inline byte *
reb_fetch_item(struct fastbuf *f UNUSED, struct reb_key *k, byte *limit UNUSED)
{
  return k->url + k->len;
}

static inline void
reb_store_item(struct fastbuf *f, struct reb_key *k)
{
  reb_copy_data(NULL, f, k);
}

static struct reb_key *
reb_merge_items(struct reb_key *a, struct reb_key *b)
{
  return reb_select(a, b);
}

#include "lib/sorter.h"

static void
synchronize_urldb(void)
{
  struct fastbuf *f;
  struct reb_key k;
  struct urlrec ur;
  oid_t last_oid = ~(oid_t)0;
  uns buck_cnt=0, new_cnt=0, update_cnt=0;

  gather_lock(0);
  gather_note_state("reconstructing");

  obuck_init(0);
  reb_pool = mp_new(65536);
  reb_counter = 0;
  log(L_INFO, "Scanning buckets");
  f = reb_sort(NULL);
  obuck_cleanup();
  log(L_INFO, "Found %d URL's", reb_counter);

  log(L_INFO, "Updating URLdb");

  urldb_open();
  while (reb_fetch_key(f, &k))
    {
      ASSERT(k.oid != last_oid);
      if (urldb_lookup(k.url, &ur))
	{
	  if (ur.oid != k.oid)
	    {
	      ur.oid = k.oid;
	      update_cnt++;
	      urldb_store(k.url, &ur);
	    }
	}
      else
	{
	  new_cnt++;
	  bzero(&ur, sizeof(ur));
	  ur.access = k.lastmod;
	  ur.oid = k.oid;
	  urldb_store(k.url, &ur);
	}
      last_oid = k.oid;
      buck_cnt++;
      if (!(buck_cnt % 1024) && verbose)
	{
	  printf("%d total, %d new, %d upd\r", buck_cnt, new_cnt, update_cnt);
	  fflush(stdout);
	}
    }
  urldb_close();
  bclose(f);
  gather_unlock();
  log(L_INFO, "Processed %d URLs, %d were missing from the db, %d had old data.", buck_cnt, new_cnt, update_cnt);
  log(L_INFO, "URLdb synchronized, remember to run full expire to fix the rest.");
}

/* Normalization of URL's */

static void
show_single_norm_url(struct fastbuf *f, byte *url)
{
  byte buf[MAX_URL_SIZE];
  int err = url_auto_canonicalize(url, buf);
  if (err)
    log(L_ERROR_R, "Invalid URL %s: %s", url, url_error(err));
  else
    bputsn(f, buf);
}

static void
show_norm_url(byte *url)
{
  struct fastbuf *o = bfdopen_shared(1, 4096);
  if (url)
    show_single_norm_url(o, url);
  else
    {
      struct fastbuf *i = bfdopen_shared(0, 4096);
      byte buf[MAX_URL_SIZE];
      while (bgets(i, buf, sizeof(buf)))
	show_single_norm_url(o, buf);
      bclose(i);
    }
  bclose(o);
}

/* Main program */

static char *shortopts = CF_SHORT_OPTS "d::fh::ilm::M:n::q::Q:r::R::su::U::vX";

static void
usage(void)
{
  fprintf(stderr, "Usage: gc [<options>] <commands>\n\
\n\
Options:\n"
CF_USAGE
"-v\t\t\tBe more verbose\n\n\
Commands:\n\
-d[<url>]\tDelete a given URL and its object\n\
-f\t\tTest reference filter\n\
-h[<url>]\tList all known hosts or a specified one\n\
-i[<url>]\tInsert a new URL\n\
-m[<md5>]\tList object matching a given MD5 sum\n\
-M<md5>\t\tDelete from MD5 database\n\
-n[<url>]\tNormalize a given URL\n\
-q[<url>]\tList queued objects [matching host, protocol and port of given URL]\n\
-Q<url>\t\tRemove all queued objects matching host, protocol and port of given URL\n\
-r[<url>]\tSchedule URL for regathering as soon as possible\n\
-R[<url>]\tLike -r, but delete the original contents immediately\n\
-s\t\tCalculate per-host document statistics\n\
-u[<url>]\tList object matching a given URL [if \"-\", read them from stdin]\n\
-U[<url>]\tDelete given URL from database [don't you want -d instead?]\n\
-X\t\tSynchronize URLdb with bucket file\n\
\n\
If no <url> is given to `list' commands, all matching records all listed.\n\
If no <url> is given to `modify' commands, URL's are taken from stdin.\n\
");
  exit(1);
}

int
main(int argc, char **argv)
{
  int opt, jobs = 0;
  log_init("gc");
  now = time(NULL);

  while ((opt = cf_getopt(argc, argv, shortopts, CF_NO_LONG_OPTS, NULL)) >= 0)
  {
    jobs++;
    gatherer_init();
    switch (opt)
    {
    case 'v':
      verbose++;
      break;
    case 'd':
      delete_objects(optarg);
      break;
    case 'f':
      test_ref_filter();
      break;
    case 'h':
      list_hosts(optarg);
      break;
    case 'i':
      insert_urls(optarg);
      break;
    case 'm':
      show_md5(optarg);
      break;
    case 'M':
      del_md5(optarg);
      break;
    case 'n':
      show_norm_url(optarg);
      break;
    case 'q':
      list_queue(optarg);
      break;
    case 'Q':
      unqueue(optarg);
      break;
    case 'r':
      requeue(0, optarg);
      break;
    case 'R':
      requeue(1, optarg);
      break;
    case 's':
      host_stats();
      break;
    case 'u':
      show_url(optarg);
      break;
    case 'U':
      del_url(optarg);
      break;
    case 'X':
      synchronize_urldb();
      break;
    default:
      usage();
    }
  }
  if (!jobs)
    usage();
  return 0;
}
