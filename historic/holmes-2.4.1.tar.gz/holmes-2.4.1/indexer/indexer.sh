#!/bin/sh
# Sherlock Indexer Script
# (c) 2001--2003 Martin Mares <mj@ucw.cz>

unset DELETING VERBOSE G LISTS STAGE1ONLY STAGE2ONLY KEEP
set -e
while getopts "12adklvC:S:" OPT ; do
	case "$OPT" in
	        1)	STAGE1ONLY=1
			;;
		2)	STAGE2ONLY=2
			;;
		a)	G="$G -SIndexer.Filter="
			;;
		d)	DELETING=1
			G="$G -SIndexer.SortDeleteSrc=1"
			;;
		k)	KEEP=1
			;;
		l)	LISTS=1 ;;
		v)	VERBOSE=1
			G="$G -SIndexer.ProgressScreen=1"
			;;
		[CS])	G="$G -$OPT$OPTARG" ;;
		*)	cat >&2 <<EOF
Usage: indexer [-1dvl]

-1	Stop after stage 1
-2	Start with stage 2
-a	Ignore filters and accept all documents
-d	Delete temporary files as soon as possible
-k	Keep intermediate versions of several files for debugging
-l	List index files between passes
-v	Be verbose (also enables progress indicators)
-C, -S	Global configuration options passed to all programs
EOF
			exit 1
			;;
	esac
done

function log
{
	bin/logger indexer I "$1"
}

function delete
{
	[ -z "$DELETING" ] || ( cd $CF_Directory && rm -f $@ )
}

function keep
{
	if [ -n "$KEEP" ] ; then
		suffix=$1
		while [ -n "$2" ] ; do
			cp $CF_Directory/$2 $CF_Directory/$2.$suffix
			shift
		done
	fi
}

function stats
{
	log "Disk usage $1: `du -s $CF_Directory | cut -f 1` blocks"
	[ -z "$LISTS" ] || ( ls -Al $CF_Directory | bin/logger indexer D )
}

function sizes
{
	bin/sizer $CF_Directory/{card-attrs,cards,lexicon,references,string-map}
	total_index=`du -bs $CF_Directory | cut -f 1`
	echo "total index size is $total_index" | bin/logger sizer I
}

eval `bin/config $G Indexer Directory=not/configured LexByFreq '*'`

log "Building index"
if [ -z "$STAGE2ONLY" ] ; then
	log "Deleting old index"
	mkdir -p $CF_Directory
	rm -f $CF_Directory/*

	bin/scanner $G
	keep scanner attributes merges
	bin/fpsort $G
	bin/mkgraph $G
	if [ -f bin/sitefinder ] ; then
		bin/sitefinder $G
	fi
	bin/backlinker $G
	keep backlinker attributes merges
	if [ -f bin/oook ] ; then
		if [ -f db/catalog.gz ] ; then
			zcat db/catalog.gz | bin/oook $G
		else
			bin/oook $G </dev/null
		fi
		keep oook attributes merges
	fi
	if [ -f bin/weights ] ; then
		bin/weights $G
		keep weights attributes
	fi
	bin/mergesums $G
	keep mergesums merges
	bin/mergesigns $G
	keep mergesigns merges
	bin/merger $G
	bin/reftexts $G
	bin/labelsort $G
	bin/ireport $G
	stats "after first stage"
	delete fingerprints labels-by-id links-by-url merges url-list url-list-translated checksums ref-texts link-graph signatures
	[ -z "$DELETING" ] || stats "after cleanup"
	[ -z "$STAGE1ONLY" ] || exit 0
fi
bin/mklex $G
[ -z "$CF_LexByFreq" ] || bin/lexfreq $G
bin/lexorder $G
delete lexicon-raw
bin/chewer $G
stats "after chewing"
delete labels attributes notes
bin/ssort $G
delete string-index
bin/wsort $G
delete word-index lexicon-order
bin/lexsort $G
delete lexicon-words stems-order
stats "after second stage"
sizes
log "Index built successfully."
