/*
 *	Sherlock Indexer -- Generate Index Reports
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/url.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"

#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

static byte *fn_class_log;
static uns class_threshold;

static struct cfitem reporter_config[] = {
  { "Reporter",		CT_SECTION,	NULL },
  { "ClassLog",		CT_STRING,	&fn_class_log },
  { "ClassThreshold",	CT_INT,		&class_threshold },
  { NULL,		CT_STOP,	NULL }
};

static void
report_merges(void)
{
  if (!fn_class_log)
    return;
  log(L_INFO, "Generating equivalence class log");

  /* Load attributes and merging array */
  uns attr_size, merges_size, card_count;
  struct card_attr *attrs = mmap_file(index_name(fn_attributes), &attr_size, 1);
  card_count = attr_size / sizeof(struct card_attr);
  u32 *merges = mmap_file(index_name(fn_merges), &merges_size, 1);
  ASSERT(merges_size == 4*card_count);

  /* Calculate class sizes */
  u32 *sizes = xmalloc_zero(card_count*4);
  for (uns i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY))
      sizes[merges[i]]++;

  /* Log large classes */
  struct fastbuf *b = bopen(index_name(fn_class_log), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  struct fastbuf *urls = bopen(index_name(fn_urls), O_RDONLY, indexer_fb_size);
  uns this_url = 0;
  for (uns i=0; i<card_count; i++)
    if (!(attrs[i].flags & CARD_FLAG_EMPTY) && sizes[merges[i]] >= class_threshold)
      {
	byte buf[MAX_URL_SIZE+1];
	while (this_url <= i)
	  {
	    bgets(urls, buf, sizeof(buf));
	    this_url++;
	  }
	bprintf(b, "%d\t%08x\t", sizes[merges[i]], merges[i]);
	bputsn(b, buf);
      }
  bclose(urls);
  bclose(b);

  /* Clean up */
  xfree(sizes);
  munmap_file(attrs, attr_size);
  munmap_file(merges, merges_size);
}

int
main(int argc, char **argv)
{
  log_init(argv[0]);
  cf_register(reporter_config);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  report_merges();
  return 0;
}
