/*
 *	Sherlock Indexer -- Lexicon Functions
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 */

#ifndef _INDEXER_LEXICON_H
#define _INDEXER_LEXICON_H

#include "lib/lists.h"

/* Word classes */

enum word_class {
  WC_UNUSED,				/* Unused type */
  WC_IGNORED,				/* Silently ignored */
  WC_NORMAL,				/* Just an ordinary word */
  WC_GARBAGE,				/* Takes place (word number), but isn't indexed */
  WC_PREPOSITION,			/* Forms pairs with WC_NORMAL behind */
  WC_POSTPOSITION,			/* Forms pairs with WC_NORMAL before */
  WC_BREAK,				/* Explicit sentence break */
  WC_COMPOUND,				/* Word complex */
  /* lexhash.h assumes that word_class fits in 3 bits */
};

/* Configuration */

struct lexicon_config {
  uns min_len_ign;
  uns min_len;
  uns max_len;
  uns max_hex_len;
  uns max_ctrl_len;
  uns max_preps;
  uns max_postps;
  uns max_gap;
};

extern struct lexicon_config lexicon_config;

/* We want to be able to exchange configurations, but not at the cost of dereferencing an extra pointer */
#define lex_min_len_ign lexicon_config.min_len_ign
#define lex_min_len lexicon_config.min_len
#define lex_max_len lexicon_config.max_len
#define lex_max_hex_len lexicon_config.max_hex_len
#define lex_max_ctrl_len lexicon_config.max_ctrl_len
#define lex_max_preps lexicon_config.max_preps
#define lex_max_postps lexicon_config.max_postps
#define lex_max_gap lexicon_config.max_gap

struct exception {
  node n;
  enum word_class class;
  byte *w;
};

extern struct list lex_exceptions;

/* Entries in LexWords and Lexicon */

struct lex_entry {	/* Beware, unaligned */
  byte ref_pos[BYTES_PER_O];
  byte ch_len[2];
  byte class;
  byte freq;
  byte length;
  byte w[0];
} PACKED;

struct cplx_entry {	/* Beware, unaligned */
  byte ref_pos[BYTES_PER_O];
  byte ch_len[2];
  u32 id[0];
} PACKED;

#endif /* _INDEXER_LEXICON_H */
