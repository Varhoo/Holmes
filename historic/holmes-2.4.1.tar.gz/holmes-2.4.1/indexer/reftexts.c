/*
 *	Sherlock Indexer -- Processing of Reference Texts
 *
 *	(c) 2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/lists.h"
#include "lib/fastbuf.h"
#include "lib/heap.h"
#include "lib/pools.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"

#include <stdlib.h>
#include <fcntl.h>

static struct card_attr *attr;
static u32 *merges;
static struct fastbuf *labels, *reftmp, *ref;
static uns cnt_in, cnt_out;

struct rt {
  u32 src, dest;
  u16 len;
  byte data[0];
} PACKED;

#define SORT_KEY struct rt
#define SORT_PREFIX(x) rt_##x
#define SORT_PRESORT
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static int
rt_compare(struct rt *x, struct rt *y)
{
  if (x->dest < y->dest)
    return -1;
  if (x->dest > y->dest)
    return 1;
  return 0;
}

static int
rt_fetch_key(struct fastbuf *f, struct rt *x)
{
  return breadb(f, x, sizeof(struct rt));
}

static void
rt_copy_data(struct fastbuf *src, struct fastbuf *dest, struct rt *x)
{
  bwrite(dest, x, sizeof(*x));
  bbcopy(src, dest, x->len);
}

static byte *
rt_fetch_item(struct fastbuf *src, struct rt *x, byte *limit)
{
  if (x->data + x->len > limit)
    return NULL;
  breadb(src, x->data, x->len);
  return x->data + x->len;
}

static void
rt_store_item(struct fastbuf *dest, struct rt *x)
{
  bwrite(dest, x, sizeof(*x) + x->len);
}

#include "lib/sorter.h"

struct rth {
  struct rth *list_next, *hash_next;
  uns w;
  uns l;
  byte data[1];
};

static struct rth **rt_hash, **rt_heap, *rt_first;
static u32 *rt_generation;
static uns rt_hash_mask;
static struct mempool *rt_pool;

static uns
rt_hf(byte *x)
{
  uns h = 0;
  uns u;
  uns lastsp = 1;

  for(;;)
    {
      GET_UTF8(x, u);
      if (!u)
	break;
      if (Ualnum(u))
	{
	  if (lastsp)
	    h = 13*h + ' ';
	  h = 13*h + Utoupper(u);
	  lastsp = 0;
	}
      else
	lastsp = 1;
    }
  return h;
}

static uns
rt_cmp(byte *x, byte *y)
{
  uns ux, uy;
  uns sx, sy;

  sx = sy = 1;
  for(;;)
    {
      for(;;)
	{
	  GET_UTF8(x, ux);
	  if (!ux || Ualnum(ux))
	    break;
	  sx = 1;
	}
      for(;;)
	{
	  GET_UTF8(y, uy);
	  if (!uy || Ualnum(uy))
	    break;
	  sy = 1;
	}
      if (!ux && !uy)
	return 0;
      if (sx != sy)
	return 1;
      if (Utoupper(ux) != Utoupper(uy))
	return 1;
      sx = sy = 0;
    }
}

static void
rthash_init(void)
{
  rt_hash = xmalloc_zero(sizeof(struct rth *) * ref_hash_size);
  rt_generation = xmalloc_zero(4 * ref_hash_size);
  rt_hash_mask = ref_hash_size - 1;
  rt_heap = xmalloc(sizeof(struct rth *) * (ref_max_count+1));
  rt_pool = mp_new(65536);
}

static void
rt_update(struct rth *rth, struct rt *rt)
{
  uns wt = attr[rt->src].weight;

  rth->w += wt;
}

static void
rthash_update(struct rt *rt)
{
  uns h = rt_hf(rt->data) & rt_hash_mask;
  struct rth *rth;

  if (rt_generation[h] != rt->dest)
    {
      rt_hash[h] = NULL;
      rt_generation[h] = rt->dest;
    }
  else for (rth = rt_hash[h]; rth; rth=rth->hash_next)
    if (!rt_cmp(rth->data, rt->data))
      {
	rt_update(rth, rt);
	return;
      }
  rth = mp_alloc_fast(rt_pool, sizeof(struct rth) + rt->len);
  rth->hash_next = rt_hash[h];
  rt_hash[h] = rth;
  rth->list_next = rt_first;
  rt_first = rth;
  rth->w = 0;
  rth->l = rt->len;
  memcpy(rth->data, rt->data, rth->l+1);
  rt_update(rth, rt);
}

#define RHEAP_LESS(a,b) (a->w > b->w)
#define RHEAP_SWAP(heap,a,b,t) (t=heap[a], heap[a]=heap[b], heap[b]=t)

static void
rthash_flush(uns dest)
{
  uns n = 0;

  if (!rt_first)
    return;
  while (rt_first)
    {
      if (n >= ref_max_count)
	HEAP_DELMIN(struct rth *, rt_heap, n, RHEAP_LESS, RHEAP_SWAP);
      rt_heap[++n] = rt_first;
      HEAP_INSERT(struct rth *, rt_heap, n, RHEAP_LESS, RHEAP_SWAP);
      rt_first = rt_first->list_next;
    }

  bputl(labels, dest);
  bputc(labels, 0xfe);
  while (n)
    {
      bputc(labels, 'x');
      bwrite(labels, rt_heap[1]->data, rt_heap[1]->l);
      bputc(labels, 0);
      cnt_out++;
      HEAP_DELMIN(struct rth *, rt_heap, n, RHEAP_LESS, RHEAP_SWAP);
    }
  bputc(labels, 0);

  mp_flush(rt_pool);
}

int
main(int argc, char **argv)
{
  uns src;
  uns attr_size, merges_size;
  struct rt *rt = alloca(sizeof(struct rt) + ref_max_length + 4);
  u32 last_dest = ~0U;

  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }
  log(L_INFO, "Analysing reference texts");

  merges = mmap_file(index_name(fn_merges), &merges_size, 0);
  fp_recog_init();
  ref = bopen(index_name(fn_ref_texts), O_RDONLY, indexer_fb_size);
  reftmp = bopen_tmp(indexer_fb_size);
  while ((src = bgetl(ref)) != ~0U)
    {
      struct fingerprint fp;
      uns l, dest;
      breadb(ref, &fp, sizeof(fp));
      l = bgetw(ref);
      dest = fp_recog(&fp);
      if (dest == ~0U ||				/* unrecognized URL */
	  merges[src] == ~0U || merges[dest] == ~0U)	/* or src/dest card dropped */
	bseek(ref, l, SEEK_CUR);
      else
	{
	  src = merges[merges[src]];			/* follow redirects and go to the right equivalence class */
	  dest = merges[merges[dest]];
	  bputl(reftmp, src);
	  bputl(reftmp, dest);
	  bputw(reftmp, l);
	  bbcopy(ref, reftmp, l);
	}
      cnt_in++;
    }
  bclose(ref);
  fp_recog_end();
  munmap_file(merges, merges_size);

  bflush(reftmp);
  bsetpos(reftmp, 0);
  reftmp = rt_sort(reftmp);

  attr = mmap_file(index_name(fn_attributes), &attr_size, 0);
  rthash_init();
  labels = bopen(index_name(fn_labels_by_id), O_WRONLY | O_APPEND, indexer_fb_size);
  while (breadb(reftmp, rt, sizeof(*rt)))
    {
      breadb(reftmp, rt->data, rt->len);
      rt->data[rt->len] = 0;
      if (rt->dest != last_dest)
	{
	  rthash_flush(last_dest);
	  last_dest = rt->dest;
	}
      rthash_update(rt);
    }
  rthash_flush(last_dest);
  munmap_file(attr, attr_size);
  bclose(labels);
  bclose(reftmp);

  log(L_INFO, "Reference texts: %d in -> %d out", cnt_in, cnt_out);
  return 0;
}
