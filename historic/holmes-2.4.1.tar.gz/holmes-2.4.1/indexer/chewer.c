/*
 *	Sherlock Indexer -- Digestive Processes
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/pools.h"
#include "lib/url.h"
#include "lib/object.h"
#include "lib/hashfunc.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"

#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <alloca.h>

static struct fastbuf *cards, *card_attrs, *word_index, *string_index;
static uns card_id;
static byte *indexed_words_end;

#undef PROFILE_TSC
#include "lib/profile.h"
static prof_t pr_fetch, pr_preproc, pr_strings, pr_words, pr_cards;

/*
 *  Configuration
 */

static uns word_buf_size = 65536;
static uns string_buf_size = 65536;
static uns string_cats = ~0;
static uns phrase_limit = 4095;
static byte *card_attr_list = "U";
static uns excerpt_min;
static uns excerpt_max = ~0;
static uns doc_buf_size = 65536;
static uns giant_ban_meta;

static struct cfitem chewer_config[] = {
  { "Chewer",		CT_SECTION,	NULL },
  { "WordBufSize",	CT_INT,		&word_buf_size },
  { "StringBufSize",	CT_INT,		&string_buf_size },
  { "StringCats",	CT_INT,		&string_cats },
  { "PhraseLimit",	CT_INT,		&phrase_limit },
  { "CardAttrs",	CT_STRING,	&card_attr_list },
  { "ExcerptMin",	CT_INT,		&excerpt_min },
  { "ExcerptMax",	CT_INT,		&excerpt_max },
  { "DocBufSize",	CT_INT,		&doc_buf_size },
  { "GiantBanMeta",	CT_INT,		&giant_ban_meta },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR chewconf_init(void)
{
  cf_register(chewer_config);
}

/*
 *  Indexing of strings
 */

struct sentry {
  struct sentry *next;
  struct fingerprint fp;
  u32 id;
  u32 type;
};

#define SENT_BITE 1024

static struct sentry *string_list;
static uns sentry_count, sentry_limit;
static struct mempool *string_pool;
static uns string_runs;
static u64 string_cnt;

static void
string_init(void)
{
  string_index = bopen(index_name(fn_string_index), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  string_pool = mp_new(sizeof(struct sentry) * SENT_BITE);
  sentry_limit = string_buf_size / sizeof(struct sentry);
  DBG("Allocated string pool, sentry_limit=%d", sentry_limit);
}

static inline int
string_cmp(const struct sentry *a, const struct sentry *b)
{
  int i = memcmp(&a->fp, &b->fp, sizeof(struct fingerprint));
  if (i)
    return i;
  if (a->id < b->id)
    return -1;
  if (a->id > b->id)
    return 1;
  if (a->type < b->type)
    return -1;
  if (a->type > b->type)
    return 1;
  return 0;
}

static struct sentry *
string_sort(struct sentry *x)
{
  struct sentry *f1, **l1, *f2, **l2, **l;

  l1 = &f1;
  l2 = &f2;
  while (x)
    {
      *l1 = x;
      l1 = &x->next;
      x = x->next;
      if (!x)
	break;
      *l2 = x;
      l2 = &x->next;
      x = x->next;
    }
  *l1 = *l2 = NULL;

  if (f1 && f1->next)
    f1 = string_sort(f1);
  if (f2 && f2->next)
    f2 = string_sort(f2);
  l = &x;
  while (f1 && f2)
    {
      if (string_cmp(f1, f2) <= 0)
	{
	  *l = f1;
	  l = &f1->next;
	  f1 = f1->next;
	}
      else
	{
	  *l = f2;
	  l = &f2->next;
	  f2 = f2->next;
	}
    }
  *l = f1 ? : f2;
  return x;
}

static void
string_flush(void)
{
  uns size;
  struct sentry *f, *g, *h, *m, **hh;
  int prevtype;
  sh_off_t expected_end;

  if (!string_list)
    return;
  string_list = string_sort(string_list);

  f = string_list;
  while (f)
    {
      g = f;
      while (f && !memcmp(&f->fp, &g->fp, sizeof(struct fingerprint)))
	f = f->next;
      /* [g,f) is the chain to flush for single fp, scan sizes */
      size = 0;
      h = g;
      while (h != f)
	{
	  m = h;
	  size += 6;
	  prevtype = -1;
	  hh = NULL;
	  while (h != f && h->id == m->id)
	    {
	      if ((int) h->type == prevtype)
		*hh = h->next;		/* duplicates are deleted */
	      else
		{
		  size += 2;
		  prevtype = h->type;
		  hh = &h->next;
		}
	      h = h->next;
	    }
	}
      /* output the chain */
      bwrite(string_index, &g->fp, sizeof(struct fingerprint));
      bputl(string_index, size);
      expected_end = btell(string_index) + size;
      while (g != f)
	{
	  bputl(string_index, g->id);
	  size = 1;
	  h = g->next;
	  while (h != f && h->id == g->id)
	    {
	      size++;
	      h = h->next;
	    }
	  bputw(string_index, size);
	  h = g;
	  while (g != f && g->id == h->id)
	    {
	      bputw(string_index, (g->type << 12) | 0xfff);
	      g = g->next;
	    }
	}
      ASSERT(btell(string_index) == expected_end);
    }
  string_runs++;
  string_list = NULL;
  sentry_count = 0;
  mp_flush(string_pool);
}

static void
string_end(void)
{
  string_flush();
  bclose(string_index);
  log(L_INFO, "Generated %Ld strings in %d runs", string_cnt, string_runs);
}

static void
string_add(byte *s, uns type)
{
  struct sentry *e;

  if (!(string_cats & (1 << type)))
    return;
  e = mp_alloc(string_pool, sizeof(*e));
  e->next = string_list;
  string_list = e;
  fingerprint(s, &e->fp);
  e->id = card_id;
  e->type = type;
  sentry_count++;
  string_cnt++;
}

struct str_list {
  uns attr, type;
};

static void
string_add_attrs(struct odes *o, struct str_list *strs)
{
  while (strs->attr)
    {
      for (struct oattr *a=obj_find_attr(o, strs->attr); a; a=a->same)
	{
	  byte *x = a->val;
	  while (*x && *x != ' ')
	    x++;
	  if (*x)
	    {
	      *x = 0;
	      string_add(a->val, strs->type);
	      *x = ' ';
	    }
	  else
	    string_add(a->val, strs->type);
	}
      strs++;
    }
}

static void
string_card(struct odes *o, struct card_hdr *hdr)
{
  for (struct card_hdr *h=hdr; h; h=h->next)
    {
      byte *url = obj_find_aval(h->odes, 'U');
      ASSERT(url);
      byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];
      struct url u;
      string_add(url, ST_URL);
      if (!url_canon_split(url, buf1, buf2, &u) && u.host)
	{
	  byte *dot = strchr(u.host, '.');
	  string_add(u.host, ST_HOST);
	  if (dot && strchr(dot+1, '.'))
	    string_add(dot+1, ST_DOMAIN);
	}
      string_add_attrs(h->odes, (struct str_list []) {
	{ 'y', ST_URL },
	{ 0, 0 }
        });
    }

  string_add_attrs(o, (struct str_list []) {
    { 'A', ST_REF },
    { 'F', ST_REF },
    { 'I', ST_REF },
    { 'R', ST_REF },
    { 'Y', ST_REF },
    { 'd', ST_REF },
    { 'f', ST_REF },
    { 0, 0 }
    });

  if (sentry_count >= sentry_limit)
    string_flush();
}

/*
 *  Preprocessing of documents
 */

static byte *doc_buf;
static uns doc_length, doc_length_max;
static uns compat_counter, trim_counter;

static void
preproc_init(void)
{
  doc_buf = xmalloc(doc_buf_size+1) + 1;
  doc_buf[-1] = 0;
}

static void
preproc_end(void)
{
  log(L_INFO, "Upgraded %d cards, trimmed %d, longest was %d chars", compat_counter, trim_counter, doc_length_max);
}

#ifdef CONFIG_COMPAT
static void
preproc_compat_meta(struct odes *o, byte *start, byte *end)
{
  uns x = *end;
  *end = 0;
  obj_add_attr(o, 'M', start);
  *end = x;
}
#endif

static void
preproc_card(struct odes *o)
{
  byte *w = doc_buf;
  byte *stop = doc_buf + doc_buf_size - MAX_ATTR_SIZE;
#ifdef CONFIG_COMPAT
  uns old_version = !obj_find_aval(o, 'v') && !obj_find_aval(o, 'G');
  byte *meta_start = NULL;
  compat_counter += old_version;
#endif

  struct oattr *oa = obj_find_attr(o, 'X');
  byte *r;
  if (oa && (oa->val[0] < 0x80 || oa->val[0] >= 0xc0))
    {
      /* If by any accident the card doesn't start with a category switch, add it */
      /* FIXME: When we become confident with our gatherer, we should turn it to an ASSERT or log(L_ERROR...) */
      *w++ = 0x80 | WT_TEXT;
      r = oa->val;
      goto run_for_it;
    }
  for (; oa; oa=oa->same)
    {
      r = oa->val;
      uns c;

      if (w >= stop)
	{
	  trim_counter++;
	  break;
	}
      if ((*r < 0x80 || *r >= 0xa0) && r[-1])
	*w++ = ' ';
    run_for_it:
      while (c = *r++)
	{
	  if (c < 0x80)
	    *w++ = c;
	  else if (c >= 0xc0)
	    {
	      *w++ = c;
	      while (*r && (c & 0x40))
		{
		  *w++ = *r++;
		  c <<= 1;
		}
	    }
	  else				/* Process a sequence of brackets and category changers */
	    {
	      uns cat = 0x80;
	      for(;;)
		{
		  if (c < 0xa0)		/* Category changes and breaks are compressed */
		    cat = (cat & 0x10) | (c & 0x1f);
		  else
		    {			/* Brackets are to be removed */
		      if (c < 0xb0 && *r)
			r++;
		    }
		  c = *r;
		  if (c < 0x80 || c >= 0xc0)
		    break;
		  r++;
		}
	      if (!(cat & 0x80))
		{
#ifdef CONFIG_COMPAT
		  if (old_version)
		    {
		      if (meta_start)
			{
			  preproc_compat_meta(o, meta_start, w);
			  w = meta_start;
			  meta_start = NULL;
			}
		      static int type_xlat[16] = { 0, WT_TEXT, WT_EMPH, WT_SMALL, ~MT_TITLE, WT_SMALL_HEADING,
						   WT_BIG_HEADING, ~MT_KEYWORD, ~MT_MISC, WT_ALT, WT_LINK, 0, 0, 0, 0, 0 };
		      int nt = type_xlat[cat & 0x0f];
		      if (nt <= 0)
			{
			  ASSERT(nt);
			  meta_start = w;
			  nt = 0x10 | ~nt;
			}
		      cat = nt | (cat & 0x10);
		    }
		  else
		    ASSERT((cat & 0x0f) < 8);
#endif
		  *w++ = 0x80 + cat;
		}
	    }
	}
    }
#ifdef CONFIG_COMPAT
  if (meta_start)
    {
      preproc_compat_meta(o, meta_start, w);
      w = meta_start;
    }
#endif
  *w = 0;
  doc_length = w - doc_buf;
  if (doc_length > doc_length_max)
    doc_length_max = doc_length;
}

/*
 *  Indexing of words
 */

#define LENT_QUANTUM 3
#define LENT_BITE 1024

typedef struct lentry {
  struct lentry *next;
  u32 id;
  u16 count;
  u16 w[LENT_QUANTUM];
} lentry;

static uns lentry_count, lentry_limit;
static struct verbum **used_words, **used_words_last;
static struct mempool *word_pool;
static uns word_runs;
static u64 word_entries, word_cnt;
static byte *approx_word_start;
static uns meta_static_part;

#define LH_CHEWER
#include "indexer/lexhash.h"

static void
lex_load(void)
{
  struct fastbuf *b;
  u32 id;
  struct verbum *v;
  uns i;

  b = bopen(index_name(fn_lex_ordered), O_RDONLY, indexer_fb_size);
  bgetl(b);
  bgetl(b);
  while ((id = bgetl(b)) != ~0UL)
    {
      u32 cnt = bgetl(b);
      enum word_class class = id & 7;
      uns len = bgetc(b);
      if (class == WC_COMPOUND)
	{
	  u32 buf[MAX_COMPLEX_LEN];
	  bread(b, buf, len);
	  len /= 4;
	  v = ch_insert(buf, len);
	  if (!v)
	    die("Malformed lexicon: Duplicate complex");
	}
      else
	{
	  byte buf[MAX_WORD_LEN+1];
	  breadb(b, buf, len);
	  buf[len] = 0;
	  v = lh_insert(buf, 0);
	  if (!v)
	    die("Malformed lexicon: Duplicate word <%s>", buf);
	}
      v->id = id;
      v->u.count = cnt;
    }
  bclose(b);
  lh_rehash(lh_hash_count);		/* Sort the chains by counts */
  ch_rehash(ch_hash_count);
  for (i=0; i<lh_hash_size; i++)
    for (v=lh_hash_table[i]; v; v=v->next)
      v->u.first_lent = NULL;
  for (i=0; i<ch_hash_size; i++)
    for (v=ch_hash_table[i]; v; v=v->next)
      v->u.first_lent = NULL;
  log(L_INFO, "Read lexicon with %d words and %d complexes", lh_hash_count, ch_hash_count);
}

static void
word_flush_single(uns id, lentry *head)
{
  lentry *f, *g;
  uns size;
  sh_off_t expos;

  /* The chain is reversed, flip it back */
  g = NULL;
  while (head)
    {
      f = head->next;
      head->next = g;
      g = head;
      head = f;
    }
  head = g;

  /* Calculate block size */
  size = 0;
  f = head;
  while (f)
    {
      size += 6;
      g = f;
      while (f && f->id == g->id)
	{
	  size += 2*f->count;
	  f = f->next;
	}
    }

  /* Write header */
  bputl(word_index, id);
  bputl(word_index, size);
  expos = btell(word_index) + size;

  /* Write body */
  f = head;
  while (f)
    {
      bputl(word_index, f->id);
      g = f;
      size = 0;
      while (g && g->id == f->id)
	{
	  size += g->count;
	  g = g->next;
	}
      bputw(word_index, size);
      g = f;
      while (f && g->id == f->id)
	{
	  bwrite(word_index, f->w, 2*f->count);
	  f = f->next;
	}
    }

  /* Sanity check */
  if (expos != btell(word_index))
    die("word_flush_single: Internal error, size mismatch");
}

#define ASORT_PREFIX(x) word_##x
#define ASORT_KEY_TYPE u32
#define ASORT_ELT(i) used_words[i]->id
#define ASORT_SWAP(i,j) do { struct verbum *tmp=used_words[i]; used_words[i]=used_words[j]; used_words[j]=tmp; } while(0)
#include "lib/arraysort.h"

static void
word_flush(void)
{
  struct verbum **w, *v;

  word_sort(used_words_last - used_words);
  *used_words_last = NULL;
  for (w=used_words; v = *w; w++)
    {
      word_flush_single(v->id/8, v->u.first_lent);
      v->u.first_lent = NULL;
    }

  mp_flush(word_pool);
  word_runs++;
  word_entries += lentry_count;
  lentry_count = 0;
  used_words_last = used_words;
}

static inline int
word_check(struct verbum *v, u16 pack)
{
  lentry *e = v->u.first_lent;

  while (e && e->id == card_id)
    {
      int i = e->count - 1;
      while (i >= 0)
	{
	  if (e->w[i] == pack)
	    return 1;
	  if ((e->w[i] ^ pack) & 0xfff)
	    return 0;
	  i--;
	}
      e = e->next;
    }
  return 0;
}

static inline void
word_add(struct verbum *v, u16 pack)
{
  lentry *e = v->u.first_lent;
  if (!e || e->id != card_id || e->count >= LENT_QUANTUM)
    {
      /* Trick: we allocate only lentries, so it will be always aligned */
      e = mp_alloc_fast_noalign(word_pool, sizeof(lentry));
      if (!v->u.first_lent)
	*used_words_last++ = v;
      e->next = v->u.first_lent;
      v->u.first_lent = e;
      e->id = card_id;
      e->count = 0;
      lentry_count++;
    }
  e->w[e->count++] = pack;
  word_cnt++;
}

static enum word_class
lm_lookup(enum word_class orig_class, word *uni, uns ulen, word_id_t *idp)
{
  struct verbum *v;

  if (orig_class != WC_NORMAL)
    return orig_class;
  v = lh_lookup(uni, ulen);
  *idp = v;
  return v->id & 7;
}

static void
lm_got_word(uns pos, uns cat, word_id_t w)
{
  if (meta_static_part)
    {
      if (pos < 0x200)
	word_add(w, meta_static_part | (pos << 2));
    }
  else if (pos >= phrase_limit)
    {
      if (!word_check(w, (cat << 12) | 4095))
	word_add(w, (cat << 12) | 4095);
      if (!indexed_words_end)
	indexed_words_end = approx_word_start;
    }
  else
    word_add(w, (cat << 12) | pos);
}

static inline void
lm_got_compound(uns pos, uns cat, word_id_t *w, uns l)
{
  struct verbum *v;

  v = ch_lookup(w, l);
#ifdef CONFIG_COMPAT
  if (!v) return;
#endif
  lm_got_word(pos, cat, v);
}

#define LM_APPROX_TRACK approx_word_start
#include "indexer/lexmap.h"

struct meta_info {
  struct meta_info *next;
  uns static_part;
  byte *text;
};
struct meta_info *meta_first[16], *meta_last[16];

static inline void
word_meta_add(struct oattr *a, struct meta_info *m)
{
  byte *t = a->val;

  if (*t >= '0' && *t <= '3')
    m->static_part = *t++ - '0';
  else
    m->static_part = 0;
  ASSERT(*t >= 0x90 && *t < 0xa0);
  uns type = *t & 0x0f;
  m->static_part |= 0x8000 | (type << 11);
  if (meta_first[type])
    meta_last[type]->next = m;
  else
    meta_first[type] = m;
  meta_last[type] = m;
  m->next = NULL;
  m->text = t;
}

static void
word_meta(struct odes *o, struct card_hdr *hdr, struct card_attr *attr)
{
  bzero(meta_first, sizeof(meta_first));
  for(struct card_hdr *h=hdr; h; h=h->next)
    for (struct oattr *a=obj_find_attr(h->odes, 'M'); a; a=a->same)
      word_meta_add(a, alloca(sizeof(struct meta_info)));
  for(struct oattr *a=obj_find_attr(o, 'M'); a; a=a->same)
    word_meta_add(a, alloca(sizeof(struct meta_info)));

  uns permit_types = (attr->flags & CARD_FLAG_GIANT_CLASS) ? ~giant_ban_meta : ~0U;
  for (uns type=0; type<16; type++)
    if (meta_first[type] && (permit_types & (1 << type)))
      {
	lm_doc_start();
	for (struct meta_info *m=meta_first[type]; m; m=m->next)
	  {
	    meta_static_part = m->static_part;
	    lm_map_text(m->text, m->text + str_len(m->text));
	  }
      }
}

static void
word_card(struct odes *o, struct card_hdr *hdr, struct card_attr *attr)
{
  lm_doc_start();
  indexed_words_end = NULL;
  meta_static_part = 0;
  lm_map_text(doc_buf, doc_buf + doc_length);
  word_meta(o, hdr, attr);
  if (lentry_count >= lentry_limit)
    word_flush();
}

static void
word_init(void)
{
  lh_init();
  lm_init();
  word_index = bopen(index_name(fn_word_index), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  lex_load();
  word_pool = mp_new(sizeof(lentry) * LENT_BITE);
  lentry_limit = word_buf_size / (sizeof(lentry) + sizeof(struct lentry *));
  /*
   * The used_words array is large, but most of it will be probably left unmapped.
   * Unfortunately, we don't have a better bound since lentry_count >= lentry_limit
   * testing is deferred to card end (which is faster and it also guarantees that no
   * ref chain for a (word,card) pair will be split, which is required by wsort).
   */
  used_words_last = used_words = xmalloc(sizeof(struct lentry *) * (lh_hash_count + ch_hash_count + 1));
  DBG("Allocated word pool, lentry_limit=%d", lentry_limit);
}

static void
word_end(void)
{
  word_flush();
  bclose(word_index);
  log(L_INFO, "Generated %Ld word refs in %d runs", word_cnt, word_runs);
  DBG("Used %Ld entries, that is %Ld bytes", word_entries, word_entries * sizeof(lentry));
}

/*
 *  Processing of cards
 */

static void
cards_init(void)
{
  struct card_attr a;

  cards = bopen(index_name(fn_cards), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  card_attrs = bopen(index_name(fn_card_attrs), O_WRONLY | O_CREAT | O_TRUNC, indexer_fb_size);
  bzero(&a, sizeof(a));			/* Create dummy document 0 to make all read ID's be >0 */
  bwrite(card_attrs, &a, sizeof(a));
  card_id++;
}

static void
card_write_start(struct card_attr *attr)
{
  uns align = (1 << CARD_POS_SHIFT) - 1;
  sh_off_t pos;

  bputc(cards, 0);
  pos = btell(cards);
  while (pos & align)
    {
      bputc(cards, 0);
      pos++;
    }
  if ((u64)(pos >> CARD_POS_SHIFT) >= 0xffffffff)
    die("Card file too large. You need to increase CARD_POS_SHIFT in lib/index.h.");
  attr->card = pos >> CARD_POS_SHIFT;
  bwrite(card_attrs, attr, sizeof(*attr));
}

static void
cards_end(void)
{
  struct card_attr a;

  bzero(&a, sizeof(a));			/* Append fake attribute marking end of card file */
  card_write_start(&a);
  bclose(cards);
  bclose(card_attrs);
  log(L_INFO, "Generated %d cards", card_id);
}

static void
card_card(struct odes *o, struct card_hdr *hdr)
{
  /* First of all, dump all headers */
  for (struct card_hdr *h=hdr; h; h=h->next)
    {
      bputs(cards, "(U\n");
      {
	/*
	 * FIXME: We do this only for compatibility with old code which
	 * didn't know anything about nesting and expected per-URL
	 * attributes to follow the URL.
	 */
	obj_move_attr_to_head(h->odes, 'U');
      }
      obj_write_nocheck(cards, h->odes);
      bputs(cards, ")\n");
    }

  /* "N" attributes must go last (needed e.g. by the multiplexer) */
  obj_move_attr_to_tail(o, 'N');

  /* Then dump all other attributes */
  for (struct oattr *at=o->attrs; at; at=at->next)
    if (strchr(card_attr_list, at->attr))
      for (struct oattr *b=at; b; b=b->same)
	{
	  bputc(cards, at->attr);
	  bputsn(cards, b->val);
	}

  /* And finally document contents, but limited to the useful part */
  uns l = indexed_words_end ? indexed_words_end - doc_buf : ~0;
  l = MAX(excerpt_min, l);
  l = MIN(excerpt_max, l);
  if (l)
    {
      if (l < doc_length)
	{
	  uns i, maxl=MIN(l+256, doc_length);
	  for (i=l; i<maxl; i++)
	    if (doc_buf[i] == ' ')
	      break;
	  if (i < maxl)
	    l = i;
	}
      else
	l = doc_length;
      bputc(cards, 'X');
      bwrite(cards, doc_buf, l);
      bputc(cards, '\n');
    }
}

/*
 *  Main loop
 */

static void
chew_card(struct card_attr *attr, struct odes *o, struct card_hdr *hdr)
{
  card_write_start(attr);
  prof_switch(&pr_fetch, &pr_preproc);
  preproc_card(o);
  prof_switch(&pr_preproc, &pr_strings);
  string_card(o, hdr);
  prof_switch(&pr_strings, &pr_words);
  word_card(o, hdr, attr);
  prof_switch(&pr_words, &pr_cards);
  card_card(o, hdr);
  prof_switch(&pr_cards, &pr_fetch);
  card_id++;
  PROGRESS(card_id, "chewer: %d cards", card_id);
}

int
main(int argc, char **argv)
{
  log_init(argv[0]);
  setproctitle_init(argc, argv);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  cards_init();
  preproc_init();
  word_init();
  string_init();

  prof_init(&pr_fetch);
  prof_init(&pr_strings);
  prof_init(&pr_words);
  prof_init(&pr_cards);

  prof_start(&pr_fetch);
  log(L_INFO, "Chewing cards and creating indices");
  fetch_cards(chew_card);
  prof_stop(&pr_fetch);

  preproc_end();
  cards_end();
  word_end();
  string_end();

#ifdef PROFILER
  log(L_DEBUG, "Profile: fetch %s, preproc %s, strings %s, words %s, cards %s", PROF_STR(pr_fetch),
      PROF_STR(pr_preproc), PROF_STR(pr_strings), PROF_STR(pr_words), PROF_STR(pr_cards));
#endif

  return 0;
}
