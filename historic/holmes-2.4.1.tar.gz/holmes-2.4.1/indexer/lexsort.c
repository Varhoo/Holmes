/*
 *	Sherlock Indexer -- Final Lexicon Sorting
 *
 *	(c) 2001--2003 Martin Mares <mj@ucw.cz>
 *
 *	This module sorts all words and complexes to an order convenient
 *	for the search server.
 *
 *	RAM required: (n_words+n_cplx)*PTR + MAX(lex_size + MAX(n_words,n_cplx)*PTR, max_stem_pairs)
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/unaligned.h"
#include "lib/pools.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"

#include <stdlib.h>
#include <fcntl.h>

static struct lex_entry **word_array, **cplx_array, **word_array_orig;
static uns n_words, n_cplx, n_lex;
static u32 *xlat_table;  /* Shares space with word_array_orig */

#define ASORT_PREFIX(x) word_##x
#define ASORT_KEY_TYPE struct lex_entry *
#define ASORT_LT(x,y) word_lt(x,y)
#define ASORT_ELT(i) word_array[i]

static int
word_lt(struct lex_entry *x, struct lex_entry *y)
{
  byte *xx = x->w;
  byte *yy = y->w;
  byte *xend = xx + x->length;
  byte *yend = yy + y->length;
  uns xu, yu, xuu, yuu;
  int pass1 = -1, pass2 = -1;

  while (xx < xend && yy < yend)
    {
      GET_UTF8(xx, xu);
      GET_UTF8(yy, yu);
      xuu = Uunaccent(xu);
      yuu = Uunaccent(yu);
      if (pass1 < 0)
	{
	  if (xuu < yuu)
	    pass1 = 1;
	  else if (xuu > yuu)
	    pass1 = 0;
	}
      if (pass2 < 0)
	{
	  if (xu < yu)
	    pass2 = 1;
	  else if (xu > yu)
	    pass2 = 0;
	}
    }
  if (yy < yend)
    return 1;
  if (xx < xend)
    return 0;
  if (pass1 >= 0)
    return pass1;
  if (pass2 >= 0)
    return pass2;
  ASSERT(x == y);
  return 0;
}

#include "lib/arraysort.h"

#define ASORT_PREFIX(x) cplx_##x
#define ASORT_KEY_TYPE struct lex_entry *
#define ASORT_LT(x,y) cplx_lt(x,y)
#define ASORT_ELT(i) cplx_array[i]

static int
cplx_lt(struct lex_entry *x, struct lex_entry *y)
{
  if (x == y)
    return 0;
  if (x->length < y->length)
    return 1;
  if (x->length > y->length)
    return 0;
  for (uns i=0; i<x->length; i+=4)
    {
      u32 a = GET_U32(&x->w[i]);
      u32 b = GET_U32(&y->w[i]);
      if (a < b)
	return 1;
      if (a > b)
	return 0;
    }
  ASSERT(0);
}

#include "lib/arraysort.h"

static inline uns
id_renumber(uns id)
{
  uns i = id/8 - 1;
  ASSERT(i < n_lex && xlat_table[i]);
  return xlat_table[i] | (id&7);
}

static void
cplx_renumber(void)
{
  for (uns i=0; i<n_cplx; i++)
    {
      struct lex_entry *e = cplx_array[i];
      for (uns j=0; j<e->length; j+=4)
	PUT_U32(&e->w[j], id_renumber(GET_U32(&e->w[j])));
    }
}

#ifdef CONFIG_LANG
struct stem_pair {
  u32 stem, derived;
};

static struct stem_pair *stem_array;

#define ASORT_PREFIX(x) stem_##x
#define ASORT_KEY_TYPE struct stem_pair
#define ASORT_LT(x,y) stem_lt(x,y)
#define ASORT_ELT(i) stem_array[i]

static int
stem_lt(struct stem_pair x, struct stem_pair y)
{
  return x.stem < y.stem || x.stem == y.stem && x.derived < y.derived;
}

#include "lib/arraysort.h"

static void
stems_renumber(void)
{
  struct fastbuf *in = bopen(index_name(fn_stems_ordered), O_RDONLY, indexer_fb_size);
  struct fastbuf *out = bopen(index_name(fn_stems), O_WRONLY|O_CREAT|O_TRUNC, indexer_fb_size);
  uns i, j, stid, lama, x;
  while ((stid = bgetl(in)) != ~0U)
    {
      lama = bgetl(in);
      bputl(out, stid);
      bputl(out, lama);
      sh_off_t start_pos = btell(in);
      while ((x = bgetl(in)) != ~0U)
	bgetl(in);
      uns cnt = (btell(in) - start_pos) / 8;
      stem_array = xmalloc(sizeof(struct stem_pair) * cnt);
      bsetpos(in, start_pos);
      for (i=0; i<cnt; i++)
	{
	  stem_array[i].stem = bgetl(in);
	  if (stid != 0x80000000)
	    stem_array[i].stem = id_renumber(stem_array[i].stem);
	  stem_array[i].derived = bgetl(in);
	  if (stid != 0x80000001)
	    stem_array[i].derived = id_renumber(stem_array[i].derived);
	}
      bgetl(in);
      stem_sort(cnt);
      i = 0;
      while (i < cnt)
	{
	  j = i;
	  while (j < cnt && stem_array[j].stem == stem_array[i].stem)
	    j++;
	  bputl(out, 0x80000000 | stem_array[i].stem);
	  while (i < j)
	    bputl(out, stem_array[i++].derived);
	}
      bputl(out, ~0U);
      xfree(stem_array);
    }
  bclose(in);
  bclose(out);
}
#endif

int
main(int argc, char **argv)
{
  log_init(argv[0]);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  /* Read the input */
  struct mempool *pool = mp_new(65536);
  struct fastbuf *in = bopen(index_name(fn_lex_words), O_RDONLY, indexer_fb_size);
  uns i, j;
  n_words = bgetl(in);
  n_cplx = bgetl(in);
  n_lex = n_words + n_cplx;
  log(L_INFO, "Reading lexicon: %d words + %d complexes", n_words, n_cplx);
  word_array_orig = xmalloc(n_lex * sizeof(struct lex_entry *));
  for (i=0; i<n_lex; i++)
    {
      struct lex_entry le, *e;
      breadb(in, &le, sizeof(le));
      e = mp_alloc_fast_noalign(pool, sizeof(le) + le.length);
      memcpy(e, &le, sizeof(le));
      breadb(in, e->w, le.length);
      word_array_orig[i] = e;
    }
  bclose(in);

  /* Prepare output file */
  struct fastbuf *out = bopen(index_name(fn_lexicon), O_WRONLY|O_CREAT|O_TRUNC, indexer_fb_size);
  bputl(out, n_words);
  bputl(out, n_cplx);

  /* Sort and dump words */
  log(L_INFO, "Sorting words");
  word_array = xmalloc(sizeof(struct lex_entry *) * n_words);
  i = 0;
  for (j=0; j<n_lex; j++)
    if (word_array_orig[j]->class != WC_COMPOUND)
      word_array[i++] = word_array_orig[j];
  ASSERT(i == n_words);
  word_sort(n_words);
  for (uns i=0; i<n_words; i++)
    {
      bwrite(out, word_array[i], sizeof(struct lex_entry) + word_array[i]->length);
      PUT_U32(word_array[i]->ref_pos, 8*i+8);  /* Misuse ref_pos for new word ID */
    }
  xfree(word_array);

  /* Renumber, sort and dump complexes */
  log(L_INFO, "Sorting complexes");
  cplx_array = xmalloc(sizeof(struct lex_entry *) * n_cplx);
  i = 0;
  xlat_table = (u32 *) word_array_orig;
  for (j=0; j<n_lex; j++)
    {
      if (word_array_orig[j]->class == WC_COMPOUND)
	{
	  cplx_array[i++] = word_array_orig[j];
	  xlat_table[j] = 0;
	}
      else
	xlat_table[j] = GET_U32(word_array_orig[j]->ref_pos);
    }
  ASSERT(i == n_cplx);
  cplx_renumber();
  cplx_sort(n_cplx);
  for (uns i=0; i<n_cplx; i++)
    {
      struct lex_entry *c = cplx_array[i];
      bwrite(out, c->ref_pos, BYTES_PER_O + 2);
      bwrite(out, c->w, c->length-4);
      bputl(out, GET_U32(c->w+c->length-4) & ~7U);
    }
  bclose(out);
  xfree(cplx_array);
  mp_delete(pool);

#ifdef CONFIG_LANG
  /* Renumber, sort and dump stem expansions */
  log(L_INFO, "Sorting stem expansions");
  stems_renumber();
#endif
  return 0;
}
