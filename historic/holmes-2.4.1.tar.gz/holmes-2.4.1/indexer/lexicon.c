/*
 *	Sherlock Indexer -- Lexicon Functions
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/pools.h"
#include "charset/unicode.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
 *  Configurable parameters
 */

struct lexicon_config lexicon_config = {
  .min_len_ign = 1,
  .min_len = 1,
  .max_len = MAX_WORD_LEN,
  .max_hex_len = MAX_WORD_LEN,
  .max_ctrl_len = MAX_WORD_LEN,
  .max_preps = 3,
  .max_postps = 3,
  .max_gap = 3,
};

struct list lex_exceptions;

#define	MAX_WORDS_PER_LINE 32

static byte *
lex_parse_words(struct cfitem *c, byte *value)
{
  byte *w[MAX_WORDS_PER_LINE];
  int i, cnt;
  cnt = wordsplit(value, w, MAX_WORDS_PER_LINE);
  for (i=0; i<cnt; i++)
    {
      struct exception *f = cfg_malloc(sizeof(struct exception));
      f->w = w[i];
      switch (c->name[7])
	{
	case 'o': f->class = WC_IGNORED; break;
	case 'm': f->class = WC_NORMAL; break;
	case 'b': f->class = WC_GARBAGE; break;
	case 'p': f->class = WC_PREPOSITION; break;
	case 't': f->class = WC_POSTPOSITION; break;
	default: ASSERT(0);
	}
      add_tail(&lex_exceptions, &f->n);
    }
  return NULL;
}

static struct cfitem lex_config[] = {
  { "Lexicon",		CT_SECTION,	NULL },
  { "MinWordLenIgnore",	CT_INT,		&lex_min_len_ign },
  { "MinWordLen",	CT_INT,		&lex_min_len },
  { "MaxWordLen",	CT_INT,		&lex_max_len },
  { "MaxHexWordLen",	CT_INT,		&lex_max_hex_len },
  { "MaxCtrlWordLen",	CT_INT,		&lex_max_ctrl_len },
  { "WordIgnored",	CT_FUNCTION,	lex_parse_words },
  { "WordNormal",	CT_FUNCTION,	lex_parse_words },
  { "WordGarbage",	CT_FUNCTION,	lex_parse_words },
  { "WordPreposition",	CT_FUNCTION,	lex_parse_words },
  { "WordPostposition",	CT_FUNCTION,	lex_parse_words },
  { "MaxPreps",		CT_INT,		&lex_max_preps },
  { "MaxPostps",	CT_INT,		&lex_max_postps },
  { "MaxGap",		CT_INT,		&lex_max_gap },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR lexconf_init(void)
{
  init_list(&lex_exceptions);
  cf_register(lex_config);
}
