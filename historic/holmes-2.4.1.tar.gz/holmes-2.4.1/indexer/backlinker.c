/*
 *	Sherlock Indexer -- Processing of Frames, Backlinks and Image Referers
 *
 *	(c) 2002--2003 Martin Mares <mj@ucw.cz>
 *
 *	This module performs four tasks:
 *
 *	  (1) It locates redirect chains according to redirect edges in the link
 *	      graph, ensures that all redirects are marked with CARD_FLAG_EMPTY
 *	      and writes the ultimate destination of each redirect in the Merges
 *	      array. It also generates redirect backlink labels.
 *
 *	  (2) It converts framesets to redirects to the largest frame if requested.
 *
 *	  (3) It calculates highest superframe information for all pages
 *     	      which belong to a frameset and generates frame backlink labels
 *	      from them, properly following redirects along the way. Frame edges
 *	      and the calculated redirects are used for this task.
 *
 *	  (4) For each page it calculates the largest weight page pointing to
 *	      the one in question.
 *
 *	  (5) The same for image references.
 */

#include "lib/lib.h"
#include "lib/url.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "indexer/indexer.h"
#include "indexer/merges.h"

#include <stdlib.h>
#include <fcntl.h>

static struct fastbuf *graph, *frame_graph, *image_graph, *label_graph;
static struct fastbuf *labels, *url_list;
static struct card_attr *attrs;
static u32 *merges;
static uns merges_size, attrs_size, card_count;

static uns max_frame_depth = ~0;

static struct cfitem back_config[] = {
  { "Backlinker",	CT_SECTION,	NULL },
  { "MaxFrameDepth",	CT_INT,		&max_frame_depth },
  { NULL,		CT_STOP,	NULL }
};

static void
flatten_merges(void)
{
  for (uns x=0; x<card_count; x++)
    if (merges[x] != ~0U)
      merges[x] = merges_find_root(merges, x);
}

static void
analyse_redirs(void)
{
  s32 v;
  uns d, x, y, loops, cnt;
  u32 w, t;

  loops = cnt = 0;
  while ((v = bgetl(graph)) >= 0)
    {
      d = bgetw(graph);
      while (d--)
	{
	  w = bgetl(graph);
	  t = w & ETYPE_MASK;
	  w &= ~ETYPE_MASK;
	  ASSERT((uns)v < card_count && w < card_count);
	  /* Found edge v->w of type t */
	  switch (t)
	    {
	    case ETYPE_REDIRECT:
	      cnt++;
	      x = merges_find_root(merges, v);
	      y = merges_find_root(merges, w);
	      if (x != y)
		merges[x] = y;
	      else
		loops++;
	      break;
	    case ETYPE_FRAME:
	      bputl(frame_graph, v);
	      bputl(frame_graph, w);
	      break;
	    case ETYPE_IMAGE:
	      bputl(image_graph, v);
	      bputl(image_graph, w);
	      break;
	    default: ;
	      /* ignore the edge */
	    }
	}
    }

  flatten_merges();
  log(L_INFO, "Found %d redirects, %d loops broken", cnt, loops);
}

static void
create_backlinks(void)
{
  uns x, y;
  uns bls=0, trees=0;

  for (x=0; x<card_count; x++)
    if (merges[x] != ~0U && merges[x] != ~1U)
      {
	y = merges[x];
	bputl(label_graph, y | ETYPE_REDIRECT);
	bputl(label_graph, x);
	bls++;
	if (merges[y] == ~0U)
	  {
	    merges[y] = ~1U;
	    trees++;
	  }
      }
  for (x=0; x<card_count; x++)
    if (merges[x] == ~1U)
      merges[x] = ~0U;

  log(L_INFO, "Created %d redirect backlinks in %d trees", bls, trees);
}

static uns
follow_redirects(uns x)
{
  return (merges[x] == ~0U) ? x : merges[x];
}

static void
analyse_subframes(void)
{
  u32 *sizes = xmalloc(4*card_count);
  u32 *subf = xmalloc(4*card_count);
  uns chg, passes=1, cnt=0;
  uns x, v, w;

  struct fastbuf *notes = bopen(index_name(fn_notes), O_RDONLY, indexer_fb_size);
  struct card_note note;
  for (x=0; x<card_count; x++)
    {
      breadb(notes, &note, sizeof(note));
      if (attrs[x].flags & CARD_FLAG_FRAMESET)
	sizes[x] = 0;
      else
	sizes[x] = note.useful_size;
      subf[x] = x;
    }
  bclose(notes);

  do
    {
      chg = 0;
      bsetpos(frame_graph, 0);
      while ((v = bgetl(frame_graph)) != ~0U)
	{
	  w = bgetl(frame_graph);
	  w = follow_redirects(w);
	  if (sizes[v] < sizes[w])
	    {
	      sizes[v] = sizes[w];
	      subf[v] = subf[w];
	      chg++;
	    }
	}
      log(L_DEBUG, "Pass %d: %d changes", passes, chg);
    }
  while (chg && ++passes < max_frame_depth);

  for (x=0; x<card_count; x++)
    if (subf[x] != x)
      {
	cnt++;
	v = merges_find_root(merges, x);
	w = merges_find_root(merges, subf[x]);
	if (v != w)
	  merges[v] = w;
      }

  flatten_merges();
  xfree(sizes);
  xfree(subf);
  log(L_INFO, "Converted %d framesets to redirects in %d passes", cnt, passes);
}

static void
analyse_superframes(void)
{
  u32 *superframe;
  uns i, chg, cnt=0, passes=1;
  u32 v, w, vv;

  superframe = xmalloc(4*card_count);
  for (i=0; i<card_count; i++)
    superframe[i] = ~0U;

  do
    {
      chg = 0;
      bsetpos(frame_graph, 0);
      while ((v = bgetl(frame_graph)) != ~0U)
	{
	  w = bgetl(frame_graph);
	  w = follow_redirects(w);
	  vv = (superframe[v] == ~0U) ? v : superframe[v];
	  if (superframe[w] == ~0U ||
	      attrs[superframe[w]].weight < attrs[vv].weight)
	    {
	      superframe[w] = vv;
	      chg++;
	    }
	}
      log(L_DEBUG, "Pass %d: %d changes", passes, chg);
    }
  while (chg && ++passes < max_frame_depth);

  for (i=0; i<card_count; i++)
    if (superframe[i] != ~0U)
      {
	bputl(label_graph, i | ETYPE_FRAME);
	bputl(label_graph, superframe[i]);
	cnt++;
      }

  xfree(superframe);
  log(L_INFO, "Calculated superframes for %d cards in %d passes", cnt, passes);
}

static void
analyse_links(void)
{
  u32 *best;
  u32 v, w, d;
  uns cnt=0, lcnt=0;

  best = xmalloc(4*card_count);
  for (v=0; v<card_count; v++)
    best[v] = ~0U;

  while ((v = bgetl(graph)) != ~0U)
    {
      d = bgetw(graph);
      while (d--)
	{
	  w = bgetl(graph);
	  if ((w & ETYPE_MASK) != ETYPE_NORMAL)
	    continue;
	  w &= ~ETYPE_MASK;
	  v = follow_redirects(v);
	  w = follow_redirects(w);
	  if (v == w)
	    continue;
	  cnt++;
	  if (best[w] == ~0U || attrs[v].weight > attrs[best[w]].weight)
	    best[w] = v;
	}
    }

  for (v=0; v<card_count; v++)
    if (best[v] != ~0U)
      {
	bputl(label_graph, v | ETYPE_NORMAL);
	bputl(label_graph, best[v]);
	lcnt++;
      }

  xfree(best);
  log(L_INFO, "Processed %d refs to %d backlinks", cnt, lcnt);
}

static void
analyse_image_links(void)
{
  uns cnt=0, lcnt=0;
  u32 v, w;
  u32 *best;

  best = xmalloc(4*card_count);
  for (v=0; v<card_count; v++)
    best[v] = ~0U;

  while ((v = bgetl(image_graph)) != ~0U)
    {
      w = bgetl(image_graph);
      v = follow_redirects(v);
      w = follow_redirects(w);
      if (best[w] == ~0U || attrs[v].weight > attrs[best[w]].weight)
	best[w] = v;
      cnt++;
    }

  for (v=0; v<card_count; v++)
    if (best[v] != ~0U)
      {
	bputl(label_graph, v | ETYPE_IMAGE);
	bputl(label_graph, best[v]);
	lcnt++;
      }

  xfree(best);
  log(L_INFO, "Processed %d image refs to %d backlinks", cnt, lcnt);
}

struct edge {
  u32 v, w;
};

#define SORT_KEY struct edge
#define SORT_PREFIX(x) edge_##x
#define SORT_PRESORT
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static int
edge_compare(struct edge *e, struct edge *f)
{
  return (e->w > f->w) - (e->w < f->w);
}

static int
edge_fetch_key(struct fastbuf *f, struct edge *e)
{
  e->v = bgetl(f);
  if (e->v == ~0U)
    return 0;
  e->w = bgetl(f);
  return 1;
}

static byte *
edge_fetch_item(struct fastbuf *src UNUSED, struct edge *e, byte *limit UNUSED)
{
  return (byte *)(e+1);
}

static void
edge_store_item(struct fastbuf *dest, struct edge *e)
{
  bputl(dest, e->v);
  bputl(dest, e->w);
}

static void
edge_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct edge *e)
{
  edge_store_item(dest, e);
}

#include "lib/sorter.h"

static void
write_backlinks(void)
{
  u32 v, w, urli;
  uns type, cnt=0;
  byte buf[MAX_URL_SIZE];

  label_graph = edge_sort(label_graph);
  labels = bopen(index_name(fn_labels_by_id), O_WRONLY | O_APPEND, indexer_fb_size);
  url_list = bopen(index_name(fn_urls), O_RDONLY, indexer_fb_size);

  urli = 0;
  bgets(url_list, buf, sizeof(buf));
  while ((v = bgetl(label_graph)) != ~0U)
    {
      switch (v & ETYPE_MASK)
	{
	case ETYPE_NORMAL:
	  type = 'z'; break;
	case ETYPE_REDIRECT:
	  type = 'y'; break;
	case ETYPE_IMAGE:
	  type = 'i'; break;
	case ETYPE_FRAME:
	  type = 'b'; break;
	default:
	  ASSERT(0);
	}
      v &= ~ETYPE_MASK;
      w = bgetl(label_graph);
      while (urli < w)
	{
	  if (!bgets(url_list, buf, sizeof(buf)))
	    die("write_backlinks: object %d not found", w);
	  urli++;
	}
      bputl(labels, v);
      bputc(labels, (attrs[w].weight < 0xff) ? attrs[w].weight : 0xfe);
      bputc(labels, type);
      bputs0(labels, buf);
      bputc(labels, 0);
      cnt++;
    }

  bclose(url_list);
  bclose(labels);
  log(L_INFO, "Created %d backlinks", cnt);
}

int
main(int argc, char **argv)
{
  uns i;

  log_init(argv[0]);
  cf_register(back_config);
  if (cf_getopt(argc, argv, CF_SHORT_OPTS, CF_NO_LONG_OPTS, NULL) >= 0 ||
      optind < argc)
  {
    fputs("This program supports only the following command-line arguments:\n" CF_USAGE, stderr);
    exit(1);
  }

  merges = mmap_file(index_name(fn_merges), &merges_size, 1);
  card_count = merges_size/4;
  attrs = mmap_file(index_name(fn_attributes), &attrs_size, 1);

  /* Scan the graph, analyse redirects and extract frame and image edges */
  graph = bopen(index_name(fn_link_graph), O_RDONLY, indexer_fb_size);
  frame_graph = bopen_tmp(indexer_fb_size);
  image_graph = bopen_tmp(indexer_fb_size);
  label_graph = bopen_tmp(indexer_fb_size);
  log(L_INFO, "Analysing redirects");
  analyse_redirs();
  bsetpos(graph, 0);
  bflush(frame_graph);
  bsetpos(frame_graph, 0);
  bflush(image_graph);
  bsetpos(image_graph, 0);

  /* Analyse subframes and superframes */
  if (frameset_to_redir)
    analyse_subframes();
  analyse_superframes();
  bclose(frame_graph);

  /* Analyse normal links */
  analyse_links();
  bclose(graph);

  /* Analyse image links */
  analyse_image_links();
  bclose(image_graph);

  /* Create backlink labels */
  create_backlinks();
  bflush(label_graph);
  bsetpos(label_graph, 0);
  write_backlinks();
  bclose(label_graph);

  /* Fix attributes */
  log(L_INFO, "Fixing attributes");
  for (i=0; i<card_count; i++)
    if (merges[i] != ~0U)
      {
	uns j = merges[i];
	if (!(attrs[i].flags & CARD_FLAG_EMPTY))
	  {
	    if (attrs[j].flags & CARD_FLAG_EMPTY)
	      {
		/*
		 *  If we redirect a non-empty page to an empty page (which can happen
		 *  e.g. in case of redirects to redirects to unknown pages), ignore
		 *  the first redirect.
		 */
		merges[i] = ~0U;
	      }
	    else
	      {
		/* Force redirect sources to be ignored */
		attrs[i].flags |= CARD_FLAG_EMPTY;
	      }
	  }
	if (attrs[i].weight > attrs[j].weight)
	  attrs[j].weight = attrs[i].weight;
      }
  munmap_file(attrs, attrs_size);
  munmap_file(merges, merges_size);

  return 0;
}
