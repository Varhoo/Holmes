/*
 *	Base 64 Encoding & Decoding
 *
 *	(c) 2002, Robert Spalek <robert@ucw.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU Lesser General Public License.
 */

uns base64_encode(byte *dest, byte *src, uns len);
uns base64_decode(byte *dest, byte *src, uns len);

/*
 * Use this macro to calculate buffer size.
 */
#define BASE64_ENC_LENGTH(x) (((x)+2)/3 *4)

/*
 * When called for BASE64_IN_CHUNK-byte chunks, the result will be
 * always BASE64_OUT_CHUNK bytes long. If a longer block is split
 * to such chunks, the result will be identical.
 */
#define BASE64_IN_CHUNK 3
#define BASE64_OUT_CHUNK 4

