/*
 *	Sherlock Language Processing Library
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

#ifndef _LANG_LANG_H
#define _LANG_LANG_H

#include "lib/lists.h"

/*
 *  Each language gets its own code (0..31). Codes are assigned in the
 *  configuration file, but code 0 is reserved for documents with
 *  unrecognized language.
 */

#define LANG_UNKNOWN 0

#define MAX_LANGUAGES 32

extern uns lang_count;			/* Number of language codes used */

int lang_name_to_code(byte *name);	/* Names as defined by RFC 1766 */
byte *lang_code_to_name(uns code);
int lang_list_to_code(byte *langs);	/* Extract the primary language from a list (as per RFC 2068) */

/*
 *  Stemmers (lemmatizers)
 */

struct stemmer {
  node n;
  u32 lang_mask;			/* Languages this stemmer applies to */
  byte *name;				/* Name of the stemmer */
  uns id;				/* ... and its internal ID */
  byte *params;				/* Additional stemmer-specific parameters */
  void *priv;				/* Data private to the stemmer */
};

struct stemmer_result {
  node n;
  byte *stem;
};

extern list stemmer_list;
struct mempool;
list *lang_stem(struct stemmer *st, byte *src, struct mempool *mp);
void lang_init_stemmers(void);

/*
 *  Synonymic dictionaries
 */

struct syndict {
  node n;
  u32 lang_mask;
  byte *name;
  struct fastbuf *fb;
};

extern list syndict_list;
void syndict_open(struct syndict *sd);
byte **syndict_read_entry(struct syndict *sd, struct mempool *mp);
void syndict_close(struct syndict *sd);

#endif
