/*
 *	Sherlock Language Processing Library -- List of Stemmers
 *
 *	(c) 2003 Martin Mares <mj@ucw.cz>
 */

STEMMER(porter)

#ifdef CONFIG_UFAL_STEMMER
STEMMER(ufal)
#endif
