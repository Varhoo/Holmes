#!/bin/bash
#
#  Sherlock Search Server Keeper Script
#  (c) 2002 Martin Mares <mj@ucw.cz>
#

ulimit -c unlimited

if [ "$UID" = 0 ] ; then
	echo >&2 "skeeper: Must not be run as root!"
	exit 1
fi
if [ -n "$1" ] ; then
	echo >&2 "skeeper: You probably meant scontrol $@, didn't you?"
	exit 1
fi

eval `bin/config SKeeper TestRetry TestWait CrashMail RotateLogs CrashWaitThreshold CrashWaitCeiling DaemonPIDFile KeeperPIDFile TestQuery SwapLock SwapLockTimeout`

leow=0
while true ; do
	`pwd`/bin/sherlockd &
	P=$!
	echo $P >$CF_DaemonPIDFile
	wait $P
	RC=$?
	if [ -n "$CF_CrashMail" ] ; then
		(
			echo Exit code: $RC
			echo Host: `hostname`
			echo Directory: `pwd`
			echo Last words:
			tail `ls -1t log/sherlockd* | head -1`
		) | mail -s "sherlockd@`hostname` crashed" $CF_CrashMail
	fi
	now=`date +%s`
	if [ $(($now-$leow)) -gt $CF_CrashWaitThreshold ] ; then
		delay=1
	elif [ $delay -lt $CF_CrashWaitCeiling ] ; then
		delay=$((2*$delay))
	fi
	sleep $delay
	leow=$now
done
