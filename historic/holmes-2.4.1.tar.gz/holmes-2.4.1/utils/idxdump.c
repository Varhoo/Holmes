/*
 *	Sherlock Utilities -- Index Dumper
 *
 *	(c) 2001--2003 Robert Spalek <robert@ucw.cz>
 *	(c) 2002--2003 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/fastbuf.h"
#include "lib/bucket.h"
#include "lib/chartype.h"
#include "charset/unicode.h"
#include "charset/charconv.h"
#include "indexer/indexer.h"
#include "indexer/lexicon.h"
#include "indexer/params.h"
#include "utils/dumpconfig.h"
#include "lang/lang.h"

#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

static int term_charset_id;
static struct conv_context conv_utf8;
static int verbose;				/* Expand object attribute names?  */
static int bare;				/* Avoid headings */

/* Maximal input line length.  */
#define	BUFSIZE	2048

static void
dump_card_attr(u64 id, void *tmp)
{
	struct card_attr *a = tmp;
	byte *attrs = "EADMIFG*";
	byte at[9];
	byte tf[32];
	uns i;

	if (!a)
	{
		if (!verbose)
			printf("ID       Card     SiteID   Wgt %s Age Type\n", attrs);
		return;
	}
	for (i=0; i<8; i++)
	  at[i] = (a->flags & (1<<i)) ? attrs[i] : '-';
	at[i] = 0;
#ifdef CONFIG_FILETYPE
	byte *x = tf + sprintf(tf, "%02x %s", a->type_flags, custom_file_type_names[CA_GET_FILE_TYPE(a)]);
	if (!(a->type_flags & 0x80))
	  sprintf(x, ", %s", lang_code_to_name(CA_GET_FILE_LANG(a)));
	if (a->type_flags & 0x80)
		sprintf(x, " other: %d/%d", CA_GET_FILE_TYPE(a), CA_GET_FILE_INFO(a));
#else
	tf[0] = 0;
#endif
	if (verbose)
	{
		printf("Attribute %x:\n", (u32) id);
		printf("Card:\t%x\n", a->card);
		printf("Weight:\t%d\n", a->weight);
		printf("Flags:\t%s\n", at);
#ifdef CONFIG_LASTMOD
		printf("Age:\t%d\n", a->age);
#endif
#ifdef CONFIG_FILETYPE
		printf("Type:\t%s\n", tf);
#endif
#define INT_ATTR(id,keywd,gf,pf) printf("Custom " #id ":\t%x\n", gf(a));
#define SMALL_SET_ATTR(id,keywd,gf,pf) printf("Custom " #id ":\t%x\n", gf(a));
  EXTENDED_ATTRS
#undef INT_ATTR
#undef SMALL_SET_ATTR
		putchar('\n');
	}
	else
	{
		printf("%8x %8x %08x %3d %s %3d %s\n",
			(u32) id, a->card,
		       0,
		       a->weight, at,
#ifdef CONFIG_LASTMOD
		       a->age,
#else
		       0,
#endif
		       tf
		       );
	}
}

static void
dump_note(u64 id, void *tmp)
{
	struct card_note *n = tmp;

	if (!n)
	{
		printf("ID       USize\n");
		return;
	}
	printf("%8x %6d\n", (u32) id, n->useful_size);
}

static void
dump_checksum(u64 id, void *tmp)
{
	struct csum *c = tmp;
	int i;
	if (!tmp)
	{
		if (!verbose)
			printf("Pos      MD5                              CardID\n");
		return;
	}
	if (verbose)
	{
		printf("Checksum at %x:\n", (u32) id);
		printf("MD5:\t");
		for (i=0; i<16; i++)
			printf("%02x", c->md5[i]);
		printf("\n");
		printf("Card:\t%08x\n\n", c->cardid);
	}
	else
	{
		printf("%08x ", (u32) id);
		for (i=0; i<16; i++)
			printf("%02x", c->md5[i]);
		printf(" %08x\n", c->cardid);
	}
}

static void
dump_fingerprint(u64 id, void *tmp)
{
	struct fprint *c = tmp;
	int i;
	if (!c)
	{
		if (!verbose)
			printf("ID       Fingerprint              CardID\n");
		return;
	}
	if (verbose)
	{
		printf("Fingerprint at %x:\n", (u32) id);
		printf("Hash:\t");
		for (i=0; i<12; i++)
			printf("%02x", c->fp.hash[i]);
		printf("\n");
		printf("Card:\t%08x\n\n", c->cardid);
	}
	else
	{
		printf("%08x ", (u32) id);
		for (i=0; i<12; i++)
			printf("%02x", c->fp.hash[i]);
		printf(" %08x\n", c->cardid);
	}
}

static void
dump_signatures(u64 id, void *tmp)
{
	uns *c = tmp;
	uns i;
	if (!tmp)
	{
		if (!verbose)
			printf("Pos      CardID   Signatures\n");
		return;
	}
	if (verbose)
	{
		printf("Checksum at %x:\n", (u32) id);
		printf("Card:\t%08x\n", *c++);
		printf("Signatures:\t");
		for (i=0; i<matcher_signatures; i++)
			printf("%08x ", c[i]);
		printf("\n\n");
	}
	else
	{
		printf("%08x ", (u32) id);
		printf("%08x", *c++);
		for (i=0; i<matcher_signatures; i++)
			printf(" %08x", c[i]);
		printf("\n");
	}
}

static void
dump_card(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	byte newline = 1, breakline = 0;
	byte attr = 0;
	uns len = 0;
	u32 id;

	if (!f)
		return;
	ASSERT(!(start & ((1 << CARD_POS_SHIFT) - 1)));
	id = start >> CARD_POS_SHIFT;
	printf("### %08x %d %d\n", id, 0, 0);
	for(;;)
	{
		int c = bgetc(f);
		if (c == EOF)
			die("Incomplete card entry");
		if (!c)
			break;
		if (c == '\n')
		{
			newline = 1;
			breakline = 0;
			len = 0;
		}
		else
		{
			if (newline)
			{
				attr = c;
				newline = 0;
			}
			len++;
		}
		if (len >= line_len)
			breakline = 1;
		if (breakline &&
			(Cspace(c)
			|| len >= 192 && Cctrl(c)
			|| len >= 256 && (c < 0x80 || c >= 0xc0)) )
		{
			printf("\\\n%c", attr);
			if (!Cspace(c))
				putc(c, stdout);
			breakline = 0;
			len = 0;
		}
		else
		{
			/* We will *NOT* recode the UTF-8 characters,
			 * because the output in this mode should be
			 * piped to objdump, which recodes the data
			 * itself and performs the formatting.
			 */
			putc(c, stdout);
		}
	}
	while (btell(f) & ((1 << CARD_POS_SHIFT) - 1))
		bgetc(f);
}

struct lab {
	u32 id;
	u32 source_id;
	u32 count;
} PACKED;

static void
dump_labels(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct lab label;
	uns i;

	if (!f)
		return;
	breadb(f, &label, sizeof(struct lab));
	printf("Label at %08qx:\n", start);
	printf("ID:\t%08x\n", label.id);
	printf("Source ID:\t%08x\n", label.source_id);
	printf("Count:\t%d\n", label.count);
	printf("Labels:\n\t");
	for (i=0; i<label.count; i++)
	{
		byte c = bgetc(f);
		if (!c)
			printf("\n\t");
		else
			putc(c, stdout);
		start++;
	}
	printf("\n");
}

static void
dump_labels_id(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u32 id;
	uns pri;

	if (!f)
		return;

	id = bgetl(f);
	pri = bgetc(f);
	printf("Label block at %08qx for ID %08x, priority %d\n\t", start, id, pri);
	while (1)
	{
		int c;
		while ((c = bgetc(f)) != 0 && c != EOF)
			putc(c, stdout);
		printf("\n\t");
		c = bgetc(f);
		if (!c || c == EOF)
			break;
		bungetc(f);
	}
	printf("\n");
}

static void
print_recoded_string(byte *str, uns len)
{
	struct conv_context *cc = &conv_utf8;
	byte recoded[MAX_WORD_LEN+1];
	int flags;
	cc->source = str;
	cc->source_end = str + len;
	cc->dest = cc->dest_start = recoded;
	cc->dest_end = recoded + MAX_WORD_LEN+1;
	do
	{
		flags = conv_run(cc);
		if (flags & (CONV_SOURCE_END | CONV_DEST_END))
		{
			fwrite(cc->dest_start, 1, cc->dest - cc->dest_start, stdout);
			cc->dest = recoded;
		}
	}
	while (! (flags & CONV_SOURCE_END));
}

static char *word_classes[] = { "????", "ignr", "word", "garb", "prep", "post", "brek", "comp" };

static void
dump_lex_word(struct fastbuf *f, uns len, uns class)
{
  byte word[MAX_WORD_LEN+1];
  uns i;

  ASSERT(len <= MAX_WORD_LEN);
  breadb(f, word, len);
  if (class == WC_COMPOUND)
    {
      for (i=0; i<len/4; i++)
	printf("%c%x", i?' ':'<', ((u32*)word)[i]);
      putchar('>');
    }
  else
    print_recoded_string(word, len);
}

static void
dump_lex_entry(struct lex_entry *l, uns id, struct fastbuf *f)
{
	sh_off_t ref_pos = GET_O(l->ref_pos);
	uns chlen = GET_U16(l->ch_len) << 12;
	id |= l->class;
	if (verbose)
	{
		printf("Word ID %x:\n", id);
		printf("References:\t%08qx + %07x\n", (long long) ref_pos, chlen);
		printf("Class:\t\t%s\n", (l->class > 7 ? "????" : word_classes[l->class]));
		printf("Frequency:\t%d\n", l->freq);
		printf("Length:\t\t%d\n", l->length);
		printf("Word:\t\t");
	}
	else
	{
		printf("%8x %8qx+%07x %s %3d %3d ", id, (long long) ref_pos, chlen,
		       (l->class > 7 ? "????" : word_classes[l->class]), l->freq, l->length);
	}
	dump_lex_word(f, l->length, l->class);
	printf(verbose ? "\n\n" : "\n");
}

static void
dump_lexicon(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	uns wordid;

	if (!f)
	{
		if (!verbose)
			printf("ID       RefPos+Len       Flgs Frq Len Word\n");
		return;
	}
	if (!start)
	{
		u32 wc = bgetl(f);
		u32 cc = bgetl(f);
		printf("# Word count:\t%d\n", wc);
		printf("# Complex count:\t%d\n", cc);
		wordid = 8;
		for (uns i=0; i<wc; i++)
		{
			struct lex_entry l;
			breadb(f, &l, sizeof(l));
			dump_lex_entry(&l, wordid, f);
			wordid += 8;
		}
		printf("# Complexes:\n");
		wordid = 0;
		for (uns i=0; i<cc; i++)
		{
			struct cplx_entry c;
			breadb(f, &c, sizeof(c));
			sh_off_t ref_pos = GET_O(c.ref_pos);
			uns chlen = GET_U16(c.ch_len) << 12;
			if (verbose)
			{
				printf("Complex ID %x:\n", wordid);
				printf("References:\t%08qx + %07x\n", (long long) ref_pos, chlen);
				printf("Cplx:\t\t");
			}
			else
			{
				printf("%8x %8qx+%07x cplx ??? ??? ", wordid, (long long) ref_pos, chlen);
			}
			u32 x;
			uns j = 0;
			do
			{
				x = bgetl(f);
				printf("%c%x", j++ ? ' ' : '<', x);
			}
			while (x & 7);
			printf(verbose ? ">\n\n" : ">\n");
			wordid++;
		}
	}
	else
		printf("# Garbage found after end of lexicon!\n");
}

static void
dump_lex_words(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	static uns wordid;

	if (!f)
	{
		if (!verbose)
			printf("ID       RefPos+Len       Flgs Frq Len Word\n");
		return;
	}
	if (!start)
	{
		u32 wc = bgetl(f);
		u32 cc = bgetl(f);
		printf("# Word count:\t%d\n", wc);
		printf("# Complex count:\t%d\n", cc);
		wordid = 8;
	}
	else
	{
		struct lex_entry l;
		breadb(f, &l, sizeof(l));
		dump_lex_entry(&l, wordid, f);
		wordid += 8;
	}
}

static void
dump_lex_temp(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;

	if (!f)
	{
		if (!verbose)
			printf("ID       Count      Flgs Len Word\n");
		return;
	}
	if (!start)
	{
		u32 wc = bgetl(f);
		u32 cc = bgetl(f);
		printf("# Word count:\t%d\n", wc);
		printf("# Complex count:\t%d\n", cc);
	}
	else
	{
		u32 id, count;
		uns length, class;
		id = bgetl(f);
		count = bgetl(f);
		class = id & 7;
		length = bgetc(f);
		if (verbose)
		{
			printf("Word ID %x:\n", id);
			printf("Count:\t\t%d\n", count);
			printf("Class:\t\t%s\n", word_classes[class]);
			printf("Length:\t\t%d\n", length);
			printf("Word:\t\t");
		}
		else
		{
			printf("%8x %10d %s %3d ", id, count, word_classes[class], length);
		}
		dump_lex_word(f, length, class);
		printf(verbose ? "\n\n" : "\n");
	}
}

static void
dump_lex_stats(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;

	if (!f || start)
		return;

	enum wtype { TOTAL, BARE, ACCENTED, DIGITS, MIXED, NTYPES };
	byte *tnames[] = { "Total", "Bare", "Accented", "Numbers", "Mixed" };
	uns wcnt[MAX_WORD_LEN+1][NTYPES];
	uns wlen[MAX_WORD_LEN+1][NTYPES];
	uns cnt = bgetl(f);
	uns cplxcnt = bgetl(f);
	bzero(wcnt, sizeof(wcnt));
	bzero(wlen, sizeof(wlen));
	while (cnt--)
	{
		bgetl(f);
		bgetl(f);
		uns len = bgetc(f);
		uns reclen = 9 + len;
		ASSERT(len && len <= MAX_WORD_LEN);
		byte buf[MAX_WORD_LEN];
		bread(f, buf, len);
		int alpha = 0;
		int digits = 0;
		int accents = 0;
		for (byte *x=buf; x<buf+len;)
		{
			uns c;
			GET_UTF8(x, c);
			if (c >= '0' && c <= '9')
				digits++;
			else
				alpha++;
			if (Uunaccent(c) != c)
				accents++;
		}
		enum wtype t;
		if (!digits) {
			if (!accents)
				t = BARE;
			else
				t = ACCENTED;
		} else {
			if (alpha)
				t = MIXED;
			else
				t = DIGITS;
		}
		len = digits+alpha;
		wcnt[len][t]++;
		wlen[len][t] += reclen;
		wcnt[len][TOTAL]++;
		wlen[len][TOTAL] += reclen;
		wcnt[0][t]++;
		wlen[0][t] += reclen;
		wcnt[0][TOTAL]++;
		wlen[0][TOTAL] += reclen;
	}
	puts("Words:");
	printf("Len ");
	for (uns j=0; j<NTYPES; j++)
		printf(" %11s Cnt/Len", tnames[j]);
	putchar('\n');
	for (uns i=0; i<=MAX_WORD_LEN; i++)
	{
		if (!i)
			printf("Sum:");
		else
			printf("%3d:", i);
		for (uns j=0; j<NTYPES; j++)
			printf(" %9d/%9d", wcnt[i][j], wlen[i][j]);
		putchar('\n');
	}

	uns preplen[MAX_COMPLEX_LEN+1], postlen[MAX_COMPLEX_LEN+1], prepcnt[MAX_COMPLEX_LEN+1], postcnt[MAX_COMPLEX_LEN+1];
	bzero(preplen, sizeof(preplen));
	bzero(prepcnt, sizeof(prepcnt));
	bzero(postlen, sizeof(postlen));
	bzero(postcnt, sizeof(postcnt));
	while (cplxcnt--)
	{
		bgetl(f);
		bgetl(f);
		uns c = bgetc(f);
		ASSERT(!(c%4));
		uns l = c/4;
		ASSERT(l >= 2 && l <= MAX_COMPLEX_LEN);
		u32 x[MAX_COMPLEX_LEN];
		bread(f, x, c);
		uns reclen = 9 + c;
		if ((x[0] & 7) != WC_NORMAL) {
			prepcnt[l]++;
			preplen[l] += reclen;
			prepcnt[1]++;
			preplen[1] += reclen;
		} else {
			postcnt[l]++;
			postlen[l] += reclen;
			postcnt[1]++;
			postlen[1] += reclen;
		}
	}
	puts("\nComplexes:");
	printf("Len: Prep Cnt/Len              Postp Cnt/Len\n");
	for (uns i=1; i<=MAX_COMPLEX_LEN; i++)
	{
		if (i == 1)
			printf("Sum");
		else
			printf("%3d", i);
		printf(": %9d/%9d %9d/%9d\n", prepcnt[i], preplen[i], postcnt[i], postlen[i]);
	}
}

static void
dump_graph(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	uns src, deg;
	byte *vtypes[4] = { "", " [redir]", " [frame]", " [img]" };

	if (!f)
		return;
	src = bgetl(f);
	deg = bgetw(f);
	printf("Vertex %d (degree %d) at %08qx:\n", src, deg, start);
	while (deg--)
	{
		u32 x = bgetl(f);
		printf("\t-> %d%s\n",
		       x & ~ETYPE_MASK,
		       vtypes[x >> 30U]);
	}
}

static void
dump_u32(u64 id, void *tmp)
{
	u32 *u = tmp;
	if (!u)
		return;
	printf("%08x -> %08x\n", (u32) id, *u);
}

static void
dump_refs(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u16 hi, lo;

	if (!f)
	{
		if (!verbose)
			printf("Pos      OID      ref\n");
		return;
	}
	if (verbose)
		printf("Reference block at %08qx:\n", start);
	hi = bgetw(f);
	while (1)
	{
		lo = bgetw(f);
		if (!hi && !lo)
			break;
		if (verbose)
			printf("OID:\t%08x\n", hi<<16 | lo);
		else
			printf("%8qx %8x ", (long long)btell(f)-4, hi<<16 | lo);
		while (1)
		{
			word ref = bgetw(f);
			if (!(ref >> 12))
			{
				hi = ref;
				break;
			}
			if (verbose)
			{
				if (ref < 0x8000)
					printf("%04x(%03x:%x) ", ref, (ref & 0xfff), ref >> 12);
				else
					printf("%04x(%03x:%x:%d) ", ref, ((ref >> 2) & 0x1ff), ((ref >> 11) & 0xf), ref & 3);
			}
			else
				printf("%04x ", ref);
		}
		printf("\n");
	}
	printf("\n");
}

static void
dump_ref_texts(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;
	uns i, l;
	struct fingerprint fp;

	if (!f)
	{
		if (!verbose)
			printf("ID       FingerPrint              Text\n");
		return;
	}
	printf("%08x ", bgetl(f));
	breadb(f, &fp, sizeof(fp));
	for (i=0; i<12; i++)
		printf("%02x", fp.hash[i]);
	putchar(' ');
	l = bgetw(f);
	while (l--) {
		i = bgetc(f);
		putchar(i);
	}
	putchar('\n');
}

static void
dump_ascii(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;
	byte line[BUFSIZE];

	if (!f)
		return;
	bgets(f, line, BUFSIZE);
	puts(line);
}

static void
dump_urls(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;
	byte line[BUFSIZE];
	static uns oid;

	if (!f) {
		oid = 0;
		return;
	}
	bgets(f, line, BUFSIZE);
	printf("%08x %s\n", oid, line);
	oid++;
}

static void
dump_string_index(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct fingerprint fp;
	u32 size;
	uns i;

	if (!f)
		return;
	breadb(f, &fp, sizeof(struct fingerprint));
	breadb(f, &size, sizeof(u32));
	if (verbose)
	{
		printf("String index entry at %08qx:\n", start);
		printf("Finger:\t");
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf("\n");
		printf("Size:\t%d\n", size);
	}
	else
	{
		printf("S%8qx ", start);
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf(" %8d\n", size);
	}
	while (size > 0)
	{
		u32 oid;
		u16 count;
		u64 estart = btell(f);
		oid = bgetl(f);
		count = bgetw(f);
		size -= sizeof(u32) + (count+1)*sizeof(u16);
		if (verbose)
		{
			printf("OID:\t%08x\n", oid);
			printf("Count:\t%d\n", count);
		}
		else
		{
			printf("O%8qx %8x %5d  ", estart, oid, count);
		}
		for (i=0; i<count; i++)
		{
			u16 ref = bgetw(f);
			if (verbose)
				printf("Ref:\t%04x\n", ref);
			else
				printf("%04x ", ref);
		}
		if (!verbose)
			printf("\n");
	}
	printf("\n");
}

static void
dump_string_map(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	struct fingerprint fp;
	sh_off_t ref_pos;
	uns i;

	if (!f)
	{
		if (!verbose)
			printf("Pos      Fingerprint              RefPos\n");
		return;
	}
	breadb(f, &fp, sizeof(struct fingerprint));
	ref_pos = bgeto(f);
	if (verbose)
	{
		printf("String map entry at %08qx:\n", start);
		printf("Finger:\t");
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf("\n");
		printf("RefPos:\t%08qx\n\n", (long long) ref_pos);
	}
	else
	{
		printf("%8qx ", start);
		for (i=0; i<12; i++)
			printf("%02x", fp.hash[i]);
		printf(" %08qx\n", (long long) ref_pos);
	}
}

static void
dump_word_index(u64 start, void *tmp)
{
	struct fastbuf *f = tmp;
	u32 wordid, size;
	uns i;

	if (!f)
		return;
	breadb(f, &wordid, sizeof(u32));
	breadb(f, &size, sizeof(u32));
	if (verbose)
	{
		printf("Word index entry at %08qx:\n", start);
		printf("Word:\t%x\n", wordid);
		printf("Size:\t%d\n", size);
	}
	else
	{
		printf("S%8qx %8x %8d\n", start, wordid, size);
	}
	while (size > 0)
	{
		u32 oid;
		u16 count;
		u64 estart = btell(f);
		oid = bgetl(f);
		count = bgetw(f);
		size -= sizeof(u32) + (count+1)*sizeof(u16);
		if (verbose)
		{
			printf("OID:\t%08x\n", oid);
			printf("Count:\t%d\n", count);
		}
		else
		{
			printf("O%8qx %8x %5d  ", estart, oid, count);
		}
		for (i=0; i<count; i++)
		{
			u16 ref = bgetw(f);
			if (verbose)
				printf("Ref:\t%04x\n", ref);
			else
				printf("%04x ", ref);
		}
		if (!verbose)
			printf("\n");
	}
	printf("\n");
}

static void
dump_params(u64 start UNUSED, void *tmp)
{
	struct index_params *par = tmp;

	if (!par)
		return;
	printf("Index version:\t\t%08x\n", par->version);
	printf("Reference time:\t\t%d\n", (uns) par->ref_time);
	printf("Lexicon config:\n");
	printf("\tmin_len_ign\t%d\n", par->lex_config.min_len_ign);
	printf("\tmin_len\t\t%d\n", par->lex_config.min_len);
	printf("\tmax_len\t\t%d\n", par->lex_config.max_len);
	printf("\tmax_hex_len\t%d\n", par->lex_config.max_hex_len);
	printf("\tmax_ctrl_len\t%d\n", par->lex_config.max_ctrl_len);
	printf("\tmax_preps\t%d\n", par->lex_config.max_preps);
	printf("\tmax_postps\t%d\n", par->lex_config.max_postps);
	printf("\tmax_gap\t\t%d\n", par->lex_config.max_gap);
	printf("Input objects:\t\t%d\n", par->objects_in);
}

static void
dump_stems_temp(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;

	if (!f)
		return;
	uns sid = bgetl(f);
	u32 lm = bgetl(f);
	printf("# Stem expansion table for stemmer #%08x langmask %08x\n", sid, lm);
	u32 x, y;
	while ((x = bgetl(f)) != ~0U)
	{
		y = bgetl(f);
		printf("%08x %08x\n", x, y);
	}
}

static void
dump_stems(u64 start UNUSED, void *tmp)
{
	struct fastbuf *f = tmp;

	if (!f)
		return;
	uns sid = bgetl(f);
	u32 lm = bgetl(f);
	printf("# Stem expansion table for stemmer #%08x langmask %08x\n", sid, lm);
	u32 x;
	while ((x = bgetl(f)) != ~0U)
	{
		if (x & 0x80000000)
			printf("%08x\n", x & 0x7fffffff);
		else
			printf("\t%08x\n", x);
	}
}

struct index_file {
	int option;
	byte **default_filename;
	int record_size;
		/* 
		 * record_size > 0:	uniform sequence with records of size record_size
		 * record_size == 0:	non-uniform sequence
		 * record_size < 0:	non-uniform sequence with records aligned to -record_size
		 */
	void (*dump_single)(u64 id, void *in);
};

static struct index_file index_files[] = {
	{ 'a', &fn_attributes, 		sizeof(struct card_attr),	dump_card_attr	},
	{ 'c', &fn_cards,		-(1 << CARD_POS_SHIFT),		dump_card	},
	{ 'd', &fn_card_attrs,		sizeof(struct card_attr),	dump_card_attr	},
	{ 'h', &fn_checksums,		sizeof(struct csum),		dump_checksum	},
	{ 'F', &fn_fingerprints,	sizeof(struct fprint),		dump_fingerprint},
	{ 'l', &fn_labels,		0,				dump_labels	},
	{ 'L', &fn_labels_by_id,	0,				dump_labels_id	},
	{ 'x', &fn_lexicon,		0,				dump_lexicon	},
	{ 'Q', &fn_lex_by_freq,		0,				dump_lex_temp	},
	{ 'R', &fn_lex_raw,		0,				dump_lex_temp	},
	{ 'T', &fn_lex_raw,		0,				dump_lex_stats	},
	{ 'O', &fn_lex_ordered,		0,				dump_lex_temp	},
	{ 'W', &fn_lex_words,		0,				dump_lex_words	},
	{ 'k', &fn_links,		sizeof(struct fprint),		dump_fingerprint},
	{ 'g', &fn_link_graph,		0,				dump_graph	},
	{ 'm', &fn_merges,		sizeof(u32),			dump_u32	},
	{ 'n', &fn_notes,		sizeof(struct card_note),	dump_note	},
	{ 'p', &fn_parameters,		sizeof(struct index_params),	dump_params	},
	{ 'r', &fn_references,		0,				dump_refs	},
	{ 't', &fn_ref_texts,		0,				dump_ref_texts	},
	{ 's', &fn_sites,		0,				dump_ascii	},
	{ 'G', &fn_signatures,		0, /* computed run-time */	dump_signatures	},
	{ 'y', &fn_stems,		0,				dump_stems	},
	{ 'Y', &fn_stems_ordered,	0,				dump_stems_temp	},
	{ 'H', &fn_string_hash,		sizeof(u32),			dump_u32	},
	{ 'I', &fn_string_index,	0,				dump_string_index },
	{ 'M', &fn_string_map,		0,				dump_string_map },
	{ 'u', &fn_urls,		0,				dump_urls	},
	{ 'w', &fn_word_index,		0,				dump_word_index },
	{ 0,   NULL,			0,				NULL		}
};

static char *shortopts = CF_SHORT_OPTS "abcdf:ghklmnprstuvwxyFGHILMOQRTWY";
static struct option longopts[] =
{
	CF_LONG_OPTS
	{ "bare",		0, 0, 'b' },
	{ "filename",		0, 0, 'f' },
	{ "verbose",		0, 0, 'v' },
	{ "attr",		0, 0, 'a' },
	{ "card",		0, 0, 'c' },
	{ "card-attr",		0, 0, 'd' },
	{ "checksum",		0, 0, 'h' },
	{ "finger",		0, 0, 'F' },
	{ "label",		0, 0, 'l' },
	{ "labels-id",		0, 0, 'L' },
	{ "lexicon",		0, 0, 'x' },
	{ "lexicon-by-freq",	0, 0, 'Q' },
	{ "lexicon-ordered",	0, 0, 'W' },
	{ "lexicon-raw",	0, 0, 'R' },
	{ "lexicon-stats",	0, 0, 'T' },
	{ "lexicon-words",	0, 0, 'W' },
	{ "link",		0, 0, 'k' },
	{ "link-graph",		0, 0, 'g' },
	{ "merge",		0, 0, 'm' },
	{ "notes",		0, 0, 'n' },
	{ "parameters",		0, 0, 'p' },
	{ "reference",		0, 0, 'r' },
	{ "reference-texts",	0, 0, 't' },
	{ "site",		0, 0, 's' },
	{ "signature",		0, 0, 'G' },
	{ "stems",		0, 0, 'y' },
	{ "stems-ordered",	0, 0, 'Y' },
	{ "string-hash",	0, 0, 'H' },
	{ "string-index",	0, 0, 'I' },
	{ "string-map",		0, 0, 'M' },
	{ "url",		0, 0, 'u' },
	{ "word",		0, 0, 'w' },
	{ NULL,			0, 0, 0 }
};

static char *help = "\
Usage: idxdump [<options>] <index-file> [<id> | [<first-id>]-[<last-id>]]\n\
\n\
Options:\n"
CF_USAGE
"-b, --bare\t\tDon't print table heading\n\
-f, --filename\t\tOverride default filename for given index file\n\
-v, --verbose\t\tSet verbose mode\n\n\
Index files:\n\
-a, --attr\t\tAttributes\n\
-c, --card\t\tCards\n\
-d, --card-attr\t\tCard attributes\n\
-h, --checksum\t\tChecksums\n\
-F, --finger\t\tFingerprints\n\
-l, --label\t\tLabels\n\
-L, --labels-id\t\tLabels by id\n\
-x, --lexicon\t\tFinal lexicon\n\
-Q, --lexicon-by-freq\tLexicon sorted by frequency\n\
-O, --lexicon-ordered\tLexicon after lexorder\n\
-W, --lexicon-words\tLexicon after wsort\n\
-R, --lexicon-raw\tRaw lexicon\n\
-T, --lexicon-stats\tRaw lexicon statistics\n\
-k, --link\t\tLinks by url\n\
-g, --link-graph\tLink graph\n\
-m, --merge\t\tMerges\n\
-n, --notes\t\tNotes\n\
-p, --parameters\tIndex parameters\n\
-r, --reference\t\tReferences\n\
-t, --reftexts\t\tReference texts\n\
-s, --site\t\tSites\n\
-G, --signature\t\tSignatures\n\
-y, --stems\t\tStem mappings\n\
-Y, --stems-ordered\tTemporary stem mappings from lexorder\n\
-H, --string-hash\tString hash\n\
-I, --string-index\tString index\n\
-M, --string-map\tString map\n\
-u, --url\t\tUrl list\n\
-w, --word\t\tWord index\n\
";

static void NONRET
usage(byte *msg)
{
	if (msg)
	{
		fputs(msg, stderr);
		fputc('\n', stderr);
	}
	fputs(help, stderr);
	exit(1);
}

static u64
xtol64(byte *c)
{
	u64 x = 0;
	int n = 0;

	while (*c)
	{
		if (++n > 16)
			die("Number too long");
		if (!Cxdigit(*c))
			die("Invalid hexadecimal number");
		x = (x << 4) | Cxvalue(*c);
		c++;
	}
	return x;
}

static void
dump_index_interval(struct index_file *f, struct fastbuf *b, u64 start, u64 stop)
{
	if (f->record_size > 0)
	{
		byte *buf = alloca(f->record_size);
		bsetpos(b, f->record_size * start);
		while (start <= stop)
		{
			if (!breadb(b, buf, f->record_size))
				break;
			f->dump_single(start, buf);
			start++;
		}
	}
	else
	{
		if (f->record_size < 0)
		{
			start *= -f->record_size;
			if (stop != ~0ULL)
				stop *= -f->record_size;
		}
		if (stop == ~0ULL)
		{
			bseek(b, 0, SEEK_END);
			stop = btell(b);
			if (!stop)
				return;
			stop--;
		}
		bsetpos(b, start);
		while ((u64) (start = btell(b)) <= stop)
			f->dump_single(start, b);
	}
}

static void
dump_index_file(struct index_file *f, struct fastbuf *b, int argc, char **argv)
{
	int i;

	if (!bare)
		f->dump_single(0, NULL);
	if (f->option == 'G')
	{
		/* The file dumped is just a temporary file of the process of
		 * building the index, hence we ignore the contingency that
		 * matcher_signatures could have changed.  The user can modify
		 * its value by setting -Smatcher.signatures anyway.  */
		f->record_size = sizeof(uns) + matcher_signatures * sizeof(u32);
	}
	if (argc == 0)
		dump_index_interval(f, b, 0, ~0ULL);
	else
		for (i=0; i<argc; i++)
		{
			u64 start = 0;
			u64 stop = ~0ULL;
			byte *c = strchr(argv[i], '-');
			if (c)
			{
				*c++ = 0;
				if (*c)
					stop = xtol64(c);
				if (*argv[i])
					start = xtol64(argv[i]);
			}
			else
				start = stop = xtol64(argv[i]);
			if (start > stop)
				usage("Invalid ID range");
			dump_index_interval(f, b, start, stop);
		}
}

int
main(int argc, char **argv)
{
	byte *force_filename = NULL;
	struct index_file *f = NULL;
	int opt, i;
	struct fastbuf *b;

	log_init(argv[0]);
	while ((opt = cf_getopt(argc, argv, shortopts, longopts, NULL)) >= 0)
		switch (opt)
		{
			case 'f':
				force_filename = optarg;
				break;
			case 'v':
				verbose++;
				break;
			case 'b':
				bare++;
				break;
			default:
				for (i=0; ; i++)
					if (opt == index_files[i].option)
					{
						if (f)
							usage("More index files specified");
						f = &index_files[i];
						break;
					}
					else if (!index_files[i].option)
						usage("Invalid option");
		}
	if (!f)
		usage("No index file specified");
	if (!force_filename)
		force_filename = index_name(*f->default_filename);
	term_charset_id = find_charset_by_name(terminal_charset);
	if (term_charset_id < 0)
		die("Unknown terminal charset %s", terminal_charset);
	conv_init(&conv_utf8);
	conv_set_charset(&conv_utf8, CONV_CHARSET_UTF8, term_charset_id);
	b = bopen(force_filename, O_RDONLY, 1<<20);
	dump_index_file(f, b, argc - optind, argv + optind);
	bclose(b);
	return 0;
}
