#!/usr/bin/perl
#	Dumper of cards (might be specified in 4 ways)
#	(c) 2003, Robert Spalek <robert@ucw.cz>

use Getopt::Long;

my @buckets, @urls, @cards, @oids;
my $idxdir = "index", $dumperparams = "", $verbose = 0, $allbuckets = 0;

my $help = "Syntax: dump-card.pl [<options>] <descriptors>
Options:
	--indexdir DIRECTORY
	--dumperparams PARAMETERS FOR OBJDUMP
	--verbose	... prints the shell program to STDERR
Descriptors:
	--allbuckets
	--bucket BUCKETNR
	--url URL
	--card CARDID	... all cards can be dumped by CARDID=0-
	--oid OID	... intervals are also allowed
";
GetOptions(
	"indexdir=s" => \$idxdir,
	"dumperparams=s" => \$dumperparams,
	"verbose!" => \$verbose,
	"allbuckets!" => \$allbuckets,
	"bucket=s@" => \@buckets,
	"url=s@" => \@urls,
	"card=s@" => \@cards,
	"oid=s@" => \@oids,
) || die $help;
die "Superfluous options (@ARGV)\n$help" if $#ARGV >= 0;

if ($#urls >= 0)
{
	$" = " -u";
	my $found = `./bin/gc -u@urls`;
	for (split /\n/, $found)
	{
		if (/^([^ ]*) (?:\[[A-Z]*\] )?(.*)$/)
		{
			$buckets[$#buckets+1] = $2;
		} else {
			print STDERR "Invalid output of gc -u: $_\n";
		}
	}
}
if ($#oids >= 0)
{
	$" = " ";
	my $found = `./bin/idxdump -f $idxdir/card-attrs -d @oids`;
	for (split /\n/, $found)
	{
		next if /^ID/;
		if (/^ *([0-9a-f]*) *([0-9a-f]*) /)
		{
			$cards[$#cards+1] = $2;
		} else {
			print STDERR "Invalid output of idxdump -d: $_\n";
		}
	}
}
die "Nothing to dump\n$help" if ($#buckets < 0 and $#cards < 0 and !$allbuckets);
my $program = "(\n";
if ($allbuckets)
{
	$program .= "echo \"### ffffffff\n#All buckets:\n\"\n";
	$program .= "./bin/buckettool -c\n";
}
if ($#buckets >= 0)
{
	$program .= "echo \"### ffffffff\n#Buckets:\n\"\n";
	$" = ", ";
	print STDERR "buckets: @buckets\n";
	@buckets = map { "echo \"### $_ 0 0\"; ./bin/buckettool -x $_; echo" } @buckets;
	$" = "\n";
	$program .= "@buckets\n";
}
if ($#cards >= 0)
{
	$program .= "echo \"### ffffffff\n#Cards:\n\"\n";
	$" = ", ";
	print STDERR "cards: @cards\n";
	$" = " ";
	$program .= "./bin/idxdump -f $idxdir/cards -c @cards\n";
}
$program .= ") | ./bin/objdump $dumperparams | less -r\n";
print STDERR $program if $verbose;
exec $program;
