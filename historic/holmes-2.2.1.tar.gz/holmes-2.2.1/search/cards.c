/*
 *	Sherlock Search Engine -- Databases and Card Files
 *
 *	(c) 1997--2001 Martin Mares <mj@ucw.cz>
 *	(c) 2001--2002 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/lfs.h"
#include "lib/pools.h"
#include "lib/hashfunc.h"
#include "indexer/lexicon.h"
#include "search/sherlockd.h"
#include "charset/unicode.h"
#include "charset/charconv.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#define	DUMP_INTERTAG_SPACES	0

static void lm_init(void);

void
db_init(void)
{
  struct database *db;
  oid_t oid = 0x1000;	/* Debugging hack to detect places where we mix absolute and relative oids. Harmless, so we leave it in. */
  uns size;
  int fd;

  for (db=databases; db; db=db->next)
    {
      fd = open(db->fn_params, O_RDONLY);
      if (fd < 0)
	die("Cannot open %s: %m", db->fn_params);
      if (read(fd, &db->params, sizeof(db->params)) != sizeof(db->params))
	die("Cannot read database parameters from %s: %m", db->fn_params);
      close(fd);
      db->card_attrs = mmap_file(db->fn_card_attrs, &size, 0);
      db->first_id = oid;
      db->num_ids = size / sizeof(struct card_attr);
      if (db->num_ids)
	db->num_ids--;
      oid = (oid + db->num_ids + 65535) & ~((oid_t) 65535);
      db->fd_cards = sh_open(db->fn_cards, O_RDONLY);
      if (db->fd_cards < 0)
	die("Unable to open %s: %m", db->fn_cards);
      db->card_file_size = sh_seek(db->fd_cards, 0, SEEK_END);
      db->fd_refs = sh_open(db->fn_references, O_RDONLY);
      if (db->fd_refs < 0)
	die("Unable to open %s: %m", db->fn_references);
      db->ref_file_size = sh_seek(db->fd_refs, 0, SEEK_END);
      log(L_INFO, "Loaded database %s: %d documents (ID %x-%x)",
	  db->name,
	  db->num_ids,
	  db->first_id,
	  db->first_id + db->num_ids - 1);
      words_init(db);
      strings_init(db);
    }
  lm_init();
}

static struct database *
oid_to_db(oid_t *ooid)
{
  oid_t oid = *ooid;
  struct database *db;

  for (db=databases; db; db=db->next)
    if (oid >= db->first_id && oid < db->first_id + db->num_ids)
      {
	*ooid = oid - db->first_id;
	return db;
      }
  die("oid_to_db: Orphan OID %08x", oid);
}

int
check_result_set(struct query *q)
{
  struct val_set *rng;

  if (!q->range)
    {
      rng = q->range = mp_alloc_zero(q->pool, sizeof(*rng));
      rng->min = 1;
      rng->max = num_matches;
    }
  for (rng=q->range; rng; rng=rng->next)
    if (rng->max > num_matches)
      {
	add_qerr("-106 Too many documents requested, only first %d matches available.", num_matches);
	return 1;
      }
    else if (rng->min < 1)
      {
	add_qerr("-106 Matches are numbered starting with 1");
	return 1;
      }
  return 0;
}

static void
show_results_list(struct query *q)
{
  uns from, to;
  struct results *res = q->results;
  struct val_set *rng;

  profiler_switch(&prof_results);
  for (rng=q->range; rng; rng=rng->next)
    {
      from = rng->min;
      to = MIN(rng->max, res->nresults);
      while (from <= to)
	{
	  struct result_note *n = res->result_heap[from++];
	  oid_t oid = n->oid;
	  struct database *db = oid_to_db(&oid);
	  reply_f("B%s", db->name);
	  reply_f("O%08x", oid);
	  reply_f("Q%d", n->q);
	  reply_f("%s", "");		/* Avoid format string warning */
	}
    }
}

#define	TRACE(mask...)	if (q->debug & DEBUG_DUMPING) log(L_DEBUG, mask)

#define	MAXBUF	256
#define	HILITE_HASH_SIZE	256
#define	MAX_TITLES		16

#define	APPEND_BUF(sp, txt)	append_word(q, buf, MAXBUF, &buflen, txt, sizeof(txt)-1, sp)
#define	APPEND_MASK(sp, mask...)	{ \
	byte tmpbuf[64]; \
	uns tmplen = sprintf(tmpbuf, mask); \
	append_word(q, buf, MAXBUF, &buflen, tmpbuf, tmplen, sp); \
}

#define	IS_SENTENCE_BREAK(c)	((c) == '.' || (c) == '?' || (c) == '!')
#define	IS_META_TYPE(c)		((1<<(c)) & WORD_TYPES_META)
#define	PREV_TAGGED_CHAR(pos, pos1, limit, c) {\
	byte *pos2;\
	pos1 = pos;\
	do { pos1--; }\
	while (pos1 > limit && *pos1 >= 0x80 && *pos1 < 0xc0);\
	do { pos2 = pos1; GET_TAGGED_CHAR(pos1, c); }\
	while (pos1 < pos);\
	pos1 = pos2;\
}

static void
append_word(struct query *q, byte *buf, uns maxbuf, uns *buflen, byte *start, uns strlen, int space)
{
	uns len = strlen + 1;				/* +1 for final '\n' */
	if (space && *buflen > 1)
		len++;
	if (space && *buflen + len >= maxbuf*3/4	/* Empty string means flushing the buffer.  */
	|| *buflen + len >= maxbuf
	|| (!strlen && *buflen > 1))
	{
		buf[(*buflen)++] = '\n';
		reply_string(q, buf, *buflen);
		*buflen = 1;
	}
	if (strlen)
	{
		if (space && *buflen > 1)
			buf[(*buflen)++] = ' ';
		memcpy(buf + *buflen, start, strlen);
		*buflen += strlen;
	}
}

static byte *wt_names[] = { WORD_TYPE_USER_NAMES };

struct context_interval
{
	byte *first_char, *last_char;				/* pointers to text */
	uns start_style;					/* style in the beginning */
	int context_len;					/* length of context in printable characters */
};

struct hilite_hash
{
	uns size;
	struct hilite_word *h[0];
};

#define	UNSET_POS	0xffff
struct lexmap_word
{
	struct node n;
	byte *orig;		/* pointer to the original text */
	word pos;		/* position */
	byte olen;		/* and word length */
	byte type;		/* word type */
};

typedef struct lexmap_word *word_id_t;

struct word_pointer
{
	struct hilite_hash *hh;
	struct database *db;
	struct list all_words;
	struct lexmap_word *curr_word;
};

static struct word_pointer *global_wptr;	/* for indexer/lexmap.h routines */
static struct mempool *global_mp;

static enum word_class
lm_lookup(enum word_class orig_class, word *uni, uns ulen, word_id_t *p, byte *orig, uns olen)
{
	struct lexmap_word *idp;
	byte wbuf[3*MAX_WORD_LEN+1], *wp=wbuf;
	uns wl, i;
	enum word_class wc;

	if (!uni)
		return orig_class;
	for (i=0; i<ulen; i++)
	{
		uns u = *uni++;
		u = Utolower(u);
		PUT_UTF8(wp, u);
	}
	*wp = 0;
	wl = wp - wbuf + 1;
	idp = mp_alloc(global_mp, sizeof(struct lexmap_word));
	idp->pos = UNSET_POS;
	idp->orig = orig;
	idp->olen = MIN(olen, 0xff);
	if (orig_class != WC_NORMAL)
		wc = orig_class;
	else
	{
		int c = word_classify(global_wptr->db, wbuf);
		if (c < 0)
			c = WC_NORMAL;
		wc = c;
	}
	*p = idp;
	return wc;
}

static void
lm_got_word(uns pos, uns type, word_id_t p)
{
	if (p->pos != UNSET_POS)
		rem_node(&p->n);
	add_tail(&global_wptr->all_words, &p->n);
	p->pos = pos;
	p->type = type;
}

static void
lm_got_compound(uns pos, uns type, word_id_t *ps, uns l)
{
	uns i;
	for (i=0; i<l; i++)
	{
		if (ps[i]->pos != UNSET_POS)
			rem_node(&ps[i]->n);
		add_tail(&global_wptr->all_words, &ps[i]->n);
		ps[i]->pos = pos+i;
		ps[i]->type = type;
	}
}

/* Import the cutter-into-words.  */
#define LM_TRACK_TEXT
#include "indexer/lexmap.h"

static inline void
next_lexmap_entry(struct word_pointer *w)
{
	if (!w->curr_word)
		return;
	w->curr_word = (void*) w->curr_word->n.next;
	if (!w->curr_word->n.next)
		w->curr_word = NULL;
}

static void
first_lexmap_entry(struct word_pointer *w)
{
	w->curr_word = HEAD(w->all_words);
	if (!w->curr_word->n.next)
		w->curr_word = NULL;
}

static void
lexmap_parse(struct word_pointer *wptr, struct hilite_hash *hilhash, struct database *db, byte *text, byte *text_end)
{
	struct lexmap_word *trailer;

	if (!global_mp)
		global_mp = mp_new(16384);
	else
		mp_flush(global_mp);
	global_wptr = wptr;
	wptr->hh = hilhash;
	wptr->db = db;
	init_list(&wptr->all_words);
	wptr->curr_word = NULL;
	lm_doc_start();
	lm_map_text(text, text_end);
	trailer = mp_alloc(global_mp, sizeof(struct lexmap_word));
	trailer->pos = 0xffff;
	trailer->orig = text_end;
	trailer->olen = 0;
	trailer->type = WT_TEXT;
	add_tail(&wptr->all_words, &trailer->n);
	first_lexmap_entry(wptr);
	global_wptr = NULL;
}

static void
browse_until_word_number(uns limit, struct word_pointer *w)
{
	while (w->curr_word && w->curr_word->pos < limit)
		next_lexmap_entry(w);
}

static void
browse_until_char(byte *limit, struct word_pointer *w)
{
	while (w->curr_word && w->curr_word->orig < limit)
		next_lexmap_entry(w);
}

static inline uns
hashf_hilite(byte *w, byte *w_end)
{
	if (w_end)
		return hash_block(w, w_end - w);
	else
		return hash_string(w);
}

static inline struct hilite_word *
search_hilite(struct hilite_hash *hilite, byte *w, byte *w_end)
{
	uns j;
	struct hilite_word *hw;
	j = hashf_hilite(w, w_end) % hilite->size;
	hw = hilite->h[j];
	while (hw && strcmp(w, hw->w))
		hw = hw->next;
	return hw;
}

static uns
word_tolower_utf8(byte *w, byte *w_end, byte *to)
{
	byte *buf = to;
	while (w < w_end)
	{
		uns u;
		GET_UTF8(w, u);
		u = Utolower(u);
		PUT_UTF8(buf, u);
	}
	*buf = 0;
	return buf - to;
}

static int
is_hilited(struct word_pointer *wp)
{
	byte w[3*MAX_WORD_LEN+1];
	word_tolower_utf8(wp->curr_word->orig, wp->curr_word->orig + wp->curr_word->olen, w);
	return !! search_hilite(wp->hh, w, NULL);
}

static void
dump_interval(struct query *q, struct result_note *note, byte descr, struct context_interval *range, byte *text_start, struct word_pointer *w)
{
	byte *text;
	byte buf[MAXBUF];
	uns buflen;
	int space;
	uns style;

	text = range->first_char;
	style = range->start_style;
	space = 1;
	buf[0] = descr;
	buflen = 1;
	APPEND_MASK(1, "<block char1=%d char2=%d context=%d>", range->first_char - text_start, range->last_char - text_start, range->context_len);
	APPEND_MASK(DUMP_INTERTAG_SPACES, "<%s>", wt_names[style]);
	while (text < range->last_char)
	{
		uns c = 0;
		int empty = 1;
		byte *bow = text, *eow = text;
		while (text < range->last_char)
		{
			GET_TAGGED_CHAR(text, c);
			if (c >= 0x80000000 || !Ualnum(c))
				break;
			empty = 0;
			eow = text;
		}
		browse_until_char(bow, w);
		if (!w->curr_word)
			die("Internal error: seeking out of word list");
		if (!empty)
		{
			uns j;
			int sign = 0;
			if (w->curr_word->orig == bow)
			{
				for (j=0; j<HARD_MAX_NOTES && note->best[j]; j++)
				{
					uns pos = ~note->best[j] & 0xfff;
					uns len = note->best[j] >> 12;
					if (w->curr_word->pos >= pos && w->curr_word->pos < pos+len)
					{
						sign = 2;
						break;
					}
				}
				if (!sign)
				{
					if (is_hilited(w))
						sign = 1;
				}
			}
			if (sign == 2)
				APPEND_BUF(space, "<best>");
			else if (sign == 1)
				APPEND_BUF(space, "<found>");
			if (sign)
				space = 0;
			append_word(q, buf, MAXBUF, &buflen, bow, eow - bow, space);
			if (sign == 2)
				APPEND_BUF(0, "</best>");
			else if (sign == 1)
				APPEND_BUF(0, "</found>");
			space = 0;
		}
		if (c >= 0x80000000)
		{
			if (c < 0x80010000)
			{
				uns new_style = c & 0x0f;
				if (new_style != style)
					APPEND_MASK(DUMP_INTERTAG_SPACES, "</%s>", wt_names[style]);
				if (c & 0x10)
					APPEND_BUF(DUMP_INTERTAG_SPACES, "<break>");
				if (new_style != style)
					APPEND_MASK(DUMP_INTERTAG_SPACES, "<%s>", wt_names[new_style]);
				style = new_style;
			}
			else
				ASSERT(0);
			space = 1;
		}
		else if (Uspace(c))
		{
			space = 1;
		}
		else if (eow < range->last_char)			/* slash, ... */
		{
			byte b[7] = {0, 0, 0, 0, 0, 0, 0}, *printing = b;
			PUT_UTF8(printing, c);
			switch (c)
			{
				case '<':
					printing = "&lt;";
					break;
				case '>':
					printing = "&gt;";
					break;
				case '&':
					printing = "&amp;";
					break;
				default:
					printing = b;
					break;
			}
			append_word(q, buf, MAXBUF, &buflen, printing, strlen(printing), space);
			space = 0;
		}
	}
	APPEND_MASK(1, "</%s>", wt_names[style]);
	APPEND_BUF(DUMP_INTERTAG_SPACES, "</block>");
	append_word(q, buf, MAXBUF, &buflen, NULL, 0, 0);
}

static uns
find_titles(struct query *q, byte *text, byte *text_end, struct context_interval *ints, uns maxints)
{
	byte *t = text;
	uns style = WT_TEXT, new_style = style;		/* The starting stype WT_TEXT is not indexed.  */
	uns i = 0;
	int building = 0;
	int added = 0;
	bzero(ints, maxints*sizeof(struct context_interval));
	while (t < text_end)
	{
		byte *t1 = t;
		uns c;
		GET_TAGGED_CHAR(t, c);
		if (c >= 0x80000000 && c < 0x80010000)
			new_style = c & 0x0f;
		if (c < 0x80000000 && building)
			added++;
		if (building && new_style != style)
		{
			ints[i-1].last_char = t1;
			ints[i-1].context_len = added;
			building = 0;
		}
		style = new_style;
		if (!building && IS_META_TYPE(new_style))
		{
			if (i >= maxints)
			{
				TRACE("Too many (%d) metaintervals in the document", maxints);
				return i;
			}
			i++;
			ints[i-1].first_char = t1;
			ints[i-1].start_style = new_style;
			building = 1;
			added = 0;
		}
	}
	if (building)
	{
		ints[i-1].last_char = t;
		ints[i-1].context_len = added;
	}
	return i;
}

static int
add_context(struct query *q, byte *text, byte *text_end, byte *pos, byte *pos_end, struct context_interval *metaints, uns maxmetaints, struct context_interval *ints, uns maxints, int available)
{
	uns i;
	uns c;
	int enlarge = -1;
	byte *hardl, *softl, *hardr, *softr;
	struct context_interval *I;
	int totaladded, added, limit1, limit2;
	if (available <= 0)
		return 0;
	ASSERT(pos && pos_end);
	ASSERT(pos <= pos_end);
	ASSERT(pos_end <= text_end);
	hardl = softl = text;
	hardr = softr = text_end;
	for (i = 0; i < maxmetaints && metaints[i].first_char; i++)
	{
		if (pos >= metaints[i].first_char && pos < metaints[i].last_char)
			return 0;
		if (metaints[i].last_char <= pos && metaints[i].last_char > hardl)
			hardl = metaints[i].last_char;
		if (metaints[i].first_char >= pos && metaints[i].first_char < hardr)
			hardr = metaints[i].first_char;
	}
	for (i = 0; i < maxints && ints[i].first_char; i++)
	{
		if (pos >= ints[i].first_char && pos < ints[i].last_char)
		{
			enlarge = i;
			TRACE("Already containted by interval %d", i);
			continue;
		}
		if (ints[i].last_char <= pos && ints[i].last_char > softl)
			softl = ints[i].last_char;
		if (ints[i].first_char >= pos && ints[i].first_char < softr)
			softr = ints[i].first_char;
	}
	if (enlarge == -1)
	{
		if (i >= maxints)
		{
			TRACE("Cannot highlight best occurence, too many intervals (%d)", maxints);
			return 0;
		}
		ints[i].first_char = pos;
		ints[i].last_char = pos_end;
		ints[i].start_style = WT_TEXT;
		ints[i].context_len = pos_end - pos;
		enlarge = i;
		TRACE("Created new interval %d with length %d", i, ints[i].context_len);
		totaladded = ints[i].context_len;
	}
	else
		totaladded = 0;
	I = ints + enlarge;
	added = 0;					/* backward */
	available -= totaladded;
	limit1 = available/3;
	limit2 = available/2;
	pos = I->first_char;
	while (pos > hardl && pos > softl)
	{
		byte *pos1;
		PREV_TAGGED_CHAR(pos, pos1, hardl, c);
		if (c < 0x8000000)
		{
			added++;
			if (added >= limit2 && Uspace(c) || added >= limit1 && IS_SENTENCE_BREAK(c))
				break;
		}
		else if (c >= 0x80000000 && c < 0x80001000)
		{
			if (added >= limit1)
				break;
		}
		pos = pos1;
	}
	TRACE("Stretched to the left side by %d characters", added);
	totaladded += added;
	I->context_len += added;
	I->first_char = pos;
	GET_TAGGED_CHAR(pos, c);
	while (pos >= text)
	{
		byte *pos1;
		PREV_TAGGED_CHAR(pos, pos1, text, c);
		if (c >= 0x80000000 && c < 0x80001000)
		{
			I->start_style = c & 0x0f;
			break;
		}
		pos = pos1;
	}
	available -= added;
	pos = I->first_char;
	if (pos > hardl && pos == softl)		/* join the intervals */
	{
		struct context_interval *J;
		for (i = 0; i < maxints && ints[i].last_char != pos; i++);
		ASSERT(i < maxints);
		ints[i].last_char = I->last_char;
		ints[i].context_len += I->context_len;
		J = I;
		I = ints + i;
		for (; J+1 < ints+maxints && J[1].first_char; J++)
		{
			J[0] = J[1];
			if (I->first_char == J->first_char)
				I = J;
		}
		bzero(J, sizeof(struct context_interval));
		TRACE("Merged with the interval %d on the left side", i);
	}
	added = 0;					/* forward */
	limit1 = available*2/3;
	limit2 = available;
	pos = I->last_char;
	while (pos < hardr && pos < softr)
	{
		byte *pos1;
		uns c;
		pos1 = pos;
		GET_TAGGED_CHAR(pos, c);
		if (c < 0x8000000)
		{
			added++;
			if (added >= limit2 && Uspace(c) || added >= limit1 && IS_SENTENCE_BREAK(c))
			{
				if (Uspace(c))
					added--, pos = pos1;
				break;
			}
		}
		else if (c >= 0x80000000 && c < 0x80001000)
		{
			if (added >= limit1)
			{
				pos = pos1;
				break;
			}
		}
	}
	TRACE("Stretched to the right side by %d characters", added);
	totaladded += added;
	I->context_len += added;
	I->last_char = pos;
	if (pos < hardr && pos == softr)		/* join the intervals */
	{
		for (i = 0; i < maxints && ints[i].first_char != pos; i++);
		ASSERT(i < maxints);
		TRACE("Merged with the interval %d on the right side", i);
		ints[i].first_char = I->last_char = I->first_char;
		ints[i].context_len += I->context_len;
	}
	if (I->first_char == I->last_char)		/* empty interval */
	{
		struct context_interval *J;
		J = I;
		I = ints + i;
		for (; J+1 < ints+maxints && J[1].first_char; J++)
		{
			J[0] = J[1];
			if (I->first_char == J->first_char)
				I = J;
		}
		bzero(J, sizeof(struct context_interval));
		TRACE("Deleted empty interval");
	}
	return totaladded;
}

static int
compare_intervals(const void *A, const void *B)
{
	const struct context_interval *a = A, *b = B;
	if (a->first_char < b->first_char)
		return -1;
	else if(a->first_char > b->first_char)
		return 1;
	else
		ASSERT(0);
}

static void
bound_metaints(struct query *q, struct context_interval *metaint, uns *metaints, int available)
{
	uns i;
	for (i = 0; i < *metaints && available > 0; i++)
	{
		if ((1 << metaint[i].start_style) & WORD_TYPES_HIDDEN)
		{
			uns j;
			TRACE("Deleting hidden MetaInterval %d of style %x", i, metaint[i].start_style);
			for (j = i+1; j < *metaints; j++)
				metaint[j-1] = metaint[j];
			(*metaints)--;
		}
		else if (metaint[i].context_len <= available)
		{
			available -= metaint[i].context_len;
		}
		else
		{
			byte *pos = metaint[i].first_char;
			uns added = 0;
			while (pos < metaint[i].last_char)
			{
				byte *pos1;
				uns c;
				pos1 = pos;
				GET_TAGGED_CHAR(pos, c);
				if (c < 0x8000000)
				{
					available--;
					added++;
					if (available <= -16 && Uspace(c) || available <= 0 && IS_SENTENCE_BREAK(c))
					{
						if (Uspace(c))
							added--, pos = pos1;
						break;
					}
				}
				else if (c >= 0x80000000 && c < 0x80001000)
				{
					if (available <= 0)
					{
						pos = pos1;
						break;
					}
				}
			}
			TRACE("MetaInterval %d is too long, cuting %d characters from the right leaving %d characters", i, metaint[0].context_len - added, added);
			metaint[i].context_len = added;
			metaint[i].last_char = pos;
		}
	}
	if (i < *metaints)
	{
		TRACE("Too long MetaIntervals, displaying only first %d MetaIntervals", i);
		*metaints = i;
	}
}

static void
show_context(struct query *q, byte *text, byte *text_end, struct result_note *note, struct hilite_hash *hilhash, struct database *db)
{
	struct word_pointer wptr, wptr_bak;
	char mask[20];
	struct context_interval interval[HARD_MAX_NOTES];
	struct context_interval metaint[MAX_TITLES];
	int metaints, intervals;
	int context = q->context_chars;
	int i;

	/* Parse into words.  */
	ASSERT(*text_end == '\n');
	lexmap_parse(&wptr, hilhash, db, text, text_end);
	wptr_bak = wptr;

	/* Verbose and normal debug messages.  */
	if (0)
	{
		TRACE("Coded OID: %d", note->oid);
		TRACE("Length of text: %d", text_end-text);
		sprintf(mask, "Text: %%%d.%ds", text_end-text, text_end-text);
		TRACE(mask, text);
		wptr = wptr_bak;
		while (wptr.curr_word)
		{
			char mask[20];
			sprintf(mask, "Word %%3d: l%%2d c%%x \"%%%d.%ds\"",
				wptr.curr_word->olen, wptr.curr_word->olen);
			TRACE(mask, wptr.curr_word->pos, wptr.curr_word->olen, wptr.curr_word->type, wptr.curr_word->orig);
			next_lexmap_entry(&wptr);
		}
	}
	for (i=0; i<HARD_MAX_NOTES && note->best[i]; i++)
		TRACE("Best %d: %d %d", i, ~note->best[i] & 0xfff, note->best[i] >> 12);

	/* Find the titles and optimal context intervals and sort them.  */
	metaints = find_titles(q, text, text_end, metaint, MAX_TITLES);
	TRACE("Found %d metaintervals.", metaints);
	bzero(interval, sizeof(interval));
	wptr = wptr_bak;
	if (note->best[0])
	{
		int ints;
		int context1, realcontext;
		for (ints=0; ints<HARD_MAX_NOTES && note->best[ints]; ints++);
		context1 = context / ints;
		for (i=0; i<ints && context > 0; i++)
		{
			uns pos = ~note->best[i] & 0xfff;
			uns len = note->best[i] >> 12;
			byte *start;
			if (pos == 0xfff)
				continue;
			if (!wptr.curr_word || pos < wptr.curr_word->pos)
				wptr = wptr_bak;
			browse_until_word_number(pos, &wptr);
			if (!wptr.curr_word)
				continue;
			start = wptr.curr_word->orig;
			browse_until_word_number(pos + len -1, &wptr);
			realcontext = add_context(q, text, text_end, start, wptr.curr_word->orig + wptr.curr_word->olen, metaint, metaints, interval, HARD_MAX_NOTES, context1);
			context -= realcontext;
			TRACE("Added interval of length %d", realcontext);
		}
		for (intervals = 0; intervals < HARD_MAX_NOTES && interval[intervals].first_char; intervals++);
		for (i=0; i<intervals && context > 0; i++)
			if (interval[i].first_char)
			{
				realcontext = add_context(q, text, text_end, interval[i].first_char, interval[i].last_char, metaint, metaints, interval, HARD_MAX_NOTES, context/2);
				context -= realcontext;
				TRACE("Stretched interval by length %d", realcontext);
			}
		for (intervals = 0; intervals < HARD_MAX_NOTES && interval[intervals].first_char; intervals++);
	}
	else
		intervals = 0;
	if (!intervals)
	{
		wptr = wptr_bak;
		while (wptr.curr_word && IS_META_TYPE(wptr.curr_word->type))
			next_lexmap_entry(&wptr);
		if (wptr.curr_word)
		{
			int realcontext = add_context(q, text, text_end, wptr.curr_word->orig, wptr.curr_word->orig + wptr.curr_word->olen, metaint, metaints, interval, HARD_MAX_NOTES, context);
			if (realcontext > 0)
			{
				TRACE("Added beginning of text of length %d", realcontext);
				intervals = 1;
				context -= realcontext;
			}
		}

	}
	if (context > 0)
	{
		/* Some text could have lasted after dispersed meta-intervals.  */
#define	TRY_ADD_INTERVAL(pos) do { \
	int realcontext; \
	if (pos && pos < text_end) { \
		uns u; \
		byte *pos1=pos; \
		GET_TAGGED_CHAR(pos1, u); \
		realcontext = add_context(q, text, text_end, pos, pos1, metaint, metaints, interval, HARD_MAX_NOTES, context); \
	} else \
		realcontext = 0; \
	if (realcontext > 0) { \
		context -= realcontext; \
		TRACE("Final stretching performed from byte %x, context %d was added", pos - text, realcontext); \
	} \
} while(0)
		TRY_ADD_INTERVAL(text);
		for (i=0; i<intervals && context > 0; i++)
			TRY_ADD_INTERVAL(interval[i].last_char);
		for (i=0; i<metaints && context > 0; i++)
			TRY_ADD_INTERVAL(metaint[i].last_char);
		for (intervals = 0; intervals < HARD_MAX_NOTES && interval[intervals].first_char; intervals++);
	}
	qsort(interval, intervals, sizeof(struct context_interval), compare_intervals);

	/* Print debug messages about found intervals.  Bound the metaintervals than.  */
	for (i = 0; i < metaints; i++)
		TRACE("MetaInterval of style %x, bytes %d-%d context %d", metaint[i].start_style, metaint[i].first_char - text, metaint[i].last_char - text, metaint[i].context_len);
	for (i = 0; i < intervals; i++)
		TRACE("Interval of style %x, bytes %d-%d context %d", interval[i].start_style, interval[i].first_char - text, interval[i].last_char - text, interval[i].context_len);
	bound_metaints(q, metaint, &metaints, q->title_chars);

	/* Dump the titles and the highlited context.  */
	wptr = wptr_bak;
	for (i = 0; i < metaints; i++)
		dump_interval(q, note, 'M', metaint + i, text, &wptr);
	wptr = wptr_bak;
	for (i = 0; i < intervals; i++)
		dump_interval(q, note, 'X', interval + i, text, &wptr);
}

struct card_url {
	byte *url;
	int first_v;
	int dumped;
};

struct card_v {
	byte *start, *end;
	char *matches;
};

static byte *
dump_lines_between(struct query *q, struct card_url *bounds, struct card_v **V, byte stop_at_y)
{
	byte *a, *attr;
	struct card_v *v = *V;
	for (a = bounds[0].url; a < bounds[1].url && (!stop_at_y || *a != 'y'); )
	{
		attr = a;
		while (*a++ != '\n')
			;
		if (attr+1 == v->start)
		{
			if (v->matches)
				reply_string(q, v->matches, strlen(v->matches));
			v++;
		}
		else
		{
			reply_string(q, attr, a-attr);
		}
	}
	*V = v;
	return a;
}

static void
show_card_url(struct query *q, struct card_url *urls, struct card_v *v)
{
	byte *a, *first_red;
	int max_redirects = global_redirect_url_max;
	struct card_url *redirects;
	int i, count;
	struct card_v *first_v;
	a = dump_lines_between(q, urls, &v, 1);
	urls[0].dumped = 1;
	first_red = a;					/* Scan the redirects.  */
	count = 0;
	for (a = first_red; a < urls[1].url; )
	{
		if (*a == 'y')
			count++;
		while (*a++ != '\n')
			;
	}
	if (!count)
		return;
	redirects = alloca((count+1) * sizeof(struct card_url));
	i = 0;
	first_v = v;
	for (a = first_red; a < urls[1].url; )
	{
		byte *attr = a;
		if (*a == 'y')
		{
			redirects[i].url = a;
			redirects[i].first_v = v - first_v;
			redirects[i].dumped = 0;
			i++;
		}
		while (*a++ != '\n')
			;
		if (attr+1 == v->start)
			v++;
	}
	ASSERT(i == count);
	redirects[i].url = a;
	redirects[i].first_v = v - first_v;
	redirects[i].dumped = 0;
	v = first_v;
	for (i=0; i<count && max_redirects; i++)	/* Dump nice redirects at first.  */
	{
		int found = 0;
		int j;
		for (j=redirects[i].first_v; j<redirects[i+1].first_v; j++)
			if (first_v[j].matches)
			{
				found = 1;
				break;
			}
		if (found)
		{
			struct card_v *vv = v + redirects[i].first_v;
			dump_lines_between(q, redirects + i, &vv, 0);
			ASSERT(vv == v + redirects[i+1].first_v);
			redirects[i].dumped = 1;
			max_redirects--;
		}
	}
	for (i=0; i<count && max_redirects; i++)	/* Dump nice redirects at first.  */
	{
		if (!redirects[i].dumped)
		{
			struct card_v *vv = v + redirects[i].first_v;
			dump_lines_between(q, redirects + i, &vv, 0);
			ASSERT(vv == v + redirects[i+1].first_v);
			redirects[i].dumped = 1;
			max_redirects--;
		}
	}
}

static void
show_card_start(struct query *q, byte *start, byte *end)
{
	byte *a, *attr;
	for (a=start; a<end; )
	{
		attr = a;
		while (*a++ != '\n')
			;
		reply_string(q, attr, a-attr);
	}
}

static void
show_card(struct query *q, struct result_note *n, struct mmap_request *mm, struct hilite_hash *hilhash)
{
	byte *a, *attr;
	oid_t oid = n->oid;
	struct database *db = oid_to_db(&oid);
	int url_count, v_count;
	struct card_url *urls;
	struct card_v *vs;
	int state, eoln;
	int i, url_max;

	reply_f("B%s", db->name);
	reply_f("O%08x", oid);
	reply_f("Q%d", n->q);
	reply_f("w%d", db->card_attrs[oid].weight);

	url_count = v_count = 0;
	attr = 0;
	eoln = 1;
	for (a = mm->u.map.start; *a && a < (byte *) mm->u.map.end; a++)
	{
		if (eoln)
		{
			if (*a == 'U')
				url_count++;
			else if (*a == 'V')
				v_count++;
			else if (*a == 'X')
			{
				attr = a;
				break;
			}
		}
		eoln = (*a == '\n');
	}
	urls = alloca((url_count+1) * sizeof(struct card_url));
	bzero(urls, (url_count+1) * sizeof(struct card_url));
	urls[url_count].url = attr;
	urls[url_count].first_v = v_count;
	vs = alloca((v_count+1) * sizeof(struct card_v));
	bzero(vs, (v_count+1) * sizeof(struct card_v));
	url_count = v_count = 0;
	state = 0;
	eoln = 1;
	for (a = mm->u.map.start; *a && a < (byte *) mm->u.map.end; a++)
	{
		if (*a == 'U' && eoln)
		{
			urls[url_count].url = a;
			urls[url_count++].first_v = v_count;
		}
		else if (*a == 'V' && eoln)
		{
			vs[v_count].start = a+1;
			state = 1;
		}
		else if (*a == '\n' && state)
		{
			vs[v_count++].end = a;
			state = 0;
		}
		eoln = (*a == '\n');
	}
	ASSERT(v_count == urls[url_count].first_v);
	url_max = q->url_max;
	for (i=0; i<url_count && url_max; i++)
	{
		int j;
		int found = 0;
		for (j = urls[i].first_v; j < urls[i+1].first_v; j++)
		{
			struct word_pointer wptr;
			lexmap_parse(&wptr, hilhash, db, vs[j].start, vs[j].end);
			while (wptr.curr_word)
			{
				if (is_hilited(&wptr))
				{
					found = 1;
					vs[j].matches = alloca(vs[j].end - vs[j].start + 3);
					break;
				}
				next_lexmap_entry(&wptr);
			}
			if (vs[j].matches)		/* copy only matched words */
			{
				char *app = vs[j].matches;
				*app++ = 'V';
				first_lexmap_entry(&wptr);
				while (wptr.curr_word)
				{
					if (is_hilited(&wptr))
					{
						if (app != vs[j].matches+1)
							*app++ = ' ';
						memcpy(app, wptr.curr_word->orig, wptr.curr_word->olen);
						app += wptr.curr_word->olen;
					}
					next_lexmap_entry(&wptr);
				}
				*app++ = '\n';
				*app++ = 0;
			}
		}
		if (found)
		{
			show_card_url(q, urls+i, vs + urls[i].first_v);
			url_max--;
		}
	}
	for (i=0; i<url_count && url_max; i++)
		if (!urls[i].dumped)
		{
			show_card_url(q, urls+i, vs + urls[i].first_v);
			url_max--;
		}
	for (a = urls[url_count].url; *a && a < (byte *) mm->u.map.end; )
	{
		attr = a;
		while (*a++ != '\n')
			;
		show_context(q, attr+1, a-1, n, hilhash, db);
	}
	show_card_start(q, mm->u.map.start, urls[0].url ? : mm->u.map.end);

	reply_f("%s", "");			/* Avoid format string warning */
}

static void
show_results_full(struct query *q)
{
  struct results *res = q->results;
  uns maxres = MIN(res->nresults, max_output_matches);
  struct val_set *rng;
  struct mmap_request *mmap_array;
  struct result_note *notes[maxres];
  struct mmap_request *mmaps[maxres];
  struct hilite_hash *hilhash;
  struct hilite_word *hilword;
  uns nres = 0;
  uns i;

  profiler_switch(&prof_resf);
  for (rng=q->range; rng; rng=rng->next)
    {
      uns from = rng->min;
      uns to = MIN(rng->max, res->nresults);
      while (from <= to && nres < maxres)
	notes[nres++] = res->result_heap[from++];
    }
  mmap_array = alloca(sizeof(struct mmap_request) * nres);
  for (i=0; i<nres; i++)
    {
      struct mmap_request *m = &mmap_array[i];
      oid_t oid = notes[i]->oid;
      struct database *db = oid_to_db(&oid);
      m->u.req.fd = db->fd_cards;
      m->u.req.start = (sh_off_t) db->card_attrs[oid].card << CARD_POS_SHIFT;
      m->u.req.end = (sh_off_t) db->card_attrs[oid+1].card << CARD_POS_SHIFT;
      m->userdata = i;
    }
  if (mmap_regions(q, mmap_array, nres) < 0)
    {
      log(L_ERROR, "Error mapping index cards for query result display");
      return;
    }
  profiler_switch(&prof_results);
  for (i=0; i<nres; i++)
    mmaps[mmap_array[i].userdata] = &mmap_array[i];
  hilhash = mp_alloc_zero(q->pool, sizeof(struct hilite_hash) + HILITE_HASH_SIZE*sizeof(struct hilite_word *));
  hilhash->size = HILITE_HASH_SIZE;
  for (hilword=q->results->first_hilite, i=0; hilword; hilword=hilword->next, i++)
  {
    uns j = hashf_hilite(hilword->w, NULL) % hilhash->size;
    struct hilite_word *w = mp_alloc_zero(q->pool, sizeof(struct hilite_word) + strlen(hilword->w));
    strcpy(w->w, hilword->w);
    w->next = hilhash->h[j];
    hilhash->h[j] = w;
    TRACE("Hilite %d: %s", i, hilword->w);
  }
  for (i=0; i<nres; i++)
    show_card(q, notes[i], mmaps[i], hilhash);
}

void
show_results(struct query *q)
{
  if (!q->results->nresults || q->list_only > 1)
    ;	/* No results or stats only */
  else if (q->list_only)
    show_results_list(q);
  else
    show_results_full(q);
}
