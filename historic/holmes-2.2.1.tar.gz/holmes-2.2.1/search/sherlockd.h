/*
 *	Sherlock Search Engine
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lists.h"
#include "lib/index.h"

#define PROFILE_TOD
#include "lib/profile.h"

/* config.c */

extern byte *log_name;
extern uns log_incoming, log_rejected, log_requests, log_replies;
extern uns port, listen_queue, connection_timeout;
extern byte *control_password;
extern struct database *databases;
extern uns num_matches, cache_size, max_output_matches;
extern uns max_words, max_word_matches, max_phrases, max_bools;
extern uns global_accent_mode, max_wildcard_zone, min_wildcard_prefix_len;
extern uns global_allow_approx, global_context_chars, global_title_chars, global_site_max, global_url_max, global_redirect_url_max;
extern uns doc_weight_scale, word_bonus;
extern uns global_allow_approx, prox_limit, prox_penalty;
extern uns global_partial_answers, default_word_types, global_debug, global_sorting, global_sort_reverse;
extern uns mem_map_zone_size, mem_map_elide_gaps, mem_map_prefetch;
extern uns query_watchdog;
extern uns magic_complexes, magic_merge_words, magic_merge_classes, magic_near;
extern uns near_bonus_word, near_penalty_gap, near_bonus_connect, near_ceiling;
extern struct ipaccess_list *access_list;

struct database {
  struct database *next;
  byte *name;

  /* Parameters */
  byte *fn_params;
  struct index_params params;

  /* Cards */
  oid_t first_id;
  oid_t num_ids;
  byte *fn_cards;
  byte *fn_card_attrs;
  byte *fn_references;
  int fd_cards, fd_refs;
  struct card_attr *card_attrs;
  sh_off_t card_file_size, ref_file_size;

  /* Words */
  uns word_weights[16];
  byte *fn_lexicon;
  uns lexicon_entries, lexicon_words, lexicon_complexes, lexicon_file_size;
  struct lexicon_entry **lexicon;

  /* Strings */
  uns string_weights[16];
  byte *fn_string_map;
  byte *fn_string_hash;
  u32 *string_hash;
  uns string_buckets, string_hash_order, string_count;
  int fd_string_map;
  uns string_hash_file_size, string_map_file_size;
};

/* reply.c */

struct reply {
  struct reply *next;
  uns len;
  byte text[1];
};

struct replybuf {
  struct reply *first, **last;
  struct mempool *pool;
};

struct query;

void init_reply_buf(struct replybuf *, struct mempool *);
void add_reply(struct replybuf *, char *, ...) __attribute__((format(printf,2,3)));
void ship_reply_buf(struct query *, struct replybuf *);
void flush_reply_buf(struct query *, struct replybuf *);
void first_reply_last(struct replybuf *);

extern struct replybuf *query_rbuf, *cache_rbuf;
void add_qr(char *, ...) __attribute__((format(printf,1,2)));
void add_qerr(char *, ...) __attribute__((format(printf,1,2)));
void add_cr(char *, ...) __attribute__((format(printf,1,2)));
void add_cerr(char *, ...) __attribute__((format(printf,1,2)));
void reply_f(char *, ...) __attribute__((format(printf,1,2)));

/* lex.c */

void lex_init(byte *);
int yylex(void);
int lookup_custom_attr(byte *);

/* parse.y */

enum expr_type {
  /*
   *  Many of the types have limited occurence:
   *	P = parsing and preprocessing
   *	I = input of analyse_query()
   *	O = output of analyse_query()
   *    A = internal to analyse_query()
   */
  EX_RESERVED,				/* ...  Undefined node type */
  EX_MATCH,				/* PI.  Match word or phrase */
  EX_OPTIONS,				/* P..  Set option defaults */
  EX_AND,				/* PIO  Boolean operators */
  EX_OR,
  EX_NOT,
  EX_ANY,				/* PIO  Logical 1 */
  EX_NONE,				/* PIO  Logical 0 */
  EX_IGNORE,				/* .A.  Non-indexed word */
  EX_REF_WORD,				/* ..O  Match word with specified index */
  EX_REF_PHRASE				/* ..O  Match phrase with specified index */
};

struct options {
  int weight;
  sbyte accent_mode;
};

struct expr {
  enum expr_type type;
  union {
    struct {
      struct expr *l, *r;
    } op;
    struct {
      struct options o;
      byte *word;
      uns classmap;
      byte is_string;
      sbyte sense;			/* Matching sense: 1=YES, -1=NOT, 0=MAYBE */
      struct expr *next_simple;		/* Next in simple search chain */
    } match;
    struct {
      struct expr *inside;
      struct options o;
    } options;
    struct {
      uns index;
    } ref;
  } u;
};

struct val_set {			/* Syntactic representation of integer sets */
  struct val_set *next;
  u32 min, max;
  byte *text;
};

#define ACCENT_DEFAULT -1		/* unset */
#define ACCENT_AUTO 0			/* magic auto mode */
#define ACCENT_STRIP 1			/* strip all accents before comparing */
#define ACCENT_STRICT 2			/* compare with accents */

#define WEIGHT_DEFAULT 65535		/* unset */

void err(byte *) NONRET;
byte *parse_query(byte *);
struct expr *new_node(enum expr_type t);
struct expr *new_op(enum expr_type t, struct expr *l, struct expr *r);

/* sherlockd.c */

#define IOBUF_SIZE 4096

struct query {
  node n;
  struct mempool *pool;			/* Memory pool for _query_ data (use results->pool for results to be cached) */

  /* Query parameters */
  u32 db_mask;				/* Database mask */
  struct options default_options;	/* Default word options */
  uns site_only;			/* Only this site */
  uns site_max;				/* Number of documents per site */
  uns allow_approx;			/* Allow approximation */
  uns partial_answers;			/* Allow partial answers */
  struct expr *expr;			/* Query expression (NULL if it's a command) */
  byte *cmd;				/* Command */
#define INT_ATTR(id,keywd,gf,pf) u32 id##_min, id##_max;
#define SMALL_SET_ATTR(id,keywd,gf,pf) u32 id##_set;
  CUSTOM_ATTRS				/* Custom attributes */
#undef INT_ATTR
#undef SMALL_SET_ATTR
  int custom_sorting;			/* Sort on custom attribute */
  u32 custom_sort_reverse;		/* ~0 if sorting reverse, else 0 */
  uns age_raw_min, age_raw_max;		/* Limits on document age */

  /* Display parameters */
  struct val_set *range;		/* Range of results to display */
  uns list_only;			/* Show only a list of results, don't show full cards */
  uns debug;				/* Debug flags */
  uns context_chars;			/* Number of context chars to print */
  uns title_chars;			/* Number of title chars to print */
  uns url_max;				/* Maximum # of URL's to print */

  /* Reply */
  struct replybuf rbuf;			/* Reply header */

  /* Connection */
  sh_time_t established;		/* Time this connection was established */
  int fd;				/* Socket file descriptor */
  int fd_err;				/* Set in case an error has occured */
  int q_status;				/* Error code returned */
  byte ipaddr[16];			/* IP address of the other end */
  byte iobuf[IOBUF_SIZE];		/* I/O buffering */
  byte *ibptr, *ibend;
  byte *obptr, *obend;

  /* Query processing status */
  struct results *results;		/* Result structure for this query */
  struct database *dbase;		/* Database we're currently examining */
  struct word *words;			/* Words matched in the query */
  uns nwords;
  struct ref_chain *first_ref, *last_ref;
  struct phrase *phrases;
  uns nphrases;
  struct word *bool_first_word;		/* First word considered in bool expression */
  uns n_bool_ids;			/* Number of such words and phrases */
  uns matching_docs;			/* Matching documents for this dbase */
  int age_min, age_max;			/* Document age relative to ref_time of current database */
  uns contains_accents;			/* There is an accent anywhere in the query */

  /* Timing statistics */
  uns time_total;
  char *profile_stats;

  /* Memory mappings */
  addr_int_t last_mapping;
};

/* Internal parameters masking themselves as custom attributes */
/* Beware, they should not collide with custom attr offsets in struct query */
#define PARAM_SITE		0
#define PARAM_AGE		1

#define DEBUG_NOCACHE		1	/* Disable reply caching */
#define DEBUG_ANALYSE		2	/* Debug query analyser */
#define DEBUG_DUMPING		4	/* Dumping the context */
#define DEBUG_WORDS		8	/* Debug processing of words */

void reply_string(struct query *, byte *, uns);

/* query.c */

#define MAX_PHRASE_LEN 8

extern struct query *current_query;
extern u32 *bool_map;

/* When processing a simple search query, we represent it by a list of these structures */

struct simple {
  node n;
  struct expr *raw;			/* "raw" version, that is an EX_MATCH node */
  struct expr *cooked;			/* "cooked" version */
  list phrase;				/* words.c: phrase expansion */
};

/*
 *   For each unique entity we match (words, word complexes, strings), we create
 *   a single struct word holding all the relevant information and pointing
 *   to reference chains corresponding to the expansion of this word. Multiple
 *   occurences of the same entity (that is, if all the key attributes marked
 *   with [K] are equal) get mapped to the same struct word.
 */

struct word {
  /* stuff used by refs.c goes first to improve caching */
  struct word *bool_next;		/* Next word considered in boolean expression */
  uns boolean_id;			/* ID used in boolean expression */
  uns type_mask;			/* [K] Bitmap of allowed word/string types */
  uns doc_count;			/* Number of documents matched */
  int weight;				/* Word weight */
  addr_int_t *ref_chains, *last_ref_chain, *end_ref_chains;	/* Variables internal to refs.c */
  int q, q2;
  int pos, pos2;
  uns is_string;			/* [K] Match strings, not words */
  uns is_outer;				/* At least once outside a phrase */
  uns accent_mode;			/* [K] Accent matching mode */
  uns ref_count;			/* Reference chains matched */
  uns ref_total_len;			/* Total length of all reference chains */
  uns status;				/* 0 for OK or error code */
  byte *word;				/* [K] The word itself */
  uns expanded;				/* Already expanded (0=not, 1=partially, 2=with refs) */
  uns width;				/* How many word positions does this word occupy */
  uns word_class;			/* words.c: Word class */
  struct ph_variant *variants;		/* words.c: The list of word variants */
  uns var_count;			/* words.c: The number of variants */
  uns cover_count;			/* words.c: Number of occurences inside a complex */
  uns use_count;			/* Number of times this word was looked up */
};

struct phrase {
  uns word[MAX_PHRASE_LEN];		/* Words the phrase consists of */
  uns relpos[MAX_PHRASE_LEN];		/* Relative positions of the words */
  uns width[MAX_PHRASE_LEN];		/* Widths of the individual words */
  u32 prox_map;				/* Where do we allow proximity */
  uns length;				/* Number of words */
  uns is_near;				/* Near matcher instead of a phrase */
  uns type_mask;
  int weight;
  uns matches;
  uns boolean_id;
  u32 word_mask;
};

struct ref_chain {
  union {
    struct {
      sh_off_t start, stop;
    } file;
    struct {
      u16 *pos;
    } mem;
  } u;
  byte index;				/* Word this ref belongs to */
  byte noaccent_only;			/* Search accentless documents only */
};

struct results {			/* Query results we cache */
  node h;				/* In hash queue (_must_ be first!) */
  node n;				/* In LRU queue */
  int status;				/* -1=uninitialized, 0=OK, else error code */
  byte *request;			/* Normalized request */
  sh_time_t create_time, access_time;	/* Time created/last used */
  struct mempool *pool;			/* Pool holding results */
  struct replybuf rbuf;			/* Reply strings */
  struct result_note **result_heap;	/* Matching documents */
  uns nresults;
  struct result_note *first_note, *free_note;
  uns bests_per_note;
  struct hilite_word *first_hilite;	/* A list of words to highlight in output */
};

struct hilite_word {
  struct hilite_word *next;
  byte w[1];
};

void cache_init(void);
void query_init(void);
void process_query(struct query *q);
int lookup_word(struct query *q, struct expr *e, byte *w);
void add_hilited_word(struct query *q, byte *w);
void eval_err(int code);

/* Profiling counters */
#define PROFILERS(sep) P(analyse) sep P(reff) sep P(refs) sep P(resf) sep P(results)
#define COMMA ,
#define P(x) prof_##x
extern prof_t PROFILERS(COMMA);
extern prof_t prof_send;
#undef P
prof_t *profiler_switch(prof_t *p);

/* cards.c */

void db_init(void);
int check_result_set(struct query *q);
void show_results(struct query *q);

/* words.c */

void words_init(struct database *db);
void word_analyse_simple(struct query *q, list *l);
int word_classify(struct database *db, byte *word);
int contains_accents(byte *s);
void words_add_hilites(struct query *q, struct word *w);

/* strings.c */

void strings_init(struct database *db);
void string_analyse_simple(struct query *q, list *l);

/* memory.c */

struct mmap_request {
  union {
    struct {
      int fd;
      sh_off_t start, end;
    } req;
    struct {
      void *start, *end;
    } map;
  } u;
  addr_int_t userdata;
};

void memory_init(void);
void memory_setup(struct query *q);
void memory_flush(struct query *q);
void *mmap_region(struct query *q, int fd, sh_off_t start, sh_off_t end);
int mmap_regions(struct query *q, struct mmap_request *reqs, int count);

/* refs.c */

#define HARD_MAX_NOTES 6

struct result_note {
  uns heap;				/* Back-link to the heap */
  oid_t oid;
  int q;
  u32 sec_sort_key;
  u16 best[HARD_MAX_NOTES];		/* (width << 12) | (pos ^ 0xfff), 0=undefined */
};

void refs_init(void);
void process_refs(struct query *q);
void query_init_refs(struct query *q);
void query_finish_refs(struct query *q);

/* cmds.c */

void do_command(struct query *q);
