/*
 *	Sherlock HTML Parser
 *
 *	(c) 1997--2001 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"
#include "lib/chartype.h"
#include "lib/index.h"
#include "gather/gather.h"
#include "gather/format/html/html.h"
#include "charset/unicode.h"
#include "charset/unistream.h"

#include <string.h>
#include <stdlib.h>

/* Configuration parameters */

static int trace;
static int comment_mode;
static int quote_hack;
static int script_hack;
static int log_metas;
static int meta_charset;
static int char_ref_hack;
static int ignore_unknown_char_refs;

static struct cfitem html_config[] = {
  { "HTML",		CT_SECTION,	NULL },
  { "Trace",		CT_INT,		&trace },
  { "CommentMode",	CT_INT,		&comment_mode },
  { "QuoteHack",	CT_INT,		&quote_hack },
  { "ScriptHack",	CT_INT,		&script_hack },
  { "CharRefHack",	CT_INT,		&char_ref_hack },
  { "IgnoreUnknownCRs",	CT_INT,		&ignore_unknown_char_refs },
  { "LogMetas",		CT_INT,		&log_metas },
  { "MetaCharset",	CT_INT,		&meta_charset },
  { NULL,		CT_STOP,	NULL }
};

static void CONSTRUCTOR html_init(void)
{
  cf_register(html_config);
}

/* Global variables */

static struct fastbuf *html_in, *html_out;
static int head_mode;
static byte *found_meta_charset;

static uns robot_control;		/* META ROBOTS and similar switches */
#define RC_INDEX 1
#define RC_FOLLOW 2

/* Reading of input file */

static int ungot_char = -1;

static int
get_char(void)
{
  if (ungot_char >= 0)
    {
      int c = ungot_char;
      ungot_char = -1;
      return c;
    }
  return bget_utf8(html_in);
}

static inline void
unget_char(int i)
{
  ASSERT(ungot_char < 0);
  ungot_char = i;
}

/* Parsing and decoding of HTML entities, returns UniCode value of the entity */

static int
decode_entity(byte *e)
{
  const struct entity *n;
  struct entity ent;

  if (e[0] == '#')
    {
      n = &ent;
      if (e[1] == 'x' || e[1] == 'X')
	ent.value = strtol(e+2, NULL, 16);
      else
	ent.value = strtol(e+1, NULL, 10);
    }
  else n = is_entity(e, strlen(e));
  if (n)
    {
      if (trace >= 100)
	printf("&%s; = %02x\n", e, n->value);
      return n->value;
    }
  else if (trace >= 100)
    printf("&%s; = ???\n", e);
  return 0;
}

static int
get_entity(uns hack)
{
  byte buf[80];
  uns i;
  int c;
  uns startpos = btell(html_in);

  i = 0;
  c = get_char();
  if (c == '#')
    {
      buf[i++] = c;
      c = get_char();
    }
  while (c >= 0 && c < 0x100 && Calnum(c))
    {
      if (i >= sizeof(buf) - 1)		/* Suspiciously long entity, try to recover */
	goto fail;
      buf[i++] = c;
      c = get_char();
    }
  if (c < 0)
    goto fail;
  buf[i] = 0;
  if (c != ';')				/* Broken ending */
    {
      if (!char_ref_hack)
	{
	  log(L_WARN_R, "Invalid character reference &%s<%x>", buf, c);
	  goto fail;
	}
      if (hack)				/* Inside parameter -- take as plain text */
	goto fail;
      unget_char(c);
    }
  c = decode_entity(buf);
  if (c > 0 || ignore_unknown_char_refs)
    return c;

fail:					/* Syntax error, interpret as plain text */
  get_char();				/* Reset unget_char() */
  bsetpos(html_in, startpos);
  return '&';
}

/* Word gathering */

static int force_class;

static int
attrs_to_class(uns a)
{
  if (force_class)
    return force_class;
  if (a & A_TITLE)
    return WT_TITLE;
  if (a & (A_H1 | A_H2 | A_H3))
    return WT_BIG_HEADING;
  if (a & (A_H4 | A_H5 | A_H6))
    return WT_SMALL_HEADING;
  if (a & (A_SUP | A_SUB | A_SMALL | A_SMALLFONT))
    return WT_SMALL;
  if (a & (A_EM | A_B | A_I | A_STRONG | A_DFN | A_BIG | A_LARGEFONT))
    return WT_EMPH;
  if (a & A_OBJECT)
    return WT_ALT;
  return WT_TEXT;
}

static int current_class;
static int queued_sentence_break;

static void
add_word(uns *wo, int class)
{
  int need_sp = 1;

  if (class != current_class || queued_sentence_break)
    {
      bputc(html_out, (queued_sentence_break ? 0x90 : 0x80) + class);
      current_class = class;
      queued_sentence_break = 0;
      need_sp = 0;
    }
  else
    bputc(html_out, ' ');
  while (*wo)
    {
      if (*wo < 0x80000000)
	bput_utf8(html_out, *wo);
      else if (*wo < 0x80020000)
	{
	  uns ref = *wo - 0x80020000;
	  bputc(html_out, 0xa0 | (ref >> 6));
	  bputc(html_out, 0x80 | (ref & 0x3f));
	}
      else
	bputc(html_out, 0xb0);
      wo++;
    }
}

static uns wordbuf[MAX_WORD_LEN];
static uns wordlen;
static uns attrs, wattrs;

static void
flush_word(void)
{
  if (wordlen >= MAX_WORD_LEN)
    {
      /*
       * We want to throw the superlong word out, but we really need to write
       * the reference brackets to keep them balanced.
       */
      uns l = wordlen;
      uns i;
      wordlen = 0;
      for (i=0; i<l; i++)
	if (wordbuf[i] >= 0x80000000)
	  wordbuf[wordlen++] = wordbuf[i];
    }
  if (wordlen)
    {
      wordbuf[wordlen] = 0;
      add_word(wordbuf, attrs_to_class(wattrs));
      wordlen = 0;
    }
  wattrs = 0;
}

static inline void
add_char(uns c)
{
  if (c >= 0x80000000)
    {
      /* URL brackets can split extremely long words */
      if (wordlen >= MAX_WORD_LEN)
	flush_word();
      wordbuf[wordlen++] = c;
    }
  else if (Uprint(c) && !Uspace(c))
    {
      if (wordlen < MAX_WORD_LEN)
	{
	  wordbuf[wordlen++] = c;
	  wattrs |= attrs;
	}
    }
  else if (wordlen)			/* Redundant condition, speedup only */
    flush_word();
}

static void
emit_ref_start(int ref)
{
  if (ref >= 0 && ref < 1024)
    add_char(0x80010000 + ref);
}

static void
emit_ref_end(int ref)
{
  if (ref >= 0 && ref < 1024)
    add_char(0x80020000);
}

static void
add_string(byte *s, int class, int ref)
{
  if (!s)
    return;
  flush_word();
  force_class = class;
  if (ref >= 0)
    emit_ref_start(ref);
  while (*s)
    {
      uns u;
      GET_UTF8(s, u);
      add_char(u);
    }
  if (ref >= 0)
    emit_ref_end(ref);
  flush_word();
  force_class = 0;
}

static void
add_obj_ref(byte *base_url, byte *ref, byte *ctype)
{
  byte bbuf1[MAX_URL_SIZE], bbuf2[MAX_URL_SIZE];
  struct url bu, *base = NULL;
  int e;

  if (base_url)
    {
      if (e = url_canon_split(base_url, bbuf1, bbuf2, &bu))
	{
	  log(L_ERROR_R, "Error parsing object base URL %s: %s", base_url, url_error(e));
	  return;
	}
      base = &bu;
    }
  gobj_add_ref_full('A', ref, ctype, base);
}

#ifndef CONFIG_IMAGES
struct gobj_ref *
image_add_ref(byte *src, byte *width UNUSED, byte *height UNUSED)
{
  struct gobj_ref *r;

  if (r = gobj_add_ref_full('I', src, NULL, NULL))
    r->dont_follow = 1;
  return r;
}
#endif

/* Processing of META tags */

static int
chew_meta_robots(byte *t)
{
  uns r = RC_INDEX | RC_FOLLOW;
  byte *p;
  byte z;

  while (*t)
    {
      if (Cspace(*t) || *t == ',')
	{
	  t++;
	  continue;
	}
      p = t;
      while (*t && *t != ',' && !Cspace(*t))
	t++;
      z = *t;
      *t = 0;
      if (!strcasecmp(p, "NOINDEX"))
	r &= ~RC_INDEX;
      else if (!strcasecmp(p, "NOFOLLOW"))
	r &= ~RC_FOLLOW;
      else if (!strcasecmp(p, "INDEX"))
	r |= RC_INDEX;
      else if (!strcasecmp(p, "FOLLOW"))
	r |= RC_FOLLOW;
      else if (!strcasecmp(p, "ALL"))
	r = RC_FOLLOW | RC_INDEX;
      else if (!strcasecmp(p, "NONE"))
	r = 0;
      else if (*p)
	return -1;
      *t = z;
    }
  return r;
}

static void
chew_meta(byte *name, byte *text)
{
  if (log_metas >= 2)
    log(L_DEBUG, "META %s=%s", name, text);
  if (!strcasecmp(name, "description"))
    add_string(text, WT_META, -1);
  else if (!strcasecmp(name, "robots"))
    {
      int r = chew_meta_robots(text);
      byte comment[64];
      if (r < 0)
	{
	err:
	  if (log_metas == 1)
	    log(L_WARN_R, "Unknown META %s=%s", name, text);
	  return;
	}
      sprintf(comment, "Meta robot control: %sINDEX, %sFOLLOW",
	      (r & RC_INDEX) ? "" : "NO",
	      (r & RC_FOLLOW) ? "" : "NO");
      obj_add_attr(gthis->aa, NULL, '.', comment);
      robot_control = r;
    }
  else if (!strcasecmp(name, "keywords"))
    add_string(text, WT_KEYWORD, -1);
  else if (!strcasecmp(name, "title"))
    add_string(text, WT_META, -1);
  else if (!strcasecmp(name, "refresh"))
    {
      byte *k = strchr(text, ';');
      if (k)
	{
	  k++;
	  while (Cspace(*k))
	    k++;
	  if (strncasecmp(k, "URL=", 4))
	    goto err;
	  gobj_add_ref('R', k+4);
	}
      else if (k = strchr(text, ','))
	{
	  k++;
	  while (Cspace(*k))
	    k++;
	  if (*k)
	    gobj_add_ref('R', k);
	}
    }
  else if (!strcasecmp(name, "content-type"))	/* Parsed in head mode */
    ;
  else if (strcasecmp(name, "author")	/* Useless META's */
	   && strcasecmp(name, "generator")
	   && strcasecmp(name, "formatter"))
    goto err;
}

static void
chew_meta_head(byte *name, byte *text)
{
  if (strcasecmp(name, "content-type"))
    return;
  parse_content_type(text, &found_meta_charset);
  if (found_meta_charset)
    {
      found_meta_charset = gstrdup(found_meta_charset);
      if (trace)
	log(L_DEBUG, "META charset=%s", found_meta_charset);
    }
}

/* Chew an already parsed HTML tag */

static byte **attr_names, **attr_vals;
static uns attr_count;
static int current_ref;
static int base_font_size;

static byte *
getarg(byte *name)
{
  uns i;

  for(i=0; i<attr_count; i++)
    if (!strcmp(attr_names[i], name))
      return attr_vals[i] ? attr_vals[i] : (byte *) "";
  return NULL;
}

static int
skip_script(int is_style)
{
  int r = 0;

  if (script_hack)			/* Work-around for broken documents */
    {
      byte *z = is_style ? "</STYLE>" : "</SCRIPT>"; /* Trick: no character occurs twice */
      int state = 0;
      while (z[state])
	{
	  r = get_char();
	  if (r < 0)
	    {
	      log(L_ERROR_R, "End of file when searching for </script>");
	      return 1;
	    }
	  if (r < 128)
	    r = Cupcase(r);
	  if (z[state] == r || z[state=0] == r)
	    state++;
	}
    }
  else					/* Standard behaviour */
    {
      do
	{
	  if (r < 0)
	    return 1;
	  if (r != '<')
	    {
	      r = get_char();
	      continue;
	    }
	}
      while ((r = get_char()) != '/' ||
	     (r = get_char()) < 0 || r < 0 || r >= 256 || !Calpha(r));
      while ((r = get_char()) >= 0 && r != '>')
	;
    }
  return 0;
}

static int
chew_tag(byte *name, byte **anames, byte **avals, uns acount)
{
  const struct tag *t;
  byte *k, *l;
  int r;
  uns tag;
  static struct tag unknown_tag = { name: "?", type: T_IGNORE | T_FLOW | T_HEAD, arg: 0 };
  struct gobj_ref *ref;

  attr_names = anames;
  attr_vals = avals;
  attr_count = acount;
  t = is_tag(name, strlen(name));
  if (!t)
    t = &unknown_tag;
  if (trace >= 100)
    {
      uns i;
      printf("<%s", t->name);
      for(i=0; i<acount; i++)
	printf(" %s=%s", anames[i], avals[i]);
      putchar('>');
      if (t)
	printf(" = %x,%x", t->type, t->arg);
      putchar('\n');
    }
  tag = t->type;
  if (head_mode)
    {
      if (!(tag & T_HEAD))
	return 1;
      switch (tag & ~(T_HEAD | T_FLOW | T_HARD))
	{
	case T_META:
	  if ((k = getarg("HTTP-EQUIV")) && (l = getarg("CONTENT")))
	    chew_meta_head(k, l);
	  break;
	}
      return 0;
    }
  if (!(tag & T_FLOW))
    flush_word();
  if (tag & T_HARD)
    queued_sentence_break = 1;
  if (k = getarg("LONGDESC"))	/* Attributes which can occur in many different tags */
    gobj_add_ref('d', k);
  /* FIXME: TITLE attribute should be handled as well */
  switch (tag & ~(T_HEAD | T_FLOW | T_HARD))
    {
    case T_IGNORE:
      break;
    case T_ON:			/* Switch an attribute on */
      attrs |= t->arg;
      break;
    case T_OFF:			/* Switch an attribute off */
      attrs &= ~t->arg;
      break;
    case T_BASE:			/* Set base URL */
      if (k = getarg("HREF"))
	gthis->base_url = gobj_parse_url(&gthis->base_url_s, k, "base", 0);
      break;
    case T_META:			/* Meta-information */
      k = getarg("NAME");
      if (!k)
	k = getarg("HTTP-EQUIV");
      l = getarg("CONTENT");
      if (k && l)
	chew_meta(k, l);
      break;
    case T_A:				/* Anchor */
      if (t->arg)			/* End */
	{
	  if (current_ref >= 0)
	    emit_ref_end(current_ref);
	  current_ref = -1;
	}
      else if (k = getarg("HREF"))
	{
	  struct gobj_ref *ref = gobj_add_ref_full('R', k, getarg("TYPE"), NULL);
	  if (current_ref >= 0)
	    emit_ref_end(current_ref);
	  current_ref = ref ? ref->id : -1;
	  emit_ref_start(current_ref);
	}
      break;
    case T_LINK:			/* A structured link */
      gobj_add_ref_full('R', getarg("HREF"), getarg("TYPE"), NULL);
      break;
    case T_IMG:				/* An image */
      ref = image_add_ref(getarg("SRC"), getarg("WIDTH"), getarg("HEIGHT"));
      if (ref)
	{
	  byte *alt = getarg("ALT");
	  /* Even if ALT is empty, we wish to store the URL brackets if the image is indexable */
	  if (!alt && !ref->dont_follow)
	    alt = "";
	  add_string(alt, WT_ALT, ref->id);
	}
      break;
    case T_FRAME:			/* Frame -- who would think such an ugliness will make its way to the HTML specs? */
      gobj_add_ref('F', getarg("SRC"));
      break;
    case T_AREA:			/* Area -- another nastie */
      r = gobj_add_ref('R', getarg("HREF"));
      add_string(getarg("ALT"), WT_ALT, r);
      break;
    case T_OBJECT:			/* An embedded object */
      if (!t->arg)
	{
	  k = getarg("CODEBASE");
	  add_obj_ref(k, getarg("CLASSID"), getarg("CODETYPE"));
	  add_obj_ref(k, getarg("DATA"), getarg("TYPE"));
	  /* add_string(getarg("STANDBY"), WT_ALT, -1); */
	  attrs |= A_OBJECT;
	}
      else
	attrs &= ~A_OBJECT;
      break;
    case T_APPLET:			/* An applet */
      add_string(getarg("ALT"), WT_ALT, -1);
      k = getarg("CODEBASE");
      add_obj_ref(k, getarg("CODE"), "application/x-java");
      add_obj_ref(k, getarg("OBJECT"), "application/x-java");
      break;
    case T_FORM:			/* A form */
      gobj_add_ref('f', getarg("ACTION"));
      break;
    case T_BLOCKQUOTE:
    case T_INSDEL:
      gobj_add_ref('R', getarg("CITE"));
      break;
    case T_TABLE:
      add_string(getarg("SUMMARY"), WT_TEXT, -1);
      break;
    case T_BASEFONT:
      if (k = getarg("SIZE"))
	base_font_size = strtol(k, NULL, 10);
      break;
    case T_FONT:
      if (!t->arg)
	{
	  if (k = getarg("SIZE"))
	    {
	      r = strtol(k, NULL, 10);
	      if (k[0] == '+' || k[0] == '-')
		r += base_font_size;
	      if (r < base_font_size)
		attrs |= A_SMALLFONT;
	      else if (r > base_font_size)
		attrs |= A_LARGEFONT;
	    }
	}
      else
	attrs &= ~(A_SMALLFONT | A_LARGEFONT);
      break;
    case T_SCRIPT:			/* Skip until "</[a-zA-Z]" */
      return skip_script(t->arg);
    default:
      die("Unknown tag type %x", t->type);
    }
  return 0;
}

/* Parse a SGML control tag (<!...> or <?...>) */

static void
parse_sgml_tag(void)
{
  int c;

  if (trace >= 100)
    puts("<!some-control-tag>");
  c = get_char();
  for(;;)
    {
      if (c < 0 || c == '>')
	return;
      if (c == '-')			/* Maybe a comment */
	{
	  c = get_char();
	  if (c != '-')
	    continue;
	  switch (comment_mode)
	    {
	    case 0:			/* Standard behaviour */
	      c = get_char();
	      for(;;)
		{
		  if (c < 0)
		    return;
		  if (c == '-')
		    {
		      c = get_char();
		      if (c == '-')
			break;
		    }
		  else
		    c = get_char();
		}
	      break;
	    case 1:			/* Silly implementation: end with ">" */
	      for(;;)
		{
		  c = get_char();
		  if (c < 0 || c == '>')
		    return;
		}
	      /* Cannot get here */
	    default:			/* Buggy Netscape compatibility: end with "-->" */
	      c = get_char();
	      for(;;)
		{
		  if (c < 0)
		    return;
		  if (c == '-')
		    {
		      c = get_char();
		      while (c == '-')
			{
			  c = get_char();
			  if (c == '>' || c < 0)
			    return;
			}
		    }
		  else
		    c = get_char();
		}
	    }
	}
      else if (c == '"' || c == '\'')	/* Quoted part */
	{
	  int k = c;
	  int hacking_quotes = 0;
	  while ((c = get_char()) != k)
	    {
	      if (c < 0)
		return;
	      if (c == '\r' || c == '\n')
		{
		  if (quote_hack == 1)
		    return;
		  if (quote_hack)
		    hacking_quotes = 1;
		}
	      if (hacking_quotes && c == '>')
		return;
	    }
	}
      c = get_char();
    }
}

/* Parse a HTML tag */

#define MAX_ATTRS 64

static int
parse_tag(void)
{					/* Ugly state-machine-like code :-| */
  byte buf[1024];
  byte *aname[MAX_ATTRS+1], *aval[MAX_ATTRS+1];
  int c, attr;
  byte *k, *stop;

  stop = buf + sizeof(buf) - 8;		/* Parse tag name */
  k = buf;
  attr = 0;
  for(;;)
    {
      c = get_char();
      if (c < 0)
	return 1;
      if (c == '>')
	goto finished;
      if (Uspace(c) || c == '\r' || c == '\n')
	break;
      if (c >= 0x80)			/* Tag names: non-ASCII characters are replaced by DEL */
	c = 0x7f;
      if (k < stop)
	*k++ = Cupcase(c);
    }
  if (k < stop)
    *k++ = 0;

  for(;;)				/* Parse attributes */
    {
      while (c >= 0 && (Uspace(c) || c == '\r' || c == '\n'))
	c = get_char();
      if (c < 0)
	return 1;
      if (c == '>')
	break;
      aname[attr] = k;
      for(;;)
	{
	  if (c < 0)
	    return 1;
	  if (c == '>')
	    {
	      aval[attr++] = NULL;
	      goto finished;
	    }
	  if (Uspace(c) || c == '\r' || c == '\n')
	    {
	      aval[attr] = NULL;
	      goto cont;
	    }
	  if (c == '=')
	    {
	      c = get_char();
	      break;
	    }
	  if (c >= 0x80)		/* Attribute names: non-ASCII characters are replaced by DEL */
	    c = 0x7f;
	  if (k < stop)
	    *k++ = Cupcase(c);
	  c = get_char();
	}
      if (k < stop)
	*k++ = 0;
      aval[attr] = k;
      if (c == '"' || c == '\'')
	{
	  int d = c;
	  int hacking_quotes = 0;

	  c = get_char();
	  while (c != d)
	    {
	      if (c < 0)
		return 1;
	      if (c == '\r' || c == '\n')
		{
		  if (quote_hack == 1)
		    return 0;
		  if (quote_hack)
		    hacking_quotes = 1;
		}
	      if (hacking_quotes && c == '>')
		return 0;
	      if (c == '&')		/* Honor entities in attribute values */
		{
		  c = get_entity(1);
		  if (!c)
		    continue;
		}
	      if (k < stop)		/* Attribute values: non-ASCII characters are encoded in UTF-8 */
		PUT_UTF8(k, c);
	      c = get_char();
	    }
	  c = get_char();
	}
      else
	for(;;)
	  {
	    if (c == '>')
	      {
		attr++;
		goto finished;
	      }
	    if (Uspace(c) || c == '\r' || c == '\n')
	      break;
	    else if (k < stop)
	      PUT_UTF8(k, c);
	    c = get_char();
	    if (c < 0)
	      return 1;
	  }
    cont:
      if (k < stop)
	*k++ = 0;
      if (attr < MAX_ATTRS)
	attr++;
    }

finished:
  if (k < stop)
    {
      *k = 0;
      return chew_tag(buf, aname, aval, attr);
    }
  return 0;
}

/* Main loop of the HTML parser */

static void
chew_html(void)
{
  int c;

  wordlen = wattrs = 0;
  current_ref = -1;
  base_font_size = 3;
  current_class = WT_TEXT;
  queued_sentence_break = 1;
  robot_control = RC_INDEX | RC_FOLLOW;

  if (trace >= 100)
    puts("### Start ###");
  while ((c = get_char()) >= 0)
    {
      if (c == '<')			/* Tag or control tag */
	{
	  c = get_char();
	  if (c < 0)
	    break;
	  if (c == '!' || c == '?')
	    parse_sgml_tag();
	  else
	    {
	      unget_char(c);
	      if (parse_tag())
		break;
	    }
	  continue;
	}
      if (head_mode)
	continue;
      if (c == '&')			/* Entity */
	{
	  c = get_entity(0);
	  if (!c)
	    continue;
	}
      add_char(c);
    }
  if (current_ref >= 0)
    emit_ref_end(current_ref);
  if (gthis->truncated)
    {
      /*
       * Fill the word buffer, so that the incomplete word at the end
       * will be ignored, but all ref brackets will be properly flushed.
       */
      uns i;
      for (i=0; i<MAX_WORD_LEN; i++)
	add_char('.');
    }
  flush_word();
}

int
html_parse(void)
{
  /* Scan the document for META tags carrying charset info if asked */
  found_meta_charset = NULL;
  if (meta_charset)
    {
      head_mode = 1;
      html_in = fbmem_clone_read(gthis->contents);
      chew_html();
      bclose(html_in);
    }

  /* Guess charset and convert to UTF-8 */
  convert_charset(found_meta_charset);

  /* Parse the document */
  head_mode = 0;
  html_in = fbmem_clone_read(gthis->contents);
  html_out = gthis->text = fbmem_create(16384);
  chew_html();
  bclose(html_in);

  if (!(robot_control & RC_INDEX))
    gthis->dont_save_contents = 1;
  if (!(robot_control & RC_FOLLOW))
    gthis->dont_follow_links = 1;

  return 1;
}
