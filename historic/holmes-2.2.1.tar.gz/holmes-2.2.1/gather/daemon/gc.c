/*
 *	Sherlock Gatherer Control Utility
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "gather/daemon/gatherd.h"
#include "lib/url.h"
#include "lib/conf.h"
#include "lib/db.h"
#include "lib/pools.h"

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

/* Globals */

static int verbose;
sh_time_t now;

/* Support functions */

static struct url url;
static byte ubuf0[MAX_URL_SIZE], ubuf1[MAX_URL_SIZE], ubuf2[MAX_URL_SIZE], ubuf3[MAX_URL_SIZE];

static void
parse_url(byte *u)
{
  int err = url_canon_split(u, ubuf0, ubuf1, &url);
  if (err)
    die("Error parsing %s: %s", u, url_error(err));
}

static byte *
canon_url(byte *u)
{
  int err = url_auto_canonicalize(u, ubuf0);
  if (err)
    die("Error parsing %s: %s", u, url_error(err));
  return ubuf0;
}

/* List hosts and queued objects */

static void
show_host(struct qhost *h)
{
  uns i;

  if (!h->protocol)			/* Free list entry */
    return;
  printf("%s://%s:%d [robots %08x age %d] [",
	 url_proto_names[h->protocol], h->name, h->port,
	 h->robot_id,
	 (h->robot_id == OID_UNDEFINED) ? 0 : (now - h->robot_time));
  for (i=0; i<SHERLOCK_NUM_SECTIONS; i++)
    {
      if (i)
	putchar('+');
      printf("%d", h->obj_count[i]);
    }
  printf(" objects] [key %08x]%s\n",
	 h->qkey,
	 h->qf_pos ? "" : " [IDLE]");
}

static void
show_host_queue(struct qhost *h)
{
  uns pos;
  byte *q;

  if (!h->protocol)			/* Free list entry */
    return;
  show_host(h);
  putchar('\n');
  pos = queue_walk_start(h);
  while (q = queue_walk_next(&pos))
    {
      putchar('\t');
      puts(q);
    }
  putchar('\n');
}

static void
list_queue(byte *u)
{
  struct qhost *h;
 
  queue_init();
  if (u)
    {
      parse_url(u);
      h = find_host(url.protoid, url.host, url.port);
      if (!h)
	die("Host not found");
      show_host_queue(h);
    }
  else
    walk_hosts(show_host_queue);
}

static void
list_hosts(byte *u)
{
  struct qhost *h;

  queue_init();
  if (u)
    {
      parse_url(u);
      h = find_host(url.protoid, url.host, url.port);
      if (!h)
	die("Host not found");
      show_host(h);
    }
  else
    walk_hosts(show_host);
}

static void
unqueue(byte *ur)
{
  struct qhost *h;
  struct qitem *a;
  struct urlrec u;
  int err;

  parse_url(ur);
  gather_lock();
  urldb_open();
  queue_init();
  if (! (h = find_host(url.protoid, url.host, url.port)))
    log(L_ERROR, "Unknown host");
  else
    {
      while (a = dequeue_item(h))
	{
	  printf("%s: ", a->text);
	  url.rest = a->text;
	  if (err = url_pack(&url, ubuf2))
	    die("url_pack: %s", url_error(err));
	  if (err = url_enescape(ubuf2, ubuf3))
	    die("url_enescape: %s", url_error(err));
	  if (urldb_lookup(ubuf3, &u))
	    {
	      if (! (u.flags & URF_QUEUED))
		printf("BAD DB RECORD\n");
	      else if (u.oid)
		{
		  printf("%08x\n", u.oid);
		  u.flags &= URF_QUEUED;
		  urldb_store(ubuf3, &u);
		}
	      else if (urldb_delete(ubuf3))
		printf("DELETED\n");
	      else
		printf("DELETE FAILED\n");
	    }
	  else
	    printf("NO DB ITEM\n");
	}
    }
  queue_cleanup();
  urldb_close();
  gather_unlock();
}

/* URLs */

static void
show_url0(byte *n, struct urlrec *z)
{
  struct tm *tm;

  printf("%s%s%s ", n,
	 (z->flags & URF_QUEUED) ? " [QUEUED]" : "",
	 (z->flags & URF_INITIAL) ? " [INIT]" : "");
  if (z->oid == OID_UNDEFINED)
    printf("<unknown>");
  else if (z->oid >= OID_FIRST_ERROR)
    printf("Error %d", z->oid - OID_FIRST_ERROR);
  else
    printf("%08x", z->oid);
  if (verbose)
    {
      time_t t;
      t = z->access;
      if (! (tm = localtime(&t)))
	die("Time parse error");
      printf (" T=%04d%02d%02d:%02d%02d",
	      tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
	      tm->tm_hour, tm->tm_min);
      if (t = z->http_last_mod)
	{
	  if (! (tm = localtime(&t)))
	    die("Lastmod parse error");
	  printf (" L=%04d%02d%02d:%02d%02d",
		  tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
		  tm->tm_hour, tm->tm_min);
	}
      if (z->avg_change_time)
	printf(" C=%d", z->avg_change_time);
      if (z->retries)
	printf(" R=%d", z->retries);
    }
  putchar('\n');
}

static void
show_url(byte *u)
{
  struct urlrec z;

  gather_lock();
  urldb_open();
  if (u)
    {
      u = canon_url(u);
      if (!urldb_lookup(u, &z))
	log(L_ERROR, "%s: Not found", u);
      else
	show_url0(u, &z);
    }
  else
    {
      byte url[MAX_URL_SIZE];
      urldb_rewind();
      while (urldb_get_next(url, &z))
	show_url0(url, &z);
    }
  urldb_close();
  gather_unlock();
}

static void
del_url(byte *u)
{
  gather_lock();
  urldb_open();
  if (!urldb_delete(u))
    log(L_ERROR, "%s: Not found", u);
  urldb_close();
  gather_unlock();
}

/* MD5 Database */

static void
show_md5(byte *m)
{
  struct md5rec z;

  gather_lock();
  md5db_open();
  if (m)
    {
      if (!md5db_lookup(m, &z))
	log(L_ERROR, "%s: Not found", m);
      else
	printf("%s: %08x\n", m, z.oid);
    }
  else
    {
      byte M[MD5_HEX_SIZE];
      md5db_rewind();
      while (md5db_get_next(M, &z))
	printf("%s: %08x\n", M, z.oid);
    }
  md5db_close();
  gather_unlock();
}

static void
del_md5(byte *m)
{
  gather_lock();
  md5db_open();
  if (!md5db_delete(m))
    log(L_ERROR, "%s: Not found", m);
  md5db_close();
  gather_unlock();
}

/* Insertion of new URL's */

struct ins_key {
  uns len;
  byte url[MAX_URL_SIZE];
};

#define SORT_KEY struct ins_key
#define SORT_PREFIX(x) ins_##x
#define SORT_PRESORT
#define SORT_UNIFY
#define SORT_INPUT_FB
#define SORT_OUTPUT_FB

static struct fastbuf *ins_src_fb;

static int
ins_compare(struct ins_key *a, struct ins_key *b)
{
  u32 ha = sdbm_hash(a->url, a->len);
  u32 hb = sdbm_hash(b->url, b->len);

  if (ha < hb)
    return -1;
  if (ha > hb)
    return 1;
  return strcmp(a->url, b->url);
}

static int
ins_fetch_key(struct fastbuf *f, struct ins_key *k)
{
  if (f)
    {
      byte *x = bgets(f, k->url, MAX_URL_SIZE);
      if (!x)
	return 0;
      k->len = x - k->url;
      return 1;
    }
  else
    {
      byte buf[MAX_URL_SIZE];
      int err;
      for(;;)
	{
	  if (!bgets(ins_src_fb, buf, MAX_URL_SIZE))
	    return 0;
	  if (!(err = url_auto_canonicalize(buf, k->url)))
	    {
	      k->len = strlen(k->url);
	      return 1;
	    }
	  if (log_ref_errors)
	    log(L_ERROR, "%s: %s", buf, url_error(err));
	}
    }
}

static inline void
ins_copy_data(struct fastbuf *src UNUSED, struct fastbuf *dest, struct ins_key *k)
{
  bwrite(dest, k->url, k->len);
  bputc(dest, '\n');
}

static inline void
ins_merge_data(struct fastbuf *src1, struct fastbuf *src2 UNUSED, struct fastbuf *dest,
	       struct ins_key *k1, struct ins_key *k2 UNUSED)
{
  ins_copy_data(src1, dest, k1);
}

static inline byte *
ins_fetch_item(struct fastbuf *f UNUSED, struct ins_key *k, byte *limit UNUSED)
{
  return k->url + k->len + 1;
}

static inline void
ins_store_item(struct fastbuf *f, struct ins_key *k)
{
  ins_copy_data(NULL, f, k);
}

static struct ins_key *
ins_merge_items(struct ins_key *a, struct ins_key *b UNUSED)
{
  return a;
}

#include "lib/sorter.h"

static void
insert_urls(int mode)
{
  struct fastbuf *f;
  byte buf[MAX_URL_SIZE];
  uns cnt = 0;

  f = bfdopen_shared(0, 4096);
  if (mode)
    {
      log(L_INFO, "Sorting URL list");
      ins_src_fb = f;
      f = ins_sort(NULL);
      log(L_INFO, "Inserting URL's");
    }

  gather_lock();
  obuck_init(1);
  obuck_cleanup();
  queue_init();
  urldb_open();
  refs_init(1);
  while (bgets(f, buf, sizeof(buf)))
    {
      if (buf[0] && buf[0] != '#')
	{
	  add_ref(buf, URF_INITIAL);
	  cnt++;
	}
    }
  bclose(f);
  log(L_INFO, "Inserted %d URL's", cnt);
  urldb_close();
  queue_cleanup();
  gather_unlock();
}

/* Calculation of statistics */

struct hs {
  struct hs *next;
  uns okays, errs, queued, requeued;
  word port;
  byte protocol;
  byte hostname[1];
};

#define HASH_NODE struct hs
#define HASH_PREFIX(x) hs_##x
#define HASH_KEY_COMPLEX(x) x hostname, x protocol, x port
#define HASH_KEY_DECL byte *hostname, uns protocol, uns port
#define HASH_WANT_LOOKUP

#define HASH_GIVE_HASHFN
#include "lib/hashfunc.h"
static inline uns hs_hash(byte *host, uns proto UNUSED, uns port UNUSED)
{
  return hash_string(host);
}

#define HASH_GIVE_EQ
static inline uns hs_eq(byte *h1, uns p1, uns t1, byte *h2, uns p2, uns t2)
{
  return !strcmp(h1, h2) && p1 == p2 && t1 == t2;
}

#define HASH_GIVE_EXTRA_SIZE
static inline int hs_extra_size(byte *h, uns p UNUSED, uns t UNUSED)
{
  return strlen(h);
}

#define HASH_GIVE_INIT_KEY
static inline void hs_init_key(struct hs *n, byte *h, uns p, uns t)
{
  strcpy(n->hostname, h);
  n->protocol = p;
  n->port = t;
  /* Does data initialization as well */
  n->okays = n->errs = n->queued = n->requeued = 0;
}

#define HASH_USE_POOL hs_pool
static struct mempool *hs_pool;

#include "lib/hashtable.h"

static void
host_stats(void)
{
  struct urlrec z;
  byte url[MAX_URL_SIZE], buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];
  struct url ur;
  int e;
  struct hs *h;

  hs_pool = mp_new(65536);
  hs_init();
  gather_lock();
  urldb_open();
  urldb_rewind();
  while (urldb_get_next(url, &z))
    {
      if (e = url_canon_split(url, buf1, buf2, &ur))
	{
	  log(L_ERROR, "Unable to parse %s: %s", url, url_error(e));
	  continue;
	}
      h = hs_lookup(ur.host, ur.protoid, ur.port);
      if (z.flags & URF_QUEUED)
	{
	  if (z.oid == OID_UNDEFINED)
	    h->queued++;
	  else
	    h->requeued++;
	}
      if (z.oid == OID_UNDEFINED)
	;
      else if (z.oid >= OID_FIRST_ERROR)
	h->errs++;
      else
	h->okays++;
    }
  urldb_close();
  gather_unlock();
  HASH_FOR_ALL(hs, h)
    {
      printf("%d\t%d\t%d\t%d\t%s://%s:%d\n", h->okays, h->errs, h->queued, h->requeued,
	     url_proto_names[h->protocol], h->hostname, h->port);
    }
  HASH_END_FOR;
}

/* Testing of ref filter */

static void
test_ref_filter(void)
{
  struct fastbuf *f = bfdopen_shared(0, 4096);
  byte buf[MAX_URL_SIZE], *msg;
  struct rfilter_data rfdata;

  refs_init(1);
  while (bgets(f, buf, sizeof(buf)))
    {
      rfdata.url = buf;
      if (msg = ref_filter(&rfdata))
	puts(msg);
      else
	printf("OK: sec=%d sectmax=%d/%d ct=%s ce=%s url_key=%s\n",
	       rfdata.section, rfdata.section_soft_max, rfdata.section_hard_max,
	       rfdata.content_type, rfdata.content_encoding, rfdata.url_key);
      ref_filter_undo();
    }
}

/* Requeueing */

static void
requeue(void)
{
  byte buf[MAX_URL_SIZE], url[MAX_URL_SIZE], buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE], buf3[MAX_URL_SIZE];
  int e;
  uns cnt = 0;
  struct url ur;
  struct urlrec u;
  sh_time_t now = time(NULL);
  struct fastbuf *f = bfdopen_shared(0, 4096);

  gather_lock();
  queue_init();
  urldb_open();
  refs_init(1);
  while (bgets(f, buf, sizeof(buf)))
    {
      if (!buf[0] || buf[0] == '#')
	continue;
      if ((e = url_canon_split(buf, buf1, buf2, &ur)) ||
	  (e = url_pack(&ur, buf3)) ||
	  (e = url_enescape(buf3, url)))
	{
	  if (log_ref_errors)
	    log(L_ERROR, "%s: %s", buf, url_error(e));
	  continue;
	}
      cnt++;
      if (urldb_lookup(url, &u))
	{
	  struct qhost *h = find_host(ur.protoid, ur.host, ur.port);
	  ASSERT(h);
	  if (!(u.flags & URF_QUEUED))
	    {
	      u.access = now;
	      u.flags |= URF_QUEUED;
	      if (u.oid >= OID_FIRST_ERROR)
		u.oid = OID_UNDEFINED;
	      u.retries = 0;
	      urldb_store(url, &u);
	      enqueue_item(h, ur.rest);
	    }
	}
      else
	add_ref(url, 0);
    }
  bclose(f);
  log(L_INFO, "Requeued %d URL's", cnt);
  urldb_close();
  queue_cleanup();
  gather_unlock();
}

/* Main program */

static char *shortopts = CF_SHORT_OPTS "vfh::iIlm::M:q::Q:rsu::U:";

static void
usage(void)
{
  fprintf(stderr, "Usage: gc [<options>] <commands>\n\
\n\
Options:\n"
CF_USAGE
"-v\t\t\tBe more verbose\n\n\
Available commands:\n\
\n\
-f\t\tTest ref filter\n\
-h[<url>]\tList known hosts [or host info]\n\
-i\t\tInsert new URL's from stdin\n\
-I\t\tBatch insert of new URL's (-i with presorting)\n\
-m\t\tList known MD5 sums\n\
-m<md5>\t\tList object matching given MD5 sum\n\
-M<md5>\t\tDelete from MD5 database\n\
-q[<url>]\tList queued objects [matching host, protocol and port of given URL]\n\
-Q<url>\t\tRemove all queued objects matching host, protocol and port of given URL\n\
-r\t\tSchedule URL's listed on stdin for regathering\n\
-s\t\tCalculate per-host document statistics\n\
-u\t\tList known URLs\n\
-u<url>\t\tList object matching given URL\n\
-U<url>\t\tDelete from URL database\n\
\n");
  exit(1);
}

int
main(int argc, char **argv)
{
  int opt, jobs = 0;
  log_init("gc");
  now = time(NULL);

  while ((opt = cf_getopt(argc, argv, shortopts, CF_NO_LONG_OPTS, NULL)) >= 0)
  {
    jobs++;
    gatherer_init();
    switch (opt)
    {
    case 'v':
      verbose++;
      break;
    case 'f':
      test_ref_filter();
      break;
    case 'h':
      list_hosts(optarg);
      break;
    case 'i':
      insert_urls(0);
      break;
    case 'I':
      insert_urls(1);
      break;
    case 'm':
      show_md5(optarg);
      break;
    case 'M':
      del_md5(optarg);
      break;
    case 'q':
      list_queue(optarg);
      break;
    case 'Q':
      unqueue(optarg);
      break;
    case 'r':
      requeue();
      break;
    case 's':
      host_stats();
      break;
    case 'u':
      show_url(optarg);
      break;
    case 'U':
      del_url(optarg);
      break;
    default:
      usage();
    }
  }
  if (!jobs)
    usage();
  return 0;
}
