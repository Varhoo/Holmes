/*
 *	Sherlock Gatherer Daemon -- Declarations
 *
 *	(c) 1997--2002 Martin Mares <mj@ucw.cz>
 */

#include "gather/gather.h"
#include "lib/bucket.h"

#define OID_FIRST_ERROR		OBUCK_OID_FIRST_SPECIAL
#define OID_UNDEFINED		OBUCK_OID_DELETED

/* gatherd.c */

extern sh_time_t now;

/* config.c */

extern byte *log_name, *host_file_name, *host_bak_name, *queue_file_name;
extern byte *lock_name, *urldb_name, *md5db_name;
extern uns max_bucket_file_size, max_host_count;
extern uns max_threads, trace_threads, trace_refs;
extern uns min_server_delay, max_run_time;
extern uns rec_err_dly1, rec_err_dly2, rec_err_limit;
extern uns ignore_refs, soft_max_obj_count, hard_max_obj_count;
extern uns max_rec_err, auto_enqueue_root;
extern uns queue_cache_size, urldb_cache_size, md5db_cache_size;
extern uns dump_full_objects, auto_sync, max_resolvers;
extern uns host_hash_size, key_hash_size, doc_change_mix;
extern uns trickster_err_prob, trickster_step, allow_hard_shutdown;

#define BANNER "Sherlock Gatherer " SHER_VER

/* db.c */

void db_sync(void);
void gather_lock(void);
void gather_unlock(void);

/*
 *  For each URL, we remember the following items to be able to map URL's
 *  to buckets or error codes, to manage the queue and to control refreshing
 *  and expiration.
 *
 *  Initially, http_last_mod is equal to the 'L' attribute in the bucket,
 *  but if we try to refresh the page and we find a new version with identical
 *  contents, we change only 'L' and keep the bucket unchanged. It is in
 *  local time of the HTTP server, hence we should never compare it with
 *  any our timestamps.
 *
 *  Caveat: The "queued" bit doesn't necessarily mean that the URL is really
 *  present in the queue. The exceptions are URL's from overflowed hosts which
 *  need to be recorded in the URL database for later requeueing by the expirer
 *  after something else from the same host gets deleted.
 */

struct urlrec {
  u32 access;				/* Time of last access (queueing counts as an access) */
  oid_t oid;				/* Object ID or error code if error */
  u32 http_last_mod;			/* Time of last modification as reported by HTTP */
  u32 avg_change_time;			/* Average time between last two changes */
  byte flags;				/* Various flags: see URF_* below */
  byte retries;				/* Retry count for this URL */
} PACKED;

enum url_flags {
  URF_INITIAL = 1,			/* Part of the initial URL set */
  URF_QUEUED = 2			/* Queued for gathering */
};

struct md5rec {
  oid_t oid;				/* Can be OID_UNDEFINED when unknown */
};

void urldb_open(void);
void urldb_close(void);
int urldb_lookup(byte *, struct urlrec *);
void urldb_rewind(void);
byte *urldb_get_next(byte *, struct urlrec *);
int urldb_exists(byte *);
int urldb_delete(byte *);
void urldb_store(byte *, struct urlrec *);

void md5db_open(void);
void md5db_close(void);
int md5db_lookup(byte *, struct md5rec *);
void md5db_rewind(void);
byte *md5db_get_next(byte *, struct md5rec *);
int md5db_exists(byte *);
int md5db_delete(byte *);
void md5db_store(byte *, oid_t);

/* queue.c */

#define QUEUE_PAGE_SIZE 1024		/* Must be minimally URL_SIZE - 5 bytes for "xx://" + 4 bytes for next ptr */
#define QUEUE_PAGE_MASK (QUEUE_PAGE_SIZE-1)

void queue_init(void);
void queue_cleanup(void);
void queue_sync(void);
void queue_reset(void);

struct qhost {				/* Representation of queued host ([*] marks persistent items) */
  node n;
  struct qhost *hash_next;
  uns qf_pos;				/* [*] Reference to first object in queue file */
  uns qf_last;				/* [*] Reference to last object in queue file */
  oid_t robot_id;			/* [*] Object describing robot file for this host */
  u32 robot_time;			/* [*] Time of last robot file refresh */
  uns obj_count[SHERLOCK_NUM_SECTIONS];	/* [*] Number of objects known for this host */
  uns rec_err_count;			/* [*] Number of recoverable errors seen lately */
  uns ex_qh_qcount;			/* Expirer: Number of physically queued items */
  uns hf_pos;				/* Reference to qf_pos instance in host file */
  u32 qkey;				/* [*] Queueing key (e.g., an IP address) */
  word port;
  byte protocol;
  byte flags;
  byte name[1];
};

#define QHF_DIRTY 		0x01	/* Needs to be flushed */
#define QHF_RELINK		0x02	/* Relink on enqueue_host() */
#define QHF_ALLOCATE		0x04	/* Not assigned a position yet */

struct qnode {
  node n;
  struct qnode *hash_next;
  u32 key;
  u32 sequence;				/* Sequence number to order by in the heap */
  sh_time_t wait_until;
  list hosts;
};

struct qitem {				/* Representation of queued data */
  uns aux;				/* Used internally */
  byte text[1];
};

extern uns host_count;

struct qhost *new_host(uns proto, byte *name, uns port);
struct qhost *find_host(uns proto, byte *host, uns port);
struct qhost *dequeue_host(sh_time_t *wait, struct qnode **pnode);
void enqueue_host(struct qhost *h, struct qnode *n, uns delay);
void touch_host(struct qhost *h);
void walk_hosts(void (*f)(struct qhost *h));

struct qitem *dequeue_item(struct qhost *h);
struct qitem *peek_item(struct qhost *h);
void enqueue_item(struct qhost *h, byte *name);
void requeue_item(struct qhost *h);
uns queue_walk_start(struct qhost *h);
byte *queue_walk_next(uns *pos);

/* refs.c */

struct rfilter_data {
  byte *url;				/* Set by the caller */
  struct url url_s;			/* Broken-down URL */
  uns section;				/* Section number */
  uns section_soft_max;			/* Maximum URL's gathered for a host in this section */
  uns section_hard_max;			/* Maximum URL's remembered for a host in this section */
  byte *content_type;			/* Guessed content-type */
  byte *content_encoding;		/* Guessed content-encoding */
  byte *url_key;			/* URL to be used for detection of already known pages */
  byte buf1[MAX_URL_SIZE], buf2[MAX_URL_SIZE];	/* Internal buffers */
};

void refs_init(uns quick);
byte *ref_filter(struct rfilter_data *data);
void ref_filter_undo(void);

void add_ref(byte *r, uns flags);
