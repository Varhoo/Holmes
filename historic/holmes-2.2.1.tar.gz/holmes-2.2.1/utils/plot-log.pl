#!/usr/bin/perl

#	Plotting statistics from precomputed data
#	(c) 2001--2002, Martin Mares <mj@ucw.cz>
#	(c) 2001, Robert Spalek <robert@ucw.cz>

use POSIX;
use IO::File;
use Getopt::Long;
use strict "refs";

$gnuplot = "/opt/bin/gnuplot";

%graph_names = (
	"gperf" => "Gatherer: Performance",
	"gerr" => "Gatherer: Performance - errors",
	"gspec" => "Gatherer: Spectrum",
	"grefrspec" => "Gatherer: Refresh spectrum",
	"gdupl" => "Gatherer: Duplicates",
	"gcumm" => "Gatherer: Cummulative statistics",
	"eglobal" => "Expirer: Global view",
	"espec" => "Expirer: Spectrum",
	"erobot" => "Expirer: Robots",
	"equeue" => "Expirer: Queue keys",
	"ebuck" => "Expirer: Buckets",
	"emd5" => "Expirer: MD5's",
	"iglob" => "Indexer: Global statistics",
	"ilex" => "Indexer: Words in lexicon",
	"gsize" => "Gatherer: Database size",
	"isize" => "Index file sizes",
	"gknown" => "Gatherer: Total count of known documents",
	"gtrue" => "Gatherer: True number of documents",
	"gdelay" => "Gatherer: Average queue delay"
);

my $suffix = "";
my @join = ();
my $join_all = "";
my $force = "";
my @quants = ();
my $remove = 1;
my $max_age = "";
my $verbose = 0;

GetOptions(
	"suffix=s" => \$suffix,
	"join=s@" => \@join,
	"join-all=s" => \$join_all,
	"force!" => \$force,
	"quants=i@" => \@quants,
	"remove!" => \$remove,
	"max-age=i" => \$max_age,
	"verbose!" => \$verbose
) || die "Syntax: plot-log [<options>]
Options:
--suffix suffix		Draw statistics for given suffix (turn off autodetection)
*(--join suffix)	Read more input data files (with given suffixes)
--join-all regex	--join all suffixes matching given regular expression
--max-age days		Filter out date suffixes older than this many days
--force			Force plotting statistics (if images already exist)
*(--quants sec)		Round the plots to given number of seconds
--noremove		Don't remove temporary files
--verbose		Comment what's going on
";

$stat_path = "log/stat-";
$img_path = "log/graph/gr-";
$tmp_path = "tmp/plot";
if ($#quants < 0) { @quants = (600, 3600); }
$undef = "?";
$now = time;

if ($suffix)
{
	@join = get_all_suffixes($join_all) if $join_all;
	if ($max_age) {
		@join = map {
			my $suff = $_;
			(date_suffix_age($suff) <= $max_age) ? $suff : ();
		} @join;
	}
	look_for_plot($suffix, $#join < 0 ? ($suffix) : @join);
}
else
{
	@files = split(/\n/, `ls $stat_path*`);
	foreach $file (@files)
	{
		next if !-f $file;
		my ($suffix) = $file =~ /$stat_path(.*)$/;
		look_for_plot($suffix, ($suffix));
	}
}
`rm -f $tmp_path*` if $remove;

sub get_all_suffixes
{
	my ($regex) = @_;
	my @files = `ls $stat_path* 2>/dev/null`;
	return map {
		chomp;
		(s/^$stat_path// && /^$regex$/) && $_ || ();
	} @files;
}

sub date_suffix_age
{
	my ($suff) = @_;
	$suff =~ /^(\d{4})(\d{2})(\d{2})$/ or return 0;
	my $age = int(($now - mktime(0, 0, 12, $3, $2-1, $1-1900)) / 86400);
	return ($age >= 0) ? $age : 0;
}

sub look_for_plot
{
	my ($output, @inputs) = @_;
	`ls $img_path$output-*.png >/dev/null 2>&1`;
	if ($? || $force)
	{
		$" = ", ";
		print STDERR "Plotting statistics to suffix $output from suffixes (@inputs) using time quants (@quants)\n" if $verbose;
		foreach my $q (@quants)
		{
			clear_stat();
			foreach my $input (@inputs)
			{
				import_stat($q, "$stat_path$input");
			}
			patch_stat();
			dump_stat($q);
			plot_stat ($q, "$img_path$output-$q");
		}
	}
}

sub clear_stat
{
	%gatherer = ();
	%expirer = ();
	%space = ();
}

sub import_stat
{
	my ($q, $path) = @_;
	my $file = new IO::File "< $path" or die "Unable to read $path";
	import_block($file, $q, \%gatherer, 1);
	import_block($file, 1, \%expirer, 0);
	import_block($file, 1, \%space, 0);
	print STDERR "Imported file $path\n" if $verbose;
}

sub import_block
{
	my ($st, $q, $hash, $solve_collisions) = @_;
	while (<$st>)
	{
		chomp;
		next if /^#/;
		last if /^$/;
		my ($time, $rest) = /^(\d+)\t(.*)$/ or die "Invalid input line: $_";
		$time -= $time % $q;
		if (!defined ${$hash}{$time} or !$solve_collisions) {
			${$hash}{$time} = $rest;
		} else {
			solve_collision($time, \${$hash}{$time}, $rest);
		}
	}
	<$st>;
	chomp;
	$_ eq "" or die "Missing empty line at the end of input data";
}

sub solve_collision
{
	my ($time, $target, $source) = @_;
	#print STDERR "Collision in time $time\n";
	my @t = split(/\t/, $$target);
	my @s = split(/\t/, $source);
	$#t == $#s or die "Mismatched array size when solving the collision ($#t != $#s)";
	$t[12] = 0;		#replace instead sum
	for (my $i=0; $i<=$#t; $i++) { $t[$i] += $s[$i]; }
	$" = "\t";
	$$target = "@t";
}

sub patch_stat
{
	$" = "\t";
	my $last_total = 0;
	foreach my $t (sort {$a <=> $b} keys %expirer)
	{
		my @values = split(/\t/, $expirer{$t});
		$last_total = $values[0] if $values[0] ne "";
		if ($last_total)	#compute the spectrum manually
		{
			$values[5] = sprintf("%.4lf", 100 * $values[5] / $last_total) if $values[5];
			$values[6] = sprintf("%.4lf", 100 * $values[6] / $last_total) if $values[6];
			$values[7] = sprintf("%.4lf", 100 * $values[7] / $last_total) if $values[7];
			$expirer{$t} = "@values";
		}
	}
}

sub dump_stat
{
	my ($q) = @_;
	$max_time = 0;
	dump_block("$tmp_path-gatherer", 14, %gatherer);
	dump_block("$tmp_path-expirer", 23, %expirer);
	dump_block("$tmp_path-space", 11, %space);
	dump_gatherer_cummulative("$tmp_path-gatherer-cumm", \%gatherer, \%expirer, $q);
}

sub dump_block
{
	my ($path, $columns, %hash) = @_;
	my $file = new IO::File "> $path" or die "Unable to create $path";
	my @times = sort {$a <=> $b} keys %hash;
	my @nonempty = (), $nonempty = 0, @values, $i;
	$times[-1] > $max_time and $max_time = $times[-1];
	foreach my $time (@times)
	{
		@values = split(/\t/, $hash{$time});
		for ($i=0; $i<$columns; $i++)
		{
			if (defined($values[$i]) and $values[$i] ne "")
			{
				if (!$nonempty[$i])
				{
					$nonempty[$i] = 1;
					$nonempty++;
				} 
			}
			else
			{
				$values[$i] = $undef;
			}
		}
		$hash{$time} = "@values";
		print $file "$time\t@values\n";
	}
	if ($#times == 0)
	{
		my $time1 = $times[0] - 86400;
		print $file "$time1" . "\t$undef" x $columns . "\n";
	}
	elsif ($#times < 0)
	{
		print $file "0" . "\t0" x $columns . "\n";
		print $file "1" . "\t0" x $columns . "\n";
	}
	elsif ($nonempty < $columns)
	{
		my $time1 = $times[0] - 86400;
		print $file $time1;
		for ($i=0; $i<$columns; $i++)
		{
			print $file "\t" . ($nonempty[$i] ? "$undef" : 0);
		}
	}
	#print STDERR "Exported temporary file $path\n";
}

sub dump_gatherer_cummulative
{
	my ($path, $gath, $expir, $q) = @_;
	my $file = new IO::File "> $path" or die "Unable to create $path";
	my $ok, $refr, $red, $dup, $err, $tot_ok, $tot_dup, $tot_err;;
	$ok = $refr = $red = $dup = $err = $tot_ok = $tot_dup = $tot_err = 0;
	$last_time = 0;
	$mode = 0;
	foreach my $time (sort {$a <=> $b} (keys %$gath, keys %$expir))
	{
		if ($$gath{$time})
		{
			split(/\t/, $$gath{$time});
			$ok += $_[1] - $_[8];
			$refr += $_[8];
			$red += $_[2];
			$dup += $_[6];
			$err += $_[5];
			$added += $_[11];
			$tot_ok += $_[11];
			$tot_dup += $_[6];
			$tot_err += $_[5];
			$mode = 1;
		}
		if ($mode && $time >= $last_time + $q)
		{
			$total_known = $tot_ok + $tot_err;
			#		1	2	3	4	5	6	7	8		9	10		11
			print $file "$time	$ok	$refr	$red	$dup	$err	$added	$total_known	$tot_ok	$tot_dup	$tot_err\n";
			$added = 0;
			$last_time = $time;
		}
		if ($$expir{$time})
		{
			split(/\t/, $$expir{$time});
			if ($_[0]) {
				$tot_ok = $_[2] + $_[3];	# queued rfsh + static
				$tot_err = $_[4];		# errors
			}
			$tot_dup = $_[16] if $_[16] ne "";	# dups
			if ($_[0] || $_[16] ne "") {
				$total_known = $tot_ok + $tot_err;
				print $file "$time\t" . "$undef\t" x 6 . "$total_known	$tot_ok	$tot_dup	$tot_err\n";
				$last_time = $time;
			}
			$mode = 0;
		}
	}
	#print STDERR "Exported temporary file $path\n";
}

sub plot_stat
{
	my ($q, $path) = @_;
	my $time_axe = "(\$1-$max_time)/86400";
	init_gnuplot("$path-index.html", $q, $path);
	$gnuplot_cmd .= "set data style lines\n";
	add_gnuplot($path, "gperf", "plot
		'$tmp_path-gatherer' using $time_axe:(\$2/$q) title \"URL's processed/sec\",
		'' using $time_axe:(\$3/$q) title \"Successful downloads/sec\",
		'' using $time_axe:(\$5/$q) title \"Successful resolves/sec\",
		'' using $time_axe:((\$6+\$7)/$q) title \"Errors/sec\",
		'' using $time_axe:(\$9/$q) title \"Refreshes/sec\"");
	add_gnuplot($path, "gerr", "plot
		'$tmp_path-gatherer' using $time_axe:(\$4/$q) title \"Redirects/sec\",
		'' using $time_axe:(\$8/$q) title \"Duplicates/sec\",
		'' using $time_axe:(\$6/$q) title \"Soft errors/sec\",
		'' using $time_axe:(\$7/$q) title \"Hard errors/sec\"");
	add_gnuplot($path, "gspec", "plot
		'$tmp_path-gatherer' using $time_axe:(perc(\$3,\$2)) title \"Download %\",
		'' using $time_axe:(perc(\$4,\$2)) title \"Redirect %\",
		'' using $time_axe:(perc(\$5,\$2)) title \"Resolves %\",
		'' using $time_axe:(perc(\$6,\$2)) title \"Soft error %\",
		'' using $time_axe:(perc(\$7,\$2)) title \"Hard error %\"");
	add_gnuplot($path, "grefrspec", "plot
		'$tmp_path-gatherer' using $time_axe:(perc(\$10,\$9)) title \"Successful refresh %\",
		'' using $time_axe:(perc(\$11,\$9)) title \"Soft error %\",
		'' using $time_axe:(perc(\$12,\$9)) title \"Hard error %\"");
	add_gnuplot($path, "gdupl", "plot
		'$tmp_path-gatherer' using $time_axe:(perc(\$8,\$3)) title \"Duplicate %\"");
	add_gnuplot($path, "gcumm", "plot
		'$tmp_path-gatherer-cumm' using $time_axe:2 title \"New documents\",
		'' using $time_axe:3 title \"Refreshes\",
		'' using $time_axe:4 title \"Redirects\",
		'' using $time_axe:5 title \"Duplicates\",
		'' using $time_axe:6 title \"Hard errors\"");
	$gnuplot_cmd .= "set data style linespoints\n";
	add_gnuplot($path, "eglobal", "plot
		'$tmp_path-expirer' using $time_axe:2 title \"URL's known\",
		'' using $time_axe:3 title \"Queued new URL's\",
		'' using $time_axe:4 title \"Queued refresh URL's\",
		'' using $time_axe:5 title \"Static URL's\",
		'' using $time_axe:6 title \"Error URL's\",
		'' using $time_axe:24 title \"Really queued\"");
	add_gnuplot($path, "espec", "plot
		'$tmp_path-expirer' using $time_axe:7 title \"Expired \%\",
		'' using $time_axe:8 title \"Requeued \%\",
		'' using $time_axe:9 title \"Filtered \%\"");
	add_gnuplot($path, "erobot", "plot
		'$tmp_path-expirer' using $time_axe:10 title \"Total known\",
		'' using $time_axe:11 title \"Expired\",
		'' using $time_axe:12 title \"Filtered\"");
	add_gnuplot($path, "equeue", "plot
		'$tmp_path-expirer' using $time_axe:13 title \"Total known\",
		'' using $time_axe:14 title \"Expired\"");
	add_gnuplot($path, "ebuck", "plot
		'$tmp_path-expirer' using $time_axe:15 title \"Total after expiration\",
		'' using $time_axe:16 title \"Deleted\"");
	add_gnuplot($path, "emd5", "plot
		'$tmp_path-expirer' using $time_axe:17 title \"Total count\",
		'' using $time_axe:18 title \"Duplicates\"");
	add_gnuplot($path, "iglob", "plot
		'$tmp_path-expirer' using $time_axe:19 title \"Input buckets\",
		'' using $time_axe:20 title \"Generated cards\",
		'' using $time_axe:21 title \"Cards after merging\",
		'' using $time_axe:22 title \"Duplicates\"");
	add_gnuplot($path, "ilex", "plot
		'$tmp_path-expirer' using $time_axe:23 title \"Total count\"");
	add_gnuplot($path, "gsize", "plot
		'$tmp_path-space' using $time_axe:2 title \"MD5.db\",
		'' using $time_axe:3 title \"URL.db\",
		'' using $time_axe:4 title \"hosts\",
		'' using $time_axe:5 title \"objects\",
		'' using $time_axe:6 title \"queue\"");
	add_gnuplot($path, "isize", "plot
		'$tmp_path-space' using $time_axe:7 title \"attributes\",
		'' using $time_axe:8 title \"cards\",
		'' using $time_axe:9 title \"lexicon\",
		'' using $time_axe:10 title \"references\",
		'' using $time_axe:11 title \"string\",
		'' using $time_axe:12 title \"Total index size\"");
	$gnuplot_cmd .= "set data style lines\n";
	add_gnuplot($path, "gknown",
		"set y2tics;
		plot
		'$tmp_path-gatherer-cumm' using $time_axe:8 axes x1y1 title \"Documents known [L]\",
		'' using $time_axe:7 axes x1y2 title \"Added documents [R]\";
		unset y2tics");
	add_gnuplot($path, "gtrue",
		"set y2tics;
		plot
		'$tmp_path-gatherer-cumm' using $time_axe:9 axes x1y1 title \"True number of documents [L]\",
		'' using $time_axe:10 axes x1y2 title \"True number of duplicates [R]\",
		'' using $time_axe:11 axes x1y2 title \"True number of errors [R]\";
		unset y2tics");
	add_gnuplot($path, "gdelay", "plot
		'$tmp_path-gatherer' using $time_axe:(div(\$15,\$2)) title \"Average queue delay\"");
	call_gnuplot();
	print STDERR "Plotted to files $path-*.png\n" if $verbose;
}

sub init_gnuplot
{
	my ($index_name, $q, $path) = @_;
	$gnuplot_cmd = "set grid
set terminal png
set pointsize 2
set xtics 1
perc(x,y) = (y!=0 ? (100*x/y) : 0)
div(x,y) = (y!=0 ? (x/y) : 0)
";

	$index_file = new IO::File "> $index_name" or die "Unable to create $index_name";
	print $index_file "<html>
<head><title>Statistics for $path, time quantum $q</title></head>
<body>\n";
	print $index_file "Reference time: " . strftime("%Y-%m-%d %H:%M:%S", localtime($max_time)) . ".<br>\n";
	my $h = int($q / 3600), $m = int($q / 60) % 60, $s = $q % 60;
	print $index_file "Time quantum: $q seconds ($h hours, $m minutes, $s seconds).<br>\n";
	print $index_file "Ticks done after days.<br>\n<ul>\n";
	foreach my $key (sort keys %graph_names)
	{
		print $index_file "<li><a href=\"#$key\">$graph_names{$key}</a></li>\n";
	}
	print $index_file "</ul>\n<hr>\n";
}

sub call_gnuplot
{
	print $index_file "</body></html>\n";
	$index_file->close();

	my $cmd_file = new IO::File "> $tmp_path-gnuplot" or die "Unable to create $tmp_path-gnuplot";
	print $cmd_file $gnuplot_cmd;
	$cmd_file->close();
	`$gnuplot $tmp_path-gnuplot`;
	die "Cannot call gnuplot with commands in script $tmp_path-gnuplot" if $?;
}

sub add_gnuplot
{
	my ($prefix, $name, $cmd) = @_;
	my $path = "$prefix-$name.png";
	my $alt = $graph_names{$name};
	die if !$alt;
	$cmd =~ s/\n/ \\\n/g;
	$gnuplot_cmd .= "set output \"$path\"\nset title \"$alt\"\n$cmd\n";
	(my $relpath = $path) =~ s/^(.*\/)*//;
	print $index_file "
<a name=\"$name\">&nbsp;</a>
<h2>$alt</h2>
<img src=\"$relpath\" alt=\"$alt\"><br>\n";
}
