/*
 *	Sherlock Gatherer -- Configuration of dumping the files
 *
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/conf.h"

byte *terminal_charset = "utf-8";
uns line_len = 78;

static struct cfitem dumperconfig[] = {
	{ "Dumper",		CT_SECTION,	NULL },
	{ "TerminalCharset",	CT_STRING,	&terminal_charset },
	{ "TerminalWidth",	CT_INT,		&line_len },
	{ NULL,			CT_STOP,	NULL }
};

static void CONSTRUCTOR dumperconfig_init(void)
{
	cf_register(dumperconfig);
}

