#!/bin/bash
#
#  Sherlock Gatherer Control Script
#  (c) 2002 Martin Mares <mj@ucw.cz>
#

set -e

if [ $UID = 0 ] ; then
	cd ${SH_HOME:-~sherlock/run}
	exec su ${SH_USER:-sherlock} -c "exec bin/gcontrol $@"
else
	if [ -n "$SH_HOME" ] ; then cd $SH_HOME ; fi
fi
if ! [ -f bin/scheduler -a -f cf/sherlock ] ; then
	echo >&2 "gcontrol: Cannot find Sherlock runtime directory"
	exit 1
fi

case "$1" in
	start)		[ -f db/scheduler.pid ] && echo >&2 "WARNING: scheduler.pid already present!"
			rm -f db/scheduler.slot
			echo -n "Starting scheduler..."
			setsid </dev/null >/dev/null 2>&1 bin/scheduler $2 &
			echo $! >db/scheduler.pid
			echo " done."
			;;
	stop)		echo -n "Stopping scheduler..."
			if [ -f db/scheduler.pid ] && kill 2>/dev/null -TERM `cat db/scheduler.pid` ; then
				while [ -f db/scheduler.slot ] ; do
					sleep 1
					echo -n "."
				done
				echo "done."
			else
				echo "no scheduler running."
			fi
			rm -f db/scheduler.pid
			;;
	restart)	bin/gcontrol stop
			bin/gcontrol start
			;;
	*)		echo >&2 "Usage: [SH_USER=<user>] [SH_HOME=<homedir>] gcontrol (start [<initial-slot>]|stop|restart)"
			exit 1
			;;
esac
