#!/bin/sh
(
	echo "Largest sites:"
	sort -nrk1 db/host_stats | head -10
	echo "Sites with largest queue:"
	sort -nrk3 db/host_stats | head -10
) | bin/logger topten I
