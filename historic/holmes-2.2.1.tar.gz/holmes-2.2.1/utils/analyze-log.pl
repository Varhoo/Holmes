#!/usr/bin/perl

#	Computing statistics from gatherer and expirer logs
#	(c) 2001--2002, Martin Mares <mj@ucw.cz>
#	(c) 2001--2002, Robert Spalek <robert@ucw.cz>

use POSIX;
use IO::File;
use Getopt::Long;
use File::stat;

my $suffix = "";
my $force = "";
my $decompress = "";
my $quantum = 60;
my $verbose = 0;

GetOptions(
	"suffix=s" => \$suffix,
	"force!" => \$force,
	"decompress!" => \$decompress,
	"quantum=i" => \$quantum,
	"verbose!" => \$verbose
) || die "Syntax: analyze-log [<options>]
Options:
--suffix suffix	Compute statistics for given suffix (turn off autodetection)
--force		Force computing statistics (if they already exist)
--decompress	Take into account compressed gatherer logs too
--quantum sec	Round the statistics to given time quantum (in seconds)
--verbose	Verbosely print what's going on
";

$gatherer_log = "log/gatherd-";
$scheduler_log = "log/scheduler-";
$stat_path = "log/stat-";

if ($suffix)
{
	look_for_stat($suffix);
}
else
{
	foreach $file (`ls $gatherer_log* $scheduler_log* 2>/dev/null`)
	{
		chomp $file;
		next if !-f $file;
		$file =~ /^(.*)\.(gz|bz2)$/ and $file = $1;
		my ($type, $suffix) = $file =~ /($gatherer_log|$scheduler_log)(.*)$/;
		$known_suffixes{$suffix}++ || look_for_stat($suffix);
	}
}

sub test_compressed
{
	my ($filename, $is_compressed) = @_;
	return $filename if -f $filename;
	if (-f "$filename.gz")
	{
		$$is_compressed = 1;
		return "$filename.gz";
	}
	if (-f "$filename.bz2")
	{
		$$is_compressed = 1;
		return "$filename.bz2";
	}
	return $filename;
}

sub decompress_method
{
	my ($filename) = @_;
	$filename =~ /\.gz$/ and return "zcat $filename |";
	$filename =~ /\.bz2$/ and return "bzcat $filename |";
	return "< $filename";
}

sub look_for_stat
{
	my ($suffix) = @_;
	my $st_name = "$stat_path$suffix";
	my $is_compressed = 0;
	my $gl_name = test_compressed("$gatherer_log$suffix", \$is_compressed);
	my $sl_name = test_compressed("$scheduler_log$suffix", \$is_compressed);
	if (-f $st_name && !$force)
	{
		my $stat_mt = stat($st_name)->mtime;
		if ((!-f $gl_name || stat($gl_name)->mtime <= $stat_mt) &&
		    (!-f $sl_name || stat($sl_name)->mtime <= $stat_mt))
		{
			return;
		}
		if ($is_compressed && !$decompress)
		{
			return;
		}
	}
	my $gl = new IO::File decompress_method($gl_name);
	my $sl = new IO::File decompress_method($sl_name);
	my $st = new IO::File "> $st_name";
	print STDERR "Computing statistics with suffix $suffix\n";
	compute_stat ($gl, $sl, $st);
}

sub compute_stat
{
	my ($gl, $sl, $st) = @_;
	my $time;
	my $counter = 0;
	%total = %download = %redirect = %resolve = %err_soft = %err_hard = %duplicate =
		%refresh = %refr_ok = %refr_err_soft = %refr_err_hard = %added = %delay = ();
	while (<$gl>)
	{
		/^I/ || next;
		/^. (\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}) / || die "Syntax error: $_";
		($time = POSIX::mktime($6,$5,$4,$3,$2-1,$1-1900)) || die "Bad time: $_";
		$time -= $time % $quantum;
		if ($verbose && !($counter++ % 10240)) { print STDERR "$counter $time\r"; STDERR->flush(); }
		if (($status, $pid, $refresh, $flag) = /: (\d{4}) .* \[(\d*)(\*?)(.?)\]/)
		{
			$total{$time}++;
			$delay = 0 unless ($delay) = /\] d=(\d+)\b/;
			$delay{$time} += $delay;
			$main_status = int($status / 1000);
			if ($main_status == 0) {
				if ($status == 0 || $status == 3 || $status == 4) { $download{$time}++; }
				elsif ($status == 1) { $redirect{$time}++; }
				elsif ($status == 2) { $resolve{$time}++; }
				else { die "Unknown status code $status"; }
			}
			elsif ($main_status == 1) { $err_soft{$time}++; }
			elsif ($main_status == 2) { $err_hard{$time}++; }
			else { die "Unknown status code $status"; }
			if ($refresh)
			{
				$refresh{$time}++;
				if ($main_status == 0 && $flag ne "") { $refr_ok{$time}++; }
				elsif ($main_status == 1) { $refr_err_soft{$time}++; }
				elsif ($main_status == 2) { $refr_err_hard{$time}++; }
			}
			if ($flag eq "+" || $flag eq "!") {
				if ($main_status == 0) { $added{$time}++; }
				if ($refresh) { $added{$time}--; }
				if ($flag eq "!") { $duplicate{$time}++; }
			}
		}
	}
	$counter = 0;
	%exp_total = %exp_spectrum_expired = %exp_spectrum_requeued = %exp_spectrum_filtered = 
		%exp_queued_new = %exp_queued_rfsh = %exp_static = %exp_error =
		%exp_robot_total = %exp_robot_expired = %exp_robot_filtered = %exp_qkeys_total = 
		%exp_qkeys_expired = %exp_buck_total = %exp_buck_deleted = %exp_md5_total = %exp_md5_dups = ();
	%size_times = %size_md5 = %size_url = %size_hosts = %size_objs = %size_queue = %size_attrs = %size_cards = %size_lexicon = %size_refs = %size_string = %size_total = ();
	%active_slots = ();
	my $exp_time;
	while (<$sl>)
	{
		/^I/ || next;
		/^. (\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}) / || next;
		($time = POSIX::mktime($6,$5,$4,$3,$2-1,$1-1900)) || die "Bad time: $_";
		if ($verbose && !($counter++ % 10240)) { print STDERR "$counter $time\r"; STDERR->flush(); }
		if (!defined($exp_time) or /Starting expirer/ or /Building index/)
		{
			$exp_time = $time;
		}
		$active_slots{$time} = 1;
		if (/\[expire\]/)
		{
			if (/Total URL's: (\d+) in -> (\d+) out: (\d+) expired, (\d+) requeued, (\d+) filtered out, (\d+) lost/) {
				print "Caution! Inconsistency found: $_" if $1 != $2 + $3 + $5 + $6;
				$exp_total{$exp_time} = $1;
				$exp_total{$time} = $2;
				$exp_spectrum_expired{$time} = $3;
				$exp_spectrum_requeued{$time} = $4;
				$exp_spectrum_filtered{$time} = $5;
			} elsif (/Queued new URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) expired, (\d+) filtered out/) {
				$exp_queued_new{$exp_time} = $1;
				$exp_queued_new{$time} = $2;
			} elsif (/Queued refresh URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) expired, (\d+) filtered out/) {
				$exp_queued_rfsh{$exp_time} = $1;
				$exp_queued_rfsh{$time} = $2;
			} elsif (/Static URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) requeued, (\d+) expired, (\d+) filtered out/) {
				$exp_static{$exp_time} = $1;
				$exp_static{$time} = $2;
			} elsif (/Error URL's: (\d+) in -> (\d+) out: (\d+) ok, (\d+) expired, (\d+) filtered out/) {
				$exp_error{$exp_time} = $1;
				$exp_error{$time} = $2;
			} elsif (/Queue: (\d+) items, (\d+) inactive, (\d+) postponed/) {
				$exp_queue_in{$time} = $1;
			} elsif (/Robots: (\d+) total, (\d+) expired, (\d+) filtered out/) {
				$exp_robot_total{$time} = $1;
				$exp_robot_expired{$time} = $2;
				$exp_robot_filtered{$time} = $3;
			} elsif (/Queue keys: (\d+) total .*, (\d+) expired/) {
				$exp_qkeys_total{$time} = $1;
				$exp_qkeys_expired{$time} = $2;
			} elsif (/Buckets: (\d+) total, (\d+) old \+ (\d+) new deleted, (\d+) bad/) {
				$exp_buck_total{$time} = $1 - ($2 + $3 + $4);
				$exp_buck_deleted{$time} = $2 + $3 + $4;
			} elsif (/MD5: (\d+) sums \+ (\d+) duplicates/) {
				$exp_md5_total{$time} = $1 + $2;
				$exp_md5_dups{$time} = $2;
			}
		}
		elsif (/\[scanner] Scanned (\d+) objects, created (\d+) cards/)
		{
			$scan_obj{$time} = $1;
			$scan_card{$time} = $2;
		}
		elsif (/\[merger] In: (\d+) .* Out: (\d+) /)
		{
			$merge_card{$time} = $2;
			$merge_dupl{$time} = $1 - $2;
		}
		elsif (/\[mklex] Built lexicon with (\d+) words/)
		{
			$mklex_words{$time} = $1;
		}
		elsif (/\[sizer]/)
		{
			$size_times{$time} = 1;
			if (/MD5.db=(\d+)\b/) { $size_md5{$time} = $1; }
			if (/URL.db=(\d+)\b/) { $size_url{$time} = $1; }
			if (/hosts=(\d+)\b/) { $size_hosts{$time} = $1; }
			if (/objects=(\d+)\b/) { $size_objs{$time} = $1; }
			if (/queue=(\d+)\b/) { $size_queue{$time} = $1; }
			if (/card-attrs=(\d+)\b/) { $size_attrs{$time} = $1; }
			if (/cards=(\d+)\b/) { $size_cards{$time} = $1; }
			if (/lexicon=(\d+)\b/) { $size_lexicon{$time} = $1; }
			if (/references=(\d+)\b/) { $size_refs{$time} = $1; }
			if (/string-map=(\d+)\b/) { $size_string{$time} = $1; }
			if (/total index size is (\d+)\b/) { $size_total{$time} = $1; }
		}
	}

	print $st	"###gatherer\n";
	print $st	"#longtime	|total	dwnld	redir	resolv	errs	errh	"
			# 1		2	3	4	5	6	7
		.	"|dupl	|refr	refrok	rerrs	rerrh	"
			# 8	9	10	11	12
		.	"|add	RFU	|delay	"
			# 13	14	15
		.	"\n";
	foreach my $t (sort {$a <=> $b} keys %total)
	{
		print $st sprintf("%d\t" x 15 . "\n", $t,	#we want the zeroes here
			$total{$t}, $download{$t}, $redirect{$t}, $resolve{$t},
			$err_soft{$t}, $err_hard{$t}, $duplicate{$t},
			$refresh{$t}, $refr_ok{$t}, $refr_err_soft{$t}, $refr_err_hard{$t},
			$added{$t}, 0, $delay{$t},
		);
	}
	print $st	"\n\n";

	print $st	"###scheduler\n";
	print $st	"#longtime	|total	quenew	querfsh	static	errors	"
			# 1		2	3	4	5	6
		.	"|spexp	spreq	spfil	|robtot	robexp	robfil	|qktot	qkexp	"
			# 7	8	9	10	11	12	13	14
		.	"|butot	budel	|md5tot	md5dup	"
			# 15	16	17	18
		.	"|scobj	sccrd	mercrd	merdup	words	"
			# 19	20	21	22	23
		.	"|qinq	"
			# 24
		.	"\n";
	foreach my $t (sort {$a <=> $b} keys %active_slots)
	{
		print $st sprintf("%s\t" x 24 . "\n", $t,	#empty records replaced by plot-log
			 $exp_total{$t},
			 $exp_queued_new{$t},
			 $exp_queued_rfsh{$t},
			 $exp_static{$t},
			 $exp_error{$t},
			 $exp_spectrum_expired{$t}, $exp_spectrum_requeued{$t}, $exp_spectrum_filtered{$t},
			 $exp_robot_total{$t}, $exp_robot_expired{$t}, $exp_robot_filtered{$t},
			 $exp_qkeys_total{$t}, $exp_qkeys_expired{$t},
			 $exp_buck_total{$t}, $exp_buck_deleted{$t},
			 $exp_md5_total{$t}, $exp_md5_dups{$t},
			 $scan_obj{$t}, $scan_card{$t},
			 $merge_card{$t}, $merge_dupl{$t}, $mklex_words{$t},
			 $exp_queue_in{$t}
		);
	}
	print $st	"\n\n";

	print $st	"###sizer\n";
	print $st	"#longtime	|md5	url	hosts	objs	queue	"
		.	"|attrs	cards	lexicon	refs	string	total	"
		.	"\n";
	foreach my $t (sort {$a <=> $b} keys %size_times)
	{
		print $st sprintf("%s\t" x 12 . "\n", $t,	#empty records replaced by plot-log
			$size_md5{$t}, $size_url{$t}, $size_hosts{$t}, $size_objs{$t}, $size_queue{$t},
			$size_attrs{$t}, $size_cards{$t}, $size_lexicon{$t}, $size_refs{$t}, $size_string{$t}, $size_total{$t}
		);
	}
	print $st	"\n\n";
}
