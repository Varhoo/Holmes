/*
 *	Sherlock Indexer -- Fetching of Cards for Second Indexer Pass
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 */

#include "lib/lib.h"
#include "lib/fastbuf.h"
#include "lib/bucket.h"
#include "lib/pools.h"
#include "indexer/indexer.h"

#include <string.h>
#include <fcntl.h>

#define LINEBUF_SIZE 4096

void
fetch_cards(void (*card_start)(uns id, struct card_attr *attr),
	    void (*got_line)(byte *line),
	    void (*card_end)(struct card_attr *attr, struct odes *obj))
{
  struct mempool *pool;
  struct fastbuf *labels, *attrs;
  struct obuck_header bh;
  struct fastbuf *b;
  struct odes *o;
  struct oattr *last_attr, *a, *first_x, *last_x;
  u32 next_label_id;
  uns id;
  struct card_attr attr;
  byte buf[LINEBUF_SIZE];

#define LINE								\
    do {								\
      ASSERT(buf[0]);							\
      if (got_line)							\
	got_line(buf);							\
      if (last_attr && last_attr->attr != buf[0])			\
	last_attr = NULL;						\
      last_attr = obj_add_attr(o, last_attr, buf[0], buf+1);		\
  } while (0)

  static inline void prepend_to_X(uns attr)
    {
      for (a=obj_find_attr(o, attr); a; a=a->same)
	if (!first_x)
	  first_x = last_x = obj_prepend_attr(o, 'X', a->val);
	else
	  last_x = obj_insert_attr(o, first_x, last_x, a->val);
    }

  obuck_init(0);
  ifilter_init(1);
  pool = mp_new(16384);
  labels = bopen(fn_labels, O_RDONLY, indexer_fb_size);
  attrs = bopen(fn_attributes, O_RDONLY, indexer_fb_size);
  id = -1;
  next_label_id = bgetl(labels);
  while (breadb(attrs, &attr, sizeof(attr)))
    {
      id++;
      if (attr.flags & (CARD_FLAG_EMPTY | CARD_FLAG_DUP))
	{
	  while (next_label_id == id)
	    {
	      uns cnt = bgetl(labels);
	      /* This really can happen, for example when we attach frame backlinks to empty frames */
	      DBG("Ignoring label for skipped object %08x", id);
	      bseek(labels, cnt, SEEK_CUR);
	      next_label_id = bgetl(labels);
	    }
	  continue;
	}
      bh.oid = attr.card;
      obuck_find_by_oid(&bh);
      if (card_start)
	card_start(id, &attr);
      b = obuck_fetch();
      mp_flush(pool);
      o = obj_new(pool);
      last_attr = NULL;
      while (bgets(b, buf, sizeof(buf)))
	{
	  if ((attr.flags & CARD_FLAG_MERGED)
	      && (strchr(label_attrs, buf[0]) || buf[0] == 'U'))
	    continue;	/* Attributes we attach via label file, but only for merged cards */
	  LINE;
	}
      obuck_fetch_end(b);
      while (next_label_id == id)
	{
	  uns cnt = bgetl(labels);
	  sh_off_t stop = btell(labels) + cnt;
	  while (btell(labels) < stop)
	    {
	      if (!bgets0(labels, buf, sizeof(buf)))
		die("Unexpected inconsistency of label file");
	      LINE;
	    }
	  next_label_id = bgetl(labels);
	}
      if (!ifilter_filter(o, &attr))
	die("Filtering rules have changed since scanner for %s", obj_find_aval(o, 'U'));
      /* Prepend "V" and "x" to "X", not calling got_line intentionally */
      first_x = last_x = NULL;
      prepend_to_X('V');
      prepend_to_X('x');
      if (card_end)
	card_end(&attr, o);
    }
  ASSERT(next_label_id == ~0U);
  obuck_cleanup();
  bclose(attrs);
  bclose(labels);
  mp_delete(pool);
  log(L_INFO, "Processed %d objects", id);
}
