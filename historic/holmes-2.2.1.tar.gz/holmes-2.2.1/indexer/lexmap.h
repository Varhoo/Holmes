/*
 *	Sherlock Indexer -- Lexical Mapping
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 *
 *	You call:
 *	   - lm_init() before doing anything else
 *	   - lm_doc_start() at the start of each document
 *	   - lm_map_text() for each piece of document text
 *	We call:
 *	   - lm_lookup() to look up and categorize a word
 *	   - lm_got_word() for each word found together with its position
 *	   - lm_got_compound() for each word complex
 *	You need to define word_id_t to a type representing a single word.
 */

#include "lib/chartype.h"

#include <string.h>

/* Internal state variables */
static uns lm_current_cat;
static uns lm_pos;
static uns lm_garb_cnt;
static uns lm_prep_cnt;
static uns lm_postp_cnt;
static word_id_t lm_preps[MAX_COMPLEX_LEN];
static word_id_t lm_last_word;

#ifdef LM_TRACK_TEXT
#define LM_TPAR
#else
#define LM_TPAR UNUSED
#endif

static inline void
lm_doc_start(void)
{
  lm_garb_cnt = lm_prep_cnt = lm_postp_cnt = 0;
  lm_last_word = 0;
  lm_current_cat = WT_TEXT;
  lm_pos = 0;
}

static inline void
lm_map_word(word *uni, uns ulen, enum word_class class, byte *ostart LM_TPAR, uns olen LM_TPAR)
{
  word_id_t thisw = 0;

#ifdef LM_TRACK_TEXT
  class = lm_lookup(class, uni, ulen, &thisw, ostart, olen);
#else
  class = lm_lookup(class, uni, ulen, &thisw);
#endif
#ifdef LOCAL_DEBUG
  {
    byte w[3*MAX_WORD_LEN+1], *p=w;
    uns i;
    for (i=0; i<ulen; i++)
      PUT_UTF8(p, uni[i]);
    *p = 0;
    DBG("@%d <%s> class=%d cat=%d", lm_pos, w, class, lm_current_cat);
  }
#endif
  /*
   *  This complex automaton parses sequences of word classes, recognizes
   *  word complexes (word+prep/postp's) and calculates word positions.
   */
  switch (class)
    {
    case WC_IGNORED:
    case WC_UNUSED:
    case WC_COMPOUND:
      break;
    case WC_NORMAL:
      if (lm_prep_cnt > lex_max_preps)
	{
	  lm_garb_cnt += lm_prep_cnt;
	  lm_prep_cnt = 0;
	}
      if (lm_garb_cnt)
	{
	  if (lm_pos)
	    lm_pos += MIN(lm_garb_cnt, lex_max_gap);
	  lm_garb_cnt = 0;
	}
      if (lm_prep_cnt)
	{
	  uns i;
	  lm_preps[lm_prep_cnt] = thisw;
	  for (i=0; i<lm_prep_cnt; i++)
	    {
	      lm_got_compound(lm_pos, lm_current_cat, lm_preps+i, lm_prep_cnt-i+1);
	      lm_pos++;
	    }
	  lm_prep_cnt = 0;
	}
      lm_got_word(lm_pos, lm_current_cat, thisw);
      lm_last_word = thisw;
      lm_postp_cnt = 0;
      lm_pos++;
      break;
    case WC_BREAK:
      lm_garb_cnt += lex_max_gap;
      /* Fall thru */
    case WC_GARBAGE:
      lm_garb_cnt += lm_prep_cnt + 1;
      lm_prep_cnt = 0;
      lm_last_word = 0;
      break;
    case WC_PREPOSITION:
      if (lm_prep_cnt < lex_max_preps)
	lm_preps[lm_prep_cnt] = thisw;
      lm_prep_cnt++;
      lm_last_word = 0;
      break;
    case WC_POSTPOSITION:
      if (lm_last_word)
	{
	  lm_postp_cnt++;
	  if (lm_postp_cnt <= lex_max_postps)
	    {
	      /* We reuse lm_preps for postpositions */
	      lm_preps[0] = lm_last_word;
	      lm_preps[lm_postp_cnt] = thisw;
	      lm_got_compound(lm_pos-lm_postp_cnt, lm_current_cat, lm_preps, lm_postp_cnt+1);
	      lm_pos++;
	      break;
	    }
	}
      lm_garb_cnt += lm_prep_cnt + 1;
      lm_prep_cnt = 0;
      break;
    }
}

#define	ANALYSED_CHARS 0x91
enum char_category { cc_lower, cc_upper, cc_digit, cc_base, cc_ctrl, cc_ox90, cc_ok, cc_end };
static byte char_analysis[ANALYSED_CHARS];

static void
lm_init(void)
{
  uns c;

  for (c=0; c<ANALYSED_CHARS; c++)
    {
      uns i;
      if (c<=0x20 || c>=0x80 && c!=0x90)
	i = cc_ok;
      else if (Clower(c))
	i = cc_lower;
      else if (Cupper(c))
	i = cc_upper;
      else if (Cdigit(c))
	i = cc_digit;
      else if (c == 0x90)
	i = cc_ox90;
      else if (c == '+' || c == '/' || c == '=')
	i = cc_base;
      else
	i = cc_ctrl;
      char_analysis[c] = i;
    }
}

static inline int
lm_sequence_valid(word *uni, uns len)
{
  byte cnts[cc_end];
  uns c, act_cat, i;
  uns last_cat = cc_ok;
  uns cat_changes = 0;
  byte *msg;

  /* Check for non-ASCII characters, if present, the string is surely NOT some
   * encoded string (base64, uuencode, base85, base32, xxencode, binhex, btoa).
   * */
  bzero(&cnts, sizeof(cnts));
  if (len >= lex_max_ctrl_len)
    for (i=0; c = uni[i]; i++)
      {
	c = uni[i];
	if (c >= ANALYSED_CHARS)
	  return 1;
	act_cat = char_analysis[c];
	cnts[act_cat] = 1;
	if (act_cat != last_cat)
	  cat_changes++;
	last_cat = act_cat;
      }

  if (cnts[cc_upper] + cnts[cc_lower] + cnts[cc_digit] >= 3 && !cnts[cc_ctrl] && !cnts[cc_ox90]
      && cat_changes >= len/4)			/* base64, base is common */
    msg = "base64";
  else if (cnts[cc_upper] + cnts[cc_digit] + (cnts[cc_base]|cnts[cc_ctrl]) >= 3 && !cnts[cc_lower] && !cnts[cc_ox90]
	   && cat_changes >= len/3)			/* uuencode */
    msg = "uuencode";
  else if (cnts[cc_upper] + cnts[cc_lower] + cnts[cc_digit] + (cnts[cc_base]|cnts[cc_ctrl]) + cnts[cc_ox90] >= 4
	   && cat_changes >= len/2)			/* binhex, btoa, base85 */
    msg = "base85";
  else
    return 1;

  DBG("Throwing out word of length %d with %d category changes containing low/upp/dig/bas/ctr/x90=%d/%d/%d/%d/%d/%d, judged as %s",
      len, cat_changes, cnts[cc_lower], cnts[cc_upper], cnts[cc_digit], cnts[cc_base], cnts[cc_ctrl], cnts[cc_ox90], msg);
  return 0;
}

static inline void
lm_map_sequence(word *uni, uns len, byte *wstart LM_TPAR)
{
  uns start, u, flags, i;
#ifdef LM_TRACK_TEXT
  byte *cpos[MAX_WORD_LEN+1];
#endif
  enum word_class class;

  if (!len)
     return;

#ifndef LM_SEARCH
  uni[len] = 0;
  if (!lm_sequence_valid(uni, len))
    {
      lm_map_word(NULL, 0, WC_GARBAGE, NULL, 0);
      return;
    }
#endif

  start = flags = 0;
  uni[len] = ' ';
  uni[len+1] = 0;
  for (i=0; u = uni[i]; i++)
    {
      uns cat = Ucategory(u);
#ifdef LM_TRACK_TEXT
      cpos[i] = wstart;
      SKIP_TAGGED_CHAR(wstart);
#endif
#ifdef LM_SEARCH
      if (u == '*' || u == '?')
	cat = _C_ALNUM;
#endif
      if (cat & _C_ALNUM)
	{
	  flags |= cat ^ _C_XDIGIT;
	  uni[i] = u;
	}
      else
	{
	  uns wlen = i - start;
	  if (wlen)
	    {
	      if ((wlen > lex_max_hex_len && ((flags & (_C_XDIGIT | _C_DIGIT)) == _C_DIGIT))
		  || (wlen > lex_max_len || !(lex_cats & lm_current_cat)))
		class = WC_GARBAGE;
	      else
		class = WC_NORMAL;
#ifdef LM_TRACK_TEXT
	      lm_map_word(uni+start, i-start, class, cpos[start], cpos[i]-cpos[start]);
#else
	      lm_map_word(uni+start, i-start, class, NULL, 0);
#endif
	    }
	  start = i+1;
	  flags = 0;
	}
    }
  if (uni[len-1] == '.' || uni[len-1] == '?' || uni[len-1] == '!')
    lm_map_word(NULL, 0, WC_BREAK, NULL, 0);
}

#ifdef LM_SEARCH

static int
lm_map_text(byte *text)
{
  word uni[MAX_WORD_LEN+1];
  uns u, l;

  l = 0;
  while (*text)
    {
      GET_UTF8(text, u);
      if (Ucategory(u) & (_C_CTRL | _C_BLANK))
	{
	  lm_map_sequence(uni, l, NULL);
	  l = 0;
	}
      else if (l < MAX_WORD_LEN)
	uni[l++] = u;
      else
	return 0;
    }
  lm_map_sequence(uni, l, NULL);
  return 1;
}

#else

static void
lm_map_text(byte *text, byte *stop)
{
  word uni[MAX_WORD_LEN+1];
  byte *wstart = NULL;	/* If !LM_TRACK_TEXT, gcc optimizes wstart out as it's never read */
  uns u, l;

  l = 0;
  wstart = text;
  while (text < stop)
    {
      GET_TAGGED_CHAR(text, u);
    restart:
      if (u < 0x80000000)
	{
	  if (Ucategory(u) & (_C_CTRL | _C_BLANK))
	    {
	      lm_map_sequence(uni, l, wstart);
	      l = 0;
	      wstart = text;
	    }
	  else if (l < MAX_WORD_LEN)
	    uni[l++] = u;
	  else
	    {
	      lm_map_word(NULL, 0, WC_GARBAGE, NULL, 0);
	      l = 0;
	      while (text < stop &&
		     ((u < 0x80000000 && !(Ucategory(u) & (_C_CTRL | _C_BLANK))) ||
		      (u >= 0x80010000)))
		{
		  wstart = text;
		  GET_TAGGED_CHAR(text, u);
		}
	      if (text < stop)
		goto restart;
	    }
	}
      else if (u < 0x80010000)		/* Word type tag, breaks words */
	{
	  lm_map_sequence(uni, l, wstart);
	  l = 0;
	  wstart = text;
	  lm_current_cat = u & 0x0f;
	  if (u & 0x10)
	    lm_map_word(NULL, 0, WC_BREAK, NULL, 0);
	}
      /* else it's a bracket which we ignore */
    }
  lm_map_sequence(uni, l, wstart);
}

#endif

#undef LM_TPAR
