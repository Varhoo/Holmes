#!/bin/sh
# Sherlock Indexer Script
# (c) 2001--2002 Martin Mares <mj@ucw.cz>

unset DELETING VERBOSE G LISTS
set -e
while getopts "dlvC:S:" OPT ; do
	case "$OPT" in
		d)	DELETING=1
			G="$G -SIndexer.SortDeleteSrc=1"
			;;
		l)	LISTS=1 ;;
		v)	VERBOSE=1
			G="$G -SIndexer.Progress=100"
			;;
		[CS])	G="$G -$OPT$OPTARG" ;;
		*)	cat >&2 <<EOF
Usage: indexer [-dvl]

-d	Delete temporary files as soon as possible
-l	List index files between passes
-v	Be verbose (also enables progress indicators)
-C, -S	Global configuration options passed to all programs
EOF
			exit 1
			;;
	esac
done

function log
{
	bin/logger indexer I "$1"
}

function delete
{
	[ -z "$DELETING" ] || ( cd $CF_Directory && rm -f $@ )
}

function stats
{
	log "Disk usage $1: `du -s $CF_Directory | cut -f 1` blocks"
	[ -z "$LISTS" ] || ( ls -Al $CF_Directory | bin/logger indexer D )
}

function sizes
{
	bin/sizer $CF_Directory/{card-attrs,cards,lexicon,references,string-map}
	total_index=`du -bs $CF_Directory | cut -f 1`
	echo "total index size is $total_index" | bin/logger sizer I
}

eval `bin/config Indexer Directory=not/configured '*'`

log "Deleting old index"
mkdir -p $CF_Directory
rm -f $CF_Directory/*

log "Building index"
bin/scanner $G
bin/fpsort $G
bin/mkgraph $G
if [ -f bin/sitefinder ] ; then
	bin/sitefinder $G
fi
bin/backlinker $G
if [ -f bin/oook ] ; then
	if [ -f db/catalog.gz ] ; then
		zcat db/catalog.gz | bin/oook $G
	else
		bin/oook $G </dev/null
	fi
fi
if [ -f bin/weights ] ; then
	bin/weights $G
fi
bin/mergesums $G
bin/mergesigns $G
bin/merger $G
bin/reftexts $G
bin/labelsort $G
stats "after first phase"
delete fingerprints labels-by-id links-by-url merges url-list url-list-translated checksums ref-texts link-graph signatures
[ -z "$DELETING" ] || stats "after cleanup"
bin/mklex $G
bin/chewer $G
stats "after chewing"
delete labels merged-attrs
bin/ssort $G
delete string-index
bin/wsort $G
delete word-index tmp-lexicon tmp-lexicon-freq
stats "after second phase"
sizes
log "Index built successfully."
