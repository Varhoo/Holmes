/*
 *	Sherlock Indexer
 *
 *	(c) 2001--2002 Martin Mares <mj@ucw.cz>
 *	(c) 2002 Robert Spalek <robert@ucw.cz>
 */

#include "lib/index.h"

/* iconfig.c */

/* File names */
extern byte *fn_fingerprints, *fn_labels_by_id, *fn_attributes, *fn_checksums;
extern byte *fn_links, *fn_urls, *fn_link_graph, *fn_sites, *fn_labels, *fn_merges, *fn_signatures, *fn_matches;
extern byte *fn_lex_temp, *fn_word_index, *fn_string_index, *fn_lexicon, *fn_references, *fn_string_map;
extern byte *fn_string_hash, *fn_cards, *fn_card_attrs, *fn_lexicon_by_cnt;
extern byte *fn_parameters, *fn_ref_texts, *fn_directory;

/* Miscellaneous */
extern byte *label_attrs, *link_attrs, *ref_link_types;
extern uns string_avg_bucket, indexer_fb_size, progress, sort_delete_src, max_degree;
extern uns ref_max_length, ref_min_length, ref_max_count, ref_hash_size;
extern uns matcher_signatures, matcher_context, matcher_min_words, matcher_threshold, matcher_passes, matcher_block;
extern uns max_num_objects;

/* Filters */
extern byte *indexer_filter_name;

/* ifilter.c */

void ifilter_init(int mode);
int ifilter_filter(struct odes *obj, struct card_attr *attr);

/* fetch.c */

void fetch_cards(void (*card_start)(uns id, struct card_attr *attr),
		 void (*got_line)(byte *line),
		 void (*card_end)(struct card_attr *attr, struct odes *obj));

/* fprecog.c */

void fp_recog_init(void);
void fp_recog_end(void);
uns fp_recog(struct fingerprint *fp);

/* Structure of files */

struct csum {
  byte md5[16];
  u32 cardid;
};

struct fprint {
  struct fingerprint fp;
  u32 cardid;
};

/* Graph edge types */

#define ETYPE_NORMAL 0
#define ETYPE_REDIRECT 0x40000000
#define ETYPE_FRAME 0x80000000
#define ETYPE_IMAGE 0xc0000000
#define ETYPE_MASK 0xc0000000
